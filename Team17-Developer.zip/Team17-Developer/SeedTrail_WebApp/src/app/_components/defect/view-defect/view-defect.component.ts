import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Defect } from 'src/app/shared/_interfaces/defect';
import { DefectService } from 'src/app/shared/_services/defect-service.service';

@Component({
  selector: 'app-view-defect',
  templateUrl: './view-defect.component.html',
  styleUrls: ['./view-defect.component.css']
})
export class ViewDefectComponent implements OnInit {

  constructor(private service: DefectService, private router: Router) { }

  @Input() defect!: Defect
  @Output() viewDefectEvent: EventEmitter<Defect> = new EventEmitter<Defect>();

  ngOnInit(): void {
    this.service.getDefectById(this.defect.defectId).subscribe(res => {
      this.defect = res;
      // convert defect.base64 to an image source
      this.defect.image = "data:image/png;base64," + this.defect.image;
      this.viewDefectEvent.emit(this.defect)
      this.router.navigate(["/defect"])
    });
  }
}
