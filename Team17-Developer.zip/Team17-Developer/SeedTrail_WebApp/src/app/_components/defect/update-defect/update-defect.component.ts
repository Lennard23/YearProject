import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Defect } from 'src/app/shared/_interfaces/defect';
import { DefectService } from 'src/app/shared/_services/defect-service.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-update-defect',
  templateUrl: './update-defect.component.html',
  styleUrls: ['./update-defect.component.css']
})
export class UpdateDefectComponent implements OnInit {

  formgrp!: UntypedFormGroup;
  itemId: number = 0;
  MAX_WIDTH = 600;
  MAX_HEIGHT = 600;
  MB = 1048576;

  constructor(
    private toastService: ToastService,
    private service: DefectService,
    private router: Router) { }

  @Input() defect!: Defect;
  @Output() updateDefectEvent: EventEmitter<Defect> = new EventEmitter<Defect>();

  defectImage: string = "";
  sizeTooBig: boolean = false;
  file!: File;

  ngOnInit(): void {
    this.service.getDefectById(this.defect.defectId).subscribe(res => {
      this.defect = res;
      this.defectImage = this.base64toJpegSrc(this.defect.image);
      this.createForm();
    });
  }

  createForm() {
    this.formgrp = new UntypedFormGroup({
      defect1: new UntypedFormControl(this.defect.defect1, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]),
      description: new UntypedFormControl(this.defect.description, [Validators.maxLength(50)]),
    });
  }


  base64toJpegSrc(base64: string) {
    return `data:image/jpeg;base64,${base64}`;
  }

  imageSelected(event: any) {
    // max size validation
    if (event.target.files[0].size > this.MB) {
      this.sizeTooBig = true;
      this.toastService.show('! Image size too big', { classname: 'bg-secondary', delay: 4000 });
      return;
    }
    else {
      this.sizeTooBig = false;
      //set form to touched and dirty
      this.formgrp.markAllAsTouched();
      this.formgrp.markAsDirty();
      const file = event.target.files[0];
      this.file = file;
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.defectImage = reader.result as string;
      };
    }
  }

  //handles form submission
  onSubmit() {
    if (this.sizeTooBig) {
      this.toastService.show('! Image size too big', { classname: 'bg-secondary', delay: 4000 });
      return;
    }
    if (this.formgrp.valid) {
      // convert file to base64 string
      const reader = new FileReader();
      reader.readAsDataURL(this.file);
      reader.onload = () => {
        this.defect.image = reader.result as string;
        let newItem: Defect = {
          defectId: this.defect.defectId,
          defect1: this.formgrp.value.defect1 ?? this.defect.defect1,
          image: this.defect.image,
          description: this.formgrp.value.description ?? this.defect.description,
          status: this.defect.status,
          labResultDefects: this.defect.labResultDefects
        };
        this.updateDefect(newItem)
      }
    }
  }

  //updates existing Defect
  updateDefect(defect: Defect) {
    //use service's update function
    return this.service.updateDefect(defect.defectId, defect).subscribe(res => {
      
      this.updateDefectEvent.emit(defect)
      this.router.navigate(["/defect"])
      window.location.reload();
      this.toastService.show('Defect updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    })
  }

  //clear
  clear() {
    this.formgrp.reset();
  }
}
