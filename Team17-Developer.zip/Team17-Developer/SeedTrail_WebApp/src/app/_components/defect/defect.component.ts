import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Defect } from 'src/app/shared/_interfaces/defect';
import { DefectService } from 'src/app/shared/_services/defect-service.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-defect',
  templateUrl: './defect.component.html',
  styleUrls: ['./defect.component.css']
})
export class DefectComponent implements OnInit {

  // Defect
  defectList: Defect[] = [];
  defect!: Defect;

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  defectForUpdate: boolean = false;
  defectForDelete: boolean = false;
  defectForView: boolean = false;
  message: string = "";
  desc: string = "";

  constructor(private service: DefectService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getDefects().subscribe(defects => {
        // if there's a search term, filter the defects
        if (this.searchTerm != null && this.searchTerm != "") {
          this.defectList = defects.filter(item => item.defect1?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.defectId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.description?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all defects
          this.defectList = defects;
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/defect', { searchTerm: this.searchTerm }]);
  }

  //gets single defect
  async getDefect(id: number) {
    return this.service.getDefectById(id).subscribe((data: Defect) => {
      //return a defect object
      return data;
    })
  }

  // view a defect
  viewDefect(defect: Defect) {
    if (!this.defectForView) {
      this.defectForView = true;
      this.defectForUpdate = false;
      this.defectForDelete = false;
      this.message = "ID#" + defect.defectId.toString()
      this.desc = "'" + (defect.defect1 ?? "") + "'";
      this.defect = defect;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + defect.defectId.toString()
      this.desc = "'" + (defect.defect1 ?? "") + "'";
      this.defect = defect;
    }
  }
  // update a defect
  updateDefect(defect: Defect) {
    if (!this.defectForUpdate) {
      this.defectForUpdate = true;
      this.defectForDelete = false;
      this.defectForView = false;
      this.message = "ID#" + defect.defectId.toString()
      this.desc = "Update defect '" + (defect.defect1 ?? "") + "'";
      this.defect = defect;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "";
      this.desc = "";
      this.defectForUpdate = false;
      this.defect = defect;
    }
  }
  // delete a defect
  deleteDefect(defect: Defect) {
    if (!this.defectForDelete) {
      this.defectForDelete = true;
      this.defectForUpdate = false;
      this.defectForView = false;
      this.message = "ID#" + defect.defectId.toString()
      this.desc = "Are you sure you want to delete defect '" + (defect.defect1 ?? "") + "'?";
      this.defect = defect;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "";
      this.desc = "";
      this.defectForDelete = false;
      this.defect = defect;
    }
  }

    // back
    back() {
      this.defectForUpdate = false;
      this.defectForDelete = false;
      this.defectForView = false;
      this.message = "";
      this.desc = "";
    }

    //history back
    historyBack() {
      this.message = "";
      this.desc = "";
      window.history.back();
    }
}
