import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { DefectService } from 'src/app/shared/_services/defect-service.service';
import { Defect } from 'src/app/shared/_interfaces/defect';

@Component({
  selector: 'app-delete-defect',
  templateUrl: './delete-defect.component.html',
  styleUrls: ['./delete-defect.component.css']
})
export class DeleteDefectComponent {

  constructor(private service: DefectService, private router: Router) { }

  @Input() defect!: Defect;
  @Output() deleteDefectEvent: EventEmitter<Defect> = new EventEmitter<Defect>();

  //handles form submission
  onSubmit() {
    let newItem: Defect = {
      defectId: this.defect.defectId,
      defect1: this.defect.defect1,
      image: "",
      description: this.defect.description,
      status: false,
      labResultDefects: this.defect.labResultDefects
    };
    this.deleteDefect(newItem)
  }

  //disables existing defect
  deleteDefect(defect: Defect) {
    return this.service.disableDefect(defect.defectId, defect).subscribe(res => {
      alert("Defect '" + defect.defect1 + "' successfully deleted!");
      this.deleteDefectEvent.emit(defect);
      this.router.navigate(['/defect']);
    })
  }
}
