import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { DefectService } from 'src/app/shared/_services/defect-service.service';
import { Router } from '@angular/router';
import { Defect } from 'src/app/shared/_interfaces/defect';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-defect',
  templateUrl: './create-defect.component.html',
  styleUrls: ['./create-defect.component.css']
})
export class CreateDefectComponent implements OnInit {

  form!: UntypedFormGroup;

  constructor(private toastService: ToastService, private service: DefectService, private router: Router) { }

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      defect1: new UntypedFormControl(null, [Validators.required, Validators.minLength(1), Validators.maxLength(15)]),
      description: new UntypedFormControl(null, [Validators.maxLength(50)])
    });
  }

  //handles form submission
  onSubmit() {
    let defect: Defect = {
      defectId: 0,
      defect1: this.form.value.defect1 ?? "No Name",
      description: this.form.value.description ?? null,
      status: true,
      image: "",
      labResultDefects: null
    }
    if (this.form.valid) {
      this.addDefect(defect);
      this.form.reset()
    }
  }

  //adds new Defect
  addDefect(defect: Defect) {
    return this.service.createDefect(defect).subscribe(() => {
      this.router.navigate(["/defect"])
      this.toastService.show('Defect added', { classname: 'bg-success text-light', delay: 4000 });
    })
  }

  //cancel
  cancel() {
    this.form.reset();
    this.router.navigate(["/defect"])
  }
          // Back in history
          historyBack() {
            this.form.reset();
            window.history.back();
          }
}
