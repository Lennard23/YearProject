import { HttpClient, HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TestResultStatus } from 'src/app/shared/_interfaces/test-result-status';
import { TestResultService } from 'src/app/shared/_services/test-result.service';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-test-result-status-report',
  templateUrl: './test-result-status-report.component.html',
  styleUrls: ['./test-result-status-report.component.css']
})


export class TestResultStatusReportComponent implements OnInit {

   // TestResultStatus
   testResultStatusList: TestResultStatus[] = [];
   testResultStatus!: TestResultStatus;

   // Search filtering
   searchTerm: string = "";

   //loading
   loading: boolean = true;

   // CRUD functionality
   testResultStatusForUpdate: boolean = false;
   testResultStatusForDelete: boolean = false;
   testResultStatusForView: boolean = false;

  //  @ViewChild('invoice') invoiceElement!: ElementRef;




   constructor(private service: TestResultService, private router: Router, private route: ActivatedRoute) { }

   ngOnInit(): void {


     // subscribe to router param changes
     this.loading = true;
     this.route.params.subscribe(params => {
       this.searchTerm = params['searchTerm']; // this is empty an string if param not found
       this.service.getTestResultStatus().subscribe(testResultStatuss => {
         // if there's a search term, filter the testResultStatuss
         if (this.searchTerm != null && this.searchTerm != "") {
           this.testResultStatusList = testResultStatuss.filter(item => item.trstatus?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
             item.testResultStatusId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
             item.description?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
         }
         else {
           // if there's no search term, return all testResultStatuss
           this.testResultStatusList = testResultStatuss;
         }
       });
       this.loading = false;
     });
   }



   // function to update the route with the search term
   search(): void {
     this.router.navigate(['/test-result-status', { searchTerm: this.searchTerm }]);
   }

   //gets single testResultStatus
   async getTestResultStatus(id: number) {
     return this.service.getTestResultStatusById(id).subscribe((data: TestResultStatus) => {
       //return a testResultStatus object
       return data;
     })
   }

   // view a testResultStatus
   viewTestResultStatus(testResultStatus: TestResultStatus) {
     if (!this.testResultStatusForView) {
       this.testResultStatusForView = true;
       this.testResultStatusForDelete = false;
       this.testResultStatus = testResultStatus;
       window.scroll({
         top: 0,
         left: 0,
         behavior: 'smooth'
       });
     }
     else {
       this.testResultStatus = testResultStatus;
     }
   }

   // delete a testResultStatus
   deleteTestResultStatus(testResultStatus: TestResultStatus) {
     if (!this.testResultStatusForDelete) {
       this.testResultStatusForDelete = true;
       this.testResultStatusForView = false;
       this.testResultStatus = testResultStatus;
       window.scroll({
         top: 0,
         left: 0,
         behavior: 'smooth'
       });
     }
     else {
       this.testResultStatusForDelete = false;
       this.testResultStatus = testResultStatus;
     }
   }

   // Back in history
   historyBack() {
     window.history.back();
   }

   // back
   back() {
     this.testResultStatusForDelete = false;
     this.testResultStatusForView = false;
     this.router.navigate(['/test-result-status']);
   }


  //  public generatePDF(): void {

  // //   html2canvas(this.invoiceElement.nativeElement, { scale: 3 }).then((canvas) => {
  // //     const imageGeneratedFromTemplate = canvas.toDataURL('image/png');
  // //     const fileWidth = 200;
  // //     const generatedImageHeight = (canvas.height * fileWidth) / canvas.width;
  // //     let PDF = new jsPDF('p', 'mm', 'a4',);
  // //     PDF.addImage(imageGeneratedFromTemplate, 'PNG', 0, 5, fileWidth, generatedImageHeight,);
  // //     PDF.html(this.invoiceElement.nativeElement.innerHTML)
  // //     PDF.save('testResultStatus.pdf');
  // //   });
  // }



}

function ViewChild(arg0: string) {
  throw new Error('Function not implemented.');
}

