import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';

@Component({
  selector: 'app-greenhouse-report',
  templateUrl: './greenhouse-report.component.html',
  styleUrls: ['./greenhouse-report.component.css']
})
export class GreenhouseReportComponent implements OnInit {

  // vars for pagination
  numPages: number;
  scenario: number;
  imgsPerPage: number;
  leftOver: number;

  greenhouseList!: Greenhouse[];
  greenhouse!: Greenhouse;
  pageSubsets!: [Greenhouse[]];

  constructor(private service: GreenhouseService) {
    this.numPages = 0;
    this.scenario = 0;
    this.leftOver = 0;
    this.imgsPerPage = 9;
  }

  @Output() viewGreenhouseEvent: EventEmitter<Greenhouse> = new EventEmitter<Greenhouse>();

  // var for NgSwitch
  display: number = 0; // 1 = activities, 2 = inventory, 3 = produce,
                       // 4 = status,     5 = info,      0 = empty div
  ngOnInit(): void {
    this.service.getGreenhouses().subscribe(data => {
      this.greenhouseList = data;
      // list length is between 1 and imgsPerPage
      if (this.greenhouseList.length > 0 && this.greenhouseList.length < this.imgsPerPage) {
        this.numPages = 1;
        this.scenario = 1;
      }
      // list length is a multiple of imgsPerPage
      else if (this.greenhouseList.length >= this.imgsPerPage && this.greenhouseList.length % this.imgsPerPage == 0) {
        this.numPages = this.greenhouseList.length / this.imgsPerPage;
        this.scenario = 2;
        // subset the list into pages
        for (let i = 0; i < this.numPages; i++) {
          this.pageSubsets[i] = this.greenhouseList.slice(i , this.imgsPerPage - 1);
        }
      }
      // imgsPerPage is not a factor of greenhouseList.length, but greenhouseList.length is greater than imgsPerPage
      else if (this.greenhouseList.length >= this.imgsPerPage && this.greenhouseList.length % this.imgsPerPage != 0) {
        this.numPages = Math.floor(this.greenhouseList.length / this.imgsPerPage) + 1;
        this.scenario = 3;
        // subset the list into pages
        for (let i = 0; i < this.numPages; i++) {
          this.pageSubsets[i] = this.greenhouseList.slice(i , this.imgsPerPage - 1);
          // if the last page is not a multiple of 9, then add the leftOver to the last page
          if (i == this.numPages - 1) {
            this.pageSubsets[i] = this.greenhouseList.slice(this.greenhouseList.length - this.leftOver, this.greenhouseList.length);
          }
        }
      }
    });
  }

  viewActivities(greenhouse: Greenhouse) {
    this.greenhouse = greenhouse;
    // if (this.display == 1) {
    //   this.display = 0;
    // }
    // else {
       this.display = 1;
    // }
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  viewInventory(greenhouse: Greenhouse) {
    this.greenhouse = greenhouse;
    // if (this.display == 2) {
    //   this.display = 0;
    // }
    // else {
      this.display = 2;
    // }
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  
  viewProduce(greenhouse: Greenhouse) {
    this.greenhouse = greenhouse;
    // if (this.display == 3) {
    //   this.display = 0;
    // }
    // else {
      this.display = 3;
    // }
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  viewStatus(greenhouse: Greenhouse) {
    this.greenhouse = greenhouse;
    // if (this.display == 4) {
    //   this.display = 0;
    // }
    // else {
      this.display = 4;
    // }
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  viewInfo(greenhouse: Greenhouse) {
    this.greenhouse = greenhouse;
    // if (this.display == 5) {
    //   this.display = 0;
    // }
    // else {
      this.display = 5;
    // }
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }
  
  // logic for back buttons
  back(){
    this.display = 0;
  }
  historyBack(){
    window.history.back();
  }
}