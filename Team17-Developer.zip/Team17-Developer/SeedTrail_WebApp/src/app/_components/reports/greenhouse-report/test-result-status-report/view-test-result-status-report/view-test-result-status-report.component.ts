import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-test-result-status-report',
  templateUrl: './view-test-result-status-report.component.html',
  styleUrls: ['./view-test-result-status-report.component.css']
})
export class ViewTestResultStatusReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
