import { Component, Input, OnInit } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseReportService } from 'src/app/shared/_services/greenhouse-report.service';

@Component({
  selector: 'app-gh-produce-report',
  templateUrl: './gh-produce-report.component.html',
  styleUrls: ['./gh-produce-report.component.css']
})
export class GhProduceReportComponent implements OnInit {

  @Input() greenhouse!: Greenhouse;

  constructor(private service: GreenhouseReportService) { }

  ngOnInit(): void {
  }

}
