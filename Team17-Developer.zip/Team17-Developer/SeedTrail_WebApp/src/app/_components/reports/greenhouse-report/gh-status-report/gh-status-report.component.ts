import { Component, Input, OnInit } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseReportService } from 'src/app/shared/_services/greenhouse-report.service';

@Component({
  selector: 'app-gh-status-report',
  templateUrl: './gh-status-report.component.html',
  styleUrls: ['./gh-status-report.component.css']
})
export class GhStatusReportComponent implements OnInit {

  @Input() greenhouse!: Greenhouse;
  
  constructor(private service: GreenhouseReportService) { }

  ngOnInit(): void {
  }

}
