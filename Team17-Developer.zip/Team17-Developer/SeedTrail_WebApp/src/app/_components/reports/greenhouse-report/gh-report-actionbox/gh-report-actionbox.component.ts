import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';

@Component({
  selector: 'app-gh-report-actionbox',
  templateUrl: './gh-report-actionbox.component.html',
  styleUrls: ['./gh-report-actionbox.component.css']
})
export class GhReportActionboxComponent {

  // input gh
  @Input() greenhouse!: Greenhouse;

  // click events
  @Output() statusEvent = new EventEmitter<Greenhouse>();
  @Output() produceEvent = new EventEmitter<Greenhouse>();
  @Output() inventoryEvent = new EventEmitter<Greenhouse>();
  @Output() activitiesEvent = new EventEmitter<Greenhouse>();

  constructor() { }

  // status click-event handler
  status(gh: Greenhouse) {
    this.statusEvent.emit(gh);
  }

  // produce click-event handler
  produce(gh: Greenhouse) {
    this.produceEvent.emit(gh);
  }

  // inventory click-event handler
  inventory(gh: Greenhouse) {
    this.inventoryEvent.emit(gh);
  }

  // activities click-event handler
  activities(gh: Greenhouse) {
    this.activitiesEvent.emit(gh);
  }
}
