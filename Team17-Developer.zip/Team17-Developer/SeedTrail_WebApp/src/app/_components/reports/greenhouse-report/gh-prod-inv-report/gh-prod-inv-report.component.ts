import { Component, Input, OnInit } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseReportService } from 'src/app/shared/_services/greenhouse-report.service';

@Component({
  selector: 'app-gh-prod-inv-report',
  templateUrl: './gh-prod-inv-report.component.html',
  styleUrls: ['./gh-prod-inv-report.component.css']
})
export class GhProdInvReportComponent implements OnInit {

  @Input() greenhouse!: Greenhouse;

  constructor(private service: GreenhouseReportService) { }

  ngOnInit(): void {
  }

}
