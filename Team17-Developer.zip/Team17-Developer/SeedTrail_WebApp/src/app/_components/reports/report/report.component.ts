import {
  AfterViewChecked,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { HttpClient } from '@angular/common/http';
import { Subscription, take } from 'rxjs';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Chart } from 'chart.js';
import { CommodityService } from 'src/app/shared/_services/commodity.service';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css'],
})
export class ReportComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('report') reportElement!: ElementRef;

  invForm: FormGroup;
  cultivarForm: FormGroup;
  commodityForm: FormGroup;

  invTypeData!: any[];
  commodityList!: any[];
  cultivarList: any[] = [];
  sizeLabels: any[] = [];

  invData: any[] = [];
  orderData: any[] = [];
  commodityData: any[] = [];
  // 0: not set
  // 1: data preset
  // 2: no data
  chartData: number = 0;

  chart: any;
  cultivarTotal: any;

  dateString: string;

  private subscriptions: Subscription[] = [];

  constructor(
    private prodInvService: ProductionInventoryService,
    private fb: FormBuilder,
    private commodityService: CommodityService,
    private cultivarService: CultivarService,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {
    this.invForm = this.fb.group({
      types: new FormArray([]),
    });

    this.cultivarForm = this.fb.group({
      from: new FormControl(
        new Date().toISOString().split('T')[0],
        Validators.required
      ),
      to: new FormControl(
        new Date().toISOString().split('T')[0],
        Validators.required
      ),
      commodityId: new FormControl(1, Validators.required),
    });

    this.commodityForm = this.fb.group({
      from: new FormControl(
        new Date().toISOString().split('T')[0],
        Validators.required
      ),
      to: new FormControl(
        new Date().toISOString().split('T')[0],
        Validators.required
      ),
      commodityId: new FormControl(0, Validators.required),
      cultivarId: new FormControl(null, Validators.required),
    });

    this.subscriptions.push(
      this.commodityForm.valueChanges.subscribe((x) => this.updateCultivars())
    );

    const date = new Date();

    this.dateString =
      date.getDate() + '/' + date.getMonth() + '/' + date.getFullYear();
  }

  ngOnInit(): void {
    this.prodInvService
      .GetTypes()
      .pipe(take(1))
      .subscribe({
        next: (res) => {
          this.invTypeData = res;
        },
      });

    this.commodityService
      .getAllCommodities()
      .pipe(take(1))
      .subscribe({
        next: (res) => {
          this.commodityList = res;
          this.cultivarForm.get('commodityId')?.patchValue(res[0].commodityId);
          this.commodityForm.get('commodityId')?.patchValue(res[0].commodityId);
        },
      });

    let dateStart = document.getElementById('datetimepickerstart');
    let dateEnd = document.getElementById('datetimepickerend');

    dateStart?.setAttribute('max', this.cultivarForm.get('to')?.value);
    dateEnd?.setAttribute('min', this.cultivarForm.get('from')?.value);
  }

  ngAfterViewChecked(): void {
    this.changeDetectorRef.detectChanges();
  }

  onCheckboxChange(event: any) {
    const selectedTypes = this.invForm.controls['types'] as FormArray;
    if (event.target.checked) {
      selectedTypes.push(new FormControl(event.target.value));
    } else {
      const index = selectedTypes.controls.findIndex(
        (x) => x.value === event.target.value
      );
      selectedTypes.removeAt(index);
    }
  }

  createOrderReport() {
    this.reset();

    this.prodInvService
      .getAllProductionInventories()
      .pipe(take(1))
      .subscribe({
        next: (res: any[]) => {
          this.orderData = [];
          res.forEach((item) => {
            const i = this.invData.findIndex(
              (x) => x.key == item.productInventoryType.productInventoryTypeId
            );
            if (i !== -1) {
              this.orderData[i].push({
                supName: item.supplier.name,
                supContact: item.supplier.contactNr,
                amount: item.productionInvOrderDetails.quantity,
                // metric: item.metric,
                status: item.productionInvOrderDetails.status,
              });
            } else {
              this.orderData.push({
                key: item.productInventoryType.productInventoryTypeId,
                typeName: item.productInventoryType.name,
                value: [
                  {
                    supName: item.supplier.name,
                    supContact: item.supplier.contactNr,
                    amount: item.productionInvOrderDetails.quantity,
                    // metric: item.metric,
                    status: item.productionInvOrderDetails.status,
                  },
                ],
              });
            }
          });
        },
      });
  }

  createInvReport() {
    this.reset();
    this.prodInvService
      .getAllProductionInventories()
      .pipe(take(1))
      .subscribe({
        next: (res: any[]) => {
          this.invData = [];

          res.forEach((item) => {
            const x = this.invForm.value.types.findIndex(
              (x: any) =>
                +x === item.productInventoryType.productInventoryTypeId
            );
            if (x !== -1) {
              const i = this.invData.findIndex(
                (x) => x.key == item.productInventoryType.productInventoryTypeId
              );
              if (i !== -1) {
                this.invData[i].value.push(item);
              } else {
                this.invData.push({
                  key: item.productInventoryType.productInventoryTypeId,
                  typeName: item.productInventoryType.name,
                  value: [item],
                });
              }
            }
          });
        },
      });
  }

  createCultivarReport() {
    this.reset();

    this.chartData = 1;

    this.cultivarService
      .getCultivarByCommodityId(
        this.cultivarForm.get('commodityId')?.value,
        new Date(this.cultivarForm.get('from')?.value),
        new Date(this.cultivarForm.get('to')?.value)
      )
      .pipe(take(1))
      .subscribe((res: any) => {
        if (res.length <= 0) {
          this.chartData = 2;
          return;
        }

        const map: number[] = [];
        let data: any = {
          labels: [],
          datasets: [
            {
              label:
                'Yield from ' +
                new Date(this.cultivarForm.get('from')?.value)
                  .toISOString()
                  .split('T')[0] +
                ' to ' +
                new Date(this.cultivarForm.get('to')?.value)
                  .toISOString()
                  .split('T')[0],
              backgroundColor: '#50a55c',
              data: [],
            },
          ],
        };

        res.forEach((x: any) => {
          const i = map.findIndex(
            (item) => item === x.batch.cultivar.cultivarId
          );

          if (i < 0) {
            map.push(x.batch.cultivar.cultivarId);

            data.labels.push(x.batch.cultivar.name);

            data.datasets[0].data.push(x.yield);
          } else {
            data.datasets[0].data[i] += x.yield;
          }
        });

        this.chart = new Chart('MyChart', {
          type: 'bar',

          data: data,
          options: {
            aspectRatio: 2.5,
          },
        });
      });
  }

  updateCultivars() {
    this.cultivarList = [];
    this.cultivarService
      .getCultivarByCommodityId(
        this.commodityForm.get('commodityId')?.value,
        new Date(this.commodityForm.get('from')?.value),
        new Date(this.commodityForm.get('to')?.value)
      )
      .pipe(take(1))
      .subscribe((res: any) => {
        res.forEach((element: any) => {
          const index = this.cultivarList.findIndex(
            (x) => x.id === element.batch.cultivar.cultivarId
          );
          if (index < 0) {
            this.cultivarList.push({
              id: element.batch.cultivar.cultivarId,
              name: element.batch.cultivar.name,
            });
          }
        });
        if (res.length > 0) {
          this.commodityForm
            .get('cultivarId')
            ?.patchValue(1, { onlySelf: true, emitEvent: false });
        }
      });
  }

  createCommodityReport() {
    this.reset();

    this.cultivarService
      .getCultivarByCommodityId(
        this.commodityForm.get('commodityId')?.value,
        new Date(this.commodityForm.get('from')?.value),
        new Date(this.commodityForm.get('to')?.value),
        this.commodityForm.get('cultivarId')?.value
      )
      .pipe(take(1))
      .subscribe((res: any) => {
        const dateMap: any[] = [];

        res.forEach((element: any) => {
          const index = dateMap.findIndex(
            (x) =>
              x.plantDate === element.batch.plantDate &&
              x.harvestDate === element.batch.harvestDate
          );

          if (index < 0) {
            dateMap.push({
              plantDate: element.batch.plantDate,
              harvestDate: element.batch.harvestDate,
            });

            this.commodityData.push({
              commodity: element.batch.cultivar.name,
              plantDate: element.batch.plantDate,
              harvestDate: element.batch.harvestDate,
              weights: [
                { name: element.commditySize.size, yield: element.yield },
              ],
              total: element.yield,
            });
          } else {
            this.commodityData[index].weights.push({
              name: element.commditySize.size,
              yield: element.yield,
            });
            this.commodityData[index].total += element.yield;
          }

          if (
            this.sizeLabels.findIndex((x) => x === element.commditySize.size) <=
            0
          ) {
            this.sizeLabels.push(element.commditySize.size);
          }
          this.cultivarTotal += element.yield;
        });

        this.sizeLabels.sort((a: any, b: any) => this.sort(a, b));

        this.commodityData.forEach((x) => {
          x.weights.sort((a: any, b: any) => this.sort(a.name, b.name));

          let weights = [...x.weights];

          x.weights = [];

          for (let i = 0; i < this.sizeLabels.length; i++) {
            let index = weights.findIndex(
              (weigth) => weigth.name === this.sizeLabels[i]
            );

            if (index < 0) {
              x.weights.push(undefined);
            } else {
              x.weights.push(weights[index]);
            }
          }
        });
      });
  }

  sort(a: any, b: any) {
    if (a < b) return -1;
    if (a > b) return 1;
    return 0;
  }

  changeDate(e: any) {
    let dateStart = document.getElementById('datetimepickerstart');
    let dateEnd = document.getElementById('datetimepickerend');

    dateStart?.setAttribute('max', this.cultivarForm.get('to')?.value);
    dateEnd?.setAttribute('min', this.cultivarForm.get('from')?.value);
  }

  downloadReport() {
    html2canvas(this.reportElement.nativeElement, { scale: 3 }).then(
      (canvas) => {
        const imageGeneratedFromTemplate = canvas.toDataURL('image/png');

        const fileWidth = 210;
        const fileHeight = 297;
        const generatedImageHeight = (canvas.height * fileWidth) / canvas.width;
        let PDF = new jsPDF('p', 'mm', 'a4');

        let heightLeft = generatedImageHeight;
        heightLeft -= fileHeight;
        let position = 0;

        PDF.addImage(
          imageGeneratedFromTemplate,
          'PNG',
          0,
          position,
          fileWidth,
          generatedImageHeight
        );

        while (heightLeft >= 0) {
          position = heightLeft - generatedImageHeight;
          PDF.addPage();
          PDF.addImage(
            imageGeneratedFromTemplate,
            'PNG',
            0,
            position,
            fileWidth,
            generatedImageHeight,
            '',
            'FAST'
          );
          heightLeft -= fileHeight;
        }

        PDF.html(this.reportElement.nativeElement.innerHTML);
        PDF.save('report-' + this.dateString.replace('/', '-') + '.pdf');
      }
    );
  }

  reset() {
    this.invData = [];
    this.orderData = [];
    this.commodityData = [];
    this.sizeLabels = [];
    this.chartData = 0;
    this.cultivarTotal = 0;

    this.chart?.destroy();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }
}
