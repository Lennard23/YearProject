import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchReport } from 'src/app/shared/_interfaces/batch-report';
import { BatchReportService } from 'src/app/shared/_services/batch-report.service';

@Component({
  selector: 'app-view-batch-report',
  templateUrl: './view-batch-report.component.html',
  styleUrls: ['./view-batch-report.component.css']
})
export class ViewBatchReportComponent implements OnInit {

  report!: BatchReport;

  constructor(private service: BatchReportService, private router: Router) { }

  @Input() batch!: Batch
  @Output() viewReportEvent: EventEmitter<Batch> = new EventEmitter<Batch>();
  @Output() downloadReportEvent: EventEmitter<Batch> = new EventEmitter<Batch>();

  ngOnInit(): void {
    this.viewReport(this.batch)
  }

  //updates existing batch
  viewReport(batch: Batch) {
    //use service's update function
    return this.service.getBatchReport(batch.batchId).subscribe(res => {
      this.report = res;
      this.viewReportEvent.emit(batch)
      this.router.navigate(["/batch-report"])
    })
  }

  downloadReport(batch: Batch) {
    //use service's update function
    return this.service.getBatchReport(batch.batchId).subscribe(res => {
      this.report = res;
      this.downloadReportEvent.emit(batch)
    })
  }
}
