import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { take } from 'rxjs';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchReport } from 'src/app/shared/_interfaces/batch-report';
import { BatchReportService } from 'src/app/shared/_services/batch-report.service';
import { BatchService } from 'src/app/shared/_services/batch.service';

@Component({
  selector: 'app-batch-report',
  templateUrl: './batch-report.component.html',
  styleUrls: ['./batch-report.component.css'],
})
export class BatchReportComponent implements OnInit {
  // Batch
  batchList: Batch[] = [];
  batches: Batch[] = [];
  batchId = '';
  batch!: Batch;
  batchReport!: BatchReport;
  fullReport!: BatchReport[];
  template!: string;
  fromDate = new Date();
  toDate = new Date();
  period: string = '';
  fromDateString: string = '';
  toDateString: string = '';

  // Search filtering
  searchTerm: string = '';

  //loading
  loading: boolean = true;
  reportForView: boolean = false;

  constructor(
    private service: BatchService,
    private service2: BatchReportService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    // subscribe to router param changes
    this.loading = true;
    this.route.params.subscribe((params) => {
      this.service.getBatches().subscribe((batches) => {
        this.batchList = this.batches = batches;
      });
      this.loading = false;
    });
  }

  // function to update the route with the search term
  search(): void {
    this.batchList = this.batches.filter(
      (item) =>
        item
          .cultivarName!.toString()
          .includes(this.searchTerm.trim().toLowerCase()) ||
        item
          .clientName!.toString()
          .includes(this.searchTerm.trim().toLowerCase())
    );
  }

  //gets single batch
  async getBatch(id: number) {
    return this.service.getBatchById(id).subscribe((data: Batch) => {
      //return a batch object
      return data;
    });
  }

  // view a batch report
  viewBatchReport(batch: Batch) {
    if (!this.reportForView) {
      this.reportForView = true;
      this.batch = batch;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth',
      });
    } else {
      this.batch = batch;
    }
  }

  updateDate() {
    if (this.fromDate > this.toDate) {
      this.toDate = this.fromDate;
      alert("'From' date cannot be greater than 'To' date");
    }
  }

  downloadFullReport() {
    console.log('download full report');
    if (this.fromDate == undefined) {
      alert('Please select a start date');
    }
    if (this.fromDate > this.toDate) {
      alert("'From' date cannot be greater than 'To' date");
    } else {
      this.loading = true;
      this.buildFullReport();
    }
  }
  buildFullReport() {
    var from = new Date(this.fromDate);
    var to = new Date(this.toDate);
    var stringFrom = from.toString().substring(0, 10);
    var stringTo = to.toString().substring(0, 10);
    console.log('start build full report for ' + stringFrom + ' - ' + stringTo);
    this.service2.getAllReports(stringFrom, stringTo).subscribe((data) => {
      this.fullReport = data;
      console.log(this.fullReport);
      this.loading = false;
    });
  }

  downloadBatchReport(batch: Batch) {
    this.batch = batch;
    console.log('download batch report');
    console.log(batch);
    this.buildBatchReport(batch);
  }
  buildBatchReport(batch: Batch) {
    var batch = batch;
    console.log(batch.batchId);
    const localDate = new Date().toLocaleDateString().substring(0, 10);
    const generatedBy = 'SeedTrail'; // need to replace with active user
    this.service2
      .getBatchReport(batch.batchId)
      .subscribe((data: BatchReport) => {
        this.batchReport = data;
        console.log(this.batchReport);
        this.service2
          .getBatchTemplate()
          .pipe(take(1))
          .subscribe((html: string) => {
            const iframe = document.createElement('iframe');
            iframe.className = 'invisible';
            document.body.appendChild(iframe);

            // write the template to the iframe
            iframe.contentWindow?.document.open();
            iframe.contentWindow?.document.write(html);
            iframe.contentWindow?.document.close();

            // replace the placeholders with the data:
            // date
            const dateEl =
              iframe.contentWindow?.document.getElementById('date');
            if (dateEl !== undefined && dateEl !== null) {
              dateEl.innerHTML = localDate;
            }

            // heading
            const headingEl =
              iframe.contentWindow?.document.getElementById('heading');
            if (headingEl !== undefined && headingEl !== null) {
              headingEl.innerHTML =
                "Report for Batch'" + batch.batchId.toString() + "'";
            }

            // footer-content
            const footerContentEl =
              iframe.contentWindow?.document.getElementById('footer-content');
            if (footerContentEl !== undefined && footerContentEl !== null) {
              footerContentEl.innerHTML = '<p>Generated by {0} on {1}</p>'
                .replace('{0}', generatedBy)
                .replace('{1}', localDate);
            }

            // content
            const batchIdEl =
              iframe.contentWindow?.document.getElementById('batchId');
            if (batchIdEl !== undefined && batchIdEl !== null) {
              batchIdEl.innerHTML = batch.batchId.toString();
            }
            const orderIdEl =
              iframe.contentWindow?.document.getElementById('orderId');
            if (orderIdEl !== undefined && orderIdEl !== null) {
              orderIdEl.innerHTML = batch.clientOrderId.toString();
            }
            const regNoEl =
              iframe.contentWindow?.document.getElementById('regNo');
            if (regNoEl !== undefined && regNoEl !== null) {
              if (
                batch.registrationNr !== undefined &&
                batch.registrationNr !== null
              ) {
                regNoEl.innerHTML = batch.registrationNr!.toString();
              } else {
                regNoEl.innerHTML = '-';
              }
            }
            const clientEl =
              iframe.contentWindow?.document.getElementById('client');
            if (clientEl !== undefined && clientEl !== null) {
              if (
                this.batchReport.client.name !== undefined &&
                this.batchReport.client.name !== null
              ) {
                clientEl.innerHTML = this.batchReport.client.name.toString();
              } else {
                clientEl.innerHTML = '-';
              }
            }
            const cultivarEl =
              iframe.contentWindow?.document.getElementById('cultivar');
            if (cultivarEl !== undefined && cultivarEl !== null) {
              if (
                this.batchReport.cultivar.name !== undefined &&
                this.batchReport.cultivar.name !== null
              ) {
                cultivarEl.innerHTML =
                  this.batchReport.cultivar.name.toString();
              } else {
                cultivarEl.innerHTML = this.batch.cultivarId.toString();
              }
            }
            const plantDateEl =
              iframe.contentWindow?.document.getElementById('plantDate');
            if (plantDateEl !== undefined && plantDateEl !== null) {
              if (
                this.batchReport.plantDate !== undefined &&
                this.batchReport.plantDate !== null
              ) {
                plantDateEl.innerHTML = this.batchReport.plantDate
                  .toString()
                  .substring(0, 10);
              } else {
                plantDateEl.innerHTML = '-';
              }
            }
            const harvestDateEl =
              iframe.contentWindow?.document.getElementById('harvestDate');
            if (harvestDateEl !== undefined && harvestDateEl !== null) {
              if (
                this.batchReport.harvestDate !== undefined &&
                this.batchReport.harvestDate !== null
              ) {
                harvestDateEl.innerHTML = this.batchReport.harvestDate
                  .toString()
                  .substring(0, 10);
              } else {
                harvestDateEl.innerHTML = 'TBC';
              }
            }
            const coldroomInDateEl =
              iframe.contentWindow?.document.getElementById('coldroomInDate');
            if (coldroomInDateEl !== undefined && coldroomInDateEl !== null) {
              if (
                this.batchReport.coldroomDateIn !== undefined &&
                this.batchReport.coldroomDateIn !== null
              ) {
                coldroomInDateEl.innerHTML = this.batchReport.coldroomDateIn
                  .toString()
                  .substring(0, 10);
              } else {
                coldroomInDateEl.innerHTML = 'TBC';
              }
            }
            const coldroomOutDateEl =
              iframe.contentWindow?.document.getElementById('coldroomOutDate');
            if (coldroomOutDateEl !== undefined && coldroomOutDateEl !== null) {
              if (
                this.batchReport.coldroomDateOut !== undefined &&
                this.batchReport.coldroomDateOut !== null
              ) {
                coldroomOutDateEl.innerHTML = this.batchReport.coldroomDateOut
                  .toString()
                  .substring(0, 10);
              } else {
                coldroomOutDateEl.innerHTML = 'TBC';
              }
            }
            const totalPlantedEl =
              iframe.contentWindow?.document.getElementById('totalPlanted');
            if (totalPlantedEl !== undefined && totalPlantedEl !== null) {
              if (
                this.batchReport.totalPlanted !== undefined &&
                this.batchReport.totalPlanted !== null
              ) {
                totalPlantedEl.innerHTML =
                  this.batchReport.totalPlanted.toString();
              } else {
                totalPlantedEl.innerHTML = '0';
              }
            }
            const totalBagsEl =
              iframe.contentWindow?.document.getElementById('totalBags');
            if (totalBagsEl !== undefined && totalBagsEl !== null) {
              if (
                this.batchReport.totalBags !== undefined &&
                this.batchReport.totalBags !== null
              ) {
                totalBagsEl.innerHTML = this.batchReport.totalBags.toString();
              } else {
                totalBagsEl.innerHTML = '0';
              }
            }
            const totalYieldEl =
              iframe.contentWindow?.document.getElementById('totalYield');
            if (totalYieldEl !== undefined && totalYieldEl !== null) {
              if (
                this.batchReport.totalYield !== undefined &&
                this.batchReport.totalYield !== null
              ) {
                totalYieldEl.innerHTML = this.batchReport.totalYield.toString();
              } else {
                totalYieldEl.innerHTML = '0';
              }
            }
            const avgYieldEl =
              iframe.contentWindow?.document.getElementById('avgYield');
            if (avgYieldEl !== undefined && avgYieldEl !== null) {
              if (
                this.batchReport.avgYield !== undefined &&
                this.batchReport.avgYield !== null
              ) {
                avgYieldEl.innerHTML = this.batchReport.avgYield.toString();
              } else {
                avgYieldEl.innerHTML = '0.0';
              }
            }
            const scrap =
              iframe.contentWindow?.document.getElementById('scrap');
            if (scrap !== undefined && scrap !== null) {
              if (
                this.batchReport.scrap !== undefined &&
                this.batchReport.scrap !== null
              ) {
                scrap.innerHTML = this.batchReport.scrap.toString();
              } else {
                scrap.innerHTML = '0';
              }
            }

            if (iframe.contentWindow?.document.body !== undefined) {
              html2canvas(iframe.contentWindow?.document.body, {
                scale: 3,
              }).then((canvas) => {
                const imageGeneratedFromTemplate =
                  canvas.toDataURL('image/png');

                const fileWidth = 210;
                const fileHeight = 297;
                const generatedImageHeight =
                  (canvas.height * fileWidth) / canvas.width;
                let PDF = new jsPDF('p', 'mm', 'a4');

                let heightLeft = generatedImageHeight;
                heightLeft -= fileHeight;
                let position = 0;

                PDF.addImage(
                  imageGeneratedFromTemplate,
                  'PNG',
                  0,
                  position,
                  fileWidth,
                  generatedImageHeight
                );

                while (heightLeft >= 0) {
                  position = heightLeft - generatedImageHeight;
                  PDF.addPage();
                  PDF.addImage(
                    imageGeneratedFromTemplate,
                    'PNG',
                    0,
                    position,
                    fileWidth,
                    generatedImageHeight,
                    '',
                    'FAST'
                  );
                  heightLeft -= fileHeight;
                }

                if (
                  iframe.contentWindow?.document?.body.innerHTML !== undefined
                )
                  PDF.html(iframe.contentWindow?.document?.body.innerHTML);
                PDF.save('batch-report.pdf');
              });
            }
          });
      });
  }

  //back
  back() {
    this.reportForView = false;
  }

  //historyback()
  historyBack() {
    window.history.back();
  }
}
