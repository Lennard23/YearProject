import { Component, OnInit } from '@angular/core';
import {
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeService } from 'src/app/shared/_services/employee.service';
import { AccessLevelArea } from 'src/app/shared/_interfaces/access-level-area';
import { AccessLevelAreaService } from 'src/app/shared/_services/access-level-area.service';
import { EmployeeType } from 'src/app/shared/_interfaces/employee-type';
import { EmployeeTypeService } from 'src/app/shared/_services/employee-type.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css'],
})
export class CreateEmployeeComponent implements OnInit {
  minDate: string;
  form!: UntypedFormGroup;
  accessLevelAreas!: AccessLevelArea[];
  employeeTypes!: EmployeeType[];
  empType!: EmployeeType;
  accessLevelArea!: AccessLevelArea;

  constructor(
    private service: EmployeeService,
    private ALAService: AccessLevelAreaService,
    private ETService: EmployeeTypeService,
    private router: Router
  ) {
    this.minDate = new Date().toISOString().substring(0, 10);
  }

  ngOnInit(): void {
    this.ALAService.getAccessLevelAreas().subscribe((data) => {
      this.accessLevelAreas = data;
    });

    this.ETService.getEmployeeTypes().subscribe((data) => {
      this.employeeTypes = data;
    });
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl('', [
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(30),
      ]),
      surname: new UntypedFormControl('', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(30),
      ]),
      contactNr: new UntypedFormControl('', [
        Validators.required,
        Validators.minLength(9),
        Validators.maxLength(13),
        Validators.pattern(/^\d{9,13}$/),
      ]),
      nationalId: new UntypedFormControl('', [Validators.required]),
      email: new UntypedFormControl('', [
        Validators.pattern(/^[^\s@]+@[^\s@]+\.[^\s@]+$/),
      ]),
      accessLevelAreaId: new UntypedFormControl('--- Select ---', [
        Validators.required,
      ]),
      empTypeId: new UntypedFormControl('--- Select ---', [
        Validators.required,
      ]),
      startDate: new UntypedFormControl(null),
    });
  }

  //handles form submission
  onSubmit() {
    if (
      this.form.value.accessLevelAreaId == '--- Select ---' ||
      this.form.value.accessLevelAreaId == null
    ) {
      alert('Please select an access level area');
      return;
    }
    if (
      this.form.value.empTypeId == '--- Select ---' ||
      this.form.value.empTypeId == null
    ) {
      alert('Please select an employee type');
      return;
    }
    if (this.form.value.email == '') {
      var email = null;
    } else {
      email = this.form.value.email;
    }
    if (this.form.value.startDate != null) {
      this.form.value.startDate = this.form.value.startDate
        .toString()
        .substring(0, 10);
    }
    if (this.form.valid) {
      // find empType
      this.empType = this.employeeTypes.find(
        (x) => x.empTypeId == this.form.value.empTypeId
      )!;
      // find accessLevelArea
      this.accessLevelArea = this.accessLevelAreas.find(
        (x) => x.accessLevelAreaId == this.form.value.accessLevelAreaId
      )!;
      // build employee object
      let employee: Employee = {
        empId: 0,
        accessLevelAreaId: this.accessLevelArea.accessLevelAreaId,
        empTypeId: this.empType.empTypeId,
        name: this.form.value.name,
        surname: this.form.value.surname,
        contactNr: this.form.value.contactNr,
        nationalId: this.form.value.nationalId,
        email: email,
        startDate: this.form.value.startDate,
        endDate: null,
        status: true,
        accessLevelArea: this.accessLevelArea,
        empType: this.empType,
        employeeActivities: null,
        employeeLogins: null,
        // type: this.e,
        // description: undefined,
        // employeeId: undefined,
        // activityEntries: undefined
      };
      // add employee
      this.addEmployee(employee);
    }
  }

  //adds new employee
  addEmployee(employee: Employee) {
    return this.service.createEmployee(employee).subscribe(() => {
      this.router.navigate(['/employee']);
      alert('Employee added successfully!');
    });
  }
    // Back in history
    historyBack() {
      this.form.reset();
      window.history.back();
    }
}
