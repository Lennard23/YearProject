import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { take } from 'rxjs';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeService } from 'src/app/shared/_services/employee.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css'],
})
export class DeleteEmployeeComponent {
  constructor(private service: EmployeeService, private router: Router) {}

  @Input() employee!: Employee;
  @Output() deleteEmployeeEvent: EventEmitter<Employee> =
    new EventEmitter<Employee>();

  //disables existing employee
  delete() {
    return this.service
      .disableEmployee(this.employee.empId, this.employee)
      .pipe(take(1))
      .subscribe({
        next: (res) => {
          alert('Employee has been deleted');
          this.router.navigate(['/employee']);
          this.deleteEmployeeEvent.emit(this.employee);
        },
        error: (err) => {
          if (err.status === 400)
            alert('Cannot delete an employee while they are assigned');
          else alert('Something went wrong deleting employee');
        },
      });
  }
}
