import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeService } from 'src/app/shared/_services/employee.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  // Employee
  employeeList: Employee[] = [];
  employee!: Employee;

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  employeeForUpdate: boolean = false;
  employeeForDelete: boolean = false;
  employeeForView: boolean = false;
  message: string = "";
  desc: string = "";

  constructor(private service: EmployeeService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getEmployees().subscribe(employees => {
        // if there's a search term, filter the employees
        if (this.searchTerm != null && this.searchTerm != "") {
          this.employeeList = employees.filter(item => item.name!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.empId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.surname!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.nationalId!.toString().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all employees
          this.employeeList = employees;
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/employee', { searchTerm: this.searchTerm }]);
  }

  //gets single employee
  async getEmployee(id: number) {
    return this.service.getEmployeeById(id).subscribe((data: Employee) => {
      //return a employee object
      return data;
    })
  }

  // view a employee
  viewEmployee(employee: Employee) {
    if (!this.employeeForView) {
      this.employeeForView = true;
      this.employeeForUpdate = false;
      this.employeeForDelete = false;
      this.message = "ID#" + employee.empId.toString();
      this.desc = "'" + (employee.name + " " + employee.surname ?? "Employee") + "'";
      this.employee = employee;
      console.log(this.employee);
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.employee = employee;
    }
  }
  // update a employee
  updateEmployee(employee: Employee) {
    if (!this.employeeForUpdate) {
      this.employeeForUpdate = true;
      this.employeeForDelete = false;
      this.employeeForView = false;
      this.message = "ID#" + employee.empId.toString();
      this.desc = "Update employee '" + (employee.name + " " + employee.surname ?? "Employee") + "'";
      this.employee = employee;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.employeeForUpdate = false;
      this.employee = employee;
    }
  }
  // delete a employee
  deleteEmployee(employee: Employee) {
    if (!this.employeeForDelete) {
      this.employeeForDelete = true;
      this.employeeForUpdate = false;
      this.employeeForView = false;
      this.message = "ID#" + employee.empId.toString();
      this.desc = "Do you want to delete '" + (employee.name + " " + employee.surname ?? "Employee") + "'?";
      this.employee = employee;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.employeeForDelete = false;
      this.employee = employee;
    }
  }

  // back
  back() {
    this.employeeForDelete = false;
    this.employeeForUpdate = false;
    this.employeeForView = false;
    this.message = "";
    this.desc = "";
  }

  // history back
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
