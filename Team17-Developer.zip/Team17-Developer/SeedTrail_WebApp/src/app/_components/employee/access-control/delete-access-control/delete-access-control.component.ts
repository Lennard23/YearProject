import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccessLevel } from 'src/app/shared/_interfaces/access-level';
import { AccessLevelsService } from 'src/app/shared/_services/access-levels.service';

@Component({
  selector: 'app-delete-access-control',
  templateUrl: './delete-access-control.component.html',
  styleUrls: ['./delete-access-control.component.css']
})
export class DeleteAccessControlComponent implements OnInit {

  form!: UntypedFormGroup;
  itemId: number = 0;

  constructor(private service: AccessLevelsService, private router: Router) {}

  @Input() accessLevel: AccessLevel= {
    accessLevelId: 0,
    description: null,
    accessLevel1: null,
    status: false,
    accessLevelAreas: null

  };
  @Output() deleteCultivarEvent: EventEmitter<AccessLevel> = new EventEmitter<AccessLevel>();

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      description: new UntypedFormControl(this.accessLevel.description, [Validators.required, Validators.minLength(2)]),
      accessLevel1: new UntypedFormControl(this.accessLevel.description),
    });
  }

  //handles form submission
  onSubmit() {
    let newItem: AccessLevel = {
      accessLevelId: this.accessLevel.accessLevelId,


      description: this.accessLevel.description,
      accessLevel1: this.accessLevel.accessLevel1,
      status: false,
      accessLevelAreas: this.accessLevel.accessLevelAreas
    };
    this.deleteCultivar(newItem)
  }

  //disables existing cultivar
  deleteCultivar(accessLevel: AccessLevel) {
    return this.service.disableAccessLevel(accessLevel.accessLevelId, accessLevel).subscribe(res => {
      this.router.navigate(['/access-level']);
      this.deleteCultivarEvent.emit(accessLevel)
    })
  }

}
