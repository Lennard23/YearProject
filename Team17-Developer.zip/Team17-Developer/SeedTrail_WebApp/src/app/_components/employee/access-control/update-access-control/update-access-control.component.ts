import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccessLevel } from 'src/app/shared/_interfaces/access-level';
import { AccessLevelsService } from 'src/app/shared/_services/access-levels.service';

@Component({
  selector: 'app-update-access-control',
  templateUrl: './update-access-control.component.html',
  styleUrls: ['./update-access-control.component.css']
})
export class UpdateAccessControlComponent implements OnInit {

  form!: UntypedFormGroup;
  itemId: number = 0;

  constructor(private service: AccessLevelsService, private router: Router) {
    this.createForm();
  }

  @Input() accessLevel: AccessLevel= {
    accessLevelId: 49,
    description: null,
    accessLevel1: null,
    status: false,
    accessLevelAreas: null
  };
  @Output() updateCultivarEvent: EventEmitter<AccessLevel> = new EventEmitter<AccessLevel>();

  ngOnInit(): void {
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      description: new UntypedFormControl(this.accessLevel.description, [Validators.required, Validators.minLength(2)]),
      accessLevel1: new UntypedFormControl(this.accessLevel.accessLevel1),
    });
  }

  //handles form submission
  onSubmit() {
    let newItem: AccessLevel = {
      accessLevelId: this.accessLevel.accessLevelId,
      description: this.form.get('description')?.value,
      accessLevel1: this.form.get('accessLevel')?.value,
      status: this.accessLevel.status,

      accessLevelAreas: this.accessLevel.accessLevelAreas
    };
    this.updateCultivar(newItem)
  }

  //updates existing accessLevel
  updateCultivar(accessLevel: AccessLevel) {
    //use service's update function
    return this.service.updateAccessLevel(accessLevel.accessLevelId, accessLevel).subscribe(res => {
      this.updateCultivarEvent.emit(accessLevel)
      this.router.navigate(["/access-level"])
    })
  }

}
