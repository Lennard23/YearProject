import { Component, OnInit } from '@angular/core';
import { AccessLevel } from 'src/app/shared/_interfaces/access-level';
import { ActivatedRoute, Router } from '@angular/router';
import { AccessLevelsService } from 'src/app/shared/_services/access-levels.service';


@Component({
  selector: 'app-access-control',
  templateUrl: './access-control.component.html',
  styleUrls: ['./access-control.component.css']
})
export class AccessControlComponent implements OnInit {

  accessLevels: AccessLevel[] = []

  constructor(private service: AccessLevelsService, private router: Router, private route: ActivatedRoute) { }


  ngOnInit(): void {
    this.service.getAccessLevels().subscribe(response => {

      var AccessLevelList = response as any []

      for (var i = 0; i< AccessLevelList.length; i++){

        if (AccessLevelList[i].Status = true){
          var AccessLevels: AccessLevel = {
            accessLevelId: AccessLevelList[i].AccessLevelId,
            accessLevel1: AccessLevelList[i].AccessLevel1,
            description: AccessLevelList[i].Description,
            status: AccessLevelList[i].Status,
            accessLevelAreas: AccessLevelList[i].AccessLevelAreas
          }
          this.accessLevels.push(AccessLevels)
        }
        else {
          console.log("No Access Level")
        }
      }
      console.log(this.accessLevels)
    })
  }
  onSave(){

    this.accessLevels[0].accessLevelId = 0
    this.accessLevels[0].accessLevel1 = "Manager"
    this.accessLevels[0].description = "This Access Level describes the access level of the Greenhouse manager. It is the highest Access Level"
    this.accessLevels[0].status = true

    console.log(this.accessLevels)


    this.accessLevels[2].accessLevelId = 1
    this.accessLevels[2].accessLevel1 = "Supervisors"
    this.accessLevels[2].description = "This Access Level describes the access level of the Supervisors. It is the middle Access Level"
    this.accessLevels[2].status = true

    console.log(this.accessLevels)

    this.accessLevels[3].accessLevelId = 2
    this.accessLevels[3].accessLevel1 = "Owner"
    this.accessLevels[3].description = "This Access Level describes the access level of the Owner. It is the lowest Access Level"
    this.accessLevels[3].status = true




    this.service.addAccessLevel(this.accessLevels)

    // .subscribe(res =>
    //   {
    //   if (res == null || res == 200)
    //   {
    //    // sessionStorage.removeItem('Basket');
    //     //this.successToast();
    //     //this.DisplayCheckout = false;
    //     //this.ionViewWillEnter();

    //     console.log("Success")
    //   }

   // })


  }
    // // Cultivar
    // accessLevelList: AccessLevel[] = [];
    // accessLevel!: AccessLevel;

    // // Search filtering
    // searchTerm: string = "";

    // //loading
    // loading: boolean = true;

    // // CRUD functionality
    // accessLevelLevelForUpdate: boolean = false;
    // accessLevelForDelete: boolean = false;
    // accessLevelForView: boolean = false;



    // ngOnInit(): void {
    //   // subscribe to router param changes
    //   this.loading = true;
    //   this.route.params.subscribe(params => {
    //     this.searchTerm = params['searchTerm']; // this is empty an string if param not found
    //     this.service.getAccessLevels().subscribe(accessLevel => {
    //       // if there's a search term, filter the cultivars
    //       if (this.searchTerm != null && this.searchTerm != "") {
    //         this.accessLevelList = accessLevel.filter(item => item.description?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
    //           item.accessLevelId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
    //           item.accessLevel1?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
    //       }
    //       else {
    //         // if there's no search term, return all cultivars
    //         this.accessLevelList = accessLevel;
    //       }
    //     });
    //     this.loading = false;
    //   });
    // }

    // // function to update the route with the search term
    // search(): void {
    //   this.router.navigate(['/access-level', { searchTerm: this.searchTerm }]);
    // }

    // //gets single AccessLevel
    // async getCultivar(id: number) {
    //   return this.service.getAccessLevelById(id).subscribe((data: AccessLevel) => {
    //     //return a AccessLevel object
    //     return data;
    //   })
    // }

    // // view a cultivar
    // viewCultivar(accessLevel: AccessLevel) {
    //   if (!this.accessLevelForView) {
    //     this.accessLevelForView = true;
    //     this.accessLevelForUpdate = false;
    //     this.accessLevelForDelete = false;
    //     this.accessLevel = accessLevel;
    //     window.scroll({
    //       top: 0,
    //       left: 0,
    //       behavior: 'smooth'
    //     });
    //   }
    //   else {
    //     this.accessLevel = accessLevel;
    //   }
    // }
    // // update a cultivar
    // updateCultivar(accessLevel: AccessLevel) {
    //   if (!this.accessLevelForUpdate) {
    //     this.accessLevelForUpdate = true;
    //     this.accessLevelForDelete = false;
    //     this.accessLevelForView = false;
    //     this.accessLevel = accessLevel;
    //     window.scroll({
    //       top: 0,
    //       left: 0,
    //       behavior: 'smooth'
    //     });
    //   }
    //   else {
    //     this.accessLevelForUpdate = false;
    //     this.accessLevel = accessLevel;
    //   }
    // }
    // // delete a cultivar
    // deleteCultivar(accessLevel: AccessLevel) {
    //   if (!this.accessLevelForDelete) {
    //     this.accessLevelForDelete = true;
    //     this.accessLevelForUpdate = false;
    //     this.accessLevelForView = false;
    //     this.accessLevel = accessLevel;
    //     window.scroll({
    //       top: 0,
    //       left: 0,
    //       behavior: 'smooth'
    //     });
    //   }
    //   else {
    //     this.accessLevelForDelete = false;
    //     this.accessLevel = accessLevel;
    //   }
    // }

    // // Back in history
    // historyBack() {
    //   window.history.back();
    // }

    // // back
    // back() {
    //   this.accessLevelForUpdate = false;
    //   this.accessLevelForDelete = false;
    //   this.accessLevelForView = false;
    //   this.router.navigate(['/access-level']);
    // }

}