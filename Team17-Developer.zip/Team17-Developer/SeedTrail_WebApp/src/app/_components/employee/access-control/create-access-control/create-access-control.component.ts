import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccessLevel } from 'src/app/shared/_interfaces/access-level';
import { AccessLevelsService } from 'src/app/shared/_services/access-levels.service';

@Component({
  selector: 'app-create-access-control',
  templateUrl: './create-access-control.component.html',
  styleUrls: ['./create-access-control.component.css']
})
export class CreateAccessControlComponent implements OnInit {

  form!: UntypedFormGroup;
  nextId: number = 0;
  accessLevels!: AccessLevel[]

  constructor(private service: AccessLevelsService, private router: Router) {}

  ngOnInit(): void {
    this.service.getAccessLevels().subscribe(data => {
      this.accessLevels = data;
    });
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      description: new UntypedFormControl("", [Validators.required, Validators.minLength(2)]),
      accessLevel1: new UntypedFormControl([Validators.required]),
    });
  }

  //handles form submission
  onSubmit() {
    this.service.getAccessLevels().subscribe(data => {
      this.nextId = data.length + 1;
      let accessLevel: AccessLevel = {
        accessLevelId: this.nextId,
        description: this.form.get('description')?.value ?? this.nextId.toString(),

        accessLevel1: this.form.get('accessLevel1')?.value ?? null,

        status: true,
        accessLevelAreas: null
      };
      this.addAccessLevel(accessLevel)
    })
  }

  //adds new AccessLevel
  addAccessLevel(accessLevel: AccessLevel) {
    return this.service.createAccessLevel(accessLevel).subscribe(() => {
      this.router.navigate(["/access-level"]);
    })
  }
}
