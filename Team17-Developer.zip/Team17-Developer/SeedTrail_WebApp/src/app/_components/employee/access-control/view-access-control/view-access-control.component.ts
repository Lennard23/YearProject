import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccessLevel } from 'src/app/shared/_interfaces/access-level';
import { AccessLevelsService } from 'src/app/shared/_services/access-levels.service';

@Component({
  selector: 'app-view-access-control',
  templateUrl: './view-access-control.component.html',
  styleUrls: ['./view-access-control.component.css']
})
export class ViewAccessControlComponent implements OnInit {

  constructor(private service: AccessLevelsService, private router: Router) {

  }

  @Input() accessLevel!: AccessLevel
  @Output() viewCultivarEvent: EventEmitter<AccessLevel> = new EventEmitter<AccessLevel>();

  ngOnInit(): void {
    this.viewCultivar(this.accessLevel)
  }

  //updates existing cultivar
  viewCultivar(accessLevel: AccessLevel) {
    //use service's update function
    return this.service.getAccessLevelById(accessLevel.accessLevelId).subscribe(res => {
      this.accessLevel! = res;
      this.viewCultivarEvent.emit(accessLevel!)
      this.router.navigate(["/access-level!"])
    })
  }

}
