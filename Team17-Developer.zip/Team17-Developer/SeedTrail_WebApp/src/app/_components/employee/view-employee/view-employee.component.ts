import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeService } from 'src/app/shared/_services/employee.service';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.css']
})
export class ViewEmployeeComponent implements OnInit {

  employmentPeriod: string | null = null;

  constructor(private service: EmployeeService, private router: Router) { }

  @Input() employee!: Employee
  @Output() viewEmployeeEvent: EventEmitter<Employee> = new EventEmitter<Employee>();

  ngOnInit(): void {
    if (this.employee.startDate != null && this.employee.endDate != null) 
    { this.employmentPeriod = this.employee.startDate.substring(0, 10) + " - " + this.employee.endDate.substring(0, 10);
    }
    else if (this.employee.startDate != null && this.employee.endDate == null) 
    { this.employmentPeriod = this.employee.startDate.substring(0, 10) + " - Present";
    }
    else if (this.employee.startDate == null && this.employee.endDate != null) 
    { this.employmentPeriod = "Unspecified - " + this.employee.endDate.substring(0, 10);
    }
    else { this.employmentPeriod = "No dates specified"; }
    this.viewEmployee(this.employee)
  }

  //updates existing employee
  viewEmployee(employee: Employee) {
    //use service's update function
    return this.service.getEmployeeById(employee.empId).subscribe(res => {
      this.employee = res;
      this.viewEmployeeEvent.emit(employee)
      this.router.navigate(["/employee"])
    })
  }
}