import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AccessLevelArea } from 'src/app/shared/_interfaces/access-level-area';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeType } from 'src/app/shared/_interfaces/employee-type';
import { AccessLevelAreaService } from 'src/app/shared/_services/access-level-area.service';
import { EmployeeTypeService } from 'src/app/shared/_services/employee-type.service';
import { EmployeeService } from 'src/app/shared/_services/employee.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  form!: UntypedFormGroup;
  accessLevelAreas!: AccessLevelArea[];
  accessLevelArea!: AccessLevelArea;
  employeeTypes!: EmployeeType[];
  empType!: EmployeeType;

  constructor(private service: EmployeeService,
    private ALAService: AccessLevelAreaService,
    private ETService: EmployeeTypeService, private router: Router) { }

  @Input() employee!: Employee
  @Output() updateEmployeeEvent: EventEmitter<Employee> = new EventEmitter<Employee>();

  ngOnInit(): void {
    this.ALAService.getAccessLevelAreas().subscribe(res => {
      this.accessLevelAreas = res;
    });
    this.ETService.getEmployeeTypes().subscribe(res => {
      this.employeeTypes = res;
    });
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.employee.name, [Validators.required, Validators.minLength(1), Validators.maxLength(30)]),
      surname: new UntypedFormControl(this.employee.surname, [Validators.required, Validators.minLength(3), Validators.maxLength(30)]),
      contactNr: new UntypedFormControl(this.employee.contactNr, [Validators.required, Validators.minLength(9), Validators.maxLength(13), Validators.pattern(/^\d{9,13}$/)]),
      nationalId: new UntypedFormControl(this.employee.nationalId, [Validators.required]),
      email: new UntypedFormControl(this.employee.email ?? "", [Validators.pattern(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)]),
      accessLevelAreaId: new UntypedFormControl(this.employee.accessLevelAreaId ?? "--- Select ---", [Validators.required]),
      empTypeId: new UntypedFormControl(this.employee.empTypeId ?? "--- Select ---", [Validators.required]),
      startDate: new UntypedFormControl(this.employee.startDate ?? null),
      endDate: new UntypedFormControl(this.employee.endDate ?? null)
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.accessLevelAreaId == "--- Select ---" || this.form.value.accessLevelAreaId == null) {
      alert("Please select an access level area");
      return;
    }
    if (this.form.value.empTypeId == "--- Select ---" || this.form.value.empTypeId == null) {
      alert("Please select an employee type");
      return;
    }
    if (this.form.value.email == "") {
      var email = null;
    }
    else {
      email = this.form.value.email;
    }
    if (this.form.value.startDate != null) {
      this.form.value.startDate = this.form.value.startDate.toString().substring(0, 10);
    }
    if (this.form.value.endDate != null) {
      this.form.value.endDate = this.form.value.endDate.toString().substring(0, 10);
    }
    if (this.form.valid) {
      // find empType
      this.empType = this.employeeTypes.find(x => x.empTypeId == this.form.value.empTypeId)!;
      // find accessLevelArea
      this.accessLevelArea = this.accessLevelAreas.find(x => x.accessLevelAreaId == this.form.value.accessLevelAreaId)!;
      // build employee object
      let newEmployee: Employee = {
        empId: this.employee.empId,
        accessLevelAreaId: this.accessLevelArea.accessLevelAreaId,
        empTypeId: this.empType.empTypeId,
        name: this.form.value.name || this.employee.name,
        surname: this.form.value.surname || this.employee.surname,
        contactNr: this.form.value.contactNr || this.employee.contactNr,
        nationalId: this.form.value.nationalId || this.employee.nationalId,
        email: email || null,
        startDate: this.form.value.startDate || this.employee.startDate,
        endDate: this.form.value.endDate || this.employee.endDate,
        status: this.employee.status,
        accessLevelArea: this.accessLevelArea,
        empType: this.empType,
        employeeActivities: this.employee.employeeActivities,
        employeeLogins: this.employee.employeeLogins,
        // type: this.employee.type,
        // description: this.employee.description,
        // employeeId: this.employee.employeeId,
        // activityEntries: this.employee.activityEntries
      }
      // add employee
      this.updateEmployee(newEmployee);
    }
  }

  //updates existing employee
  updateEmployee(employee: Employee) {
    //use service's update function
    return this.service.updateEmployee(employee.empId, employee).subscribe(res => {
      alert("Employee updated successfully!");
      this.updateEmployeeEvent.emit(employee)
      this.router.navigate(["/employee"])
    })
  }
}

