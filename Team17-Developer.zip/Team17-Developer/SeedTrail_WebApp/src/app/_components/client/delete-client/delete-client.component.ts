import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientService } from 'src/app/shared/_services/client.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-client',
  templateUrl: './delete-client.component.html',
  styleUrls: ['./delete-client.component.css']
})
export class DeleteClientComponent {

  constructor(private toastService: ToastService, private service: ClientService, private router: Router) { }

  @Input() client!: Client;
  @Output() deleteClientEvent: EventEmitter<Client | null> = new EventEmitter<Client | null>();

  //handles form submission
  onSubmit() {
    this.service.checkRefIntegrity(this.client.clientId).subscribe(res => {
      if (res == true) {
        this.toastService.show('Client has existing orders. Cannot delete.', { classname: 'bg-secondary', delay: 5000 });
        return;
      }
      else {
        this.service.disableClient(this.client.clientId, this.client).subscribe({
          next: () => {
            this.deleteClientEvent.emit(this.client)
          },
          error: err => {
            console.log(err);
            this.deleteClientEvent.emit(null);
          }
        });
      }
    });
  }
}
