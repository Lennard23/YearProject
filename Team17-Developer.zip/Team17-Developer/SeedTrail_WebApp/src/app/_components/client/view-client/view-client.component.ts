import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientService } from 'src/app/shared/_services/client.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-view-client',
  templateUrl: './view-client.component.html',
  styleUrls: ['./view-client.component.css']
})
export class ViewClientComponent implements OnChanges {

  constructor(private toastService: ToastService, private service: ClientService, private router: Router) { }

  @Input() client!: Client
  @Output() viewClientEvent: EventEmitter<Client | null> = new EventEmitter<Client | null>();

  ngOnChanges(): void {
    this.service.getClientById(this.client.clientId).subscribe({
      next: (data: Client) => {
        this.client = data;
        this.viewClientEvent.emit(this.client)
      },
      error: (err: any) => {
        console.log(err);
        this.viewClientEvent.emit(null)
      }
    })
  }

  viewClientOrders() {
    this.router.navigate(['/client-order', { searchTerm: this.client.name }]);
  }
}
