import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientService } from 'src/app/shared/_services/client.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  // Client
  clientList: Client[] = [];
  client!: Client;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  clientForUpdate: boolean = false;
  clientForDelete: boolean = false;
  clientForView: boolean = false;

  constructor(private toastService: ToastService, private service: ClientService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getClients().subscribe(clients => {
        // if there's a search term, filter the clients
        if (this.searchTerm != null && this.searchTerm != "") {
          this.clientList = clients.filter(item => item.name!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.clientId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.email!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all clients
          this.clientList = clients;
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/client', { searchTerm: this.searchTerm }]);
  }

  //gets single client
  async getClient(id: number) {
    return this.service.getClientById(id).subscribe((data: Client) => {
      //return a client object
      return data;
    })
  }

  // view a client
  viewClient(client: Client) {
    if (!this.clientForView) {
      this.clientForView = true;
      this.clientForUpdate = false;
      this.clientForDelete = false;
      this.message = "#" + client.clientId.toString()
      this.desc = "'" + client.name.toString() + "'";
      this.client = client;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + client.clientId.toString()
      this.desc = "'" + client.name.toString() + "'";
      this.client = client;
    }
  }
  viewClientReturn(client: Client | null) {
    if (client == null) {
      this.toastService.show("Failed retrieve client", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (client != null && this.clientForView){
      this.message = "#" + client.clientId.toString()
      this.desc = "'" + client.name.toString() + "'";
    }
  }
  // update a client
  updateClient(client: Client) {
    if (!this.clientForUpdate) {
      this.clientForUpdate = true;
      this.clientForDelete = false;
      this.clientForView = false;
      this.message = "#" + client.clientId.toString()
      this.desc = "Update client details for '" + client.name.toString() + "'";
      this.client = client;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.clientForUpdate = false;
      this.client = client;
    }
  }
  updateClientReturn(client: Client | null) {
    if (client != null) {
      this.router.navigate(["/client"]);
      this.toastService.show('Client updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.clientForUpdate = false;
      this.toastService.show('Failed to update client', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (client != null && this.clientForUpdate){
      this.client = client;
      this.clientForUpdate = false;
    }
  }
  // delete a client
  deleteClient(client: Client) {
    if (!this.clientForDelete) {
      this.clientForDelete = true;
      this.clientForUpdate = false;
      this.clientForView = false;
      this.message = "#" + client.clientId.toString()
      this.desc = "Do you want to delete client '" + client.name.toString() + "'?";
      this.client = client;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.clientForDelete = false;
      this.client = client;
    }
  }
  deleteClientReturn(client: Client | null) {
    if (client != null) {
      this.clientList = this.clientList.filter(item => item.clientId != client.clientId);
      this.router.navigate(["/client"]);
      this.toastService.show('Client deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.clientForDelete = false;
      this.toastService.show('Failed to delete client', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (client != null && this.clientForDelete){
      this.client = client;
      this.clientForDelete = false;
    }
  }
  // back
  back() {
    this.clientForUpdate = false;
    this.clientForDelete = false;
    this.clientForView = false;
    this.message = "";
    this.desc = "";
  }

  //history back
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
