import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { ClientOrderStatusService } from 'src/app/shared/_services/client-order-status.service';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-view-client-order',
  templateUrl: './view-client-order.component.html',
  styleUrls: ['./view-client-order.component.css']
})
export class ViewClientOrderComponent implements OnChanges {

  orderStatusName!: string;

  constructor(private toastService: ToastService, private service: ClientOrderService, private closService: ClientOrderStatusService, private router: Router) { }

  @Input() clientOrder!: ClientOrder
  @Output() viewClientOrderEvent: EventEmitter<ClientOrder | null> = new EventEmitter<ClientOrder | null>();

  ngOnChanges(): void {
    this.closService.getOrderStatusById(this.clientOrder.orderStatusId).subscribe(res => {
      this.orderStatusName = res.ostatus ?? "none";
    });
    this.service.getClientOrderById(this.clientOrder.clientOrderId).subscribe({
      next: (data: ClientOrder) => {
        this.clientOrder = data;
        this.clientOrder.dateRequired = this.clientOrder.dateRequired!.substring(0, 10);
        this.clientOrder.datePlaced = this.clientOrder.datePlaced!.substring(0, 10);
        this.viewClientOrderEvent.emit(data)
      },
      error: (err: any) => {
        console.log(err);
        this.viewClientOrderEvent.emit(null)
      }
    })
  }

  getBatches(): void {
    this.router.navigate(['/greenhouse-batch', { searchTerm: "COID#"+this.clientOrder.clientOrderId }]);
  }
}
