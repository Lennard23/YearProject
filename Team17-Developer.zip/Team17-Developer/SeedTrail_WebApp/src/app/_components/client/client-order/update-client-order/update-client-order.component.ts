import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { OrderStatus } from 'src/app/shared/_interfaces/order-status';
import { ClientOrderStatusService } from 'src/app/shared/_services/client-order-status.service';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-update-client-order',
  templateUrl: './update-client-order.component.html',
  styleUrls: ['./update-client-order.component.css']
})
export class UpdateClientOrderComponent implements OnInit {

  form!: UntypedFormGroup;
  clientList!: Client[];
  orderStatusList!: OrderStatus[];
  client!: string;
  orderstatus!: OrderStatus;
  today!: string;

  constructor(private toastService: ToastService, private service: ClientOrderService, private service3: ClientOrderStatusService, private router: Router) { }

  @Input() clientOrder!: ClientOrder;
  @Output() updateClientOrderEvent: EventEmitter<ClientOrder | null> = new EventEmitter<ClientOrder | null>();

  ngOnInit(): void {
    this.clientOrder.datePlaced = this.clientOrder.datePlaced!.slice(0, 10);
    this.clientOrder.dateRequired = this.clientOrder.dateRequired!.slice(0, 10);
    this.today = new Date().toISOString().slice(0, 10);
    this.service3.getOrderStatuses().subscribe((data: OrderStatus[]) => {
      this.orderStatusList = data;
      this.orderstatus = this.orderStatusList.find(x => x.orderStatusId == this.clientOrder.orderStatusId)!;
    });
    this.form = new UntypedFormGroup({
      orderStatusId: new UntypedFormControl(this.clientOrder.orderStatusId, [Validators.required]),
      description: new UntypedFormControl(this.clientOrder.description, [Validators.required, Validators.maxLength(255)]),
      dateRequired: new UntypedFormControl(this.clientOrder.dateRequired)
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.orderStatusId == "Current Status: "+ this.orderstatus.ostatus || this.form.value.orderStatusId == null) {
      this.toastService.show('Please select an order status!', { classname: 'bg-secondary', delay: 3000 });
      return;
    }
    if (this.form.value.dateRequired != null) {
      var dateReqString: string | null = this.form.value.dateRequired
    }
    else {
      var dateReqString: string | null = null;
    }
    if (this.form.valid) {
      //find order status
      let orderStatus = this.orderStatusList.find(x => x.orderStatusId == this.form.value.orderStatusId);
      if (orderStatus == null) {
        this.toastService.show('Please select a valid order status!', { classname: 'bg-danger text-light', delay: 5000 });
        return;
      }
      let clientOrder: ClientOrder = {
        clientOrderId: this.clientOrder.clientOrderId,
        clientId: this.clientOrder.clientId,
        clientName: this.clientOrder.clientName,
        orderStatusId: orderStatus.orderStatusId,
        description: this.form.value.description ?? this.clientOrder.description,
        datePlaced: this.clientOrder.datePlaced,
        dateRequired: dateReqString ?? this.clientOrder.dateRequired,
        status: this.clientOrder.status,
        batches: this.clientOrder.batches,
        client: this.clientOrder.client,
        orderStatus: orderStatus
      };
      this.service.updateClientOrder(clientOrder.clientOrderId, clientOrder).subscribe({
        next: () => {
          this.updateClientOrderEvent.emit(clientOrder);
        },
        error: (err) => {
          console.log(err);
          this.updateClientOrderEvent.emit(null);
        }
      });
    }
  }
}
