import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { ActivatedRoute } from '@angular/router';
import { ToastService } from 'src/app/shared/_services/toast.service';
@Component({
  selector: 'app-client-order',
  templateUrl: './client-order.component.html',
  styleUrls: ['./client-order.component.css']
})
export class ClientOrderComponent implements OnInit {

  // ClientOrder
  clientOrderList: ClientOrder[] = [];
  clientOrder!: ClientOrder;
  message: string = "";
  desc: string = "";
  clientName!: string;

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  clientOrderForUpdate: boolean = false;
  clientOrderForDelete: boolean = false;
  clientOrderForView: boolean = false;

  constructor(private toastService: ToastService, private service: ClientOrderService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getClientOrders().subscribe(clientOrders => {
        // if there's a search term, filter the clientOrders
        if (this.searchTerm != null && this.searchTerm != "") {
          if (this.searchTerm.includes("STAT#")) {
            var statId = this.searchTerm.replace("STAT#", "");
            this.clientOrderList = clientOrders.filter(clientOrder => clientOrder.orderStatusId == parseInt(statId));
          }
          else {
            this.clientOrderList = clientOrders.filter(item => item.clientOrderId!.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.datePlaced?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
              item.description.toString().toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
              item.clientName?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()))
              .map(item => {
                if (item.datePlaced != null) {
                  item.datePlaced = item.datePlaced.substring(0, 10);
                }
                if (item.dateRequired != null) {
                  item.dateRequired = item.dateRequired.substring(0, 10);
                }
                return item;
              });
          }
        }
        else {
          // if there's no search term, return all clientOrders
          this.clientOrderList = clientOrders.map(item => {
            if (item.datePlaced != null) {
              item.datePlaced = item.datePlaced.substring(0, 10);
            }
            if (item.dateRequired != null) {
              item.dateRequired = item.dateRequired.substring(0, 10);
            }
            return item;
          });
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/client-order', { searchTerm: this.searchTerm }]);
  }

  //gets single clientOrder
  async getClientOrder(id: number) {
    return this.service.getClientOrderById(id).subscribe((data: ClientOrder) => {
      //return a clientOrder object
      return data;
    })
  }

  // view a clientOrder
  viewClientOrder(clientOrder: ClientOrder) {
    if (!this.clientOrderForView) {
      this.clientOrderForView = true;
      this.clientOrderForUpdate = false;
      this.clientOrderForDelete = false;
      this.message = "#" + clientOrder.clientOrderId.toString()
      this.desc = "'" + clientOrder.description + "'";
      this.clientOrder = clientOrder;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "#" + clientOrder.clientOrderId.toString()
      this.desc = "'" + clientOrder.description + "'";
      this.clientOrder = clientOrder;
    }
  }
  viewClientOrderReturn(clientOrder: ClientOrder | null) {
    if (clientOrder == null) {
      this.toastService.show("Failed retrieve client order", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (clientOrder != null && this.clientOrderForView) {
      this.message = "#" + clientOrder!.clientOrderId.toString()
      this.desc = "'" + clientOrder!.description + "'";
    }
  }
  // update a clientOrder
  updateClientOrder(clientOrder: ClientOrder) {
    if (!this.clientOrderForUpdate) {
      this.clientOrderForUpdate = true;
      this.clientOrderForDelete = false;
      this.clientOrderForView = false;
      this.message = "#" + clientOrder.clientOrderId.toString()
      this.desc = "Update client order for '" + clientOrder.clientName + "'";
      this.clientOrder = clientOrder;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.clientOrderForUpdate = false;
      this.clientOrder = clientOrder;
    }
  }
  updateClientOrderReturn(clientOrder: ClientOrder | null) {
    if (clientOrder != null) {
      this.router.navigate(["/client-order"]);
      this.toastService.show('Client Order updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.clientOrderForUpdate = false;
      this.toastService.show('Failed to update client order', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (clientOrder != null && this.clientOrderForUpdate) {
      this.clientOrder = clientOrder;
      this.clientOrderForUpdate = false;
    }
  }
  // delete a clientOrder
  deleteClientOrder(clientOrder: ClientOrder) {
    if (!this.clientOrderForDelete) {
      this.clientOrderForDelete = true;
      this.clientOrderForUpdate = false;
      this.clientOrderForView = false;
      this.message = "#" + clientOrder.clientOrderId.toString()
      this.desc = "Do you want to delete order for client: '" + clientOrder.clientName + "'?";
      this.clientOrder = clientOrder;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.clientOrderForDelete = false;
      this.clientOrder = clientOrder;
    }
  }
  deleteClientOrderReturn(clientOrder: ClientOrder | null) {
    if (clientOrder != null) {
      this.clientOrderList = this.clientOrderList.filter(item => item.clientOrderId != clientOrder.clientOrderId);
      this.router.navigate(["/client-order"]);
      this.toastService.show('Client Order deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.clientOrderForDelete = false;
      this.toastService.show('Failed to delete client order', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (clientOrder != null && this.clientOrderForDelete) {
      this.clientOrder = clientOrder;
      this.clientOrderForDelete = false;
    }
  }
  // Back in history
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }

  // back
  back() {
    this.clientOrderForUpdate = false;
    this.clientOrderForDelete = false;
    this.clientOrderForView = false;
    this.message = "";
    this.desc = "";
    this.router.navigate(['/client-order']);
  }
}