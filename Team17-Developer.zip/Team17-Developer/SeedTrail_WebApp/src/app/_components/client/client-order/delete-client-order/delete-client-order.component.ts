import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-client-order',
  templateUrl: './delete-client-order.component.html',
  styleUrls: ['./delete-client-order.component.css']
})
export class DeleteClientOrderComponent {

  constructor(
    private service: ClientOrderService,
    private toastService: ToastService) { }

  @Input() clientOrder!: ClientOrder;
  @Output() deleteClientOrderEvent: EventEmitter<ClientOrder | null> = new EventEmitter<ClientOrder | null>();

  //handles form submission
  onSubmit() {
    this.service.checkRefIntegrity(this.clientOrder.clientOrderId).subscribe(res => {
      if (res == true) {
        this.service.deleteClientOrder(this.clientOrder.clientOrderId).subscribe({
          next: () => {
            this.deleteClientOrderEvent.emit(this.clientOrder);
          },
          error: err => {
            console.log(err);
            this.deleteClientOrderEvent.emit(null);
          }
        });
      }
      else {
        this.toastService.show('Client order has existing Batches. Cannot delete.', { classname: 'bg-secondary', delay: 5000 });
      }
    });
  }
}
