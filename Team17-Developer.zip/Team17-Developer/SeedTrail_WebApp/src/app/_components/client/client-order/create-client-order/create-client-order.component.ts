import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { OrderStatus } from 'src/app/shared/_interfaces/order-status';
import { ClientOrderStatusService } from 'src/app/shared/_services/client-order-status.service';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { ClientService } from 'src/app/shared/_services/client.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-client-order',
  templateUrl: './create-client-order.component.html',
  styleUrls: ['./create-client-order.component.css']
})
export class CreateClientOrderComponent implements OnInit {

  form!: UntypedFormGroup;
  clientList!: Client[];
  orderStatusList!: OrderStatus[];
  today!: string;

  constructor(private toastService: ToastService, private service: ClientOrderService, private osService: ClientOrderStatusService, private service2: ClientService, private router: Router) { }

  ngOnInit(): void {
    this.today = new Date().toISOString().slice(0, 10);
    this.service2.getClients().subscribe((data: Client[]) => {
      this.clientList = data;
    });
    this.osService.getOrderStatuses().subscribe((data: OrderStatus[]) => {
      this.orderStatusList = data;
    });
    this.form = new UntypedFormGroup({
      clientId: new UntypedFormControl("--- Select ---", [Validators.required]),
      description: new UntypedFormControl("", [Validators.required, Validators.maxLength(255)]),
      dateRequired: new UntypedFormControl(this.today)
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.clientId == "--- Select ---" || this.form.value.clientId == null) {
      this.toastService.show('Please select a Client!', { classname: 'bg-secondary', delay: 3000 });
      return;
    }
    if (this.form.value.dateRequired != null) {
      var dateReqString: string | null = this.form.value.dateRequired
    }
    else {
      var dateReqString: string | null = null;
    }
    if (this.form.valid) {
      //find client
      let client = this.clientList.find(x => x.clientId == this.form.value.clientId);
      if (client == null) {
        this.toastService.show('Client not found!', { classname: 'bg-danger text-light', delay: 5000 });
        return;
      }
      //find order status
      let orderStatus = this.orderStatusList.find(x => x.orderStatusId == 1);
      if (orderStatus == null) {
        this.toastService.show('Order Status not found!', { classname: 'bg-danger text-light', delay: 5000 });
        return;
      }
      //get current date
      var datePlacedString = new Date().toISOString().slice(0, 10);
      // create client order
      let clientOrder: ClientOrder = {
        clientOrderId: 0,
        clientId: client.clientId,
        clientName: client.name,
        orderStatusId: orderStatus.orderStatusId,
        description: this.form.value.description,
        datePlaced: datePlacedString,
        dateRequired: dateReqString ?? null,
        status: true,
        batches: null,
        client: client,
        orderStatus: orderStatus
      };
      console.log(datePlacedString);
      console.log(dateReqString);
      this.service.createClientOrder(clientOrder).subscribe({
        next: () => {
          this.toastService.show('Client order created successfully', { classname: 'bg-primary text-light', delay: 2000 });
        },
        error: err => {
          console.log(err);
          this.toastService.show("Error creating client order\n" + err.error, { classname: 'bg-danger text-light', delay: 3000 });
        }
      });
    }
  }
  //history back
  historyBack() {
    window.history.back();
  }
}
