import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientService } from 'src/app/shared/_services/client.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-update-client',
  templateUrl: './update-client.component.html',
  styleUrls: ['./update-client.component.css']
})
export class UpdateClientComponent implements OnInit {

  form!: UntypedFormGroup;

  constructor(private toastService: ToastService, private service: ClientService, private router: Router) { }

  @Input() client!: Client;
  @Output() updateClientEvent: EventEmitter<Client | null> = new EventEmitter<Client | null>();

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.client.name, [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      contractNr: new UntypedFormControl(this.client.contractNr, [Validators.required, Validators.pattern(/^(\+27|0)[6-8][0-9]{8}$/)]),
      email: new UntypedFormControl(this.client.email, [Validators.required, Validators.email, Validators.maxLength(40)]),
      address: new UntypedFormControl(this.client.address, [Validators.maxLength(60)])
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.address == "") {
      this.form.value.address = null;
    }
    if (this.form.valid) {
      let client: Client = {
        clientId: this.client.clientId,
        name: this.form.value.name ?? this.client.name,
        contractNr: this.form.value.contractNr ?? this.client.contractNr,
        email: this.form.value.email ?? this.client.email,
        address: this.form.value.address ?? this.client.address,
        status: this.client.status,
        clientOrders: this.client.clientOrders
      };
      this.service.isEmailUniqueUpdate(client.clientId, client.email).subscribe((res: boolean) => {
        if (res == true) {
          this.service.updateClient(client.clientId, client).subscribe({
            next: () => {
              this.updateClientEvent.emit(client)
            },
            error: err => {
              console.log(err);
              this.updateClientEvent.emit(null)
            }
          });
        }
        else {
          this.toastService.show('Email already exists.', { classname: 'bg-secondary', delay: 5000 });
        }
      });
    }
  }
}
