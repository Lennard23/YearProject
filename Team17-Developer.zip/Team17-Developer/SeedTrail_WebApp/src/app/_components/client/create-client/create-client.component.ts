import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Client } from 'src/app/shared/_interfaces/client';
import { ClientService } from 'src/app/shared/_services/client.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-client',
  templateUrl: './create-client.component.html',
  styleUrls: ['./create-client.component.css']
})
export class CreateClientComponent implements OnInit {

  form!: UntypedFormGroup;

  constructor(private toastService: ToastService, private service: ClientService, private router: Router) { }

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      contractNr: new UntypedFormControl("", [Validators.required, Validators.pattern(/^(\+27|0)[6-8][0-9]{8}$/)]),
      email: new UntypedFormControl("", [Validators.required, Validators.email, Validators.maxLength(40)]),
      address: new UntypedFormControl("", [Validators.maxLength(60)])
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.address == "") {
      this.form.value.address = null;
    }
    if (this.form.valid) {
      let client: Client = {
        clientId: 0,
        name: this.form.value.name,
        contractNr: this.form.value.contractNr,
        email: this.form.value.email,
        address: this.form.value.address ?? null,
        status: true,
        clientOrders: null
      };
      this.service.isEmailUnique(client.email).subscribe((res: boolean) => {
        if (res == true) {
          this.service.createClient(client).subscribe({
            next: () => {
              this.toastService.show('Client created successfully', { classname: 'bg-primary text-light', delay: 2000 });
            },
            error: err => {
              console.log(err);
              this.toastService.show("Error creating client\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
            }
          });
        }
        else {
          this.toastService.show('Email already exists! Please choose another', { classname: 'bg-secondary', delay: 5000 });
        }
      });
    }
  }

  //history back
  historyBack() {
    window.history.back();
  }
}
