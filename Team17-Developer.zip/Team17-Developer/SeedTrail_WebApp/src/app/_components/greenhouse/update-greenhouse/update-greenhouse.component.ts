import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-update-greenhouse',
  templateUrl: './update-greenhouse.component.html',
  styleUrls: ['./update-greenhouse.component.css']
})
export class UpdateGreenhouseComponent implements OnInit {

  form!: UntypedFormGroup;
  itemId: number = 0;
  statDescs: GreenhouseStatusDescription[] = [];
  ghss: GreenhouseStatus[] = [];
  numInput: number = 0;
  descInput: number = 0;

  @Input() greenhouse!: Greenhouse;
  @Output() updateGreenhouseEvent: EventEmitter<Greenhouse | null> = new EventEmitter<Greenhouse | null>();

  constructor(
    private toastService: ToastService,
    private service: GreenhouseService,
    private service2: GreenhouseStatusDescriptionService,
    private ghsService: GreenhouseStatusService) {}

  ngOnInit(): void {
    this.service.getGreenhouseById(this.greenhouse.greenhouseId).subscribe(res => {
      this.greenhouse = res;
    });
    this.ghsService.getGreenhouseStatuses().subscribe(data => {
      this.ghss = data;
      this.service2.getGreenhouseStatusesDescription().subscribe(data => {
        this.statDescs = data.map(item => {
          let stat = this.ghss.find(x => x.greenhouseStatusId == item.greenhouseStatusId);
          item.description = item.description! + " - " + stat!.ghstatus
          return item;
        });
      });
    });
    this.createForm();
  }

  createForm() {
    this.descInput = this.greenhouse.greenhouseStatusDescId ?? 0;
    this.numInput = this.greenhouse.greenhouseNumber ?? 0;
    this.form = new UntypedFormGroup({
      number: new UntypedFormControl(this.numInput, [Validators.required, Validators.min(0), Validators.max(9999)]),
      statusDesc: new UntypedFormControl(this.descInput, [Validators.required])
    });
  }

  //handles form submission
  onSubmit() {
    //find statusDesc
    let descId = +this.form.value.statusDesc;
    let desc = this.statDescs.find(x => x.greenhouseStatusDescId == descId)!;
    let newItem: Greenhouse = {
      greenhouseId: this.greenhouse.greenhouseId,
      greenhouseStatusDescId: descId ?? this.greenhouse.greenhouseStatusDescId,
      greenhouseNumber: +this.form.value.number ?? this.greenhouse.greenhouseNumber,
      status: this.greenhouse.status,
      greenhouseStatusDesc: desc ?? this.greenhouse.greenhouseStatusDesc,
      greenhouseActivities: this.greenhouse.greenhouseActivities,
      greenhouseProductionInventories: this.greenhouse.greenhouseProductionInventories,
      greenhouseTables: this.greenhouse.greenhouseTables
    };
    this.updateGreenhouse(newItem)
  }

  //update greenhouse
  updateGreenhouse(greenhouse: Greenhouse) {
    return this.service.isNumberUniqueUpdate(greenhouse.greenhouseId, greenhouse.greenhouseNumber).subscribe(res => {
      if (res) {
        this.service.updateGreenhouse(greenhouse.greenhouseId, greenhouse).subscribe({
          next: () => {
            this.updateGreenhouseEvent.emit(greenhouse)
          },
          error: err => {
            console.log(err);
            this.updateGreenhouseEvent.emit(null)
          }
        })
      }
      else {
        this.toastService.show('Greenhouse Number "'+greenhouse.greenhouseNumber+'" already exists! Please choose another number', { classname: 'bg-secondary', delay: 5000 });
      }
    });
  }
}
