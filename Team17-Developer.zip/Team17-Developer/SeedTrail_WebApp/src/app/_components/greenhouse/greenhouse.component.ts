import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';


@Component({
  selector: 'app-greenhouse',
  templateUrl: './greenhouse.component.html',
  styleUrls: ['./greenhouse.component.css']
})
export class GreenhouseComponent implements OnInit {

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  greenhouseList: Greenhouse[] = []
  greenhouseForUpdate: boolean = false;
  greenhouseForDelete: boolean = false;
  greenhouseForView: boolean = false;
  greenhouseForCount: boolean = false;
  greenhouse!: Greenhouse;
  scenario: number = 1;
  guiMessage: string = "Table";
  message: string = "";
  desc: string = "";

  constructor(private toastService: ToastService, private service: GreenhouseService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getGreenhouses().subscribe(greenhouses => {
        // if there's a search term, filter the cultivars
        if (this.searchTerm != null && this.searchTerm != "") {
          if (this.searchTerm.includes("GHSDID#")) {
            this.message = "> with status description ID#" + this.searchTerm.replace("GHSDID#", "");
            this.greenhouseList = greenhouses.filter(greenhouse => greenhouse.greenhouseStatusDescId == parseInt(this.searchTerm.split("#")[1]));
          }
          else if (this.searchTerm.includes("with status description ID#")) {
            this.message = "> with status description ID#" + this.searchTerm.replace("with status description ID#", "");
            this.greenhouseList = greenhouses.filter(greenhouse => greenhouse.greenhouseStatusDescId == parseInt(this.searchTerm.split("#")[1]));
          }
          else if (this.searchTerm.includes("GHID#")) {
            this.message = "> with ID#" + this.searchTerm.replace("GHID#", "");
            this.greenhouseList = greenhouses.filter(greenhouse => greenhouse.greenhouseId == parseInt(this.searchTerm.split("#")[1]));
          }
          else {
            this.greenhouseList = greenhouses.filter(item => item.greenhouseNumber?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.greenhouseId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.greenhouseStatusDescId.toString().includes(this.searchTerm.trim().toLowerCase()));
          }
        }
        else {
          // if there's no search term, return all cultivars
          this.greenhouseList = greenhouses;
        }
      });
    });
  }

  // Search function
  search() {
    this.router.navigate(['/greenhouse', { searchTerm: this.searchTerm }]);
  }

  //gets single greenhouse
  async getGreenhouse(id: number) {
    return this.service.getGreenhouseById(id).subscribe((data: Greenhouse) => {
      //return a greenhouse object
      return data;
    })
  }

  viewGreenhouse(greenhouse: Greenhouse) {
    if (!this.greenhouseForView) {
      this.greenhouseForView = true;
      this.greenhouseForUpdate = false;
      this.greenhouseForDelete = false;
      this.greenhouseForCount = false;
      this.message = "#" + greenhouse.greenhouseNumber.toString()
      this.desc = "Greenhouse Number '" + greenhouse.greenhouseNumber.toString() + "'";
      this.greenhouse = greenhouse;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.greenhouse = greenhouse;
    }
  }
  viewGreenhouseReturn(greenhouse: Greenhouse | null) {
    if (greenhouse == null) {
      this.toastService.show("Failed to retrieve greenhouse", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (greenhouse != null && this.greenhouseForView) {
      this.message = "#" + greenhouse.greenhouseNumber.toString()
      this.desc = "Greenhouse Number '" + greenhouse.greenhouseNumber.toString() + "'";
    }
  }
  updateGreenhouse(greenhouse: Greenhouse) {
    if (!this.greenhouseForUpdate) {
      this.greenhouseForUpdate = true;
      this.greenhouseForDelete = false;
      this.greenhouseForView = false;
      this.greenhouseForCount = false;
      this.greenhouse = greenhouse;
      this.message = "#" + greenhouse.greenhouseNumber.toString()
      this.desc = "Do you want to update greenhouse '#" + (greenhouse.greenhouseNumber.toString() ?? greenhouse.greenhouseId) + "'?";
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.greenhouse = greenhouse;
      window.location.reload();
    }
  }
  updateGreenhouseReturn(greenhouse: Greenhouse | null) {
    if (greenhouse != null) {
      this.router.navigate(["/greenhouse"]);
      this.toastService.show('Greenhouse updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.greenhouseForUpdate = false;
      this.toastService.show('Failed to update greenhouse', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (greenhouse != null && this.greenhouseForUpdate) {
      this.greenhouse = greenhouse;
      this.greenhouseForUpdate = false;
    }
  }
  deleteGreenhouse(greenhouse: Greenhouse) {
    if (!this.greenhouseForDelete) {
      this.message = "#" + greenhouse.greenhouseNumber.toString()
      this.desc = "Do you want to delete greenhouse No. '" + greenhouse.greenhouseNumber.toString() + "'?";
      this.greenhouseForDelete = true;
      this.greenhouseForUpdate = false;
      this.greenhouseForView = false;
      this.greenhouseForCount = false;
      this.greenhouse = greenhouse;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.greenhouse = greenhouse;
      window.location.reload();
    }
  }
  deleteGreenhouseReturn(greenhouse: Greenhouse | null) {
    if (greenhouse != null) {
      this.greenhouseList = this.greenhouseList.filter(item => item.greenhouseId != greenhouse.greenhouseId);
      this.router.navigate(["/greenhouse"]);
      this.toastService.show('Greenhouse deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.greenhouseForDelete = false;
      this.toastService.show('Failed to delete greenhouse', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (greenhouse != null && this.greenhouseForDelete) {
      this.greenhouse = greenhouse;
      this.greenhouseForDelete = false;
    }
  }
  countGreenhouse(greenhouse: Greenhouse) {
    if (!this.greenhouseForDelete) {
      this.message = "#" + greenhouse.greenhouseNumber.toString()
      this.desc = "Counts for Greenhouse '" + greenhouse.greenhouseNumber.toString() + "'";
      this.greenhouseForDelete = false;
      this.greenhouseForUpdate = false;
      this.greenhouseForView = false;
      this.greenhouseForCount = true;
      this.greenhouse = greenhouse;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.greenhouse = greenhouse;
      window.location.reload();
    }
  }
  countGreenhouseReturn(greenhouse: Greenhouse | null) {
    if (greenhouse == null){
      this.greenhouseForCount = false;
      this.toastService.show('Failed to get counts', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (greenhouse != null && this.greenhouseForCount) {
      this.message = "#" + greenhouse.greenhouseNumber.toString()
      this.desc = "Counts for Greenhouse '" + greenhouse.greenhouseNumber.toString() + "'";
    }
  }

  //back
  back() {
    this.greenhouseForUpdate = false;
    this.greenhouseForDelete = false;
    this.greenhouseForView = false;
    this.greenhouseForCount = false;
    this.message = "";
    this.desc = "";
  }

  //history back
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }

  guiSwitch() {
    if (this.scenario == 2) {
      this.message = "";
      this.desc = "";
      this.scenario = 1;
      this.guiMessage = "Table";
    }
    else {
      this.message = "";
      this.desc = "";
      this.scenario = 2;
      this.guiMessage = "GUI";
    }
  }
}