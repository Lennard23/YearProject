import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { take } from 'rxjs/operators';
import { GhInfo } from 'src/app/shared/_interfaces/gh-info';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseProductionInventory } from 'src/app/shared/_interfaces/greenhouse-production-inventory';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseProductionInventoryService } from 'src/app/shared/_services/greenhouse-production-inventory.service';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';

@Component({
  selector: 'app-view-greenhouse',
  templateUrl: './view-greenhouse.component.html',
  styleUrls: ['./view-greenhouse.component.css']
})
export class ViewGreenhouseComponent implements OnChanges {

  constructor(private service: GreenhouseService, private ghpiService: GreenhouseProductionInventoryService, private ghsService: GreenhouseStatusService, private descService: GreenhouseStatusDescriptionService, private router: Router) { }

  ghStatusDescForView = false;

  @Input() greenhouse!: Greenhouse

  greenhouseStatus!: GreenhouseStatus;
  ghss: GreenhouseStatus[] = [];
  ghs!: GreenhouseStatus;
  ghstatus!: string;
  statDescs: GreenhouseStatusDescription[] = [];
  statdesc!: GreenhouseStatusDescription;
  statId: number = 1;
  description!: string;
  basicInfo!: GhInfo;
  gpiids: number[] = [];

  @Output() viewGreenhouseEvent: EventEmitter<Greenhouse | null> = new EventEmitter<Greenhouse | null>();

  ngOnChanges( changes: SimpleChanges ) {
    if (changes['greenhouse']) {
      this.service.getGreenhouseById(this.greenhouse.greenhouseId).pipe(take(1)).subscribe({
        next: (data: Greenhouse) => {
          this.greenhouse = data;
          this.viewGreenhouseEvent.emit(this.greenhouse)
          this.service.getBasicInfo(this.greenhouse.greenhouseId).pipe(take(1)).subscribe((res: GhInfo) => {
            this.basicInfo = res;
            this.descService.getGreenhouseStatusesDescription().pipe(take(1)).subscribe({
              next: (data: GreenhouseStatusDescription[]) => {
                let descIndex = data.findIndex(item => item.greenhouseStatusDescId == this.greenhouse.greenhouseStatusDescId)!;
                this.description = data[descIndex].description!;
                this.statId = data[descIndex].greenhouseStatusId!;
                this.ghsService.getGreenhouseStatusesById(this.statId).pipe(take(1)).subscribe({
                  next: (data: GreenhouseStatus) => {
                    this.ghs = data;
                    this.ghstatus = data.ghstatus!;
                  },
                  error: (err: any) => console.log(err)
                });
                this.ghpiService.getAllProdInvsForGhId(this.greenhouse.greenhouseId).pipe(take(1)).subscribe({
                  next: (data: GreenhouseProductionInventory[]) => {
                    // get all Gh production inventories and map them to an array of their ids
                    this.gpiids = data.map(item => item.productionInvId);
                  },
                  error: (err: any) => console.log("ERROR:",err.message)
                });
              },
              error: (err: any) => console.log("ERROR:",err.message)
            });
          });
        },
        error: (err: any) => {
          console.log(err);
          this.viewGreenhouseEvent.emit(null);
        }
      });
    }
  }

  prodInv() {
    // ',' is a delimiter to separate the ids in the url
    let string: string = this.gpiids.join(",");
    this.router.navigate(['/production-inventory', { searchTerm: "##" + string }]);
  }

  getBlocks() {
    if (this.basicInfo.tables != null) {
      let blockIds = this.basicInfo.tables.map(item => item.blockId);
      let string: string = blockIds.join(",");
      this.router.navigate(['/greenhouse-block', { searchTerm: "#BIDS#" + string }]);
    }
  }

  getTables() {
    this.router.navigate(['/greenhouse-table', { searchTerm: "GHID#" + this.greenhouse.greenhouseId }]);
  }

  viewGreenhouseStatus() {
    this.ghStatusDescForView = true;
  }
}
