import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { ToastService } from 'src/app/shared/_services/toast.service';
@Component({
  selector: 'app-greenhouseStatusDescription',
  templateUrl: './greenhouse-status-description.component.html',
  styleUrls: ['./greenhouse-status-description.component.css']
})
export class GreenhouseStatusDescriptionComponent implements OnInit {

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  ghsdList: GreenhouseStatusDescription[] = []
  ghsd!: GreenhouseStatusDescription;

  greenhouseStatusDescriptionForUpdate: boolean = false;
  greenhouseStatusDescriptionForDelete: boolean = false;
  greenhouseStatusDescriptionForView: boolean = false;
  
  message: string = "";
  desc: string = "";

  constructor(
    private toastService: ToastService,
    private service: GreenhouseStatusDescriptionService,
    private ghsService: GreenhouseStatusService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getGreenhouseStatusesDescription().subscribe(data => {
        // if there's a search term, filter the descriptions
        if (this.searchTerm != null && this.searchTerm != "") {
          this.ghsdList = data.filter(item => item.description!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.greenhouseStatusDescId.toString().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all descriptions
          this.ghsdList = data;
        }
      });
    });
  }

  // Search function
  search() {
    this.router.navigate(['/greenhouse-status-description', { searchTerm: this.searchTerm }]);
  }

  //gets single greenhouse
  async getGreenhouse(id: number) {
    return this.service.getGreenhouseStatusDescriptionById(id).subscribe((data: GreenhouseStatusDescription) => {
      //return a greenhouse object
      return data;
    })
  }

  viewGhStatDesc(ghstatdesc: GreenhouseStatusDescription) {
    if (!this.greenhouseStatusDescriptionForView) {
      this.ghsd = ghstatdesc;
      this.ghsService.getGreenhouseStatusesById(this.ghsd.greenhouseStatusDescId).subscribe((data: GreenhouseStatus) => {
        this.message = data.ghstatus!.toString()
        this.desc = "Description: '" + ghstatdesc.description + "'";
        window.scroll({
          top: 0,
          left: 0,
          behavior: 'smooth'
        });
      });
      this.greenhouseStatusDescriptionForView = true;
      this.greenhouseStatusDescriptionForUpdate = false;
      this.greenhouseStatusDescriptionForDelete = false;
    }
    else {
      this.ghsd = ghstatdesc;
    }
  }
  viewGhStatDescReturn(ghstatdesc: GreenhouseStatusDescription | null) {
    if (ghstatdesc == null) {
      this.toastService.show("Failed to retrieve greenhouse status description", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (ghstatdesc != null && this.greenhouseStatusDescriptionForView){
      this.ghsService.getGreenhouseStatusesById(ghstatdesc.greenhouseStatusId).subscribe((data: GreenhouseStatus) => {
        this.message = data.ghstatus!.toString()
        this.desc = "Description: '" + ghstatdesc.description + "'";
        this.ghsd = ghstatdesc;
      });
    }
  }
  updateGhStatDesc(ghstatdesc: GreenhouseStatusDescription) {
    if (!this.greenhouseStatusDescriptionForUpdate) {
      this.greenhouseStatusDescriptionForView = false;
      this.greenhouseStatusDescriptionForUpdate = true;
      this.greenhouseStatusDescriptionForDelete = false;
      this.ghsService.getGreenhouseStatusesById(ghstatdesc.greenhouseStatusId).subscribe((data: GreenhouseStatus) => {
        this.message = data.ghstatus!.toString()
        this.desc = "Update '" + ghstatdesc.description + "'";
        window.scroll({
          top: 0,
          left: 0,
          behavior: 'smooth'
        });
        this.ghsd = ghstatdesc;
      });
    }
    else {
      this.ghsd = ghstatdesc;
      window.location.reload();
    }
  }
  updateGhStatDescReturn(ghstatdesc: GreenhouseStatusDescription | null) {
    if (ghstatdesc != null) {
      this.router.navigate(["/greenhouse-status-description"]);
      this.toastService.show('Greenhouse Status Description updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.greenhouseStatusDescriptionForUpdate = false;
      this.toastService.show('Failed to update greenhouse status description', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (ghstatdesc != null && this.greenhouseStatusDescriptionForUpdate){
      this.ghsd = ghstatdesc;
      this.greenhouseStatusDescriptionForUpdate = false;
    }
  }
  deleteGhStatDesc(ghstatdesc: GreenhouseStatusDescription) {
    if (!this.greenhouseStatusDescriptionForDelete) {
      this.greenhouseStatusDescriptionForDelete = true;
      this.greenhouseStatusDescriptionForUpdate = false;
      this.greenhouseStatusDescriptionForView = false;
      this.ghsService.getGreenhouseStatusesById(ghstatdesc.greenhouseStatusId).subscribe((data: GreenhouseStatus) => {
        this.message = data.ghstatus!.toString()
        this.desc = "Delete '" + ghstatdesc.description + "'?";
        window.scroll({
          top: 0,
          left: 0,
          behavior: 'smooth'
        });
        this.ghsd = ghstatdesc;
      });
    }
    else {
      this.ghsd = ghstatdesc;
      window.location.reload();
    }
  }
  deleteGhStatDescReturn(ghstatdesc: GreenhouseStatusDescription | null) {
    if (ghstatdesc != null) {
      this.ghsdList = this.ghsdList.filter(item => item.greenhouseStatusDescId != ghstatdesc.greenhouseStatusDescId);
      this.router.navigate(["/greenhouse-status-description"]);
      this.toastService.show('Greenhouse status description deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.greenhouseStatusDescriptionForDelete = false;
      this.toastService.show('Failed to delete greenhouse status description', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (ghstatdesc != null && this.greenhouseStatusDescriptionForDelete){
      this.ghsd = ghstatdesc;
      this.greenhouseStatusDescriptionForDelete = false;
    }
  }

  //back
  back() {
    this.greenhouseStatusDescriptionForUpdate = false;
    this.greenhouseStatusDescriptionForDelete = false;
    this.greenhouseStatusDescriptionForView = false;
    this.message = "";
    this.desc = "";
  }

  //history back
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }

}
