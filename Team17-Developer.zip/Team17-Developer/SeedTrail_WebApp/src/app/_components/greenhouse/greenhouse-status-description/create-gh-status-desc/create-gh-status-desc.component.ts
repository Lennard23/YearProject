import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { ToastService } from 'src/app/shared/_services/toast.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-create-gh-status-desc',
  templateUrl: './create-gh-status-desc.component.html',
  styleUrls: ['./create-gh-status-desc.component.css']
})
export class CreateGhStatusDescComponent implements OnInit {

  form!: UntypedFormGroup;
  ghStatList!: GreenhouseStatus[];
  ghStat!: GreenhouseStatus;

  constructor(private toastService: ToastService, private service: GreenhouseStatusDescriptionService, private statusService: GreenhouseStatusService) { }

  ngOnInit(): void {
    this.statusService.getGreenhouseStatuses().pipe(take(1)).subscribe({
      next: (ghStatList) => {
        this.ghStatList = ghStatList;
      },
      error: err => {
        console.log(err);
      }
    });
    this.form = new UntypedFormGroup({
      ghStatId: new UntypedFormControl("Select", [Validators.required]),
      description: new UntypedFormControl("", [Validators.required, Validators.minLength(3), Validators.maxLength(30)]),
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.description == "") {
      this.form.value.description = null;
    }
    // find greenhouse status
    if (this.form.value.ghStatId != null && this.form.value.ghStatId != "-- Select --") {
      this.ghStat = this.ghStatList.find(x => x.greenhouseStatusId == +this.form.value.ghStatId)!;
    }
    else {
      this.toastService.show("Please select a greenhouse status.", { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    if (this.form.valid) {
      let ghStatDesc: GreenhouseStatusDescription = {
        greenhouseStatusDescId: 0,
        greenhouseStatusId: this.ghStat.greenhouseStatusId,
        description: this.form.value.description ?? null,
        status: true,
        greenhouseStatus: this.ghStat,
        greenhouses: null,
      };
      this.service.createGreenhouseStatusDescription(ghStatDesc).subscribe({
        next: () => {
          this.toastService.show('Status Description created successfully', { classname: 'bg-primary text-light', delay: 2000 });
        },
        error: err => {
          console.log(err);
          this.toastService.show("Error creating Status Description\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
        }
      });
    }
  }

  //history back
  historyBack() {
    window.history.back();
  }

}
