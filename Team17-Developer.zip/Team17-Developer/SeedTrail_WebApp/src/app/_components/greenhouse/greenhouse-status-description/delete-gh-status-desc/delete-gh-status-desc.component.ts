import { Component, EventEmitter, Input, Output } from '@angular/core';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-gh-status-desc',
  templateUrl: './delete-gh-status-desc.component.html',
  styleUrls: ['./delete-gh-status-desc.component.css']
})
export class DeleteGhStatusDescComponent {

  constructor(private toastService: ToastService, private service: GreenhouseStatusDescriptionService) { }

  @Input() greenhouseStatusDescription!: GreenhouseStatusDescription;
  @Output() deleteGreenhouseStatDescEvent: EventEmitter<GreenhouseStatusDescription | null> = new EventEmitter<GreenhouseStatusDescription | null>();

  //disables existing greenhouse
  onSubmit() {
    this.service.checkRefIntegrity(this.greenhouseStatusDescription.greenhouseStatusDescId).subscribe(res => {
      if (res == true) {
        this.toastService.show('This Description is used by certain Greenhouses. You cannot delete it.', { classname: 'bg-secondary', delay: 6000 });
        return;
      }
      else {
        this.service.deleteGreenhouseStatusDescription(this.greenhouseStatusDescription.greenhouseStatusDescId).subscribe({
          next: () => {
            this.deleteGreenhouseStatDescEvent.emit(this.greenhouseStatusDescription)
          },
          error: err => {
            console.log(err);
            this.deleteGreenhouseStatDescEvent.emit(null)
          }
        });
      }
    });
  }

}
