import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { take } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-gh-status-desc',
  templateUrl: './view-gh-status-desc.component.html',
  styleUrls: ['./view-gh-status-desc.component.css']
})
export class ViewGhStatusDescComponent implements OnChanges {

  greenhouseStatus!: GreenhouseStatus;
  ghss: GreenhouseStatus[] = [];
  ghs!: GreenhouseStatus;
  ghstatus!: string;
  statDescs: GreenhouseStatusDescription[] = [];
  statId: number = 1;
  description!: string;
  count: number = 0;

  constructor(private router: Router, private service: GreenhouseStatusDescriptionService, private ghsService: GreenhouseStatusService) { }

  @Input() greenhouseStatusDescription!: GreenhouseStatusDescription;
  @Output() viewGreenhouseStatDescEvent: EventEmitter<GreenhouseStatusDescription | null> = new EventEmitter<GreenhouseStatusDescription | null>();

  ngOnChanges() {
    this.updategh();
  }

  updategh() {
    this.ghsService.getGreenhouseStatusesById(this.greenhouseStatusDescription.greenhouseStatusId).pipe(take(1)).subscribe({
      next: (data: GreenhouseStatus) => {
        this.ghs = data;
        this.ghstatus = data.ghstatus!;
        this.viewGreenhouseStatDescEvent.emit(this.greenhouseStatusDescription)
      },
      error: (err: any) => {
        console.log(err);
        this.viewGreenhouseStatDescEvent.emit(null);
      }
    });
  }

  greenhouses() {
    this.router.navigate(['/greenhouse', { searchTerm: "GHSDID#" + this.greenhouseStatusDescription.greenhouseStatusDescId.toString() }]);
  }
}
