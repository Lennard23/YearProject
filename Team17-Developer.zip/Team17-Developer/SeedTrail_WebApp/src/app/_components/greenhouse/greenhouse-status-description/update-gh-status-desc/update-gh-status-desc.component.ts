import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { ToastService } from 'src/app/shared/_services/toast.service';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-update-gh-status-desc',
  templateUrl: './update-gh-status-desc.component.html',
  styleUrls: ['./update-gh-status-desc.component.css']
})
export class UpdateGhStatusDescComponent implements OnInit {

  form!: UntypedFormGroup;
  ghStatList!: GreenhouseStatus[];
  ghStat!: GreenhouseStatus;

  constructor(private toastService: ToastService, private service: GreenhouseStatusDescriptionService, private statusService: GreenhouseStatusService) { }

  @Input() greenhouseStatusDescription!: GreenhouseStatusDescription;
  @Output() updateGreenhouseStatDescEvent: EventEmitter<GreenhouseStatusDescription | null> = new EventEmitter<GreenhouseStatusDescription | null>();
  
  ngOnInit(): void {
    this.statusService.getGreenhouseStatuses().pipe(take(1)).subscribe({
      next: (ghStatList : GreenhouseStatus[]) => {
        this.ghStatList = ghStatList;
      },
      error: err => {
        console.log(err);
      }
    });
    this.form = new UntypedFormGroup({
      ghStatId: new UntypedFormControl(this.greenhouseStatusDescription.greenhouseStatusId, [Validators.required]),
      description: new UntypedFormControl(this.greenhouseStatusDescription.description, [Validators.required, Validators.minLength(3), Validators.maxLength(30)]),
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.description == "") {
      this.form.value.description = null;
    }
    // find greenhouse status
    if (this.form.value.ghStatId != null && this.form.value.ghStatId != "-- Select --") {
      this.ghStat = this.ghStatList.find(x => x.greenhouseStatusId == +this.form.value.ghStatId)!;
    }
    else {
      this.toastService.show("Please select a greenhouse status.", { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    if (this.form.valid) {
      let ghStatDesc: GreenhouseStatusDescription = {
        greenhouseStatusDescId: this.greenhouseStatusDescription.greenhouseStatusDescId,
        greenhouseStatusId: this.ghStat.greenhouseStatusId,
        description: this.form.value.description ?? this.greenhouseStatusDescription.description,
        status: this.greenhouseStatusDescription.status,
        greenhouseStatus: this.ghStat,
        greenhouses: this.greenhouseStatusDescription.greenhouses,
      };
      this.service.updateGreenhouseStatusDescription(ghStatDesc.greenhouseStatusDescId, ghStatDesc).subscribe({
        next: () => {
          this.toastService.show('Status Description updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
        },
        error: err => {
          console.log(err);
          this.toastService.show("Error updating Status Description\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
        }
      });
    }
  }

  //history back
  historyBack() {
    window.history.back();
  }

}
