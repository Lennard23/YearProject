import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { Router } from '@angular/router';
import { GreenhouseStatusDescription } from 'src/app/shared/_interfaces/greenhouse-status-description';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { ToastService } from 'src/app/shared/_services/toast.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
@Component({
  selector: 'app-create-greenhouse',
  templateUrl: './create-greenhouse.component.html',
  styleUrls: ['./create-greenhouse.component.css']
})
export class CreateGreenhouseComponent implements OnInit {

  form!: UntypedFormGroup;
  nextId: number = 0;
  statDescs: GreenhouseStatusDescription[] = [];
  ghss: GreenhouseStatus[] = [];

  constructor(
    private toastService: ToastService,
    private router: Router,
    private service: GreenhouseService,
    private service2: GreenhouseStatusDescriptionService,
    private ghsService: GreenhouseStatusService) { }

  ngOnInit(): void {
    this.ghsService.getGreenhouseStatuses().subscribe(data => {
      this.ghss = data;
      this.service2.getGreenhouseStatusesDescription().subscribe(data => {
        this.statDescs = data.map(item => {
          let stat = this.ghss.find(x => x.greenhouseStatusId == item.greenhouseStatusId);
          item.description = item.description! + " - " + stat!.ghstatus
          return item;
        });
      });
    });
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      number: new UntypedFormControl([Validators.required, Validators.min(0), Validators.max(9999)]),
      statusDesc: new UntypedFormControl("-- Select --",[Validators.required]),
    });
  }

  //handles form submission
  onSubmit() {
    let statdesc = this.statDescs.find(x => x.greenhouseStatusDescId == +this.form.value.statusDesc);
    this.service.getGreenhouses().subscribe(data => {
      this.nextId = data.length + 1;
      let greenhouse: Greenhouse= {
        greenhouseId: this.nextId,
        greenhouseStatusDescId: +this.form.value.statusDesc,
        greenhouseNumber: +this.form.get('number')?.value,
        status: true,
        greenhouseStatusDesc: statdesc as GreenhouseStatusDescription,
        greenhouseActivities: null,
        greenhouseProductionInventories: null,
        greenhouseTables: null
      };
      this.addGreenhouse(greenhouse)
    })
  }

  //adds new greenhouse
  addGreenhouse(greenhouse: Greenhouse) {
    return this.service.isNumberUnique(greenhouse.greenhouseNumber).subscribe(data => {
      if (data == true) {
        this.service.createGreenhouse(greenhouse).subscribe({
          next: () => {
            this.toastService.show('Greenhouse created successfully', { classname: 'bg-primary text-light', delay: 2000 });
            this.router.navigate(['/greenhouse']);
          },
          error: err => {
            console.log(err);
            this.toastService.show("Error creating greenhouse\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
          }
        });
      }
      else {
        this.toastService.show('Greenhouse Number "'+greenhouse.greenhouseNumber+'" already exists! Please choose another number', { classname: 'bg-secondary', delay: 5000 });
      }
    });
  }

  historyBack() {
    this.form.reset();
    window.history.back();
  }
}


