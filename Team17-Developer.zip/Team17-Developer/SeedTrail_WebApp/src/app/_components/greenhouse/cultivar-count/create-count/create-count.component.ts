import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseCultivarCount } from 'src/app/shared/_interfaces/greenhouse-cultivar-count';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';
import { GreenhouseCultivarCountService } from 'src/app/shared/_services/greenhouse-cultivar-count.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-count',
  templateUrl: './create-count.component.html',
  styleUrls: ['./create-count.component.css']
})
export class CreateCountComponent implements OnInit {

  form!: UntypedFormGroup;
  ghList: Greenhouse[] = [];
  cultList: Cultivar[] = [];

  constructor(
    private toastService: ToastService,
    private router: Router,
    private route: ActivatedRoute,
    private service: GreenhouseCultivarCountService,
    private ghService: GreenhouseService,
    private cultService: CultivarService
  ) { }

  ngOnInit(): void {
    this.cultService.getCultivars().subscribe(data => {
      this.cultList = data;
      this.ghService.getGreenhouses().subscribe(data => {
        this.ghList = data;
      });
    });
    this.route.params.subscribe(params => {
      let ghId = +params['greenhouseId'];
      this.form = new UntypedFormGroup({
        ghId: new UntypedFormControl(ghId ?? 1, [Validators.required]),
        cultId: new UntypedFormControl(1, [Validators.required]),
        count: new UntypedFormControl(0, [Validators.required, Validators.min(0)])
      });
    });
  }

  onSubmit() {
    //check if cultId is selected
    if (this.form.value.cultId == null || this.form.value.cultId == "-- Select --") {
      this.toastService.show('Please select a Cultivar!', { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    //check if ghId is selected
    if (this.form.value.ghId == null || this.form.value.ghId == "-- Select --") {
      this.toastService.show('Please select a Greenhouse!', { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    if (this.form.valid) {
      //find cultivar
      let cult = this.cultList.find(x => x.cultivarId == this.form.value.cultId)!;
      //find greenhouse
      let gh = this.ghList.find(x => x.greenhouseId == this.form.value.ghId)!;
      //create greenhouseCultivarCount
      let count: GreenhouseCultivarCount = {
        greenhouseCultivarCountId: 0,
        greenhouseNumber: gh.greenhouseNumber,
        cultivarName: cult.name,
        greenhouseId: gh.greenhouseId,
        cultivarId: cult.cultivarId,
        count: +this.form.value.count,
        greenhouse: gh,
        cultivar: cult
      }
      this.addCount(count);
    }
  }

  addCount(count: GreenhouseCultivarCount) {
    this.service.checkGreenhouseCultivarCountUnique(count.greenhouseId, count.cultivarId).subscribe(data => {
      if (data) {
        this.service.createGreenhouseCultivarCount(count).subscribe(data => {
          console.log(data);
          this.form.reset();
          this.router.navigate(['/new-count']);
          this.toastService.show('Count successfully created!', { classname: 'bg-success', delay: 5000 });
        });
      } else {
        // ask for confirmation
        if (confirm("A count exists with the same Greenhouse and Cultivar. Do you want to update this count?")) {
          this.service.updateGreenhouseCultivarCount(count).subscribe({
            next: () => {
              this.toastService.show('Count successfully updated!', { classname: 'bg-success', delay: 3000 });
              this.form.reset();
              this.router.navigate(['/new-count', { greenhouseId: count.greenhouseId }]);
            },
            error: err => {
              console.log(err);
              this.toastService.show('Error updating count!', { classname: 'bg-danger text-light', delay: 5000 });
            }
          });
        }
      }
    });
  }

  // back form submission
  historyBack() {
    this.form.reset();
    window.history.back();
  }

}
