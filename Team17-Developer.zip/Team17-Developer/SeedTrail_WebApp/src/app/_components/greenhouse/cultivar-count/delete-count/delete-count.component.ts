import { Component, EventEmitter, Input, Output } from '@angular/core';
import { GreenhouseCultivarCount } from 'src/app/shared/_interfaces/greenhouse-cultivar-count';
import { GreenhouseCultivarCountService } from 'src/app/shared/_services/greenhouse-cultivar-count.service';

@Component({
  selector: 'app-delete-count',
  templateUrl: './delete-count.component.html',
  styleUrls: ['./delete-count.component.css']
})
export class DeleteCountComponent {

  constructor(
    private service: GreenhouseCultivarCountService,
  ) { }

  cultivarName: string = "";
  greenhouseNumber: string = "";

  @Input() count!: GreenhouseCultivarCount;
  @Output() deleteCountEvent: EventEmitter<GreenhouseCultivarCount | null> = new EventEmitter<GreenhouseCultivarCount | null>();

  onSubmit() {
    this.service.deleteGreenhouseCultivarCount(this.count.greenhouseCultivarCountId).subscribe({
      next: () => {
        this.deleteCountEvent.emit(this.count);
      },
      error: err => {
        console.log(err);
        this.deleteCountEvent.emit(null);
      }
    });
  }

}
