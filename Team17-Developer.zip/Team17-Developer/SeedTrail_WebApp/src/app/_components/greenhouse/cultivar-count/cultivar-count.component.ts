import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseCultivarCount } from 'src/app/shared/_interfaces/greenhouse-cultivar-count';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';
import { GreenhouseCultivarCountService } from 'src/app/shared/_services/greenhouse-cultivar-count.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-cultivar-count',
  templateUrl: './cultivar-count.component.html',
  styleUrls: ['./cultivar-count.component.css']
})
export class CultivarCountComponent implements OnInit, OnChanges {

  constructor(
    private toastService: ToastService,
    private router : Router,
    private service: GreenhouseCultivarCountService,
    private cultivarService: CultivarService,
    private greenhouseService: GreenhouseService
    ) { }

  @Input() greenhouse!: Greenhouse;
  @Output() countGreenhouseEvent: EventEmitter<Greenhouse | null> = new EventEmitter<Greenhouse | null>();

  cultivarList: Cultivar[] = [];
  counts: GreenhouseCultivarCount[] = [];
  count!: GreenhouseCultivarCount;
  countForDelete: boolean = false;
  countForUpdate: boolean = false;
  bsyCount: string = "click GET on a count to see the Batch Size Yield count";

  ngOnInit(): void {
    this.greenhouseService.getGreenhouseById(this.greenhouse.greenhouseId).subscribe({
      next: greenhouse => {
        this.countGreenhouseEvent.emit(greenhouse);
        this.cultivarService.getCultivars().subscribe({
          next: cultivars => {
            this.cultivarList = cultivars;
            this.service.getGreenhouseCultivarCountByGreenhouse(greenhouse.greenhouseId).subscribe({
              next: counts => {
                this.counts = counts;
                if (counts.length == 0){
                  this.bsyCount = "No Counts";
                }
              },
              error: err => {
                console.log(err);
              }
            });
          },
          error: err => {
            console.log(err);
          }
        });
      },
      error: err => {
        console.log(err);
        this.countGreenhouseEvent.emit(null);
      }
    });
  }

  ngOnChanges(): void {
    this.greenhouseService.getGreenhouseById(this.greenhouse.greenhouseId).subscribe({
      next: greenhouse => {
        this.countGreenhouseEvent.emit(greenhouse);
        this.service.getGreenhouseCultivarCountByGreenhouse(greenhouse.greenhouseId).subscribe({
          next: counts => {
            this.counts = counts;
            if (counts.length == 0){
              this.bsyCount = "No Counts";
            }
          },
          error: err => {
            console.log(err);
          }
        });
      },
      error: err => {
        console.log(err);
        this.countGreenhouseEvent.emit(null);
      }
    });
  }

  getBsy(count: GreenhouseCultivarCount): void {
    let cultId = count.cultivarId;
    this.service.getBatchSizeYieldCountsCultivar(this.greenhouse.greenhouseId, cultId).subscribe({
      next: bsy => {
        this.bsyCount = "Batch Size Yield count for " + count.cultivarName + " is " + (bsy.toString() ?? "0") + 
        "\n" + (bsy.toString() ?? "0") + " out of " + count.count.toString() + " plants have been assigned to a batch size yield";
      },
      error: err => {
        console.log(err);
        this.bsyCount = "Batch Size Yield count for " + count.cultivarName + " is 0";
      }
    });
  }
  // delete a Count
  deleteCount(count: GreenhouseCultivarCount) {
    if (!this.countForDelete) {
      this.countForDelete = true;
      this.countForUpdate = false;
      this.count = count;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.countForDelete = false;
      this.count = count;
    }
  }
  deleteCountReturn(count: GreenhouseCultivarCount | null) {
    if (count != null) {
      this.counts = this.counts.filter(b => b.greenhouseCultivarCountId != count.greenhouseCultivarCountId);
      this.router.navigate(["/greenhouse"]);
      this.toastService.show('Count deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.countForDelete = false;
      this.toastService.show('Failed to delete Count', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (count != null && this.countForDelete) {
      this.count = count;
      this.countForDelete = false;
    }
  }

  //back
  back() {
    this.countForUpdate = false;
    this.countForDelete = false;
  }

  //historyback()
  historyBack() {
    this.countForUpdate = false;
    this.countForDelete = false;
    window.history.back();
  }

}
