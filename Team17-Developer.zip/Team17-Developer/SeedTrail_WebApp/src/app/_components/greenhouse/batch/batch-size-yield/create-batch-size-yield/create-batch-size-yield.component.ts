import { Component, OnInit } from '@angular/core';
import {
  UntypedFormControl,
  UntypedFormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchSizeYield } from 'src/app/shared/_interfaces/batch-size-yield';
import { CommoditySize } from 'src/app/shared/_interfaces/commodity-size';
import { BatchSizeYieldService } from 'src/app/shared/_services/batch-size-yield.service';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { CommoditySizeService } from 'src/app/shared/_services/commodity-size.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-batch-size-yield',
  templateUrl: './create-batch-size-yield.component.html',
  styleUrls: ['./create-batch-size-yield.component.css'],
})
export class CreateBatchSizeYieldComponent implements OnInit {
  form!: UntypedFormGroup;
  batchList: Batch[] = [];
  batch!: Batch;
  selectedBatch!: Batch;
  comSizeList: CommoditySize[] = [];
  comSize!: CommoditySize;

  constructor(
    private toastService: ToastService,
    private service: BatchSizeYieldService,
    private comSizeService: CommoditySizeService,
    private batchService: BatchService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.batchService.getBatches().subscribe({
      next: (data: Batch[]) => {
        this.batchList = data;
        this.comSizeService.getCommoditySizes().subscribe({
          next: (data: CommoditySize[]) => {
            this.comSizeList = data;
          },
          error: (err: any) => {
            this.toastService.show('Failed to get Commodity Sizes', {
              classname: 'bg-danger text-light',
              delay: 3000,
            });
            console.log('Failed to get Commodity Sizes: ', err);
          },
        });
      },
      error: (err: any) => {
        this.toastService.show('Failed to get Batches', {
          classname: 'bg-danger text-light',
          delay: 3000,
        });
        console.log('Failed to get batches: ', err);
      },
    });
    this.form = new UntypedFormGroup({
      batchId: new UntypedFormControl('-- Select --', [Validators.required]),
      comSizeId: new UntypedFormControl('-- Select --', [Validators.required]),
      yield: new UntypedFormControl(1, [
        Validators.required,
        Validators.pattern('^[0-9]*$'),
      ]),
    });
  }

  changeBatch(id: number): void {
    this.batchService.getBatchById(id).subscribe({
      next: (data: Batch) => {
        this.selectedBatch = data;
        this.comSizeService
          .getCommoditySizeByCultivarId(this.selectedBatch.cultivarId)
          .subscribe({
            next: (data: CommoditySize[]) => {
              this.comSizeList = data;
            },
            error: (err: any) => {
              this.toastService.show(
                'Failed to get Commodity Sizes for selected Batch',
                { classname: 'bg-danger text-light', delay: 3000 }
              );
              console.log('Failed to get Commodity Sizes ERROR: ', err);
              this.comSizeList = [];
            },
          });
      },
      error: (err: any) => {
        console.log('Failed to get batch: ', err);
      },
    });
  }

  // handles submission
  onSubmit(): void {
    // check if Batch is selected
    if (
      this.form.value.batchId == '-- Select --' ||
      this.form.value.batchId == null
    ) {
      this.toastService.show('Please select a Batch!', {
        classname: 'bg-secondary',
        delay: 5000,
      });
      return;
    }
    // check if CommoditySize is selected
    if (
      this.form.value.comSizeId == '-- Select --' ||
      this.form.value.comSizeId == null
    ) {
      this.toastService.show('Please select a Commodity Size!', {
        classname: 'bg-secondary',
        delay: 5000,
      });
      return;
    } else {
      // find batch
      this.batch = this.batchList.find((batch: Batch) => {
        return batch.batchId === +this.form.value.batchId;
      })!;
      // find commodity size
      this.comSize = this.comSizeList.find(
        (comSize: CommoditySize) =>
          comSize.commoditySizeId === +this.form.value.comSizeId
      )!;
      // build batch size yield object
      let newBsy: BatchSizeYield = {
        batchSizeYieldId: 0,
        batchId: this.batch.batchId,
        batch: this.batch,
        commditySizeId: this.comSize.commoditySizeId,
        commditySize: this.comSize,
        yield: +this.form.value.yield,
        status: true,
        description:
          'Size yield for ' +
          this.batch.clientName +
          "'s " +
          this.batch.cultivarName +
          ' batch',
      };
      this.createBatchSizeYield(newBsy);
    }
  }

  // handles creation of batch size yield
  createBatchSizeYield(newBsy: BatchSizeYield): void {
    console.log('rip');
    this.service.createBatchSizeYield(newBsy).subscribe({
      next: () => {
        this.toastService.show('Batch Size Yield created successfully', {
          classname: 'bg-success text-light',
          delay: 3000,
        });
        this.router.navigate(['/batch-size-yield']);
      },
      error: (err: any) => {
        this.toastService.show('Failed to create Batch Size Yield', {
          classname: 'bg-danger text-light',
          delay: 3000,
        });
        console.log('Failed to create Batch Size Yield: ', err);
      },
    });
  }

  // back function
  historyBack(): void {
    this.form.reset();
    window.history.back();
  }
}
