import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ActivatedRoute } from '@angular/router';
import { ToastService } from 'src/app/shared/_services/toast.service';
@Component({
  selector: 'app-batch',
  templateUrl: './batch.component.html',
  styleUrls: ['./batch.component.css']
})
export class BatchComponent implements OnInit {

  // Batch
  batchList: Batch[] = [];
  batch!: Batch;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  batchForUpdate: boolean = false;
  batchForDelete: boolean = false;
  batchForView: boolean = false;

  constructor(private toastService: ToastService, private service: BatchService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getBatches().subscribe(batches => {
        if (this.searchTerm != null && this.searchTerm.includes("BATID#")) {
          this.message = "> with Batch ID#" + this.searchTerm.replace("BATID#", "");
          this.batchList = batches.filter(batch => batch.batchId == parseInt(this.searchTerm.split("#")[1]));
        }
        else if (this.searchTerm != null && this.searchTerm.includes("COID#")) {
          this.message = "> for Client Order #" + this.searchTerm.replace("COID#", "");
          this.batchList = batches.filter(batch => batch.clientOrderId == parseInt(this.searchTerm.split("#")[1]));
        }
        else {
          // if there's a search term, filter the batchs
          if (this.searchTerm != null && this.searchTerm != "") {
            this.batchList = batches.filter(item => item.batchId?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.clientOrderId?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.cultivarName!.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.clientName!.toString().includes(this.searchTerm.trim().toLowerCase()))
              .map(item => {
                if (item.plantDate != null) {
                  item.plantDate = item.plantDate.substring(0, 10);
                }
                if (item.harvestDate != null) {
                  item.harvestDate = item.harvestDate.substring(0, 10);
                }
                return item;
              });
          }
          else {
            // if there's no search term, return all batchs
            this.batchList = batches.map(item => {
              if (item.plantDate != null) {
                item.plantDate = item.plantDate.substring(0, 10);
              }
              if (item.harvestDate != null) {
                item.harvestDate = item.harvestDate.substring(0, 10);
              }
              return item;
            });
          }
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/greenhouse-batch', { searchTerm: this.searchTerm }]);
  }

  //gets single batch
  async getBatch(id: number) {
    return this.service.getBatchById(id).subscribe((data: Batch) => {
      //return a batch object
      return data;
    })
  }

  // view a batch
  viewBatch(batch: Batch) {
    if (!this.batchForView) {
      this.batchForView = true;
      this.batchForUpdate = false;
      this.batchForDelete = false;
      this.message = "#" + batch.batchId.toString()
      this.desc = "\"" + batch.cultivarName + "'s\" for " + batch.clientName + "\""
      this.batch = batch;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.batch = batch;
    }
  }
  viewBatchReturn(batch: Batch | null) {
    if (batch == null) {
      this.toastService.show("Failed to retrieve batch", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (batch != null && this.batchForView) {
      this.message = "#" + batch.batchId.toString()
      this.desc = "\"" + batch.cultivarName + "'s\" for " + batch.clientName + "\""
    }
  }
  // update a batch
  updateBatch(batch: Batch) {
    if (!this.batchForUpdate) {
      this.batchForUpdate = true;
      this.batchForDelete = false;
      this.batchForView = false;
      this.message = "#" + batch.batchId.toString()
      this.desc = "Update batch for '" + batch.clientName + "'"
      this.batch = batch;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.batchForUpdate = false;
      this.batch = batch;
    }
  }
  updateBatchReturn(batch: Batch | null) {
    if (batch != null) {
      this.router.navigate(["/greenhouse-batch"]);
      this.toastService.show('Batch updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.batchForUpdate = false;
      this.toastService.show('Failed to update batch', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (batch != null && this.batchForUpdate) {
      this.batch = batch;
      this.batchForUpdate = false;
    }
  }
  // delete a batch
  deleteBatch(batch: Batch) {
    if (!this.batchForDelete) {
      this.batchForDelete = true;
      this.batchForUpdate = false;
      this.batchForView = false;
      this.message = "#" + batch.batchId.toString()
      this.desc = "Delete batch '" + batch.batchId.toString() + "' for client '" + batch.clientName + "'?"
      this.batch = batch;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.batchForDelete = false;
      this.batch = batch;
    }
  }
  deleteBatchReturn(batch: Batch | null) {
    if (batch != null) {
      this.batchList = this.batchList.filter(item => item.batchId != batch.batchId);
      this.router.navigate(["/greenhouse-batch"]);
      this.toastService.show('Batch deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.batchForDelete = false;
      this.toastService.show('Failed to delete batch', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (batch != null && this.batchForDelete) {
      this.batch = batch;
      this.batchForDelete = false;
    }
  }

  //back
  back() {
    this.batchForView = false;
    this.batchForUpdate = false;
    this.batchForDelete = false;
    this.message = "";
    this.desc = "";
  }

  //historyback()
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}