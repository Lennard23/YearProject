import { Component, EventEmitter, Input, Output } from '@angular/core';
import { BatchSizeYield } from 'src/app/shared/_interfaces/batch-size-yield';
import { BatchSizeYieldService } from 'src/app/shared/_services/batch-size-yield.service';

@Component({
  selector: 'app-delete-batch-size-yield',
  templateUrl: './delete-batch-size-yield.component.html',
  styleUrls: ['./delete-batch-size-yield.component.css']
})
export class DeleteBatchSizeYieldComponent {

  constructor(private service: BatchSizeYieldService) { }

  @Input() batchSizeYield!: BatchSizeYield; 
  @Output() deleteBatchSizeYieldEvent: EventEmitter<BatchSizeYield | null> = new EventEmitter<BatchSizeYield | null>();

  //disables existing greenhouse
  onSubmit() {
    this.service.disableBatchSizeYield(this.batchSizeYield.batchSizeYieldId, this.batchSizeYield).subscribe({
      next: () => {
        this.deleteBatchSizeYieldEvent.emit(this.batchSizeYield)
      },
      error: err => {
        console.log(err);
        this.deleteBatchSizeYieldEvent.emit(null)
      }
    });
  }
}
