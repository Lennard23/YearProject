import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { Router } from '@angular/router';
import { BatchSizeYield } from 'src/app/shared/_interfaces/batch-size-yield';
import { CommoditySize } from 'src/app/shared/_interfaces/commodity-size';
import { BatchSizeYieldService } from 'src/app/shared/_services/batch-size-yield.service';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { CommoditySizeService } from 'src/app/shared/_services/commodity-size.service';

@Component({
  selector: 'app-view-batch-size-yield',
  templateUrl: './view-batch-size-yield.component.html',
  styleUrls: ['./view-batch-size-yield.component.css']
})
export class ViewBatchSizeYieldComponent implements OnChanges {

  constructor(
    private service: BatchSizeYieldService,
    private batchService: BatchService,
    private router: Router,
    private commSizeService: CommoditySizeService,
  ) { }

  batchName!: string;
  commSize!: string;

  @Input() batchSizeYield!: BatchSizeYield; 
  @Output() viewBatchSizeYieldEvent: EventEmitter<BatchSizeYield | null> = new EventEmitter<BatchSizeYield | null>();

  ngOnChanges(): void {
    this.service.getBatchSizeYieldById(this.batchSizeYield.batchSizeYieldId).subscribe({
      next: (batchSizeYield: BatchSizeYield) => {
        this.batchSizeYield = batchSizeYield;
        this.batchService.getBatchById(this.batchSizeYield.batchId).subscribe({
          next: (batch) => {
            this.batchName = batch.batchId.toString() + " | " + batch.clientName + "'s " + batch.cultivarName + "'s";
            this.commSizeService.getCommoditySizeById(this.batchSizeYield.commditySizeId).subscribe({
              next: (commSize: CommoditySize) => {
                this.commSize = commSize.size + " | " + commSize.description;
              },
              error: (err: any) => {
                console.log(err);
              }
            });
          },
          error: err => {
            console.log(err);
          }
        });
      },
      error: err => {
        console.log(err);
        this.viewBatchSizeYieldEvent.emit(null)
      }
    });
  }

  viewBatch() {
    this.router.navigate(['/greenhouse-batch', { searchTerm: "BATID#" + this.batchSizeYield.batchId }]);
  }

}
