import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchInfo } from 'src/app/shared/_interfaces/batch-info';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';

@Component({
  selector: 'app-view-batch',
  templateUrl: './view-batch.component.html',
  styleUrls: ['./view-batch.component.css']
})
export class ViewBatchComponent implements OnChanges {

  constructor(private coldroomService: ColdroomService, private service: BatchService, private router: Router) { }

  @Input() batch!: Batch
  @Output() viewBatchEvent: EventEmitter<Batch | null> = new EventEmitter<Batch | null>();

  lrCount: string | undefined;
  bsyCount: string | undefined;
  blockCount: string | undefined;
  batchInfo: BatchInfo | null = null;
  coldroomName: string | undefined;
  lrIds: number[] = [];
  bsyIds: number[] = [];
  blockIds: number[] = [];

  ngOnChanges(): void {
    this.service.getBatchById(this.batch.batchId).subscribe({
      next: (res: Batch) => {
        this.batch = res;
        if (res.plantDate != null) {
          this.batch.plantDate = this.batch.plantDate!.substring(0, 10);
        }
        if (res.harvestDate != null) {
          this.batch.harvestDate = this.batch.harvestDate!.substring(0, 10);
        }
        this.viewBatchEvent.emit(this.batch);
        if (this.batch.coldroomId != null) {
          this.coldroomService.getColdroomById(this.batch.coldroomId).subscribe((data: Coldroom) => {
            this.coldroomName = data.name;
            this.service.getBatchInfo(this.batch.batchId).subscribe({
              next: (res: BatchInfo) => {
                this.batchInfo = res;
                this.lrIds = this.batchInfo?.labResults!.map(x => x.labResultsId) || [];
                this.bsyIds = this.batchInfo?.batchSizeYields!.map(x => x.batchSizeYieldId) || [];
                this.blockIds = this.batchInfo?.blocks!.map(x => x.blockId) || [];
                this.lrCount = this.batchInfo?.labResults?.length.toString() ?? "0";
                this.bsyCount = this.batchInfo?.batchSizeYields?.length.toString() ?? "0";
                this.blockCount = this.batchInfo?.blocks?.length.toString() ?? "0";
              },
              error: err => {
                console.log(err);
              }
            });
          });
        }
      },
      error: err => {
        console.log(err);
        this.viewBatchEvent.emit(null)
      }
    });
  }

  getBsy(){
    this.router.navigate(['/batch-size-yield', { searchTerm: "BATID#" + this.batch.batchId.toString() }]);
  }

  getLr(){
    // ',' is a delimiter to separate the ids in the url
    let string: string = this.lrIds.join(",");
    this.router.navigate(['/lab-results', { searchTerm: "##" + string }]);
  }

  getBlocks(){
    // ',' is a delimiter to separate the ids in the url
    let string: string = this.blockIds.join(",");
    this.router.navigate(['/greenhouse-block', { searchTerm: "##" + string }]);
  }
}
