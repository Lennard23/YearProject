import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-update-batch',
  templateUrl: './update-batch.component.html',
  styleUrls: ['./update-batch.component.css']
})
export class UpdateBatchComponent implements OnInit {

  form!: UntypedFormGroup;
  nextId: number = 0;
  batchList: Batch[] = [];
  coList: ClientOrder[] = [];
  co!: ClientOrder;
  cultList: Cultivar[] = [];
  cult!: Cultivar;
  crList: Coldroom[] = [];
  cr!: Coldroom | null;
  crDateIn: string = "";
  crDateOut: string = "";
  today!: string;
  plantDate!: string;
  plantDateFinal: string | null = null;
  harvestDateFinal: string | null = null;

  constructor(
    private toastService: ToastService,
    private service: BatchService,
    private service2: ClientOrderService,
    private service3: CultivarService,
    private service4: ColdroomService) { } 

  @Input() batch!: Batch;
  @Output() updateBatchEvent: EventEmitter<Batch | null> = new EventEmitter<Batch | null>();

  ngOnInit(): void {
    if (this.batch.plantDate != null) {
      this.plantDateFinal = this.batch.plantDate.split('T')[0];
    }
    if (this.batch.harvestDate != null) {
      this.harvestDateFinal = this.batch.harvestDate.split('T')[0];
    }
    if (this.batch.coldroomDateIn != null) {
      this.crDateIn = this.batch.coldroomDateIn.split('T')[0];
    }
    if (this.batch.coldroomDateOut != null) {
      this.crDateOut = this.batch.coldroomDateOut.split('T')[0];
    }
    this.today = new Date().toISOString().split('T')[0];
    this.plantDate = this.today;
    this.service2.getClientOrders().subscribe(data => {
      this.coList = data;
    });
    this.service3.getCultivars().subscribe(data => {
      this.cultList = data;
    });
    this.service4.getColdrooms().subscribe(data => {
      this.crList = data;
    });
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      cultId: new UntypedFormControl(this.batch.cultivarId, [Validators.required]),
      coId: new UntypedFormControl(this.batch.clientOrderId, [Validators.required]),
      crId: new UntypedFormControl(this.batch.coldroomId ?? "-- Select --"),
      regNum: new UntypedFormControl(null, [Validators.maxLength(255)]),
      pd: new UntypedFormControl(this.plantDateFinal ?? this.today),
      hd: new UntypedFormControl(this.harvestDateFinal ?? this.today),
      tp: new UntypedFormControl(0, [Validators.pattern("^[0-9]*$")]),
      scrap: new UntypedFormControl(this.batch.scrap, [Validators.pattern("^[0-9]*$")]),
      ty: new UntypedFormControl(this.batch.totalYield ?? 0, [Validators.pattern("^[0-9]*$")]),
      avgy: new UntypedFormControl(this.batch.avgYield ?? 0, [Validators.pattern("^[+]?([0-9]+\.?[0-9]*|\.[0-9]+)$")]),
      sample: new UntypedFormControl(this.batch.sample ?? 0, [Validators.pattern("^[0-9]*$")]),
      tb: new UntypedFormControl(this.batch.totalBags ?? 0, [Validators.pattern("^[0-9]*$")]),
      cdi: new UntypedFormControl(this.batch.coldroomDateIn?.substring(0, 10) ?? null),
      cdo: new UntypedFormControl(this.batch.coldroomDateOut?.substring(0, 10) ?? null),
    });
  }

  //handles form submission
  onSubmit() {
    // check if crId is selected
    if (this.form.value.crId != "-- Select --" && this.form.value.crId != null) {
      // find coldroom
      this.cr = this.crList.find(c => c.coldroomId == +this.form.value.crId)!;
    }
    else {
      this.cr = null;
    }
    // check if cultName is selected
    if (this.form.value.cultId == "-- Select --" || this.form.value.cultId == null) {
      this.toastService.show('Please select a cultivar!', { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    // check if coId is selected
    else if (this.form.value.coId == "-- Select --" || this.form.value.coId == null) {
      this.toastService.show('Please select a client order!', { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    else {
      // find cultivar
      this.cult = this.cultList.find(c => c.cultivarId == this.form.value.cultId)!;
      // find client order
      this.co = this.coList.find(c => c.clientOrderId == this.form.value.coId)!;
      // if plantDate and harvestDate are not null, convert them to c# DateTime format
      if (this.form.value.pd != null) {
        var pdfinal = this.form.value.pd.toString().substring(0, 10);
      }
      if (this.form.value.hd != null) {
        var hdfinal= this.form.value.hd.toString().substring(0, 10);
      }
      if (this.form.value.cdi != null) {
        var cdifinal = this.form.value.cdi.toString().substring(0, 10);
      }
      if (this.form.value.cdo != null) {
        var cdofinal = this.form.value.cdo.toString().substring(0, 10);
      }
      // build updated object
      let newBatch: Batch = {
        batchId: this.batch.batchId,
        coldroomId: this.cr?.coldroomId ?? null,
        clientOrderId: this.co.clientOrderId,
        cultivarId: this.cult.cultivarId,
        registrationNr: this.form.value.regNum ?? this.batch.registrationNr,
        plantDate: pdfinal ?? this.batch.plantDate,
        harvestDate: hdfinal ?? this.batch.harvestDate,
        totalPlanted: +this.form.value.tp ?? this.batch.totalPlanted,
        totalYield: +this.form.value.ty ?? this.batch.totalYield,
        scrap: +this.form.value.scrap ?? this.batch.scrap,
        sample: +this.form.value.sample ?? this.batch.sample,
        totalBags: +this.form.value.tb ?? this.batch.totalBags,
        avgYield: +this.form.value.avgy ?? this.batch.avgYield,
        status: this.batch.status,
        coldroomDateIn: cdifinal ?? this.batch.coldroomDateIn,
        coldroomDateOut: cdofinal ?? this.batch.coldroomDateOut,
        coldroom: this.cr ?? null,
        clientOrder: this.co,
        cultivar: this.cult,
        clientName: this.co.clientName,
        cultivarName: this.cult.name,
        labResults: this.batch.labResults ?? null,
        blocks: this.batch.blocks ?? null,
        batchSizeYields: this.batch.batchSizeYields ?? null
      };
      // update batch
      this.updateBatch(newBatch);
    }
  }

  //update batch
  updateBatch(batch: Batch) {
    return this.service.updateBatch(batch.batchId, batch).subscribe({
      next: () => {
        this.updateBatchEvent.emit(batch)
      },
      error: err => {
        console.log(err);
        this.updateBatchEvent.emit(null)
      }
    })
  }
}