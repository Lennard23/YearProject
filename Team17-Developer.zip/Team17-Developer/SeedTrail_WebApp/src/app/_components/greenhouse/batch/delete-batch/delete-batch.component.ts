import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-batch',
  templateUrl: './delete-batch.component.html',
  styleUrls: ['./delete-batch.component.css']
})
export class DeleteBatchComponent {

  constructor(private toastService: ToastService, private service: BatchService) { }

  @Input() batch!: Batch; 
  @Output() deleteBatchEvent: EventEmitter<Batch | null> = new EventEmitter<Batch | null>();

  //disables existing greenhouse
  onSubmit() {
    return this.service.checkRefIntegrity(this.batch.batchId).subscribe(res => {
      if (res == true) {
        this.service.disableBatch(this.batch.batchId, this.batch).subscribe({
          next: () => {
            this.deleteBatchEvent.emit(this.batch)
          },
          error: err => {
            console.log(err);
            this.deleteBatchEvent.emit(null)
          }
        });
      }
      else {
        this.toastService.show('This Batch has some Blocks, Yields or Lab Results that depend on it. You cannot delete it.', { classname: 'bg-secondary', delay: 6000 });
        return;
      }
    });
  }
}
