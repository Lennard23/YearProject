import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BatchSizeYield } from 'src/app/shared/_interfaces/batch-size-yield';
import { BatchSizeYieldService } from 'src/app/shared/_services/batch-size-yield.service';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-batch-size-yield',
  templateUrl: './batch-size-yield.component.html',
  styleUrls: ['./batch-size-yield.component.css']
})
export class BatchSizeYieldComponent implements OnInit {

  // Batch
  batchSizeYieldList: BatchSizeYield[] = [];
  batchSizeYield!: BatchSizeYield;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  batchSizeYieldForUpdate: boolean = false;
  batchSizeYieldForDelete: boolean = false;
  batchSizeYieldForView: boolean = false;

  constructor(
    private service: BatchSizeYieldService,
    private batchService: BatchService,
    private toastService: ToastService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getBatchSizeYields().subscribe(bsys => {
        if (this.searchTerm != null && this.searchTerm.includes("##")) {
          let batchSizeYieldIds = this.searchTerm.split("##")[1].split(",");
          this.batchSizeYieldList = bsys.filter(b => batchSizeYieldIds.includes(b.batchSizeYieldId.toString()));
        }
        else if (this.searchTerm != null && this.searchTerm.includes("BATID#")) {
          let batchId = this.searchTerm.split("BATID#")[1];
          this.batchSizeYieldList = bsys.filter(b => b.batchId == parseInt(batchId));
        }
        else {
          // if there's a search term, filter the batch size yields
          if (this.searchTerm != null && this.searchTerm != "") {
            this.batchSizeYieldList = bsys.filter(item => item.batchSizeYieldId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.batchId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.commditySizeId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.description!.toString().toLowerCase().includes(this.searchTerm.toLowerCase()));
          }
          else {
            // if there's no search term, return all batchs
            this.batchSizeYieldList = bsys;
          }
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/batch-size-yield', { searchTerm: this.searchTerm }]);
  }

  // view a batch size yield
  viewBatchSizeYield(batchSizeYield: BatchSizeYield) {
    if (!this.batchSizeYieldForView) {
      var cultivarName = "";
      var clientName = "";
      this.batchService.getBatchById(batchSizeYield.batchId).subscribe(data => {
        cultivarName = data.cultivarName;
        clientName = data.clientName;
        console.log(cultivarName, clientName, batchSizeYield.batchId);
        this.batchSizeYieldForView = true;
        this.batchSizeYieldForUpdate = false;
        this.batchSizeYieldForDelete = false;
        this.message = "#" + batchSizeYield.batchSizeYieldId.toString()
        this.desc = cultivarName + "'s for " + clientName;
        this.batchSizeYield = batchSizeYield;
        window.scroll({
          top: 0,
          left: 0,
          behavior: 'smooth'
        });
      });
    }
    else {
      this.batchSizeYield = batchSizeYield;
    }
  }
  viewBatchizeYieldReturn(batchSizeYield: BatchSizeYield | null) {
    if (batchSizeYield == null) {
      this.toastService.show("Failed to retrieve batch size yield", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (batchSizeYield != null && this.batchSizeYieldForView) {
      var cultivarName = "";
      var clientName = "";
      this.batchService.getBatchById(batchSizeYield.batchId).subscribe(data => {
        cultivarName = data.cultivarName;
        clientName = data.clientName;
        this.message = "#" + batchSizeYield.batchSizeYieldId.toString()
        this.desc = cultivarName + "'s for " + clientName;
      });
    }
  }
  // update a batch size yield
  updateBatchSizeYield(batchSizeYield: BatchSizeYield) {
    if (!this.batchSizeYieldForUpdate) {
      this.batchSizeYieldForUpdate = true;
      this.batchSizeYieldForDelete = false;
      this.batchSizeYieldForView = false;
      this.message = "#" + batchSizeYield.batchSizeYieldId.toString()
      this.desc = "Update batch size yield '" + batchSizeYield.batchSizeYieldId + "'"
      this.batchSizeYield = batchSizeYield;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.batchSizeYieldForUpdate = false;
      this.batchSizeYield = batchSizeYield;
    }
  }
  updateBatchSizeYieldReturn(batchSizeYield: BatchSizeYield | null) {
    if (batchSizeYield != null) {
      this.router.navigate(["/batch-size-yield"]);
      this.toastService.show('Batch Size Yield updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.batchSizeYieldForUpdate = false;
      this.toastService.show('Failed to update Batch Size Yield', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (batchSizeYield != null && this.batchSizeYieldForUpdate) {
      this.batchSizeYield = batchSizeYield;
      this.batchSizeYieldForUpdate = false;
    }
  }
  // delete a batch size yield
  deleteBatchSizeYield(batchSizeYield: BatchSizeYield) {
    if (!this.batchSizeYieldForDelete) {
      this.batchSizeYieldForDelete = true;
      this.batchSizeYieldForUpdate = false;
      this.batchSizeYieldForView = false;
      var cultivarName = "";
      var clientName = "";
      this.batchService.getBatchById(batchSizeYield.batchId).subscribe(data => {
        cultivarName = data.cultivarName;
        clientName = data.clientName;
        this.message = "#" + batchSizeYield.batchSizeYieldId.toString()
        this.desc = "Delete batch size yield for " + clientName + "'s " + cultivarName + "'s?"
        this.batchSizeYield = batchSizeYield;
        window.scroll({
          top: 0,
          left: 0,
          behavior: 'smooth'
        });
      });
    }
    else {
      this.batchSizeYieldForDelete = false;
      this.batchSizeYield = batchSizeYield;
    }
  }
  deleteBatchSizeYieldReturn(batchSizeYield: BatchSizeYield | null) {
    if (batchSizeYield != null) {
      this.batchSizeYieldList = this.batchSizeYieldList.filter(item => item.batchSizeYieldId != batchSizeYield.batchSizeYieldId);
      this.toastService.show('Batch Size Yield deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.batchSizeYieldForDelete = false;
      this.toastService.show('Failed to delete batch size yield', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (batchSizeYield != null && this.batchSizeYieldForDelete) {
      this.batchSizeYield = batchSizeYield;
      this.batchSizeYieldForDelete = false;
    }
  }

  //back
  back() {
    this.batchSizeYieldForView = false;
    this.batchSizeYieldForUpdate = false;
    this.batchSizeYieldForDelete = false;
    this.message = "";
    this.desc = "";
  }

  //historyback()
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
