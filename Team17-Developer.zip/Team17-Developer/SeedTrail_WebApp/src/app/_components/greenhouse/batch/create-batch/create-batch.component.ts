import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { ClientOrder } from 'src/app/shared/_interfaces/client-order';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ClientOrderService } from 'src/app/shared/_services/client-order.service';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-batch',
  templateUrl: './create-batch.component.html',
  styleUrls: ['./create-batch.component.css']
})
export class CreateBatchComponent implements OnInit {

  form!: UntypedFormGroup;
  batchList: Batch[] = [];
  coList: ClientOrder[] = [];
  co!: ClientOrder;
  cultList: Cultivar[] = [];
  cult!: Cultivar;
  today!: string;
  plantDate!: string;
  plantDateFinal: string | null = null;
  harvestDateFinal: string | null = null;
  dateReq!: string;
  displayDateReq: boolean = false;

  constructor(private toastService: ToastService, private service: BatchService, private service2: ClientOrderService, private service3: CultivarService, private router: Router) { }

  ngOnInit(): void {
    this.today = new Date().toISOString().split('T')[0];
    this.plantDate = this.today;
    this.service2.getIncompleteOrders().subscribe(data => {
      this.coList = data.map(item => {
        item.dateRequired = item.dateRequired!.toString().substring(0, 10);
        return item;
      });
    });
    this.service3.getCultivars().subscribe(data => {
      this.cultList = data;
    });
    this.createForm();
  }

  createForm() {
    this.form = new UntypedFormGroup({
      cultId: new UntypedFormControl("-- Select --", [Validators.required]),
      coId: new UntypedFormControl("-- Select --", [Validators.required]),
      regNum: new UntypedFormControl(null, [Validators.maxLength(255)]),
      pd: new UntypedFormControl(this.today),
      hd: new UntypedFormControl(null)
    });
  }

  //handles form submission
  onSubmit() {
    // check if cultName is selected
    if (this.form.value.cultId == "-- Select --" || this.form.value.cultId == null) {
      this.toastService.show("Please select a cultivar!", { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    // check if coId is selected
    if (this.form.value.coId == "-- Select --" || this.form.value.coId == null) {
      this.toastService.show("Please select a client order!", { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    else {
      // find cultivar
      this.cult = this.cultList.find(c => c.cultivarId == this.form.value.cultId)!;
      // find client order
      this.co = this.coList.find(c => c.clientOrderId == this.form.value.coId)!;
      // if plantDate and harvestDate are not null, convert them to c# DateTime format
      if (this.form.value.pd != null) {
        this.plantDateFinal = this.form.value.pd.toString().substring(0, 10);
      }
      if (this.form.value.hd != null) {
        this.harvestDateFinal = this.form.value.hd.toString().substring(0, 10);
      }
      // find nextId and create batch
      this.service.getAllBatches().subscribe(data => {
        this.batchList = data;
        let batch: Batch = {
          batchId: 0,
          coldroomId: null,
          clientOrderId: this.co.clientOrderId,
          cultivarId: this.cult.cultivarId,
          registrationNr: this.form.value.regNum ?? null,
          plantDate: this.plantDateFinal ?? null,
          harvestDate: this.harvestDateFinal ?? null,
          totalPlanted: 0,
          totalYield: 0,
          scrap: 0,
          sample: 0,
          totalBags: 0,
          clientName: this.co.clientName,
          cultivarName: this.cult.name,
          avgYield: 0.0,
          status: true,
          coldroomDateIn: null,
          coldroomDateOut: null,
          coldroom: null,
          clientOrder: this.co,
          cultivar: this.cult,
          labResults: null,
          blocks: null,
          batchSizeYields: null,
        };
        this.addBatch(batch);
      });
    }
  }

  updateCo(coId: number){
    this.co = this.coList.find(c => c.clientOrderId == coId)!;
    this.dateReq = this.co.dateRequired!.toString().substring(0, 10);
    if (this.form.value.hd != null){
      var datereq = new Date(this.dateReq);
      var datehd = new Date(this.form.value.hd.toString().substring(0, 10));
      if (this.co.dateRequired != null && datehd > datereq) {
        this.displayDateReq = true;
      }
      else {
        this.displayDateReq = false;
      }
    }
  }

  updateHd(hd: string){
    this.form.value.hd = hd;
    this.dateReq = this.co.dateRequired!.toString().substring(0, 10);
    if (this.form.value.hd != null){
      var datereq = new Date(this.dateReq);
      var datehd = new Date(this.form.value.hd.toString().substring(0, 10));
      if (this.co.dateRequired != null && datehd > datereq) {
        this.displayDateReq = true;
      }
      else {
        this.displayDateReq = false;
      }
    }
  }

  // adds new batch
  addBatch(batch: Batch) {
    return this.service.createBatch(batch).subscribe({
      next: () => {
        this.toastService.show('Batch created successfully', { classname: 'bg-primary text-light', delay: 2000 });
      },
      error: err => {
        console.log(err);
        this.toastService.show("Error creating batch\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
      }
    })
  }

  updatePd() {
    this.plantDateFinal = this.form.value.pd.toString().substring(0, 10);
  }

  // back form submission
  historyBack() {
    this.form.reset();
    window.history.back();
  }
}
