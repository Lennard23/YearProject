import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';

@Component({
  selector: 'app-view-greenhouse-status',
  templateUrl: './view-greenhouse-status.component.html',
  styleUrls: ['./view-greenhouse-status.component.css']
})
export class ViewGreenhouseStatusComponent implements OnInit {

  constructor(private dService: GreenhouseStatusService, private gService: GreenhouseService, private router: Router, private route: ActivatedRoute) { }

  @Input() greenhouseStatus!: GreenhouseStatus;
  @Output() viewGreenhouseStatusEvent: EventEmitter<GreenhouseStatus> = new EventEmitter<GreenhouseStatus>();

  routeGreenhouseId!: number;

  ngOnInit(): void {
  // update chosen greenhouse according to route params
    this.route.params.subscribe(params => {
      this.routeGreenhouseId = params['greenhouseStatusId'];
      if (this.routeGreenhouseId) {
        this.dService.getGreenhouseStatusesById(this.routeGreenhouseId).subscribe(res => {
          this.greenhouseStatus = res;
          this.viewGreenhouse(this.greenhouseStatus);
        });
      }
      else {
        this.router.navigate(["/view-greenhouse-status"]);
      }
    });
  }

  //updates existing greenhouse
  viewGreenhouse(greenhouse: GreenhouseStatus) {
    //use service's update function
    return this.dService.getGreenhouseStatusesById(greenhouse.greenhouseStatusId).subscribe(res => {
      this.greenhouseStatus= res;
      this.viewGreenhouseStatusEvent.emit(this.greenhouseStatus);
      this.routeGreenhouseId = this.greenhouseStatus.greenhouseStatusId;
      this.router.navigate(["/view-greenhouse-status", this.routeGreenhouseId])
    })
  }
}