import { Component, OnInit } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';

@Component({
  selector: 'app-greenhouseStatus',
  templateUrl: './greenhouse-status.component.html',
  styleUrls: ['./greenhouse-status.component.css']
})
export class GreenhouseStatusComponent implements OnInit {

  greenhouseStatusList: GreenhouseStatus[] = []

  constructor(private service: GreenhouseStatusService) { }

  ngOnInit(): void {
    this.service.getGreenhouseStatuses().subscribe(res => {
      this.greenhouseStatusList = res;
    });
  }
}
