import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-greenhouse',
  templateUrl: './delete-greenhouse.component.html',
  styleUrls: ['./delete-greenhouse.component.css']
})
export class DeleteGreenhouseComponent  {

  constructor(private toastService: ToastService, private service: GreenhouseService) { }

  @Input() greenhouse!: Greenhouse; 
  @Output() deleteGreenhouseEvent: EventEmitter<Greenhouse | null> = new EventEmitter<Greenhouse | null>();

  //handles form submission
  onSubmit() {
    let newItem: Greenhouse = {
      greenhouseId: this.greenhouse.greenhouseId,
      greenhouseStatusDescId: this.greenhouse.greenhouseStatusDescId,
      greenhouseNumber: this.greenhouse.greenhouseNumber,
      // change status to false
      status: false,
      greenhouseStatusDesc: this.greenhouse.greenhouseStatusDesc,
      greenhouseActivities: this.greenhouse.greenhouseActivities,
      greenhouseProductionInventories: this.greenhouse.greenhouseProductionInventories,
      greenhouseTables: this.greenhouse.greenhouseTables
    };
    this.deleteGreenhouse(newItem)
  }

  //disables existing greenhouse
  deleteGreenhouse(greenhouse: Greenhouse) {
    return this.service.checkRefIntegrity(this.greenhouse.greenhouseId).subscribe(res => {
      if (res == true) {
        this.toastService.show('This Greenhouse has some Inventory, Tables or Activities that depend on it. You cannot delete it.', { classname: 'bg-secondary', delay: 6000 });
        return;
      }
      else {
        this.service.disableGreenhouse(this.greenhouse.greenhouseId, this.greenhouse).subscribe({
          next: () => {
            this.deleteGreenhouseEvent.emit(greenhouse)
          },
          error: err => {
            console.log(err);
            this.deleteGreenhouseEvent.emit(null)
          }
        });
      }
    });
  }
}
