import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ActivityEntry } from 'src/app/shared/_interfaces/activity-entry';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseActivity } from 'src/app/shared/_interfaces/greenhouse-activity';
import { ActivityEntryService } from 'src/app/shared/_services/activity-entry.service';
import { GreenhouseActivityService } from 'src/app/shared/_services/greenhouse-activity.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';

@Component({
  selector: 'app-create-activity',
  templateUrl: './create-activity.component.html',
  styleUrls: ['./create-activity.component.css']
})
export class CreateActivityComponent implements OnInit {

  ghId:number =0;
  form!: UntypedFormGroup;
  activityEntryList: ActivityEntry[] = [];
  greenhouseList: Greenhouse[] = [];

  constructor(private service: GreenhouseActivityService,
    private service2: ActivityEntryService,
    private service3: GreenhouseService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.ghId = Number(this.route.snapshot.paramMap.get('Id'));

    this.service2.getActivities().subscribe((data: ActivityEntry[]) => {
      this.activityEntryList = data;

    });
    this.service3.getGreenhouses().subscribe((data: Greenhouse[]) => {
      this.greenhouseList = data;
    });
    this.form = new UntypedFormGroup({
      greenhouseId: new UntypedFormControl("--- Select ---", [Validators.required]),
      activityEntryId: new UntypedFormControl("--- Select ---", [Validators.required]),

      startDate: new UntypedFormControl(),
      endDate: new UntypedFormControl()
    });
  }

  //handles form submission
  onSubmit() {
    // if (this.form.value.greenhouseId == "--- Select ---" || this.form.value.greenhouseId == null) {
    //   alert("Please select an order status");
    //   return;
    // }
    if (this.form.value.activityEntryId == "--- Select ---" || this.form.value.activityEntryId == null) {
      alert("Please select a activityEntry");
      return;
    }
    if (this.form.value.startDate != null) {
      this.form.value.startDate = this.form.value.startDate.toString().substring(0, 10);
    }
    if (this.form.value.endDate != null) {
      this.form.value.endDate = this.form.value.endDate.toString().substring(0, 10);
    }
    if (this.form.valid) {
      //find activityEntry
      let activityEntry = this.activityEntryList.find(x => x.activityEntryId == this.form.value.activityEntryId);
      if (activityEntry == null) {
        alert("ActivityEntry not found");
        return;
      }
      //find order status
      let greenhouse = this.greenhouseList.find(x => x.greenhouseId == this.ghId);
      if (greenhouse == null) {
        alert("Greenhouse not found");
        return;
      }
      let greenhouseActivity: GreenhouseActivity = {
        greenhouseActivityId: 0,
        activityEntryId: activityEntry.activityEntryId,

        greenhouseId: this.ghId,

        startDate: this.form.value.startDate ?? null,
        endDate: null,
        status: true,

        activityEntry: activityEntry,
        greenhouse: greenhouse,
        employeeActivities: null
      };
      this.service.createGreenhouseActivity(greenhouseActivity).subscribe(() => {
        alert("ActivityEntry order created successfully");
        this.router.navigate(["/greenhouse-activities/"+this.ghId]);
      })
    }
  }
    //history back
    historyBack() {
      window.history.back();
    }
}


