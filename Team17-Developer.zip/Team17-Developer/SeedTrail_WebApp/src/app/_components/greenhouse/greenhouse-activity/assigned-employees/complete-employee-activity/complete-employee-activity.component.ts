import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeActivity } from 'src/app/shared/_interfaces/employee-activity';
import { GreenhouseActivity } from 'src/app/shared/_interfaces/greenhouse-activity';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { EmployeeActivityService } from 'src/app/shared/_services/employee-activity.service';
import { EmployeeService } from 'src/app/shared/_services/employee.service';
import { GreenhouseActivityService } from 'src/app/shared/_services/greenhouse-activity.service';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';

@Component({
  selector: 'app-complete-employee-activity',
  templateUrl: './complete-employee-activity.component.html',
  styleUrls: ['./complete-employee-activity.component.css']
})
export class CompleteEmployeeActivityComponent implements OnInit {

  ghaId:number=0;
  greenhouseActivityId! : number;
  pdtId :number=0;
  productionInventoryList: ProductionInventory[] =[]
  greenhouseActivity!: GreenhouseActivity;
  employee!: Employee;
  employeeActivities: EmployeeActivity[] =[];
  endDate!:string;

  startDate!: Date;
date!: string;
  
  employeeActivity!: EmployeeActivity;
  model!: NgbDateStruct;
  
  form!: FormGroup;
  
  nextId: number = 0;
  dynamicForm!: FormGroup;
  
  
    constructor(private service:EmployeeActivityService, 
      private service2: GreenhouseActivityService,
      private service3: EmployeeService,
      private service4: ProductionInventoryService,
      private service5: EmployeeActivityService, 
      private router: Router,
      private formBuilder: FormBuilder,
      private route: ActivatedRoute
      ) { }
  
    ngOnInit(): void {
      this.ghaId = Number(this.route.snapshot.paramMap.get('Id'));
      console.log(this.ghaId)
  
      this.service.getEmployeeActivityById(this.ghaId).subscribe((data: EmployeeActivity) => {
        this.employeeActivity = data;
      console.log(this.employeeActivity)

      this.startDate = new Date(this.employeeActivity.startDate!)

     this.startDate.setDate(this.startDate.getDate() + 2);
     console.log(this.startDate)

     this.date = this.startDate!.toISOString().substring(0, 10);
     console.log(this.date) 
  
      this.service2.getGreenhouseActivityById(this.employeeActivity.greenhouseActivityId).subscribe((data: GreenhouseActivity) => {
        this.greenhouseActivity = data;
      console.log(this.greenhouseActivity)
      })
  
      this.service3.getEmployeeById(this.employeeActivity.empId).subscribe((data: Employee)=> 
      {this.employee = data;}
      )
  
      this.service5.getEmployeeActivitiesByGhaId(this.employeeActivity.employeeActivityId).subscribe((data: EmployeeActivity[])=> 
      {this.employeeActivities = data;}
      )
      })
  
  
      
  
      this.form = new FormGroup({
        
        endDate: new FormControl("YYYY/MM/DD",[Validators.required])
  
      });
  
    }
  
       onSubmit(){
  
        if (this.form!.value.endDate != null) {
          this.endDate = this.form!.value.endDate.toString().substring(0, 10);
        }
  
      let employeeActivity: EmployeeActivity = {
        employeeActivityId: this.employeeActivity.employeeActivityId,
        greenhouseActivityId: this.employeeActivity.greenhouseActivityId,
        empId: this.employeeActivity.empId,
        startDate: this.employeeActivity.startDate!.toString().substring(0, 10),
        endDate: this.endDate,
        status: false,
        greenhouseActivity: this.greenhouseActivity,
        emp: this.employee
      };

      console.log(employeeActivity)
      this.service.updateEmployeeActivity(employeeActivity.employeeActivityId, employeeActivity).subscribe(() => {
        alert("Employee Activity Updated Successfully and completed");
       // this.updateGreenhouseActivityEvent.emit(employeeActivity);
        //this.router.navigate(["/employee"]).then(()=>{window.location.reload();});
        window.history.back();
        
      })
  }
  
  //history back
  historyBack() {
    window.history.back();
  }
}