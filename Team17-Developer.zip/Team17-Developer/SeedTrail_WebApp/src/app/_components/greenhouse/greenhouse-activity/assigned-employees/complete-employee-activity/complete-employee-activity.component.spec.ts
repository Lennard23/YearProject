import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteEmployeeActivityComponent } from './complete-employee-activity.component';

describe('CompleteEmployeeActivityComponent', () => {
  let component: CompleteEmployeeActivityComponent;
  let fixture: ComponentFixture<CompleteEmployeeActivityComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompleteEmployeeActivityComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CompleteEmployeeActivityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
