import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ActivityEntry } from 'src/app/shared/_interfaces/activity-entry';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeActivity } from 'src/app/shared/_interfaces/employee-activity';
import { GreenhouseActivity } from 'src/app/shared/_interfaces/greenhouse-activity';
import { ActivityEntryService } from 'src/app/shared/_services/activity-entry.service';
import { EmployeeActivityService } from 'src/app/shared/_services/employee-activity.service';
import { EmployeeService } from 'src/app/shared/_services/employee.service';
import { GreenhouseActivityService } from 'src/app/shared/_services/greenhouse-activity.service';

@Component({
  selector: 'app-assign',
  templateUrl: './assign.component.html',
  styleUrls: ['./assign.component.css']
})
export class AssignComponent implements OnInit {


   
  ghaId:number =0;
  form!: UntypedFormGroup;
  greenhouseActivityList: GreenhouseActivity[] = [];
  employeeList: Employee[] = [];
  startDate!: Date;
  date!: string;
  greenhouseActivity!: GreenhouseActivity;

  constructor(private service: EmployeeActivityService, 
    private service2: GreenhouseActivityService,
    private service3: EmployeeService, 
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.ghaId = Number(this.route.snapshot.paramMap.get('Id'));

    this.service2.getGreenhouseActivityById(this.ghaId).subscribe((data: GreenhouseActivity) => {
      this.greenhouseActivity = data;
    console.log(this.greenhouseActivity)

  this.startDate = new Date(this.greenhouseActivity.startDate!)

  this.startDate.setDate(this.startDate.getDate() + 1 );
  console.log(this.startDate)

  this.date = this.startDate!.toISOString().substring(0, 10);
  console.log(this.date) 
    })

    this.service2.getGreenhouseActivities().subscribe((data: GreenhouseActivity[]) => {
      this.greenhouseActivityList = data;

    });
    this.service3.getEmployees().subscribe((data: Employee[]) => {
      this.employeeList = data;
    });

    this.form = new UntypedFormGroup({
      empId: new UntypedFormControl("--- Select ---", [Validators.required]),
     // greenhouseActivityId: new UntypedFormControl("--- Select ---", [Validators.required]),
      
      startDate: new UntypedFormControl(),
      endDate: new UntypedFormControl()
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.empId == "--- Select ---" || this.form.value.empId == null) {
      alert("Please select an order status");
      return;
    }
//    if (this.form.value.greenhouseActivityId == "--- Select ---" || this.form.value.greenhouseActivityId == null) {
 //     alert("Please select a greenhouseActivity");
  //    return;
    
    if (this.form.value.startDate != null) {
      this.form.value.startDate = this.form.value.startDate.toString().substring(0, 10);
    }
    // if (this.form.value.endDate != null) {
    //   this.form.value.endDate = this.form.value.endDate.toString().substring(0, 10);
    // }
    if (this.form.valid) {
      //find greenhouseActivity
      let greenhouseActivity = this.greenhouseActivityList.find(x => x.greenhouseActivityId == this.ghaId);
      if (greenhouseActivity == null) {
        alert("GreenhouseActivity not found");
        return;
      }
      //find order status
      let employee = this.employeeList.find(x => x.empId == this.form.value.empId);
      if (employee == null) {
        alert("Employee not found");
        return;
      }

      console.log(employee)

      let employeeActivity: EmployeeActivity = {
        employeeActivityId: 0,
        greenhouseActivityId: this.ghaId,
        //greenhouseActivityName: greenhouseActivity.name,
        empId: this.form.value.empId,
        // description: this.form.value.description,
        startDate: this.form.value.startDate ?? null,
        endDate: null,
        status: true,
        //batches: null,
        greenhouseActivity: greenhouseActivity,
        emp: employee
      };
      console.log(employeeActivity)
      this.service.createEmployeeActivity(employeeActivity).subscribe(() => {
        alert("Employee Activity created successfully");
        window.history.back()
        //this.router.navigate(["/greenhouseActivity-order"]);
      })
    }
  }
  //history back
  historyBack() {
    window.history.back();
  }
}

