import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup,  UntypedFormGroup,  Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { ActivityEntry } from 'src/app/shared/_interfaces/activity-entry';
import { EmployeeActivity } from 'src/app/shared/_interfaces/employee-activity';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseActivity } from 'src/app/shared/_interfaces/greenhouse-activity';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { ActivityEntryService } from 'src/app/shared/_services/activity-entry.service';
import { EmployeeActivityService } from 'src/app/shared/_services/employee-activity.service';
import { GreenhouseActivityService } from 'src/app/shared/_services/greenhouse-activity.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';

@Component({
  selector: 'app-complete-greenhouse-activity',
  templateUrl: './complete-greenhouse-activity.component.html',
  styleUrls: ['./complete-greenhouse-activity.component.css']
})
export class CompleteGreenhouseActivityComponent implements OnInit {
ghaId:number=0;
activityEntryId! : number;
pdtId :number=0;
productionInventoryList: ProductionInventory[] =[]
activityEntry!: ActivityEntry;
greenhouse!: Greenhouse;
employeeActivities: EmployeeActivity[] =[];
endDate!:string;
startDate!: Date;
date!: string;
greenhouseActivity!: GreenhouseActivity;
model!: NgbDateStruct;

form!: FormGroup;

nextId: number = 0;
dynamicForm!: FormGroup;


  constructor(private service:GreenhouseActivityService, 
    private service2: ActivityEntryService,
    private service3: GreenhouseService,
    private service4: ProductionInventoryService,
    private service5: EmployeeActivityService, 
    private router: Router,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute
    ) { }

  ngOnInit(): void {
    this.ghaId = Number(this.route.snapshot.paramMap.get('Id'));
    console.log(this.ghaId)

    this.service.getGreenhouseActivityById(this.ghaId).subscribe((data: GreenhouseActivity) => {
      this.greenhouseActivity = data;
    console.log(this.greenhouseActivity)

  this.startDate = new Date(this.greenhouseActivity.startDate!)

  this.startDate.setDate(this.startDate.getDate() + 1);
  console.log(this.startDate)

  this.date = this.startDate!.toISOString().substring(0, 10);
  console.log(this.date)  

  
    this.service2.getActivityById(this.greenhouseActivity.activityEntryId).subscribe((data: ActivityEntry) => {
      this.activityEntry = data;
    console.log(this.activityEntry)
    })

    this.service3.getGreenhouseById(this.greenhouseActivity.greenhouseId).subscribe((data: Greenhouse)=> 
    {this.greenhouse = data;}
    )

    this.service5.getEmployeeActivitiesByGhaId(this.greenhouseActivity.greenhouseActivityId).subscribe((data: EmployeeActivity[])=> 
    {this.employeeActivities = data;}
    )
    })

     this.form = new FormGroup({
      
      endDate: new FormControl("YYYY/MM/DD",[Validators.required])

    });

   
  }
 //history back
  historyBack() {
    window.history.back();
  }
     onSubmit(){

      if (this.form!.value.endDate != null) {
        this.endDate = this.form!.value.endDate.toString().substring(0, 10);
      }

    let greenhouseActivity: GreenhouseActivity = {
      greenhouseActivityId: this.greenhouseActivity.greenhouseActivityId,
      activityEntryId: this.greenhouseActivity.activityEntryId,
      greenhouseId: this.greenhouseActivity.greenhouseId,
      startDate: this.greenhouseActivity.startDate!.toString().substring(0, 10),
      endDate: this.endDate,
      status: false,
      activityEntry: this.activityEntry,
      greenhouse: this.greenhouse,
      employeeActivities: this.employeeActivities
    };
    
    this.service.updateGreenhouseActivity(greenhouseActivity.greenhouseActivityId, greenhouseActivity).subscribe(() => {
      alert("Greenhouse Activity Updated Successfully ");
     // this.updateActivityEntryEvent.emit(greenhouseActivity);
      this.router.navigate(["/greenhouse"]).then(()=>{window.location.reload();});
      
    })
    

}

  //     this.activityEntryId = this.greenhouseActivity.activityEntryId;

  //     if (this.activityEntryId = 2)
  //     {this.pdtId = 5}
  //     if (this.activityEntryId = 4)
  //     {this.pdtId = 1}
  //     if (this.activityEntryId = 5)
  //     {this.pdtId = 6}
  //     if (this.activityEntryId = 9)
  //     {this.pdtId = 3}

  // if (this.pdtId !== 0)
  // { this.service4.getProductionInventoriesById(this.pdtId).subscribe((data: ProductionInventory[]) => {
  //   this.productionInventoryList = data;})
  //   this.form = this.formBuilder.group({
  //       usage: []
 
  //       });



  

     

      

      


  

  
    
  
 

     



  }


