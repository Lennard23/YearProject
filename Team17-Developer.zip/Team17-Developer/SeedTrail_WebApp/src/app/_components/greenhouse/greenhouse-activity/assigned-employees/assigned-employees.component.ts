import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ActivityEntry } from 'src/app/shared/_interfaces/activity-entry';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeActivity } from 'src/app/shared/_interfaces/employee-activity';
import { ActivityEntryService } from 'src/app/shared/_services/activity-entry.service';
import { EmployeeActivityService } from 'src/app/shared/_services/employee-activity.service';
import { EmployeeService } from 'src/app/shared/_services/employee.service';
import { GreenhouseActivity } from 'src/app/shared/_interfaces/greenhouse-activity';
import { GreenhouseActivityService } from 'src/app/shared/_services/greenhouse-activity.service';

@Component({
  selector: 'app-assigned-employees',
  templateUrl: './assigned-employees.component.html',
  styleUrls: ['./assigned-employees.component.css']
})
export class AssignedEmployeesComponent implements OnInit {

  ghaId: number = 0;



  searchTerm: string = "";

  // loading
  loading: boolean = true;

  form!: UntypedFormGroup;
  nextId: number = 0;
  empActList: EmployeeActivity[] = [];
  actList: ActivityEntry[] = []; //shows list of activities in greenhouse
  empList: Employee[] = []; // shows employees that can do greenhouse activities
  emp!: Employee;
  empAct!: EmployeeActivity;
  act!: ActivityEntry;
  // ghList: GreenhouseActivity[] = [];
  gh!: GreenhouseActivity;
  ghList!: any;
  tempList!: any [];

  list:any = [];
  employeeActivityList: EmployeeActivity[] = []
  employeeActivity!: EmployeeActivity;


  //private service: EmployeeActivityService, private service2: ActivityEntryService, private service3: EmployeeService,
  constructor( private employeeActivityService: EmployeeActivityService, private service2: ActivityEntryService, private service3: EmployeeService,private ghService: GreenhouseActivityService ,private router: Router, private route: ActivatedRoute) { }



  ngOnInit(): void {
    
    this.ghaId = Number(this.route.snapshot.paramMap.get('Id'));

      //subscribe to router param changes
      this.loading = true;
      this.route.params.subscribe(params => {
        this.searchTerm = params['SearchTerm']; // this is empty an string if param not found
       this.employeeActivityService.getEmployeeActivitiesByGhaId(this.ghaId).subscribe(employeeActivities => {
         this.employeeActivityList = employeeActivities; 
         console.log(this.employeeActivityList)
         this.list.push(this.employeeActivityList) 
         console.log(this.list)

       
         console.log(this.employeeActivityList)
         // if there's a search term, filter the cultivars
         if (this.searchTerm != null && this.searchTerm != "") {
           this.employeeActivityList = employeeActivities.filter(item => item.employeeActivityId?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
             item.employeeActivityId.toString().includes(this.searchTerm.trim().toLowerCase()) );
             
         }
         else {
           // if there's no search term, return all cultivars
           this.employeeActivityList = employeeActivities;
          
         }
       });
       this.loading = false;
      // alert('List!! :-)\n\n' + JSON.stringify(this.employeeActivityList, null, 4));
     });

     


     
 console.log(this.ghaId);
 console.log(this.employeeActivityList)

 console.log(this.list)

   


 }

  createForm() {
    this.form = new UntypedFormGroup({
      actId: new UntypedFormControl("-- Select --", [Validators.required]),
      empName: new UntypedFormControl("-- Select --", [Validators.required]),

      sd: new UntypedFormControl(null),
    });
  }
  // Search function
  search() {
    this.router.navigate(['/greenhouse', { searchTerm: this.searchTerm }]);
  }

  //handles form submission
  onSubmit() {
    //check if employee name is selected
    if (this.form.value.empName == "-- Select --" || this.form.value.actId == null) {
      alert("Please select an employee");
      return;
    }
        // check if actId is selected
    if (this.form.value.actId == "-- Select --" || this.form.value.actId == null) {
      alert("Please select an activity");
      return;
    }
    else {
      // find employee
      this.emp = this.empList.find(c => c.name == this.form.value.empName)!;


      // find activity
      this.act = this.actList.find(c => c.activityEntryId == this.form.value.actId)!;
      // if end date is not null, convert to c# DateTime format
      if (this.form.value.sd != null) {
        this.form.value.sd = this.form.value.sd.toString().substring(0, 10);
      }
      for (let a = 0; a < this.ghList.length; a++){
      this.ghService.getGreenhouseActivityById(this.ghList[a]).subscribe((res) => {
        // this.tempList.push({res['EmpName']+ ""+ res['ActTitle']})

        // this.ghService.GetActList(this.ghList[])

        // this.Name = this.ghList.Name;
        // Title = this.ghList.Title;
        // Sd = this.ghList.Sd;
        // GhNum = this.ghList.ghn
      })


        // this.empActList = data;
        // this.nextId = data.length + 1;
        // let empActivity: EmployeeActivity= {
        //   employeeActivityId: this.nextId,
        //   //  activityEntryId: this.act.activityEntryId,
        //   empId: this.emp.empId,
        //   startDate: this.form.value.sd,
        //   endDate: null,
        //   status: true,
        //   greenhouseActivityId: this.gh.greenhouseActivityId,
        //   greenhouseActivity: this.gh,
        //   emp: this.emp
      // };
        //this.AssignActivity(empActivity);
      }
      console.log(this.act.activityEntryId)
    }
  }

  //Assign Activity to employee
  AssignActivity(empActivity: EmployeeActivity){
    return this.employeeActivityService.createEmployeeActivity(empActivity).subscribe(() => {
      this.router.navigate(["/scheduling"])
    })
  }

  cancel(){
    this.form.reset();
    this.router.navigate(["/assign-employee-activity"])
  }




  //history back
  historyBack() {
    window.history.back();
  }

  AssignEmployee(){
    return;
  }


}
