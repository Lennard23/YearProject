import { Component, Input, OnInit, AfterViewInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ActivityEntry } from 'src/app/shared/_interfaces/activity-entry';
import { ActivityType } from 'src/app/shared/_interfaces/activity-type';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseActivity } from 'src/app/shared/_interfaces/greenhouse-activity';
import { GreenhouseStatus } from 'src/app/shared/_interfaces/greenhouse-status';
import { ActivityEntryService } from 'src/app/shared/_services/activity-entry.service';
import { ActivityTypeService } from 'src/app/shared/_services/activity-type.service';
import { GreenhouseActivityService } from 'src/app/shared/_services/greenhouse-activity.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';

@Component({
  selector: 'app-greenhouse-activity',
  templateUrl: './greenhouse-activity.component.html',
  styleUrls: ['./greenhouse-activity.component.css']
})
export class GreenhouseActivityComponent implements OnInit {
  ghId: number = 0;
  // Search filtering
  searchTerm: string = "";

  // loading
  loading: boolean = true;

  // CRUD functionality
  list: any = []
  anotherList: any = []
  greenhouseActivityList: GreenhouseActivity[] = []
  greenhouseForUpdate: boolean = false;
  greenhouseForDelete: boolean = false;
  greenhouseForView: boolean = false;
  greenhouseActivity!: GreenhouseActivity;

  activityTypes: ActivityType[] = [];
  activityEntries: ActivityEntry[] = [];

  @Input() greenhouseId = undefined;


  constructor(private greenhouseActivityService: GreenhouseActivityService,
    private activityEntryService: ActivityEntryService,
    private activityTypeService: ActivityTypeService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.ghId = Number(this.route.snapshot.paramMap.get('Id'));
    console.log(this.ghId)
    this.route.params.subscribe(params => {
      this.searchTerm = params['SearchTerm']; // this is empty an string if param not found
      this.greenhouseActivityService.getGreenhouseActivityByGhId(this.ghId).subscribe(greenhouseActivities => {
        this.greenhouseActivityList = greenhouseActivities;
        //console.log(this.greenhouseActivityList)
        this.list.push(this.greenhouseActivityList)
        console.log(this.list)
        // if there's a search term, filter the cultivars
       if (this.searchTerm != null && this.searchTerm != "") {
          this.greenhouseActivityList = greenhouseActivities.filter(item => item.greenhouseActivityId?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.greenhouseActivityId.toString().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all cultivars
          this.greenhouseActivityList = greenhouseActivities;

        }
      });

    });
  }

  //history back
  historyBack() {
    window.history.back();
  }

  search() {
    this.router.navigate(['/greenhouse/', { Id: this.searchTerm }]);
  }

}
