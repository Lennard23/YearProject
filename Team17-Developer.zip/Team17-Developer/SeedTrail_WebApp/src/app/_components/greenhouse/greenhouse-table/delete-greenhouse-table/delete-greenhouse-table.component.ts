import { Component, EventEmitter, Input, Output } from '@angular/core';
import { GreenhouseTable } from 'src/app/shared/_interfaces/greenhouse-table';
import { GreenhouseTableService } from 'src/app/shared/_services/greenhouse-table.service';

@Component({
  selector: 'app-delete-greenhouse-table',
  templateUrl: './delete-greenhouse-table.component.html',
  styleUrls: ['./delete-greenhouse-table.component.css']
})
export class DeleteGreenhouseTableComponent {
  
  constructor(private service: GreenhouseTableService) { }

  @Input() greenhouseTable!: GreenhouseTable
  @Output() deleteGreenhouseTableEvent: EventEmitter<GreenhouseTable | null> = new EventEmitter<GreenhouseTable | null>();

  onSubmit() {
    let newItem: GreenhouseTable = {
      tableId: this.greenhouseTable.tableId,
      greenhouseId: this.greenhouseTable.greenhouseId,
      blockId: this.greenhouseTable.blockId,
      tableTotalCrates: this.greenhouseTable.tableTotalCrates,
      status: false,
      block: this.greenhouseTable.block,
      greenhouse: this.greenhouseTable.greenhouse
    };
    this.service.disableGreenhouseTable(this.greenhouseTable.tableId, newItem).subscribe({
      next: () => {
        this.deleteGreenhouseTableEvent.emit(newItem)
      },
      error: err => {
        console.log(err);
        this.deleteGreenhouseTableEvent.emit(null)
      }
    });
  }
}
