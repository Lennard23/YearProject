import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Block } from 'src/app/shared/_interfaces/block';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseTable } from 'src/app/shared/_interfaces/greenhouse-table';
import { BlockService } from 'src/app/shared/_services/block.service';
import { GreenhouseStatusDescriptionService } from 'src/app/shared/_services/greenhouse-status-description.service';
import { GreenhouseStatusService } from 'src/app/shared/_services/greenhouse-status.service';
import { GreenhouseTableService } from 'src/app/shared/_services/greenhouse-table.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-greenhouse-table',
  templateUrl: './create-greenhouse-table.component.html',
  styleUrls: ['./create-greenhouse-table.component.css']
})
export class CreateGreenhouseTableComponent implements OnInit {

  constructor(
    private service: GreenhouseTableService,
    private ghService: GreenhouseService,
    private ghStatDescService: GreenhouseStatusDescriptionService,
    private ghStatService: GreenhouseStatusService,
    private blockService: BlockService,
    private toastService: ToastService,
    private router: Router
  ) { }

  form!: UntypedFormGroup;
  ghList!: Greenhouse[];
  chosenGreenhouse!: Greenhouse;
  blockList!: Block[];
  chosenBlock!: Block;
  isActive: boolean = true;

  ngOnInit(): void {
    this.ghService.getGreenhouses().subscribe(data => {
      this.ghList = data;
    });
    this.blockService.getAllBlocks().subscribe(data => {
      this.blockList = data;
    });
    this.form = new UntypedFormGroup({
      tc: new UntypedFormControl(1, [Validators.pattern('^[0-9]+$')]),
      ghId: new UntypedFormControl("-- Select --", [Validators.required]),
      blockId: new UntypedFormControl("-- Select --", [Validators.required])
    });
  }

  // handles form submission
  onSubmit() {

    // check if a block is not selected
    if (this.form.value.blockId == "-- Select --" || this.form.value.blockId == null) {
      this.toastService.show("Please select a Block", { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    // check if a greenhouse is not selected
    else if (this.form.value.ghId == "-- Select --" || this.form.value.ghId == null) {
      this.toastService.show("Please select a Greenhouse", { classname: 'bg-secondary', delay: 5000 });
      return;
    }
    else {
      if (this.form.valid) {
        // find Block
        this.chosenBlock = this.blockList.find(c => c.blockId == this.form.value.blockId)!;
        // find Greenhouse
        this.chosenGreenhouse = this.ghList.find(c => c.greenhouseId == this.form.value.ghId)!;
        // build GreenhouseTable object
        let newGht: GreenhouseTable = {
          tableId: 0,
          blockId: this.chosenBlock.blockId,
          greenhouseId: this.chosenGreenhouse.greenhouseId,
          tableTotalCrates: +this.form.value.tc,
          status: true,
          block: this.chosenBlock,
          greenhouse: this.chosenGreenhouse
        };
        this.service.createGreenhouseTable(newGht).subscribe({
          next: () => {
            this.toastService.show('Table created successfully', { classname: 'bg-primary text-light', delay: 2000 });
          },
          error: err => {
            console.log(err);
            this.toastService.show("Error creating table!\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
          }
        });
      }
    }
  }

  newgh(ghId: number) {
    this.ghService.getGreenhouseById(ghId).subscribe({
      next: data => {
        this.chosenGreenhouse = data;
        this.ghStatDescService.getGreenhouseStatusDescriptionById(this.chosenGreenhouse.greenhouseStatusDescId).subscribe({
          next: data => {
            this.chosenGreenhouse.greenhouseStatusDesc = data;
            this.ghStatService.getGreenhouseStatusesById(data.greenhouseStatusId).subscribe({
              next: data => {
                this.chosenGreenhouse.greenhouseStatusDesc.greenhouseStatus = data;
                if (data.ghstatus != "Active") {
                  this.isActive = false;
                }
                else {
                  this.isActive = true;
                }
              },
              error: err => {
                console.log(err);
              }
            });
          },
          error: err => {
            console.log(err);
          }
        });
      },
      error: err => {
        console.log(err);
        this.toastService.show("Error getting greenhouse!\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
      }
    });
  }

  // back button
  historyBack() {
    this.form.reset();
    window.history.back();
  }
}