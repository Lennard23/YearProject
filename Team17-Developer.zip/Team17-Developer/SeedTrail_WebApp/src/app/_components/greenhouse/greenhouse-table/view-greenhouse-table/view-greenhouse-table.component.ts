import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Block } from 'src/app/shared/_interfaces/block';
import { Greenhouse } from 'src/app/shared/_interfaces/greenhouse';
import { GreenhouseTable } from 'src/app/shared/_interfaces/greenhouse-table';
import { BlockService } from 'src/app/shared/_services/block.service';
import { GreenhouseTableService } from 'src/app/shared/_services/greenhouse-table.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';

@Component({
  selector: 'app-view-greenhouse-table',
  templateUrl: './view-greenhouse-table.component.html',
  styleUrls: ['./view-greenhouse-table.component.css']
})
export class ViewGreenhouseTableComponent implements OnChanges {

  constructor(
    private router: Router,
    private service: GreenhouseTableService,
    private blockService: BlockService,
    private ghService: GreenhouseService) { }

  blockDesc: string | null = null;
  greenhouseNum: string = '';

  @Input() greenhouseTable!: GreenhouseTable;
  @Output() viewGreenhouseTableEvent: EventEmitter<GreenhouseTable | null> = new EventEmitter<GreenhouseTable | null>();

  ngOnChanges(): void { 
    this.service.getGreenhouseTableById(this.greenhouseTable.tableId).subscribe({
      next: (data: GreenhouseTable) => {
        this.greenhouseTable = data;
        this.blockService.getBlockById(this.greenhouseTable.blockId!).subscribe({
          next: (data: Block) => {
            this.blockDesc = data.blockId.toString() + " - " + data.description;
            this.ghService.getGreenhouseById(this.greenhouseTable.greenhouseId!).subscribe({
              next: (data: Greenhouse) => {
                this.greenhouseNum = data.greenhouseNumber.toString() ?? this.greenhouseTable.greenhouseId;
              },
              error: (err: any) => {
                console.log(err);
              }
            });
          },
          error: (err: any) => {
            console.log(err);
          }
        });
        this.viewGreenhouseTableEvent.emit(this.greenhouseTable);
      },
      error: (err: any) => {
        console.log(err);
        this.viewGreenhouseTableEvent.emit(null);
      }
    });
  }

  viewBlock(){
    this.router.navigate(['/greenhouse-block', { searchTerm: "GHBID#" + this.greenhouseTable.blockId }]);
  }

  viewGreenhouse(){
    this.router.navigate(['/greenhouse', { searchTerm: "GHID#" + this.greenhouseTable.greenhouseId }]);
  }
}
