import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GreenhouseTable } from 'src/app/shared/_interfaces/greenhouse-table';
import { GreenhouseTableService } from 'src/app/shared/_services/greenhouse-table.service';
import { GreenhouseService } from 'src/app/shared/_services/greenhouse.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-greenhouse-table',
  templateUrl: './greenhouse-table.component.html',
  styleUrls: ['./greenhouse-table.component.css']
})
export class GreenhouseTableComponent implements OnInit {

  searchTerm!: string;
  message: string = '';
  desc: string = '';
  greenhouseTableList: GreenhouseTable[] = []
  greenhouseTable!: GreenhouseTable;
  greenhouseTableForUpdate: boolean = false;
  greenhouseTableForDelete: boolean = false;
  greenhouseTableForView: boolean = false;

  constructor(
    private toastService: ToastService,
    private service: GreenhouseTableService,
    private ghService: GreenhouseService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getGreenhouseTable().subscribe(tables => {
        // if there's a search term, filter the tables
        // ## is followed by a list of Greenhouse Table IDs (delimited by commas)
        if (this.searchTerm != null && this.searchTerm.includes("##")) {
          let tableIds = this.searchTerm.split("##")[1].split(",");
          this.greenhouseTableList = tables.filter(t => tableIds.includes(t.tableId.toString()));
        }
        else if (this.searchTerm != null && this.searchTerm.includes("GHID#")) {
          this.greenhouseTableList = tables.filter(t => t.greenhouseId.toString() == this.searchTerm.split("GHID#")[1].trim());
        }
        else {
          if (this.searchTerm != null && this.searchTerm != "") {
            this.greenhouseTableList = tables.filter(item => item.tableId?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.greenhouseId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.blockId.toString().includes(this.searchTerm.trim().toLowerCase()));
          }
          else {
            // if there's no search term, return all blocks
            this.greenhouseTableList = tables;
          }
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/greenhouse-table', { searchTerm: this.searchTerm }]);
  }

  //gets single greenhouseTable
  async getGreenhouseTable(id: number) {
    return this.service.getGreenhouseTableById(id).subscribe((data: GreenhouseTable) => {
      //return a greenhouseTable object
      return data;
    })
  }

  viewGreenhouseTable(greenhouseTable: GreenhouseTable) {
    if (!this.greenhouseTableForView) {
      this.greenhouseTableForView = true;
      this.greenhouseTableForUpdate = false;
      this.greenhouseTableForDelete = false;
      this.ghService.getGreenhouseById(greenhouseTable.greenhouseId).subscribe(gh => {
        this.message = "Table ID#" + greenhouseTable.tableId.toString()
        this.desc = "Table \"" + greenhouseTable.tableId + "\" of Greenhouse #" + gh.greenhouseNumber.toString()
        this.greenhouseTable = greenhouseTable;
        window.scroll({
          top: 0,
          left: 0,
          behavior: 'smooth'
        });
      });
    }
    else {
      this.greenhouseTable = greenhouseTable;
    }
  }
  viewGreenhouseTableReturn(ght: GreenhouseTable | null) {
    if (ght == null) {
      this.toastService.show("Failed to retrieve Greenhouse Table", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (ght != null && this.greenhouseTableForView) {
      this.ghService.getGreenhouseById(ght.greenhouseId).subscribe(gh => {
        this.message = "Table ID#" + ght.tableId.toString()
        this.desc = "Table \"" + ght.tableId + "\" of Greenhouse #" + gh.greenhouseNumber.toString()
      });
    }
  }

  updateGreenhouseTable(greenhouseTable: GreenhouseTable) {
    if (!this.greenhouseTableForUpdate) {
      this.greenhouseTableForUpdate = true;
      this.greenhouseTableForDelete = false;
      this.greenhouseTableForView = false;
      this.message = "Table ID#" + greenhouseTable.tableId.toString()
      this.desc = "Update Table '" + greenhouseTable.tableId.toString() + "'";
      this.greenhouseTable = greenhouseTable;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.greenhouseTable = greenhouseTable;
      this.greenhouseTableForUpdate = false;
    }
  }
  updateGreenhouseTableReturn(ght: GreenhouseTable | null) {
    if (ght != null) {
      this.router.navigate(["/greenhouse-table"]);
      this.toastService.show('Greenhouse Table updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.greenhouseTableForUpdate = false;
      this.toastService.show('Failed to update Greenhouse Table', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (ght != null && this.greenhouseTableForUpdate) {
      this.greenhouseTable = ght;
      this.greenhouseTableForUpdate = false;
    }
  }

  deleteGreenhouseTable(greenhouseTable: GreenhouseTable) {
    if (!this.greenhouseTableForDelete) {
      this.greenhouseTableForDelete = true;
      this.greenhouseTableForUpdate = false;
      this.greenhouseTableForView = false;
      this.message = "Table ID#" + greenhouseTable.tableId.toString()
      this.desc = "Delete Table '" + greenhouseTable.tableId.toString() + "'?";
      this.greenhouseTable = greenhouseTable;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.greenhouseTable = greenhouseTable;
    }
  }
  deleteGreenhouseTableReturn(greenhouseTable: GreenhouseTable | null) {
    if (greenhouseTable != null) {
      this.greenhouseTableList = this.greenhouseTableList.filter(t => t.tableId != greenhouseTable.tableId);
      this.router.navigate(["/greenhouse-table"]);
      this.toastService.show('Table deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.greenhouseTableForDelete = false;
      this.toastService.show('Failed to delete table', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (greenhouseTable != null && this.greenhouseTableForDelete) {
      this.greenhouseTable = greenhouseTable;
      this.greenhouseTableForDelete = false;
    }
  }

  //back
  back() {
    this.greenhouseTableForUpdate = false;
    this.greenhouseTableForDelete = false;
    this.greenhouseTableForView = false;
  }

  //historyBack
  historyBack() {
    window.history.back();
  }
}
