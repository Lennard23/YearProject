import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Block } from 'src/app/shared/_interfaces/block';
import { BlockService } from 'src/app/shared/_services/block.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-block',
  templateUrl: './delete-block.component.html',
  styleUrls: ['./delete-block.component.css']
})
export class DeleteBlockComponent {

  constructor(private toastService: ToastService, private service: BlockService, private router: Router) {}

  @Input() block!: Block
  @Output() deleteBlockEvent: EventEmitter<Block | null> = new EventEmitter<Block | null>();

  //handles form submission
  onSubmit() {
    let newItem: Block = {
      blockId: this.block.blockId,
      batchId: this.block.batchId,
      description: this.block.description,
      status: false,
      batch: this.block.batch,
      greenhouseTables: this.block.greenhouseTables
    };
    this.service.checkRefIntegrity(this.block.blockId).subscribe(res => {
      if (res == true) {
        this.service.disableBlock(this.block.blockId, newItem).subscribe({
          next: () => {
            this.deleteBlockEvent.emit(this.block)
          },
          error: err => {
            console.log(err);
            this.deleteBlockEvent.emit(null)
          }
        });
      }
      else {
        this.toastService.show('This Block has some Tables that depend on it. You cannot delete it.', { classname: 'bg-secondary', delay: 6000 });
        return;
      }
    });
  }
}
