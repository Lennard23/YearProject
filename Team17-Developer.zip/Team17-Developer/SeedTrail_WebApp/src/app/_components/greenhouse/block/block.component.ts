import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Block } from 'src/app/shared/_interfaces/block';
import { BlockService } from 'src/app/shared/_services/block.service';
import { ActivatedRoute } from '@angular/router';
import { ToastService } from 'src/app/shared/_services/toast.service';
@Component({
  selector: 'app-block',
  templateUrl: './block.component.html',
  styleUrls: ['./block.component.css']
})
export class BlockComponent implements OnInit {

  // Block
  blockList: Block[] = [];
  block!: Block;

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  blockForUpdate: boolean = false;
  blockForDelete: boolean = false;
  blockForView: boolean = false;
  message: string = "";
  desc: string = "";

  constructor(private toastService: ToastService, private service: BlockService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getBlocks().subscribe(blocks => {
        // if there's a search term, filter the blocks
        if (this.searchTerm != null && this.searchTerm.includes("GHBID#")) {
          this.message = "> with Block ID#" + this.searchTerm.replace("GHBID#", "");
          this.blockList = blocks.filter(block => block.blockId == parseInt(this.searchTerm.split("#")[1]));
        }
        else if (this.searchTerm != null && this.searchTerm.includes("#BIDS#")) {
          let blockIds = this.searchTerm.split("#BIDS#")[1].split(",");
          this.blockList = blocks.filter(t => blockIds.includes(t.blockId.toString()));
        }
        else if (this.searchTerm != null && this.searchTerm.includes("##")) {
          let blockIds = this.searchTerm.split("##")[1].split(",");
          this.blockList = blocks.filter(b => blockIds.includes(b.blockId.toString()));
        }
        else {
          if (this.searchTerm != null && this.searchTerm != "") {
            this.blockList = blocks.filter(item => item.batchId?.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.blockId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.description?.toString().includes(this.searchTerm.trim().toLowerCase()));
          }
          else {
            // if there's no search term, return all blocks
            this.blockList = blocks;
          }
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/greenhouse-block', { searchTerm: this.searchTerm }]);
  }

  //gets single block
  async getBlock(id: number) {
    return this.service.getBlockById(id).subscribe((data: Block) => {
      //return a block object
      return data;
    })
  }

  // view a block
  viewBlock(block: Block) {
    if (!this.blockForView) {
      this.blockForView = true;
      this.blockForUpdate = false;
      this.blockForDelete = false;
      this.message = "#" + block.blockId.toString()
      this.desc = "Description: \"" + (block.description ?? block.blockId) + "\""
      this.block = block;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.block = block;
    }
  }
  viewBlockReturn(block: Block | null) {
    if (block == null) {
      this.toastService.show("Failed to retrieve block", { classname: 'bg-danger text-light', delay: 3000 });
    }
    if (block != null && this.blockForView) {
      this.message = "#" + block.blockId.toString()
      this.desc = "Description: \"" + (block.description ?? block.blockId) + "\""
    }
  }
  // update a block
  updateBlock(block: Block) {
    if (!this.blockForUpdate) {
      this.blockForUpdate = true;
      this.blockForDelete = false;
      this.blockForView = false;
      this.message = "#" + block.blockId.toString()
      this.desc = "Update \"" + (block.description ?? block.blockId) + "\""
      this.block = block;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.blockForUpdate = false;
      this.block = block;
    }
  }
  updateBlockReturn(block: Block | null) {
    if (block != null) {
      this.router.navigate(["/greenhouse-block"]);
      this.toastService.show('Block updated successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.blockForUpdate = false;
      this.toastService.show('Failed to update Block', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (block != null && this.blockForUpdate) {
      this.block = block;
      this.blockForUpdate = false;
    }
  }
  // delete a block
  deleteBlock(block: Block) {
    if (!this.blockForDelete) {
      this.blockForDelete = true;
      this.blockForUpdate = false;
      this.blockForView = false;
      this.message = "#" + block.blockId.toString()
      this.desc = "Delete Block \"" + (block.description ?? block.blockId) + "\"?"
      this.block = block;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.blockForDelete = false;
      this.block = block;
    }
  }
  deleteBlockReturn(block: Block | null) {
    if (block != null) {
      this.blockList = this.blockList.filter(b => b.blockId != block.blockId);
      this.router.navigate(["/greenhouse-block"]);
      this.toastService.show('Block deleted successfully', { classname: 'bg-primary text-light', delay: 2000 });
    }
    else {
      this.blockForDelete = false;
      this.toastService.show('Failed to delete block', { classname: 'bg-danger text-light', delay: 5000 });
    }
    if (block != null && this.blockForDelete) {
      this.block = block;
      this.blockForDelete = false;
    }
  }

  //back
  back() {
    this.blockForView = false;
    this.blockForUpdate = false;
    this.blockForDelete = false;
    this.message = "";
    this.desc = "";
  }

  //historyback()
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
