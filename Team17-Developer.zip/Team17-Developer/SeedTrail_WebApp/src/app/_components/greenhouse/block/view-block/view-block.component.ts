import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Block } from 'src/app/shared/_interfaces/block';
import { GreenhouseTable } from 'src/app/shared/_interfaces/greenhouse-table';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { BlockService } from 'src/app/shared/_services/block.service';

@Component({
  selector: 'app-view-block',
  templateUrl: './view-block.component.html',
  styleUrls: ['./view-block.component.css']
})
export class ViewBlockComponent implements OnChanges {

  constructor(private service: BlockService, private batchService: BatchService, private router: Router) { }

  ghtCount: number = 0;
  ghtIds: number[] = [];
  clientName: string | null = "";
  cultivarName: string | null = "";
  batId: number = 0;
  batchName: string = "";

  @Input() block!: Block
  @Output() viewBlockEvent: EventEmitter<Block | null> = new EventEmitter<Block | null>();

  ngOnChanges(): void {
    this.service.getBlockById(this.block.blockId).subscribe({
      next: (data: Block) => {
        this.block = data;
        this.batchService.getBatchById(this.block.batchId!).subscribe({
          next: (data: any) => {
            this.batId = data.batchId;
            this.clientName = data.clientName;
            this.cultivarName = data.cultivarName;
            this.batchName = data.clientName + " - " + data.cultivarName;
          },
          error: (err: any) => {
            console.log(err);
          }
        });
        this.service.getBlockTables(this.block.blockId).subscribe((res: GreenhouseTable[]) => {
          this.block.greenhouseTables = res;
          this.ghtIds = res.map(t => t.tableId);
          this.ghtCount = res.length;
        });
        this.viewBlockEvent.emit(this.block)
        this.router.navigate(["/greenhouse-block"])
      },
      error: (err: any) => {
        console.log(err);
        this.viewBlockEvent.emit(null)
      }
    });
  }

  getGht() {
    // ',' is a delimiter to separate the ids in the url
    let string: string = this.ghtIds.join(",");
    this.router.navigate(['/greenhouse-table', { searchTerm: "##" + string }]);
  }

  viewBatch() {
    this.router.navigate(['/greenhouse-batch', { searchTerm: "BATID#" + this.batId }]);
  }
}
