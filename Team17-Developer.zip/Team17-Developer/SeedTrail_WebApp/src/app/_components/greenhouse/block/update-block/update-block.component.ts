import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { Block } from 'src/app/shared/_interfaces/block';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { BlockService } from 'src/app/shared/_services/block.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-update-block',
  templateUrl: './update-block.component.html',
  styleUrls: ['./update-block.component.css']
})
export class UpdateBlockComponent implements OnInit {

  form!: UntypedFormGroup;
  batch!: Batch | null;
  batchList: Batch[] = [];

  constructor(private toastService: ToastService, private service: BlockService, private service2: BatchService, private router: Router) { }

  @Input() block!: Block
  @Output() updateBlockEvent: EventEmitter<Block | null> = new EventEmitter<Block | null>();

  ngOnInit(): void {
    this.service2.getBatches().subscribe(data => {
      this.batchList = data.filter(a => a.harvestDate == null);
    });
    this.form = new UntypedFormGroup({
      batchId: new UntypedFormControl(this.block.batchId, [Validators.required]),
      desc: new UntypedFormControl(this.block.description, [Validators.required, Validators.maxLength(255)])
    });
  }

  //handles form submission
  onSubmit() {
    // find batch
    if (this.form.value.batchId == null || this.form.value.batchId == "-- Select --") {
      this.toastService.show('Please select a Batch!', { classname: 'bg-secondary', delay: 5000 });
    }
    else {
      this.batch = this.batchList.find(x => x.batchId == this.form.value.batchId)!;
    }
    if (this.form.valid && this.batch != null) {
      let block: Block = {
        blockId: this.block.blockId,
        status: this.block.status,
        batchId: this.batch!.batchId ?? this.block.batchId,
        batch: this.batch ?? this.block.batch,
        description: this.form.value.desc ?? this.block.description,
        greenhouseTables: this.block.greenhouseTables
      }
      this.updateBlock(block)
    }
  }

  //update new block
  updateBlock(block: Block) {
    return this.service.updateBlock(block.blockId, block).subscribe({
      next: () => {
        this.updateBlockEvent.emit(block)
      },
      error: err => {
        console.log(err);
        this.updateBlockEvent.emit(null)
      }
    })
  }

  // cancels form submission
  cancel() {
    this.form.reset();
    this.router.navigate(["/greenhouse-block"]);
  }

  // back form submission
  historyBack() {
    this.form.reset();
    window.history.back();
  }
}
