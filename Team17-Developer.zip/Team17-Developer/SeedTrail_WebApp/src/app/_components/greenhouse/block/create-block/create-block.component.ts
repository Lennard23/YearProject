import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Block } from 'src/app/shared/_interfaces/block';
import { BlockService } from 'src/app/shared/_services/block.service';
import { Router } from '@angular/router';
import { Batch } from 'src/app/shared/_interfaces/batch';
import { BatchService } from 'src/app/shared/_services/batch.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-create-block',
  templateUrl: './create-block.component.html',
  styleUrls: ['./create-block.component.css']
})
export class CreateBlockComponent implements OnInit {

  constructor(private toastService: ToastService, private service: BlockService, private service2: BatchService, private router: Router) { }

  form!: UntypedFormGroup;
  batch!: Batch | null;
  batchList: Batch[] = [];

  ngOnInit(): void {
    this.service2.getBatches().subscribe(data => {
      this.batchList = data.filter(a => a.harvestDate == null).map(item => {
        if (item.plantDate != null) {
          item.plantDate = item.plantDate!.toString().substring(0, 10);
        }
        return item;
      });;
    });
    this.form = new UntypedFormGroup({
      batchId: new UntypedFormControl("-- Select --", [Validators.required]),
      desc: new UntypedFormControl(null, [Validators.required, Validators.maxLength(255)])
    });
  }

  //handles form submission
  onSubmit() {
    // find batch
    if (this.form.value.batchId == null || this.form.value.batchId == "-- Select --") {
      this.toastService.show('Please select a Batch!', { classname: 'bg-secondary', delay: 5000 });
    }
    else {
      this.batch = this.batchList.find(x => x.batchId == this.form.value.batchId)!;
    }
    if (this.form.valid && this.batch != null) {
      let block: Block = {
        blockId: 0,
        status: true,
        batchId: this.batch!.batchId,
        batch: this.batch,
        description: this.form.value.desc ?? null,
        greenhouseTables: null
      }
      this.addBlock(block)
    }
  }

  //adds new block
  addBlock(block: Block) {
    return this.service.createBlock(block).subscribe({
      next: () => {
        this.toastService.show('Block created successfully', { classname: 'bg-primary text-light', delay: 2000 });
        this.router.navigate(["/greenhouse-block"]);
      },
      error: err => {
        console.log(err);
        this.toastService.show("Error creating block\n" + err.error, { classname: 'bg-danger text-light', delay: 5000 });
      }
    })
  }

  // cancels form submission
  cancel() {
    this.form.reset();
    this.router.navigate(["/greenhouse-block"]);
  }

  // back form submission
  historyBack() {
    this.form.reset();
    window.history.back();
  }
}
