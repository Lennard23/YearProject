import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';

@Component({
  selector: 'app-view-coldroom',
  templateUrl: './view-coldroom.component.html',
  styleUrls: ['./view-coldroom.component.css']
})
export class ViewColdroomComponent implements OnInit {

  constructor(private service: ColdroomService, private router: Router) { }

  @Input() coldroom!: Coldroom
  @Output() viewColdroomEvent: EventEmitter<Coldroom> = new EventEmitter<Coldroom>();

  ngOnInit(): void {
    this.viewColdroom(this.coldroom)
  }

  //updates existing coldroom
  viewColdroom(coldroom: Coldroom) {
    //use service's update function
    return this.service.getColdroomById(coldroom.coldroomId).subscribe(res => {
      this.coldroom = res;
      this.viewColdroomEvent.emit(coldroom)
      this.router.navigate(["/coldroom"])
    })
  }
}