import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';

@Component({
  selector: 'app-create-coldroom',
  templateUrl: './create-coldroom.component.html',
  styleUrls: ['./create-coldroom.component.css']
})
export class CreateColdroomComponent implements OnInit {

  form!: UntypedFormGroup;

  constructor(private service: ColdroomService, private router: Router) { }

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.maxLength(30)]),
      description: new UntypedFormControl("", [Validators.maxLength(255)])
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.description == "" || this.form.value.description == null) {
      this.form.value.description = null;
    }
    if (this.form.valid) {
      // build object
      let coldroom: Coldroom = {
        coldroomId: 0,
        name: this.form.value.name,
        description: this.form.value.description ?? null,
        status: true,
        batches: null
      };
      this.addColdroom(coldroom);
    }
  }

  //adds new coldroom
  addColdroom(coldroom: Coldroom) {
    return this.service.createColdroom(coldroom).subscribe(() => {
      alert("Coldroom created successfully");
      this.router.navigate(["/coldroom"]);
    })
  }
        // Back in history
        historyBack() {
          this.form.reset();
          window.history.back();
        }
}
