import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';

@Component({
  selector: 'app-delete-coldroom',
  templateUrl: './delete-coldroom.component.html',
  styleUrls: ['./delete-coldroom.component.css']
})
export class DeleteColdroomComponent {

  constructor(private service: ColdroomService, private router: Router) { }

  @Input() coldroom!: Coldroom;
  @Output() deleteColdroomEvent: EventEmitter<Coldroom> = new EventEmitter<Coldroom>();

  delete(coldroom: Coldroom) {
    this.service.disableColdroom(coldroom.coldroomId, coldroom).subscribe(res => {
      alert("Coldroom successfully deleted");
      this.router.navigate(['/coldroom']);
      this.deleteColdroomEvent.emit(coldroom);
      window.location.reload();
    });
  }
}
