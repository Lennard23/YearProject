import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';

@Component({
  selector: 'app-update-coldroom',
  templateUrl: './update-coldroom.component.html',
  styleUrls: ['./update-coldroom.component.css']
})
export class UpdateColdroomComponent implements OnInit {
  
  form!: UntypedFormGroup;

  constructor(private service: ColdroomService, private router: Router) { }

  @Input() coldroom!: Coldroom;
  @Output() updateColdroomEvent: EventEmitter<Coldroom> = new EventEmitter<Coldroom>();

  ngOnInit(): void { 
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.coldroom.name, [Validators.required, Validators.maxLength(30)]),
      description: new UntypedFormControl(this.coldroom.description, [Validators.maxLength(255)])
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.description == "" || this.form.value.description == null) {
      this.form.value.description = null;
    }
    if (this.form.valid) {
      // build object
      let newItem: Coldroom = {
        coldroomId: this.coldroom.coldroomId,
        name: this.form.value.name ?? this.coldroom.name,
        description: this.form.value.description ?? this.coldroom.description,
        status: this.coldroom.status,
        batches: this.coldroom.batches
      };
      this.updateColdroom(newItem);
    }
    else {
      alert("Please fill out all fields");
    }
  }

  //updates existing coldroom
  updateColdroom(coldroom: Coldroom) {
    //use service's update function
    return this.service.updateColdroom(coldroom.coldroomId, coldroom).subscribe(res => {
      alert("Coldroom updated successfully!");
      this.updateColdroomEvent.emit(coldroom)
      this.router.navigate(["/coldroom"])
      window.location.reload();
    })
  }
}
