import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Coldroom } from 'src/app/shared/_interfaces/coldroom';
import { ColdroomService } from 'src/app/shared/_services/coldroom.service';

@Component({
  selector: 'app-coldroom',
  templateUrl: './coldroom.component.html',
  styleUrls: ['./coldroom.component.css']
})
export class ColdroomComponent implements OnInit {

  // Coldroom
  coldroomList: Coldroom[] = [];
  coldroom!: Coldroom;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  coldroomForUpdate: boolean = false;
  coldroomForDelete: boolean = false;
  coldroomForView: boolean = false;

  constructor(private service: ColdroomService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getColdrooms().subscribe(coldrooms => {
        // if there's a search term, filter the coldrooms
        if (this.searchTerm != null && this.searchTerm != "") {
          this.coldroomList = coldrooms.filter(item => item.name!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.coldroomId.toString().includes(this.searchTerm.trim().toLowerCase())) ;
        }
        else {
          // if there's no search term, return all coldrooms
          this.coldroomList = coldrooms;
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/coldroom', { searchTerm: this.searchTerm }]);
  }

  //gets single coldroom
  async getColdroom(id: number) {
    return this.service.getColdroomById(id).subscribe((data: Coldroom) => {
      //return a coldroom object
      return data;
    })
  }

  // view a coldroom
  viewColdroom(coldroom: Coldroom) {
    if (!this.coldroomForView) {
      this.coldroomForView = true;
      this.coldroomForUpdate = false;
      this.coldroomForDelete = false;
      this.message = "ID#" + coldroom.coldroomId.toString()
      this.desc = "'" + (coldroom.name ?? "") + "'";
      this.coldroom = coldroom;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.coldroom = coldroom;
    }
  }
  // update a coldroom
  updateColdroom(coldroom: Coldroom) {
    if (!this.coldroomForUpdate) {
      this.coldroomForUpdate = true;
      this.coldroomForDelete = false;
      this.coldroomForView = false;
      this.message = "ID#" + coldroom.coldroomId.toString()
      this.desc = "Update coldroom '" + (coldroom.name ?? "") + "'";
      this.coldroom = coldroom;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.coldroomForUpdate = false;
      this.coldroom = coldroom;
    }
  }
  // delete a coldroom
  deleteColdroom(coldroom: Coldroom) {
    if (!this.coldroomForDelete) {
      this.coldroomForDelete = true;
      this.coldroomForUpdate = false;
      this.coldroomForView = false;
      this.message = "ID#" + coldroom.coldroomId.toString()
      this.desc = "Do you want to delete '" + (coldroom.name ?? "") + "'?";
      this.coldroom = coldroom;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.coldroomForDelete = false;
      this.coldroom = coldroom;
    }
  }

  // back
  back() {
    this.coldroomForUpdate = false;
    this.coldroomForDelete = false;
    this.coldroomForView = false;
    this.message = "";
    this.desc = "";
  }

  //history back
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
