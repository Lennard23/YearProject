import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { CommodityService } from 'src/app/shared/_services/commodity.service';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';

@Component({
  selector: 'app-view-cultivar',
  templateUrl: './view-cultivar.component.html',
  styleUrls: ['./view-cultivar.component.css']
})
export class ViewCultivarComponent implements OnInit {

  commodityName!: string;

  constructor(private service: CultivarService, private comService: CommodityService, private router: Router) { }

  @Input() cultivar!: Cultivar
  @Output() viewCultivarEvent: EventEmitter<Cultivar> = new EventEmitter<Cultivar>();

  ngOnInit(): void {
    this.comService.getCommodityById(this.cultivar.commodityId).subscribe(commodity => {
      this.commodityName = commodity.name;
    });
    this.service.getCultivarById(this.cultivar.cultivarId).subscribe(res => {
      this.cultivar = res;
      this.viewCultivarEvent.emit(this.cultivar)
      this.router.navigate(["/cultivar"])
    })
  }
}
