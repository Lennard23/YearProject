import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-cultivar',
  templateUrl: './cultivar.component.html',
  styleUrls: ['./cultivar.component.css']
})
export class CultivarComponent implements OnInit {

  // Cultivar
  cultivarList: Cultivar[] = [];
  cultivar!: Cultivar;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  cultivarForUpdate: boolean = false;
  cultivarForDelete: boolean = false;
  cultivarForView: boolean = false;

  constructor(private service: CultivarService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getCultivars().subscribe(cultivars => {
        // if there's a search term, filter the cultivars
        if (this.searchTerm != null && this.searchTerm != "") {
          this.cultivarList = cultivars.filter(item => item.name?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.cultivarId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.description?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all cultivars
          this.cultivarList = cultivars;
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/cultivar', { searchTerm: this.searchTerm }]);
  }

  //gets single cultivar
  async getCultivar(id: number) {
    return this.service.getCultivarById(id).subscribe((data: Cultivar) => {
      //return a cultivar object
      return data;
    })
  }

  // view a cultivar
  viewCultivar(cultivar: Cultivar) {
    if (!this.cultivarForView) {
      this.cultivarForView = true;
      this.cultivarForUpdate = false;
      this.cultivarForDelete = false;
      this.message = "ID#" + cultivar.cultivarId.toString()
      this.desc = "'" + (cultivar.name ?? "") + "'";
      this.cultivar = cultivar;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + cultivar.cultivarId.toString()
      this.desc = "'" + (cultivar.name ?? "") + "'";
      this.cultivar = cultivar;
    }
  }
  // update a cultivar
  updateCultivar(cultivar: Cultivar) {
    if (!this.cultivarForUpdate) {
      this.cultivarForUpdate = true;
      this.cultivarForDelete = false;
      this.cultivarForView = false;
      this.message = "ID#" + cultivar.cultivarId.toString()
      this.desc = "Update cultivar '" + (cultivar.name ?? "") + "'";
      this.cultivar = cultivar;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "";
      this.desc = "";
      this.cultivarForUpdate = false;
      this.cultivar = cultivar;
    }
  }
  // delete a cultivar
  deleteCultivar(cultivar: Cultivar) {
    if (!this.cultivarForDelete) {
      this.cultivarForDelete = true;
      this.cultivarForUpdate = false;
      this.cultivarForView = false;
      this.message = "ID#" + cultivar.cultivarId.toString()
      this.desc = "Do you want to delete cultivar '" + (cultivar.name ?? "") + "'?";
      this.cultivar = cultivar;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + cultivar.cultivarId.toString()
      this.desc = "Do you want to delete cultivar '" + (cultivar.name ?? "") + "'?";
      this.cultivar = cultivar;
    }
  }

  // Back in history
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }

  // back
  back() {
    this.message = "";
    this.desc = "";
    this.cultivarForUpdate = false;
    this.cultivarForDelete = false;
    this.cultivarForView = false;
    this.router.navigate(['/cultivar']);
  }
}
