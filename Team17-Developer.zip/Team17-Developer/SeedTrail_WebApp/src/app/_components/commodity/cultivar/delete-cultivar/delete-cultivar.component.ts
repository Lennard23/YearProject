import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';

@Component({
  selector: 'app-delete-cultivar',
  templateUrl: './delete-cultivar.component.html',
  styleUrls: ['./delete-cultivar.component.css']
})
export class DeleteCultivarComponent {

  constructor(private service: CultivarService, private router: Router) { }

  @Input() cultivar!: Cultivar;
  @Output() deleteCultivarEvent: EventEmitter<Cultivar> = new EventEmitter<Cultivar>();

  //handles form submission
  onSubmit() {
    this.service.disableCultivar(this.cultivar.cultivarId, this.cultivar).subscribe(res => {
      alert("Cultivar deleted successfully");
      this.router.navigate(['/cultivar']);
      this.deleteCultivarEvent.emit(this.cultivar)
      window.location.reload();
    })
  }
}
