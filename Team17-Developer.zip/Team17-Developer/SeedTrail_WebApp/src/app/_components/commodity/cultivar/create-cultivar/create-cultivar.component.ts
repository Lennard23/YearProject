import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';
import { Router } from '@angular/router';
import { CommodityService } from 'src/app/shared/_services/commodity.service';
import { Commodity } from 'src/app/shared/_interfaces/commodity';

@Component({
  selector: 'app-create-cultivar',
  templateUrl: './create-cultivar.component.html',
  styleUrls: ['./create-cultivar.component.css']
})
export class CreateCultivarComponent implements OnInit {

  form!: UntypedFormGroup;
  commodities!: Commodity[]

  constructor(private service: CultivarService, private commsService: CommodityService, private router: Router) { }

  ngOnInit(): void {
    this.commsService.getCommodity().subscribe(data => {
      this.commodities = data;
    });
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      commodityId: new UntypedFormControl("--- Select ---", [Validators.required]),
      description: new UntypedFormControl("", [Validators.required, Validators.minLength(3), Validators.maxLength(255)]),
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.commodityId == "--- Select ---" ||
      this.form.value.commodityId == "" ||
      this.form.value.commodityId == null) {
      alert("Please select a commodity");
      return;
    }
    else {
      if (this.form.valid) {
        // find commodity
        let commodity = this.commodities.find(c => c.commodityId == +this.form.value.commodityId);
        if (commodity == null || commodity == undefined) {
          alert("Invalid commodity!");
          return;
        }
        // build object
        let cultivar: Cultivar = {
          cultivarId: 0,
          commodityId: commodity.commodityId,
          name: this.form.value.name,
          description: this.form.value.description,
          status: true,
          commodity: commodity,
          batches: null
        }
        // create
        this.service.createCultivar(cultivar).subscribe(() => {
          alert("Cultivar added successfully");
          this.router.navigate(["/cultivar"]);
        })
      }
    }
  }
        // Back in history
        historyBack() {
          this.form.reset();
          window.history.back();
        }
}
