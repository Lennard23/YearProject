import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Commodity } from 'src/app/shared/_interfaces/commodity';
import { Cultivar } from 'src/app/shared/_interfaces/cultivar';
import { CommodityService } from 'src/app/shared/_services/commodity.service';
import { CultivarService } from 'src/app/shared/_services/cultivar.service';

@Component({
  selector: 'app-update-cultivar',
  templateUrl: './update-cultivar.component.html',
  styleUrls: ['./update-cultivar.component.css']
})
export class UpdateCultivarComponent implements OnInit {

  form!: UntypedFormGroup;
  commodities!: Commodity[];
  commodityName: string = "";

  constructor(private service: CultivarService, private comService: CommodityService, private router: Router) { }

  @Input() cultivar!: Cultivar;
  @Output() updateCultivarEvent: EventEmitter<Cultivar> = new EventEmitter<Cultivar>();

  ngOnInit(): void {
    this.comService.getCommodity().subscribe(data => {
      this.commodities = data;
      this.commodityName = this.commodities.find(c => c.commodityId == this.cultivar.commodityId)?.name || "";
    });
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.cultivar.name, [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      commodityId: new UntypedFormControl(this.commodityName, [Validators.required]),
      description: new UntypedFormControl(this.cultivar.description, [Validators.required, Validators.minLength(3), Validators.maxLength(255)]),
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.commodityId == "" || this.form.value.commodityId == null) {
      alert("Please select a commodity");
      return;
    }
    else {
      if (this.form.valid) {
        // find commodity
        let commodity = this.commodities.find(c => c.commodityId == +this.form.value.commodityId);
        if (commodity == null || commodity == undefined) {
          alert("Invalid commodity selection!");
          return;
        }
        // build object
        let cultivar: Cultivar = {
          cultivarId: this.cultivar.cultivarId,
          commodityId: commodity.commodityId,
          name: this.form.value.name ?? this.cultivar.name,
          description: this.form.value.description ?? this.cultivar.description,
          status: this.cultivar.status,
          commodity: commodity,
          batches: this.cultivar.batches
        }
        // create
        this.service.updateCultivar(cultivar.cultivarId, cultivar).subscribe(() => {
          alert("Cultivar updated successfully");
          this.form.reset();
          this.updateCultivarEvent.emit(cultivar);
          this.router.navigate(["/cultivar"]);
          window.location.reload();
        })
      }
    }
  }
}
