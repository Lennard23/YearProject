import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Commodity } from 'src/app/shared/_interfaces/commodity';
import { CommodityService } from 'src/app/shared/_services/commodity.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-commodity',
  templateUrl: './delete-commodity.component.html',
  styleUrls: ['./delete-commodity.component.css']
})
export class DeleteCommodityComponent {

  constructor(private toastService: ToastService, private service: CommodityService, private router: Router) { }

  @Input() commodity!: Commodity;
  @Output() deleteCommodityEvent: EventEmitter<Commodity | null> = new EventEmitter<Commodity | null>();

  //handles form submission
  onSubmit() {
    this.service.checkRefIntegrity(this.commodity.commodityId).subscribe(res => {
      console.log(res)
      if (res == true) {
        this.toastService.show('Commodity is in use. Cannot delete.', { classname: 'bg-secondary', delay: 5000 });
        console.log(this.commodity)
        return;
      }
      else {
        this.service.disableCommodity(this.commodity.commodityId, this.commodity).subscribe({
          next: () => {
            this.deleteCommodityEvent.emit(this.commodity)

          },
          error: err => {
            console.log(err);
            this.deleteCommodityEvent.emit(null);
          }
        });
      }
    });
  }
}
