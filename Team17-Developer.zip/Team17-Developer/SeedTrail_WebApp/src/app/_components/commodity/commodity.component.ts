import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Commodity } from 'src/app/shared/_interfaces/commodity';
import { CommodityService } from 'src/app/shared/_services/commodity.service';

@Component({
  selector: 'app-commodity',
  templateUrl: './commodity.component.html',
  styleUrls: ['./commodity.component.css']
})
export class CommodityComponent implements OnInit {

  // Search filtering
  searchTerm: string = "";

  commodity!: Commodity;
  commodityList: Commodity[] = []
  commodityForUpdate: boolean = false;
  commodityForDelete: boolean = false;
  commodityForView: boolean = false;
  message: string = "";
  desc: string = "";

  constructor(private service: CommodityService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getCommodity().subscribe(commodities => {
        // if there's a search term, filter the cultivars
        if (this.searchTerm != null && this.searchTerm != "") {
          this.commodityList = commodities.filter(item => item.name?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.commodityId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.description?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all cultivars
          this.commodityList = commodities;
        }
      });
    });
  }

  //search function
  search(): void {
    this.router.navigate(['/commodity', { searchTerm: this.searchTerm }]);
  }

  //gets single commodity
  async getCommodity(id: number) {
    return this.service.getCommodityById(id).subscribe((data: Commodity) => {
      //return a commodity object
      return data;
    })
  }

  viewCommodity(commodity: Commodity) {
    if (!this.commodityForView) {
      this.commodityForView = true;
      this.commodityForUpdate = false;
      this.commodityForDelete = false;
      this.message = "ID#" + commodity.commodityId.toString()
      this.desc = "'" + commodity.name + "'";
      this.commodity = commodity;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + commodity.commodityId.toString()
      this.desc = "'" + commodity.name + "'";
      this.commodity = commodity;
    }
  }

  updateCommodity(commodity: Commodity) {
    if (!this.commodityForUpdate) {
      this.commodityForUpdate = true;
      this.commodityForDelete = false;
      this.commodityForView = false;
      this.message = "ID#" + commodity.commodityId.toString()
      this.desc = "Update commodity '" + commodity.name + "'";
      this.commodity = commodity;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.commodity = commodity;
      this.commodityForUpdate = false;
    }
  }

  deleteCommodity(commodity: Commodity) {
    if (!this.commodityForDelete) {
      this.commodityForDelete = true;
      this.commodityForUpdate = false;
      this.commodityForView = false;
      this.message = "ID#" + commodity.commodityId.toString()
      this.desc = "Do you want to delete commodity '" + commodity.name + "'?";
      this.commodity = commodity;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.commodity = commodity;
      this.commodityForDelete = false;
    }
  }

  //back
  back() {
    this.commodityForView = false;
    this.commodityForUpdate = false;
    this.commodityForDelete = false;
    this.message = "";
    this.desc = "";
  }

  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
