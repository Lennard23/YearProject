import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Commodity } from 'src/app/shared/_interfaces/commodity';
import { CommodityService } from 'src/app/shared/_services/commodity.service';

@Component({
  selector: 'app-create-commodity',
  templateUrl: './create-commodity.component.html',
  styleUrls: ['./create-commodity.component.css']
})
export class CreateCommodityComponent implements OnInit {

  form!: UntypedFormGroup;

  constructor(private service: CommodityService, private router: Router) { }

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      description: new UntypedFormControl("", [Validators.maxLength(255)]),
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.valid) {
      // build a new commodity object from the form values
      let commodity: Commodity = {
        commodityId: 0,
        name: this.form.value.name,
        description: this.form.value.description ?? null,
        status: true,
        batchSizeYields: null,
        commoditySizes: null,
        cultivars: null
      }
      this.service.createCommodity(commodity).subscribe(() => {
        alert("Commodity successfully created");
        this.router.navigate(["/commodity"]);
      });
    }
  }
      // Back in history
      historyBack() {
        this.form.reset();
        window.history.back();
      }
}
