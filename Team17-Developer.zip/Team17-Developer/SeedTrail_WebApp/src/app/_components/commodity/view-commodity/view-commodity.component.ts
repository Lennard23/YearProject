import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Commodity } from 'src/app/shared/_interfaces/commodity';
import { CommodityService } from 'src/app/shared/_services/commodity.service';

@Component({
  selector: 'app-view-commodity',
  templateUrl: './view-commodity.component.html',
  styleUrls: ['./view-commodity.component.css']
})
export class ViewCommodityComponent implements OnInit {

  constructor(private service: CommodityService, private router: Router) { }

  @Input() commodity!: Commodity
  @Output() viewCommodityEvent: EventEmitter<Commodity> = new EventEmitter<Commodity>();

  ngOnInit(): void {
    this.service.getCommodityById(this.commodity.commodityId).subscribe(res => {
      this.commodity = res;
      this.viewCommodityEvent.emit(this.commodity)
      this.router.navigate(["/commodity"])
    })
  }
}
