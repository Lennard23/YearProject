import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Commodity } from 'src/app/shared/_interfaces/commodity';
import { CommodityService } from 'src/app/shared/_services/commodity.service';

@Component({
  selector: 'app-update-commodity',
  templateUrl: './update-commodity.component.html',
  styleUrls: ['./update-commodity.component.css']
})
export class UpdateCommodityComponent implements OnInit {
  
  form!: UntypedFormGroup;

  constructor(private service: CommodityService, private router: Router) { }

  @Input() commodity!: Commodity
  @Output() updateCommodityEvent: EventEmitter<Commodity> = new EventEmitter<Commodity>();

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.commodity.name, [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      description: new UntypedFormControl(this.commodity.description, [Validators.maxLength(255)]),
    });
  }

  // handles form submission
  onSubmit() {
    if (this.form.valid) {
      // build a commodity object from the form values
      let commodity: Commodity = {
        commodityId: this.commodity.commodityId,
        name: this.form.value.name ?? this.commodity.name,
        description: this.form.value.description ?? this.commodity.description,
        status: this.commodity.status,
        batchSizeYields: this.commodity.batchSizeYields,
        commoditySizes: this.commodity.commoditySizes,
        cultivars: this.commodity.cultivars
      }
      this.service.updateCommodity(commodity.commodityId, commodity).subscribe(() => {
        alert("Commodity successfully updated");
        this.router.navigate(["/commodity"]);
        window.location.reload();
      });
    }
  }
}
