import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { take } from 'rxjs';
import { Login } from 'src/app/shared/_class/login';
//import { ToastrService } from 'ngx-toastr';
import { UserService } from 'src/app/shared/_services/user.service';
import { AuthState } from 'src/app/store/reducers/auth.reducer';
import { login } from 'src/app/store/actions/auth.action';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup = this.fb.group({
    Username: new FormControl('', [Validators.required, Validators.email]),
    Password: new FormControl('', Validators.required),
  });

  constructor(
    private router: Router,
    private userService: UserService,
    private fb: FormBuilder,
    private store: Store<AuthState>
  ) {} //private toastr:ToastrService

  ngOnInit(): void {}

  onSubmit() {
    let loginModel: Login = {
      email: this.loginForm.value.Username,
      password: this.loginForm.value.Password,
    };

    this.userService
      .login(loginModel)
      .pipe(take(1))
      .subscribe({
        next: (res) => {
          this.store.dispatch(login({ auth: res }));
          this.router.navigate(['home']);
        },
        error: (res) => {
          //show something went wrong
          console.log(res);
        },
      });
  }
}
