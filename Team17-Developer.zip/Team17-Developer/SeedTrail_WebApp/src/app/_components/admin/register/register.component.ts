import { Component, OnInit } from '@angular/core';
import {
  UntypedFormControl,
  UntypedFormGroup,
  NgForm,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/shared/_class/user';
import { UserService } from 'src/app/shared/_services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  constructor(
    private service: UserService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}


  RegisterForm: UntypedFormGroup = new UntypedFormGroup({
    Email: new UntypedFormControl('', Validators.required), //Validators.email
    Password: new UntypedFormControl('', [
      Validators.required,
      Validators.minLength(4),
    ]),
  });
  ngOnInit(): void {}

  // registerFormGroup: FormGroup = this.fb.group({
  //   UserName: ['', [Validators.required, Validators.email]],
  //   Password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(16)]],
  // })

  // constructor(private router: Router, private dataService: UserService, private fb: FormBuilder, private snackBar: MatSnackBar) { }


  onSubmit() {
    if (this.RegisterForm.valid) {
      let newUser = new User();
      newUser.Email = this.RegisterForm.value.Email;
      newUser.Password = this.RegisterForm.value.Password;
      newUser.Role = 'Employee';
      this.service.Register(newUser).subscribe(
        (res: any) => {
          this.RegisterForm.reset();

          if (res.code == 200) {
            this.snackBar.open(`Registered successfully`, 'X', {
              duration: 5000,
            });

            //After successful registration navigate to login
            this.router.navigateByUrl('/user/login');
          }
        },
        (res: HttpErrorResponse) => {
          if (res.status === 403) {
            this.snackBar.open(res.error, 'X', { duration: 5000 });
          }
          if (res.status == 401) {
            this.snackBar.open(res.error, 'X', { duration: 5000 });
          }
        }
      );
    }
    // else
    // {
    //   this.snackBar.error("Please Fill in Fields");
    // }
  }
  }
  // new old code
  // RegisterUser(){

  //   if(this.registerFormGroup.valid)
  //   {
  //     this.dataService.RegisterUser(this.registerFormGroup.value).subscribe(() => {
  //       this.registerFormGroup.reset();
  //       this.router.navigate(['']).then((navigated: boolean) => {
  //         if(navigated) {
  //           this.snackBar.open(`Registered successfully`, 'X', {duration: 5000});

  //         }
  //      });
  //     }, (response: HttpErrorResponse) => {
  //       if (response.status === 403) {
  //         this.snackBar.open(response.error, 'X', {duration: 5000});
  //       }
  //       if (response.status === 500){
  //         this.snackBar.open(response.error, 'X', {duration: 5000});
  //       }
  //     })
  //   }

