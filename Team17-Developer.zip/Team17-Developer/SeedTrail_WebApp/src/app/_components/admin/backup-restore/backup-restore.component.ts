import { Component, OnInit } from '@angular/core';
import { BackupRestoreService } from 'src/app/shared/_services/backup-restore.service';

@Component({
  selector: 'app-backup-restore',
  templateUrl: './backup-restore.component.html',
  styleUrls: ['./backup-restore.component.css']
})
export class BackupRestoreComponent implements OnInit {

  lastBackup: string = "never";
  backupCount: string = "no";
  isare: string = "are";
  backupString: string = "Backups";
  backupRestoreType: string = "backup";

  loadingLastBackup: boolean = true;
  loadingExistingBackups: boolean = true;

  constructor(private repo: BackupRestoreService) { }

  ngOnInit(): void {
    this.repo.getLastBackup().subscribe({
      next: data => {
        if (data.date != null) {
          this.lastBackup = data.date.substring(0, 10);
        };
      },
      error: err => {
        console.log(err);
      }
    });

    this.repo.getExistingBackups().subscribe(data => {
      if (data != 0) {
        this.backupCount = data.toString()
      }
      if (data == 1) {
        this.backupCount = data.toString()
        this.backupString = "Backup";
        this.isare = "is";
      }
      this.loadingExistingBackups = false;
    });
  }
      // Back in history
      historyBack() {
        window.history.back();
      }
}
