import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Backup } from 'src/app/shared/_interfaces/backup';
import { Restore } from 'src/app/shared/_interfaces/restore';
import { BackupRestoreService } from 'src/app/shared/_services/backup-restore.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-restore',
  templateUrl: './restore.component.html',
  styleUrls: ['./restore.component.css']
})
export class RestoreComponent implements OnInit {

  backupList!: Backup[];
  searchTerm: string = "";

  constructor(
    private service: BackupRestoreService,
    private router: Router,
    private route: ActivatedRoute,
    private toastService: ToastService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm'];
      this.service.getBackups().subscribe({
        next: backups => {
          if (this.searchTerm != null && this.searchTerm != "") {
            this.backupList = backups.filter(item => item.fileName.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
              item.date?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
              item.description?.toLowerCase().includes(this.searchTerm.trim().toLowerCase()))
          }
          else
          {
            this.backupList = backups;
          }
        },
        error: err => {
          console.log(err)
        }
      });
    });
  }
  search(): void {
    this.router.navigate(['/backup-and-restore/restore', { searchTerm: this.searchTerm }]);
  }

  async restoreBackup(backup: Backup) {
    if (confirm("Are you sure you want to restore " + backup.fileName + "?\nThis will overwrite all existing data.")) {
      // build restore object
      let restore: Restore = {
        restoreId: 0,
        backupId: backup.backupId,
        date: null,
        time: null,
        description: backup.description,
        status: true,
        backup: backup
      }
      console.log("restore: ", restore);
      this.service.createRestore(restore).subscribe({
        next: () => {
          this.toastService.show('Restore created successfully', { classname: 'bg-primary text-light', delay: 2000 });
        },
        error: err => {
          console.log(err)
          this.toastService.show('Failed to create restore', { classname: 'bg-danger text-light', delay: 5000 });
        }
      });
    }
  }

  historyBack() {
    window.history.back();
  }
}
