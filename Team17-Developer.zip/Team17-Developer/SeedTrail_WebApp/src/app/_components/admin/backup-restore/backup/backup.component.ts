import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Backup } from 'src/app/shared/_interfaces/backup';
import { BackupRestoreService } from 'src/app/shared/_services/backup-restore.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-backup',
  templateUrl: './backup.component.html',
  styleUrls: ['./backup.component.css']
})
export class BackupComponent implements OnInit {

  backup!: Backup;
  location: string = "";
  form!: UntypedFormGroup;
  successfulBackup = false;
  todayString: string = "";

  constructor(
    private repo: BackupRestoreService,
    private toastService: ToastService
    ) { }

    today: Date = new Date();
  ngOnInit(): void {
    this.todayString = this.today.getFullYear() + "-" + (this.today.getMonth() + 1) + "-" + this.today.getDate();
    this.form = new UntypedFormGroup({
      desc: new UntypedFormControl("Backup for "+this.todayString, [Validators.maxLength(240)])
    });
  }

  // form submission
  onSubmit() {
    // build entity
    let newBackup: Backup = {
      backupId: 0,
      date: null,
      description: this.form.value.desc ?? "none",
      fileName: "",
      status: true,
      time: null,
      restores: null
    }
    // create backup
    this.createBackup(newBackup);
  }

  // backup method
  createBackup(backup: Backup) {
    this.repo.createBackup(backup).subscribe({
      next: () => {
        this.form.reset();
        this.toastService.show('Backup created successfully', { classname: 'bg-primary text-light', delay: 2000 });
      },
      error: err => {
        this.toastService.show('Failed to create backup', { classname: 'bg-danger text-light', delay: 5000 });
      }
    });
  }

  historyBack() {
    window.history.back();
  }
}
