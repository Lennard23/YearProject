import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeService } from 'src/app/shared/_services/employee.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.css']
})
export class ViewProfileComponent implements OnInit {

  constructor(private service: EmployeeService, private router: Router) { }

  @Input() employee!: Employee
  @Output() viewProfileEvent: EventEmitter<Employee> = new EventEmitter<Employee>();

  ngOnInit(): void {
    this.service.getEmployeeById(this.employee.empId).subscribe(res => {
      this.employee = res;
      this.viewProfileEvent.emit(this.employee)
      this.router.navigate(["/profiles"])
    })
  }
}
