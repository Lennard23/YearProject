import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/shared/_interfaces/employee';
import { EmployeeService } from 'src/app/shared/_services/employee.service';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.css']
})
export class ProfilesComponent implements OnInit {

  // profile
  profilesList!: Employee[];
  profile!: Employee;
  profileForView = false;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  constructor(private service: EmployeeService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getEmployees().subscribe(employees => {
        // if there's a search term, filter the employees
        if (employees != null) {
          if (this.searchTerm != null && this.searchTerm != "") {
            this.profilesList = employees.filter(item => item.name!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
              item.empId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
              item.surname!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
              item.empTypeId.toString().includes(this.searchTerm.trim().toLowerCase()));
          }
          else {
            // if there's no search term, return all employees
            this.profilesList = employees;
          }
        }
        else {
          this.profilesList = [];
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/profiles', { searchTerm: this.searchTerm }]);
  }

  //gets single employee
  async getEmployee(id: number) {
    return this.service.getEmployeeById(id).subscribe((data: Employee) => {
      //return an employee object
      return data;
    })
  }

  // view an employee profile
  viewProfile(employee: Employee) {
    if (!this.profileForView) {
      this.profileForView = true;
      this.message = "ID#" + employee.empId.toString()
      this.desc = "'" + (employee.name+" "+employee.surname ?? "") + "'";
      this.profile = employee;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.profile = employee;
    }
  }

  back() {
    this.profileForView = false;
    this.message = "";
    this.desc = "";
  }

  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }

}
