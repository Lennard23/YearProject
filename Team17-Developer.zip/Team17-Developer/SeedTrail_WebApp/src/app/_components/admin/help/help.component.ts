import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {
  searchText='';
  Admin =`<h5><b>Admin</b></h5>
  <p>Admin exists of 3 options: Backup&Restore, Help and Profiles</p>
  <h6 ><b>Backup & Restore</b></h6>
  <p>Backup & Restore allows the user to make a backup copy of the system and it's data and save it to be accessed at a later date.
     Restore allows the user to access one of these backup copies and to reimplement this backup copy of the system. 
  </p>
  <h6><b>Help</b></h6>
  <p>This help section is there to guide the user through the system, explain the different sections of the system and the different components of each section</p>
  <h6><b>Profiles</b></h6>
  <p>The profiles of all the employees are listed in a table with the details of the given employ, with a "View" button that will direct you to the employee section and display the employee's personal information</p>
`
Employees=` <h5><b>Employees</b></h5>
<p>Employees has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Employee</b></h6>
<p>If you would like to create a new employee click on the create button. This will display a page where you can enter the name and description of the new employee. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Employee</b></h6>
<p>If you would like to view a employee, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Employee</b></h6>
<p>If you would like to update a employee, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Employee</b></h6>
<p>If you would like to delete a employee, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>
`
Clients=` <h5><b>Clients</b></h5>
<p>Clients has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Client</b></h6>
<p>If you would like to create a new client click on the create button. This will display a page where you can enter the name and description of the new client. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Client</b></h6>
<p>If you would like to view a client, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Client</b></h6>
<p>If you would like to update a client, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Client</b></h6>
<p>If you would like to delete a client, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>

<h5><b>Client Orders</b></h5>
<p>Client Orders has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Client Order</b></h6>
<p>If you would like to create a new client order click on the create button. This will display a page where you can enter the name and description of the new client order. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Client Order</b></h6>
<p>If you would like to view a client order, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Client Order</b></h6>
<p>If you would like to update a client order, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Client Order</b></h6>
<p>If you would like to delete a client order, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>
`
ProductionInventories=` <h5><b>Production Inventories</b></h5>
<p>Production Inventories has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Production Inventory</b></h6>
<p>If you would like to create a new production inventory click on the create button. This will display a page where you can enter the name and description of the new production inventory. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Production Inventory</b></h6>
<p>If you would like to view a production inventory, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Production Inventory</b></h6>
<p>If you would like to update a production inventory, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Production Inventory</b></h6>
<p>If you would like to delete a production inventory, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>

<h5><b>Suppliers</b></h5>
<p>Suppliers has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Supplier</b></h6>
<p>If you would like to create a new supplier click on the create button. This will display a page where you can enter the name and description of the new supplier. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Supplier</b></h6>
<p>If you would like to view a supplier, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Supplier</b></h6>
<p>If you would like to update a supplier, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Supplier</b></h6>
<p>If you would like to delete a supplier, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>
`
Scheduling=` <h5><b>Activity Entries</b></h5>
<p>Activity Entries has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Activity Entry</b></h6>
<p>If you would like to create a new activity entry click on the create button. This will display a page where you can enter the name and description of the new activity entry. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Activity Entry</b></h6>
<p>If you would like to view a activity entry, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Activity Entry</b></h6>
<p>If you would like to update a activity entry, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Activity Entry</b></h6>
<p>If you would like to delete a activity entry, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>

<h5><b>Activity Types</b></h5>
<p>Activity Types has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that can be used to search for any items in the list. If you accidentally went to this page you can click the back button to return to the previous page.</p>
<h6><b>Create Activity Type</b></h6>
<p>If you would like to create a new activity type click on the create button. This will display a page where you can enter the name and description of the new activity type. Both the description and name are required. If the create button is not working it means you did not fill in both fields. A message will also display to tell you if data was entered incorrectly.</p>
<h6><b>View Activity Type</b></h6>
<p>If you would like to view a activity type, you can click on the view button in the list for that record. This will display the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click back to perform a different action.</p>
<h6><b>Update Activity Type</b></h6>
<p>If you would like to update a activity type, you can click on the update button in the list for that record. This will display the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter new values for either the name or description to update that record. You can click the cancel button to stop this operation.</p>
<h6><b>Delete Activity Type</b></h6>
<p>If you would like to delete a activity type, you can click on the delete button in the list for that record. This will display the name of the record and another delete button to confirm the delete operation. You can click the cancel button to stop this operation.</p>

<h5><b>Calendar</b></h5>
<p>The calendar shows all the employee activities that have been completed and that are yet to be completed.
<br><br>
   The calendar view can vary between a month, week, and day format, by selecting the "Month", "Week" or "Day" buttons.
<br><br>
   The "Previous" button is to show the previous month,week or day, dependending on the view format chosen. <br>
   The "Today" button is to show the current month,week or day, dependending on the view format chosen. <br>
   The "Next" button is to show the following month,week or day, dependending on the view format chosen. </p>
`
Commodities=` <h5><b>Commodities</b> </h5>
<p> Commodities has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that
    can be used to search for any items in the list.
    If you accidentally went to this page you can click the back button to return to the previous page.</p>
    <h6><b>Create Commodities</b> </h6>
    <p>
    If you would like to create a new commodity click on the create button. This will display a page
    where you can enter the name and description of the new commodity. Both the description and name are
    required. If the create button is not working it means you did not fill in both fields. A message will also display
    to tell you if data was entered incorrectly. </p>
    <h6><b>View Commodities </b></h6>
    <p>
    If you would like to view a commodity, you can click on the view button in the list for that record. This will display
    the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click
    back to perform a different action.
     </p>
     <h6><b>Update Commodities </b></h6>
     <p>
     If you would like to update a commodity, you can click on the update button in the list for that record. This will display
     the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter
     new values for either the name or description to update that record. You can click the cancel button to stop this operation.
      </p>
      <h6><b>Delete Commodities</b> </h6>
      <p>
      If you would like to delete a commodity, you can click on the delete button in the list for that record. This will
      display the name of the record and another delete button to confirm the delete operation.
      You can click the cancel button to stop this operation.
       </p></div>


       <div class="accordion-body"><h5><b>Culivar</b></h5>
        <p> Culivar has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that
            can be used to search for any items in the list.
            If you accidentally went to this page you can click the back button to return to the previous page.</p>
            <h6><b>Create Culivar </b></h6>
            <p>
            If you would like to create a new cultivar click on the create button. This will display a page
            where you can enter the name and description of the new cultivar with a drop down selection
            for which cultivar should be assigned to this commodity. The description, name and commodity are
            required. If the create button is not working it means you did not fill in all fields. A message will also display
            to tell you if data was entered incorrectly. </p>
            <h6><b>View Culivar</b> </h6>
            <p>
            If you would like to view a cultivar, you can click on the view button in the list for that record. This will display
            the ID, name, description and commodity for that record. You can click back to return to the normal list view. You don't have to click
            back to perform a different action.
             </p>
             <h6><b>Update Culivar</b> </h6>
             <p>
             If you would like to update a cultivar, you can click on the update button in the list for that record. This will display
             the name, description and commodity for that record which have been auto populated. You can click back to return to the normal list view. You need to enter
             new values for either the name or description to update that record. You can click the cancel button to stop this operation.
              </p>
              <h6><b>Delete Culivar </b></h6>
              <p>
              If you would like to delete a cultivar, you can click on the delete button in the list for that record. This will
              display the name of the record and another delete button to confirm the delete operation.
              You can click the cancel button to stop this operation.
               </p>
`
Greenhouses=`<h5><b>Greenhouses</b></h5></div>
<p> Greenhouse has a list with 6 buttons: Back, Table, Create, Update, Delete and View. It also has a searchbar that
    can be used to search for any items in the list. It also displays an image for each greenhouse.
    If you accidentally went to this page you can click the back button to return to the previous page.
    To find more options for the greenhouse you can also click on the View button or the Table button. These extra
    functions will be explain underneath.</p>

          <h6><b>Create Greenhouse</b> </h6>
          <p>
          If you would like to create a new greenhouse click on the create button. This will display a page
          where you can enter the number of the new greenhouse with a drop down selection
          for the greenhouse status. Both fields are required.
          If the create button is not working it means you did not fill in all fields. A message will also display
          to tell you if data was entered incorrectly. </p>
          <h6><b>View Greenhouse </b></h6>
          <p>
          If you would like to view a greenhouse, you can click on the view button in the list for that record. This will display
          the ID, number, status, description, amount of: tables, blocks activities and production inventory for that record.
          You can click back to return to the normal list view. You don't have to click
          back to perform a different action. There will also be additional buttons displayed for this greenhouse record. Those are explained
          underneath.
           </p>
           <h6><b>Update Greenhouse </b></h6>
           <p>
           If you would like to update a greenhouse, you can click on the update button in the list for that record. This will display
           the number and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter
           new values for either the number or status to update that record. You can click the cancel button to stop this operation.
            </p>
            <h6><b>Delete Greenhouse </b></h6>
            <p>
            If you would like to delete a greenhouse, you can click on the delete button in the list for that record. This will
            display the number of the record and another delete button to confirm the delete operation.
            You can click the cancel button to stop this operation.
             </p>
             <h6><b>Table</b></h6>
             <p>
             The table button converts the greenhouse images to a normal list. Both pages have the same functions and is merely for display purposes.
              </p>
              <h6><b>Count</b></h6>
              <p>
                This displays a new table of the cultivar with the count next to it. You can also create a new count for a cultivar.
              </p><br>
              <h5><b>Greeenhouse Activities</b></h5>
              <p>
              Clicking on this button will redirect you to the greenhouse activities for that specific greenhouse record. Here there are buttons for
              creating an activity for the greenhouse, or assigning employees to the greenhouse activity, or completing the greenhouse activity.
              </p>
              <h6><b>Create Activity</b></h6>
              <p>
               Clicking on this button will display a page with a dropdown for activity entry and a start date. The start date is not required to create the activity.
              </p>
              <h6><b>Assigned Employees</b></h6>
              <p>
               Clicking on this will display a list of employees assigned to a greenhouse. Here you can also assign an employee and complete the employee activity.
              </p>
              <h6><b>Assign Employee</b></h6>
              <p>
              Here is where you can assign an employee activity to the greenhouse. It requires an employee name from a dropdown menu and a start date for the
              activity. This employee is not created here but in the employee section. All employees on the system are displayed here. If you don't see the
              employee you're looking for try creating them in employee first.
               </p>
               <h6><b>Complete Employee Activity</b></h6>
               <p>
                This will show a page where an employee activity can be marked as complete removing it from the list of activities. An end date is
                required to complete the activity.
                </p>
              <h6><b>Complete Greenhouse Activities</b></h6>
              <p>
                This displays a page where you can select an end date to complete the activity.
              </p>
              <h6><b>Production Inventory</b></h6>
              <p>
                After you completed everything you want to do on the greenhouse page this button redirect you to the production inventory page.
              </p>
<br>

    <h5><b>Greenhouse Batches </b></h5>
    <p>
      This display a list of the client name, order id, cultivar, plant date and harvest date. It also shows the create, view, update and delete
      buttons. For more information about these refer back to the greenhouse list items.
    </p>
    <h6><b>Greenhouse Batch Size Yields </b></h6>
    <p>
      This si another list that shows the batch size yields with the yield number, description and yield count. This page also has a create, view
      update and delete. For more information on these refer back to the greenhouse list items for each of these.
    </p>
    <h6><b>Blocks</b></h6>
    Block shows a list of blocks with 5 buttons similar to the greenhouse list. If you need help with either Create, View, Update, or delete
    refer back to the greenhouse list items above.
    <p>

     </p>
     <h6><b>Greenhouse Status Description</b></h6>
     <p>
      This is another page of list items showing all the descriptions a greenhouse can be. This also has a Create, View, Update and delete.
      If you need help with any of these actions refer back to the greenhouse section explaining the use of each button.
      </p>`

      Reports=`<h5><b>Reports</b></h5>
                
      This is where you can generate a report for the several items. These include:
    <p>-  Production Inventory Quantity</p>
    <p>-  Production Inventory Ordered</p>
    <p>-  Commodity</p>
    <p>-  Cultivar</p>
    <p>-  Batch</p>
    <h5><b>Lab Results</b></h5>
    <p>This is where you can upload a pdf of the lab results which will be stored on the system</p>
  `
  Defects=`<h5><b>Defects</b></h5>
  <p> Defects has a list with 5 buttons: Back, Create, Update, Delete and View. It also has a searchbar that
  can be used to search for any items in the list.
  If you accidentally went to this page you can click the back button to return to the previous page.</p>
  <h6><b>Create Defects </b></h6>
  <p>
  If you would like to create a new defect click on the create button. This will display a page
  where you can enter the name and description of the new defect. Both the description and name are
  required. If the create button is not working it means you did not fill in both fields. A message will also display
  to tell you if data was entered incorrectly. </p>
  <h6><b>View Defects </b></h6>
  <p>
  If you would like to view a defect, you can click on the view button in the list for that record. This will display
  the ID, name and description for that record. You can click back to return to the normal list view. You don't have to click
  back to perform a different action.
   </p>
   <h6><b>Update Defects</b> </h6>
   <p>
   If you would like to update a defect, you can click on the update button in the list for that record. This will display
   the name and description for that record which have been auto populated. You can click back to return to the normal list view. You need to enter
   new values for either the name or description to update that record. You can click the cancel button to stop this operation.
    </p>
    <h6><b>Delete Defects</b> </h6>
    <p>
    If you would like to delete a defect, you can click on the delete button in the list for that record. This will
    display the name of the record and another delete button to confirm the delete operation.
    You can click the cancel button to stop this operation.
     </p>`


  searchTerm: string = "";
  constructor(private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void { 
    this.searchText = String(this.route.snapshot.paramMap.get('section'));
  }
  search() {
    this.router.navigate(['/greenhouse/', { Id: this.searchTerm }]);
  }

  //  // function to update the route with the search term
  //  searchInv(term : string): void {

  //   if (term.length == 0) {
  //     this.productionInventoryList = this.productionInventoryListOriginal;
  //     return;
  //   }

  //   const keys = ['name', 'quantity', 'description'];
  //   this.productionInventoryList = this.globalSearch(term, this.productionInventoryListOriginal, keys);

  // }

  // //put in global
  // globalSearch(term : string, toSearch : any[], objKeys : string[]) {
  //   const hits = new Fuse(toSearch, {
  //     keys : objKeys
  //   }).search(term);

  //   const output : any[] = [];
  //   hits.forEach((el : any) => {
  //     output.push(el.item);
  //   });

  //   return output;
  // }


}
