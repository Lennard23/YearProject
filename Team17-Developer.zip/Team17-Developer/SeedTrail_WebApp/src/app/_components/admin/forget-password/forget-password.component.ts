import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { take } from 'rxjs';
import { UserService } from 'src/app/shared/_services/user.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css'],
})
export class ForgetPasswordComponent implements OnInit {
  forgotPswdForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
  });

  constructor(
    private router: Router,
    private service: UserService,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {}

  onSubmit() {
    if (this.forgotPswdForm.valid) {
      this.service
        .SendResetPasswordLink(this.forgotPswdForm.get('email')?.value)
        .pipe(take(1))
        .subscribe({
          next: () => {
            this.router.navigate(['login']);
          },
        });
    }
  }
}
