import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { iif, take } from 'rxjs';
// import { Password } from 'src/app/shared/_interfaces/password';
import { UserService } from 'src/app/shared/_services/user.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
})
export class ResetPasswordComponent implements OnInit {
  resetForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });
  private resetLink!: string;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: UserService,
    private fb: FormBuilder
  ) {
    this.route.paramMap.pipe(take(1)).subscribe((params) => {
      const resetLink = params.get('resetLink');
      if (resetLink !== null) this.resetLink = resetLink;
      else this.router.navigate(['home']);
    });
  }

  ngOnInit(): void {}

  onSubmit() {
    if (this.resetForm.valid) {
      this.service
        .resetPassword(
          this.resetForm.get('email')?.value,
          this.resetForm.get('password')?.value,
          this.resetLink
        )
        .pipe(take(1))
        .subscribe({
          next: () => {
            this.router.navigate(['login']);
          },
        });
    }
  }
}
