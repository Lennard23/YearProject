import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Metric } from 'src/app/shared/_interfaces/metric';
import { ProductInventoryType } from 'src/app/shared/_interfaces/product-inventory-type';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { ProductionInventoryCost } from 'src/app/shared/_interfaces/production-inventory-cost';
import { ProductionInventoryOrder } from 'src/app/shared/_interfaces/production-inventory-order';
import { ProductionInventoryWriteOff } from 'src/app/shared/_interfaces/production-inventory-write-off';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';
import { ToastService } from 'src/app/shared/_services/toast.service';


@Component({
  selector: 'app-create-production-inventory',
  templateUrl: './create-production-inventory.component.html',
  styleUrls: ['./create-production-inventory.component.css']
})
export class CreateProductionInventoryComponent implements OnInit {

  form!: UntypedFormGroup;
  productionInventoryTypes!: ProductInventoryType[];
  productionInventoryCosts!: ProductionInventoryCost[];
  productionInventoryCost!: ProductionInventoryCost;
  productionInventoryOrders!: ProductionInventoryOrder[];
  productionInventoryOrder!: ProductionInventoryOrder;
  productionInventoryWriteOffs!: ProductionInventoryWriteOff[];
  productionInventoryWriteOff!: ProductionInventoryWriteOff;

  metric! :Metric;
  metrics!:Metric[]



  constructor(private toastService: ToastService,
    private service: ProductionInventoryService,
    service2:ProductionInventoryService,
    private commsService: ProductionInventoryService,
    private router: Router) { }

  ngOnInit(): void {
    this.commsService.GetTypes().subscribe(data => {
      this.productionInventoryTypes = data;
    });
    console.log(this.productionInventoryTypes)

    this.commsService.GetCosts().subscribe(data => {
      this.productionInventoryCosts = data;
    });

    this.commsService.GetCostbyId(1).subscribe(data => {
      this.productionInventoryCost = data;
    });
    this.commsService.GetOrders().subscribe(data => {
      this.productionInventoryOrders = data;
    });

    this.commsService.GetOrderbyId(1).subscribe(data => {
      this.productionInventoryOrder = data;
    });

    this.commsService.GetWriteOffs().subscribe(data => {
      this.productionInventoryWriteOffs = data;
    });

    this.commsService.GetWriteOffbyId(1).subscribe(data => {
      this.productionInventoryWriteOff = data;
    });

    this.commsService.GetMetrics().subscribe(data => {
      this.metrics = data;
      console.log(this.metrics)
    });
    console.log(this.metrics)





    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      productInventoryTypeId: new UntypedFormControl("--- Select ---", [Validators.required]),
      description: new UntypedFormControl("", [Validators.required, Validators.minLength(3), Validators.maxLength(255)]),
      quantity: new UntypedFormControl(1, [Validators.min(0), Validators.pattern('^[0-9]+$')]),
      metricId: new UntypedFormControl("--- Select ---", [Validators.required])
    });
  }

  getMetric(){
     console.log(this.form.value.metricId)
  }

  //handles form submission
  onSubmit() {
    // this.commsService.GetMetricbyId(this.metrics.).subscribe(data => {
    //   this.metric = data;
    //   console.log(this.metric)
    // });


    if (this.form.value.productInventoryTypeId == "--- Select ---" ||
      this.form.value.productInventoryTypeId == "" ||
      this.form.value.productInventoryTypeId == null) {
      alert("Please select a productInventoryType");
      return;
    }
    if (this.form.value.metricId == "--- Select ---" ||
    this.form.value.metricId == "" ||
    this.form.value.metricId == null) {
    alert("Please select a metric");
    return;
  }
    else {
      if (this.form.valid) {
        // find productInventoryType\

        let productInventoryType = this.productionInventoryTypes.find(c => c.productInventoryTypeId == +this.form.value.productInventoryTypeId);
        if (productInventoryType == null || productInventoryType == undefined) {
          console.log(this.productionInventoryTypes)
          alert("Invalid productInventoryType!");
          return;
        }

        console.log(productInventoryType)


        this.metric = this.metrics.find(c => c.metricId == +this.form.value.metricId)!;
  if (this.metric == null || this.metric == undefined) {
    alert("Invalid metric!");
    return;
  }

console.log(this.metric)


      //  this.metric = this.form.value.metricId,
      //  console.log(this.form.value.metricId)

      //find metric

      this.metric = this.metrics.find(c => c.metricId == +this.form.value.metricId)!;
      if (this.metric == null || this.metric == undefined) {
        alert("Invalid metric!");
        return;
      }

    console.log(this.metric)
    //previous
      // let Metric = this.metrics.find(z => z.metricId == +this.form.value.metricId);
      //   console.log(this.form.value.metricId)
      // if (Metric == null || Metric == undefined) {
      //   alert("Invalid metric!");
      //   return;
      // }


      //console.log(metric)
      // let Metric = this.metrics.find(z => z.metricId == +this.form.value.metricId);
      // if (Metric == null || Metric == undefined) {
      //   alert("Invalid metric!");
      //   return;
      // }


        // build object
        let productionInventory: ProductionInventory = {
          productionInvId: 0,
          //productInventor: productInventoryType.productInventoryTypeId,
          name: this.form.value.name,
          description: this.form.value.description?? null,
          status: true,
          productionInvOrderId: 1,
          productionInvCostId: 1,
          productionInventoryWriteOffId: 1,
          metricId: this.metric.metricId,
          quantity: this.form.value.quantity,
          threshold: 0,
          productionInvCost: this.productionInventoryCost,
          productionInvOrder: this.productionInventoryOrder,
          productionInventoryWriteOff: this.productionInventoryWriteOff,
          metric: this.metric,
          greenhouseProductionInventories: null,
          productInventoryTypeId: productInventoryType.productInventoryTypeId
        }
        console.log(productionInventory)

        // create
        this.service.createProductionInventory(productionInventory).subscribe(() => {
          alert("ProductionInventory added successfully");
          this.router.navigate(["/production-inventory"]);
        })
      }
    }
  }

    //history back
    historyBack() {
      window.history.back();
    }
}
