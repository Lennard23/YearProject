import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';

@Component({
  selector: 'app-view-production-inventory',
  templateUrl: './view-production-inventory.component.html',
  styleUrls: ['./view-production-inventory.component.css']
})
export class ViewProductionInventoryComponent implements OnInit {


  productInventoryTypeName!: string;

  constructor(private service: ProductionInventoryService, private comService: ProductionInventoryService, private router: Router) { }

  @Input() productionInventory!: ProductionInventory
  @Output() viewProductionInventoryEvent: EventEmitter<ProductionInventory> = new EventEmitter<ProductionInventory>();

  ngOnInit(): void {

    this.comService.GetTypebyId(this.productionInventory.productInventoryTypeId).subscribe(productInventoryType => {
      this.productInventoryTypeName = productInventoryType.name!;
    });

    this.service.getProductionInventoryById(this.productionInventory.productionInvId).subscribe(res => {
      this.productionInventory = res;
      this.viewProductionInventoryEvent.emit(this.productionInventory)
      // this.router.navigate(["/productionInventory"]);
      console.log(this.productionInventory)
    })

  }
}