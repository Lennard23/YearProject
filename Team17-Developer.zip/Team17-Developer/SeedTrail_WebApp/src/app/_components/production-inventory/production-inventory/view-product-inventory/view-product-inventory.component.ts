import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-product-inventory',
  templateUrl: './view-product-inventory.component.html',
  styleUrls: ['./view-product-inventory.component.css']
})
export class ViewProductInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
