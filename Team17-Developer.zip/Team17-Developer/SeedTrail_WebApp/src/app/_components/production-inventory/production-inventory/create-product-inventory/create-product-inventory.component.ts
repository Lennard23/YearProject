import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, UntypedFormControl, UntypedFormGroup, Validators, ReactiveFormsModule, FormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { ProductInventoryType } from 'src/app/shared/_interfaces/product-inventory-type';
import { ProductionInventoryCost } from 'src/app/shared/_interfaces/production-inventory-cost';
import { ProductionInventoryOrder } from 'src/app/shared/_interfaces/production-inventory-order';
import { ProductionInventoryWriteOff } from 'src/app/shared/_interfaces/production-inventory-write-off';

@Component({
  selector: 'app-create-product-inventory',
  templateUrl: './create-product-inventory.component.html',
  styleUrls: ['./create-product-inventory.component.css']
})
export class CreateProductInventoryComponent implements OnInit {

  form!: UntypedFormGroup;
  productionInventoryTypes!: ProductInventoryType[];
  productionInventoryCosts!: ProductionInventoryCost[];
  productionInventoryCost!: ProductionInventoryCost;
  productionInventoryOrders!: ProductionInventoryOrder[];
  productionInventoryOrder!: ProductionInventoryOrder;
  productionInventoryWriteOffs!: ProductionInventoryWriteOff[];
  productionInventoryWriteOff!: ProductionInventoryWriteOff;
  metric :any;
  metrics:any=[]
  

  constructor(private service: ProductionInventoryService,
    service2:ProductionInventoryService, 
    private commsService: ProductionInventoryService, 
    private router: Router) { }

  ngOnInit(): void {
    this.commsService.GetTypes().subscribe(data => {
      this.productionInventoryTypes = data;
    });

    this.commsService.GetCosts().subscribe(data => {
      this.productionInventoryCosts = data;
    });

    this.commsService.GetCostbyId(1).subscribe(data => {
      this.productionInventoryCost = data;
    });
    this.commsService.GetOrders().subscribe(data => {
      this.productionInventoryOrders = data;
    });

    this.commsService.GetOrderbyId(1).subscribe(data => {
      this.productionInventoryOrder = data;
    });

    this.commsService.GetWriteOffs().subscribe(data => {
      this.productionInventoryWriteOffs = data;
    });

    this.commsService.GetWriteOffbyId(1).subscribe(data => {
      this.productionInventoryWriteOff = data;
    });

    this.commsService.GetMetrics().subscribe(data => {
      this.metrics = data;
    });

    this.commsService.GetMetricbyId(1).subscribe(data => {
      this.metric = data;
    });


    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      productInventoryTypeId: new UntypedFormControl("--- Select ---", [Validators.required]),
      description: new UntypedFormControl("", [Validators.required, Validators.minLength(3), Validators.maxLength(255)]),
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.productInventoryTypeId == "--- Select ---" ||
      this.form.value.productInventoryTypeId == "" ||
      this.form.value.productInventoryTypeId == null) {
      alert("Please select a productInventoryType");
      return;
    }
    else {
      if (this.form.valid) {
        // find productInventoryType
        let productInventoryType = this.productionInventoryTypes.find(c => c.productInventoryTypeId == +this.form.value.productInventoryTypeId);
        if (productInventoryType == null || productInventoryType == undefined) {
          alert("Invalid productInventoryType!");
          return;
        }


        // build object
        let productionInventory: ProductionInventory = {
          productionInvId: 0,
          //productInventor: productInventoryType.productInventoryTypeId,
          name: this.form.value.name,
          description: this.form.value.description,
          status: true,
          productionInvOrderId: 1,
          productionInvCostId: 1,
          productionInventoryWriteOffId: 1,
          metricId: 1,
          quantity: 0,
          threshold: 0,
          productionInvCost: this.productionInventoryCost,
          productionInvOrder: this.productionInventoryOrder,
          productionInventoryWriteOff: this.productionInventoryWriteOff,
          metric: this.metric,
          greenhouseProductionInventories: null,
          productInventoryTypeId: this.form.value.productInventoryType
        }
        // create
        this.service.createProductionInventory(productionInventory).subscribe(() => {
          alert("ProductionInventory added successfully");
          this.router.navigate(["/productionInventory"]);
        })
      }
    }
  }
}