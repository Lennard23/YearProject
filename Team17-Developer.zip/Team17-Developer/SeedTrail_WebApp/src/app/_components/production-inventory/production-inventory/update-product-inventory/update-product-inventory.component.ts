import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductInventoryType } from 'src/app/shared/_interfaces/product-inventory-type';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';

@Component({
  selector: 'app-update-product-inventory',
  templateUrl: './update-product-inventory.component.html',
  styleUrls: ['./update-product-inventory.component.css']
})
export class UpdateProductInventoryComponent implements OnInit {

  form!: UntypedFormGroup;

  productionInventoryTypes!: ProductInventoryType[];
  productInventoryTypeName: string = "";

  constructor(private service: ProductionInventoryService, private comService: ProductionInventoryService, private router: Router) { }

  @Input() productionInventory!: ProductionInventory;
  @Output() updateProductionInventoryEvent: EventEmitter<ProductionInventory> = new EventEmitter<ProductionInventory>();

  ngOnInit(): void {
    this.comService.GetTypes().subscribe(data => {
      this.productionInventoryTypes = data;
      this.productInventoryTypeName = this.productionInventoryTypes.find(c => c.productInventoryTypeId == this.productionInventory.productInventoryTypeId)?.name || "";
    });

    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.productionInventory.name, [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      productInventoryTypeId: new UntypedFormControl(this.productInventoryTypeName, [Validators.required]),
      description: new UntypedFormControl(this.productionInventory.description, [Validators.required, Validators.minLength(3), Validators.maxLength(255)]),
    });
    
  }

  //handles form submission
  onSubmit() {
    if (this.form.value.productInventoryTypeId == "" || this.form.value.productInventoryTypeId == null) {
      alert("Please select a productInventoryType");
      return;
    }
    else {
      if (this.form.valid) {
        // find productInventoryType
        let productInventoryType = this.productionInventoryTypes.find(c => c.productInventoryTypeId == +this.form.value.productInventoryTypeId);
        if (productInventoryType == null || productInventoryType == undefined) {
          alert("Invalid productInventoryType selection!");
          return;
        }
        // build object
        let productionInventory: ProductionInventory = {
          productionInvId: this.productionInventory.productionInvId,
          productInventoryTypeId: productInventoryType.productInventoryTypeId,
          name: this.form.value.name ?? this.productionInventory.name,
          description: this.form.value.description ?? this.productionInventory.description,
          status: this.productionInventory.status,
          productionInvOrderId: this.productionInventory.productionInvOrderId,
          productionInvCostId: this.productionInventory.productionInvCostId,
          productionInventoryWriteOffId: this.productionInventory.productionInventoryWriteOffId,
          metricId: this.productionInventory.metricId,
          quantity: 0,
          threshold: null,
          productionInvCost: this.productionInventory.productionInvCost,
          productionInvOrder: this.productionInventory.productionInvOrder,
          productionInventoryWriteOff: this.productionInventory.productionInventoryWriteOff,
          metric: this.productionInventory.metric,
          greenhouseProductionInventories: this.productionInventory.greenhouseProductionInventories
        }
        // create
        this.service.updateProductionInventory(productionInventory.productionInvId, productionInventory).subscribe(() => {
          alert("ProductionInventory updated successfully");
          this.form.reset();
          this.updateProductionInventoryEvent.emit(productionInventory);
          this.router.navigate(["/productionInventory"]);
          window.location.reload();
        })
      }
    }
  }
}