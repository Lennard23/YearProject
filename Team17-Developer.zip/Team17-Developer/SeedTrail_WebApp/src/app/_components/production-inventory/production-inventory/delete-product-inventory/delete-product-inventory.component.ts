import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-product-inventory',
  templateUrl: './delete-product-inventory.component.html',
  styleUrls: ['./delete-product-inventory.component.css']
})
export class DeleteProductInventoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
