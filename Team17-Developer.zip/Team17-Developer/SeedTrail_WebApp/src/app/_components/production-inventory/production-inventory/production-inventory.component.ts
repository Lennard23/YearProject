import { Component, OnInit } from '@angular/core';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { Router, ActivatedRoute } from '@angular/router';

//import this:
import Fuse from 'fuse.js';

@Component({
  selector: 'app-production-inventory',
  templateUrl: './production-inventory.component.html',
  styleUrls: ['./production-inventory.component.css'],
})
export class ProductionInventoryComponent implements OnInit {

  // ProductionInventory
  productionInventoryList: ProductionInventory[] = [];
  //duplicate it:
  productionInventoryListOriginal: ProductionInventory[] = [];
  productionInventory!: ProductionInventory;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  productionInventoryForUpdate: boolean = false;
  productionInventoryForDelete: boolean = false;
  productionInventoryForView: boolean = false;

  constructor(private service: ProductionInventoryService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getProductionInventory().subscribe(productionInventories => {

        this.productionInventoryList = productionInventories;
        this.productionInventoryListOriginal = productionInventories;

        console.log('ivt list', this.productionInventoryList);
      });
    });
  }

  // function to update the route with the search term
  searchInv(term : string): void {

    if (term.length == 0) {
      this.productionInventoryList = this.productionInventoryListOriginal;
      return;
    }

    const keys = ['name', 'quantity', 'description'];
    this.productionInventoryList = this.globalSearch(term, this.productionInventoryListOriginal, keys);

  }

  //put in global
  globalSearch(term : string, toSearch : any[], objKeys : string[]) {
    const hits = new Fuse(toSearch, {
      keys : objKeys
    }).search(term);

    const output : any[] = [];
    hits.forEach((el : any) => {
      output.push(el.item);
    });

    return output;
  }

  //gets single productionInventory
  async getProductionInventory(id: number) {
    return this.service.getProductionInventoryById(id).subscribe((data: ProductionInventory) => {
      //return a productionInventory object
      return data;
    })
  }

  // view a productionInventory
  viewProductionInventory(productionInventory: ProductionInventory) {
    if (!this.productionInventoryForView) {
      this.productionInventoryForView = true;
      this.productionInventoryForUpdate = false;
      this.productionInventoryForDelete = false;
      this.message = "ID#" + productionInventory.productionInvId.toString()
      this.desc = "'" + (productionInventory.name ?? "") + "'";
      this.productionInventory = productionInventory;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + productionInventory.productionInvId.toString()
      this.desc = "'" + (productionInventory.name ?? "") + "'";
      this.productionInventory = productionInventory;
    }
    //console.log(productionInventory.quantity)
  }
  // update a productionInventory
  updateProductionInventory(productionInventory: ProductionInventory) {
    if (!this.productionInventoryForUpdate) {
      this.productionInventoryForUpdate = true;
      this.productionInventoryForDelete = false;
      this.productionInventoryForView = false;
      this.message = "ID#" + productionInventory.productionInvId.toString()
      this.desc = "Update Production Inventory '" + (productionInventory.name ?? "") + "'";
      this.productionInventory = productionInventory;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "";
      this.desc = "";
      this.productionInventoryForUpdate = false;
      this.productionInventory = productionInventory;
    }
  }
  // delete a productionInventory
  deleteProductionInventory(productionInventory: ProductionInventory) {
    if (!this.productionInventoryForDelete) {
      this.productionInventoryForDelete = true;
      this.productionInventoryForUpdate = false;
      this.productionInventoryForView = false;
      this.message = "ID#" + productionInventory.productionInvId.toString()
      this.desc = "Do you want to delete Production Inventory '" + (productionInventory.name ?? "") + "'?";
      this.productionInventory = productionInventory;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + productionInventory.productionInvId.toString()
      this.desc = "Do you want to delete productionInventory '" + (productionInventory.name ?? "") + "'?";
      this.productionInventory = productionInventory;
    }
  }

  // Back in history
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }

  // back
  back() {
    this.message = "";
    this.desc = "";
    this.productionInventoryForUpdate = false;
    this.productionInventoryForDelete = false;
    this.productionInventoryForView = false;
    // this.router.navigate(['/production-inventory']);
  }
}
