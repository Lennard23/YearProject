import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Supplier } from 'src/app/shared/_interfaces/supplier';
import { SupplierService } from 'src/app/shared/_services/supplier.service';

@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent implements OnInit {

  // Supplier
  supplierList: Supplier[] = [];
  supplier!: Supplier;
  message: string = "";
  desc: string = "";

  // Search filtering
  searchTerm: string = "";

  // CRUD functionality
  supplierForUpdate: boolean = false;
  supplierForDelete: boolean = false;
  supplierForView: boolean = false;

  constructor(private service: SupplierService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    // subscribe to router param changes
    this.route.params.subscribe(params => {
      this.searchTerm = params['searchTerm']; // this is empty an string if param not found
      this.service.getSuppliers().subscribe(suppliers => {
        // if there's a search term, filter the suppliers
        if (this.searchTerm != null && this.searchTerm != "") {
          this.supplierList = suppliers.filter(item => item.name!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()) ||
            item.supplierId.toString().includes(this.searchTerm.trim().toLowerCase()) ||
            item.email!.toLowerCase().includes(this.searchTerm.trim().toLowerCase()));
        }
        else {
          // if there's no search term, return all suppliers
          this.supplierList = suppliers;
        }
      });
    });
  }

  // function to update the route with the search term
  search(): void {
    this.router.navigate(['/supplier', { searchTerm: this.searchTerm }]);
  }

  //gets single supplier
  async getSupplier(id: number) {
    return this.service.getSupplierById(id).subscribe((data: Supplier) => {
      //return a supplier object
      return data;
    })
  }

  // view a supplier
  viewSupplier(supplier: Supplier) {
    if (!this.supplierForView) {
      this.supplierForView = true;
      this.supplierForUpdate = false;
      this.supplierForDelete = false;
      this.message = "ID#" + supplier.supplierId.toString()
      this.desc = "'" + supplier.name + "'";
      this.supplier = supplier;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.message = "ID#" + supplier.supplierId.toString()
      this.desc = "'" + supplier.name + "'";
      this.supplier = supplier;
    }
  }
  // update a supplier
  updateSupplier(supplier: Supplier) {
    if (!this.supplierForUpdate) {
      this.supplierForUpdate = true;
      this.supplierForDelete = false;
      this.supplierForView = false;
      this.message = "ID#" + supplier.supplierId.toString()
      this.desc = "Update supplier '" + supplier.name + "'";
      this.supplier = supplier;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.supplierForUpdate = false;
      this.supplier = supplier;
    }
  }
  // delete a supplier
  deleteSupplier(supplier: Supplier) {
    if (!this.supplierForDelete) {
      this.supplierForDelete = true;
      this.supplierForUpdate = false;
      this.supplierForView = false;
      this.message = "ID#" + supplier.supplierId.toString()
      this.desc = "Do you want to delete supplier '" + supplier.name + "'?";
      this.supplier = supplier;
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
    else {
      this.supplierForDelete = false;
      this.supplier = supplier;
    }
  }

  // back
  back() {
    this.supplierForUpdate = false;
    this.supplierForDelete = false;
    this.supplierForView = false;
    this.message = "";
    this.desc = "";
  }

  //history back
  historyBack() {
    this.message = "";
    this.desc = "";
    window.history.back();
  }
}
