import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Supplier } from 'src/app/shared/_interfaces/supplier';
import { SupplierService } from 'src/app/shared/_services/supplier.service';

@Component({
  selector: 'app-view-supplier',
  templateUrl: './view-supplier.component.html',
  styleUrls: ['./view-supplier.component.css']
})
export class ViewSupplierComponent implements OnInit {

  constructor(private service: SupplierService, private router: Router) { }

  @Input() supplier!: Supplier
  @Output() viewSupplierEvent: EventEmitter<Supplier> = new EventEmitter<Supplier>();

  ngOnInit(): void {
    this.service.getSupplierById(this.supplier.supplierId).subscribe(res => {
      this.supplier = res;
      this.viewSupplierEvent.emit(this.supplier)
      this.router.navigate(["/supplier"])
    })
  }
}
