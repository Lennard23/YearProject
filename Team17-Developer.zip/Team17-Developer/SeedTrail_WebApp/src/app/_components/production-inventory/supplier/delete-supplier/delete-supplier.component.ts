import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Supplier } from 'src/app/shared/_interfaces/supplier';
import { SupplierService } from 'src/app/shared/_services/supplier.service';

@Component({
  selector: 'app-delete-supplier',
  templateUrl: './delete-supplier.component.html',
  styleUrls: ['./delete-supplier.component.css']
})
export class DeleteSupplierComponent {

  constructor(private service: SupplierService, private router: Router) {}
 
  @Input() supplier!: Supplier; 
  @Output() deleteSupplierEvent: EventEmitter<Supplier> = new EventEmitter<Supplier>();

  //handles form submission
  onSubmit() {
    this.service.disableSupplier(this.supplier.supplierId, this.supplier).subscribe(res => {
      alert("Supplier successfully deleted");
      this.router.navigate(['/supplier']);
      this.deleteSupplierEvent.emit(this.supplier)
      window.location.reload();
    })
  }
}
