import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Supplier } from 'src/app/shared/_interfaces/supplier';
import { SupplierService } from 'src/app/shared/_services/supplier.service';

@Component({
  selector: 'app-update-supplier',
  templateUrl: './update-supplier.component.html',
  styleUrls: ['./update-supplier.component.css']
})
export class UpdateSupplierComponent implements OnInit {
  
  form!: UntypedFormGroup;

  constructor(private service: SupplierService, private router: Router) { }

  @Input() supplier!: Supplier;
  @Output() updateSupplierEvent: EventEmitter<Supplier> = new EventEmitter<Supplier>();

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl(this.supplier.name, [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      contactNr: new UntypedFormControl(this.supplier.contactNr, [Validators.required, Validators.minLength(10), Validators.maxLength(13), Validators.pattern(/^\d{9,13}$/)]),
      email: new UntypedFormControl(this.supplier.email, [Validators.required, Validators.maxLength(40), Validators.email]),
      description: new UntypedFormControl(this.supplier.description, [Validators.required, Validators.maxLength(255)])
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.valid) {
      let supplier: Supplier = {
        supplierId: this.supplier.supplierId,
        name: this.form.value.name,
        contactNr: this.form.value.contactNr ?? null,
        email: this.form.value.email ?? null,
        description: this.form.value.description ?? null,
        status: this.supplier.status,
        productionInventoryOrders: null
      };
      this.service.updateSupplier(supplier.supplierId, supplier).subscribe(res => {
        alert("Supplier updated successfully!");
        this.form.reset();
        this.updateSupplierEvent.emit(supplier)
        this.router.navigate(["/supplier"])
        window.location.reload();
      })
    }
  }
}
