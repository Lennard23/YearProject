import { Component, OnInit } from '@angular/core';
import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Supplier } from 'src/app/shared/_interfaces/supplier';
import { SupplierService } from 'src/app/shared/_services/supplier.service';

@Component({
  selector: 'app-create-supplier',
  templateUrl: './create-supplier.component.html',
  styleUrls: ['./create-supplier.component.css']
})
export class CreateSupplierComponent implements OnInit {

  form!: UntypedFormGroup;

  constructor(private service: SupplierService, private router: Router) { }

  ngOnInit(): void {
    this.form = new UntypedFormGroup({
      name: new UntypedFormControl("", [Validators.required, Validators.minLength(2), Validators.maxLength(30)]),
      contactNr: new UntypedFormControl("", [Validators.required, Validators.minLength(10), Validators.maxLength(13), Validators.pattern(/^\d{9,13}$/)]),
      email: new UntypedFormControl("", [Validators.required, Validators.maxLength(40), Validators.email]),
      description: new UntypedFormControl("", [Validators.required, Validators.maxLength(255)])
    });
  }

  //handles form submission
  onSubmit() {
    if (this.form.valid) {
      //create new supplier object
      let supplier: Supplier = {
        supplierId: 0,
        name: this.form.value.name,
        contactNr: this.form.value.contactNr,
        email: this.form.value.email,
        description: this.form.value.description,
        status: true,
        productionInventoryOrders: null
      }
      this.service.createSupplier(supplier).subscribe(() => {
        this.router.navigate(["/supplier"]);
      })
    }
    else {
      alert("Please fill in all fields");
    }
  }
}
