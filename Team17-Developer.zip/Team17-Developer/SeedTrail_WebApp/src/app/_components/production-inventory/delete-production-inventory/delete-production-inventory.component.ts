import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { ProductionInventory } from 'src/app/shared/_interfaces/production-inventory';
import { ProductionInventoryService } from 'src/app/shared/_services/production-inventory.service';
import { ToastService } from 'src/app/shared/_services/toast.service';

@Component({
  selector: 'app-delete-production-inventory',
  templateUrl: './delete-production-inventory.component.html',
  styleUrls: ['./delete-production-inventory.component.css']
})
export class DeleteProductionInventoryComponent implements OnInit {


  constructor(private toastService: ToastService, private service: ProductionInventoryService, private router: Router) { }
  ngOnInit(): void {
   // throw new Error('Method not implemented.');
  }

  @Input() productionInventory!: ProductionInventory;
  @Output() deleteProductionInventoryEvent: EventEmitter<ProductionInventory | null> = new EventEmitter<ProductionInventory | null>();

  //handles form submission
  onSubmit() {
    // this.service.disableProductionInventory(this.productionInventory.productionInvId, this.productionInventory).subscribe( {
    //   next: (res:any) => {
    //     alert("ProductionInventory deleted successfully");
    //     this.router.navigate(['/productionInventory']);
    //     this.deleteProductionInventoryEvent.emit(this.productionInventory)
    //     window.location.reload();
    //   },
    //   error: () => {
    //     alert("Production Inventory delete Failed")
    //   }
    // })
    this.service.checkRefIntegrity(this.productionInventory.productionInvId).subscribe(res => {
      if (res == true) {
        this.toastService.show('Production Inventory has is in use. Cannot delete.', { classname: 'bg-secondary', delay: 5000 });
        return;
      }
      else {
        this.service.disableProductionInventory(this.productionInventory.productionInvId, this.productionInventory).subscribe({
          next: () => {
            this.deleteProductionInventoryEvent.emit(this.productionInventory);
            window.location.reload();
          },
          error: err => {
            console.log(err);
            this.deleteProductionInventoryEvent.emit(null);
          }
        });
      }
    });
  }
}
