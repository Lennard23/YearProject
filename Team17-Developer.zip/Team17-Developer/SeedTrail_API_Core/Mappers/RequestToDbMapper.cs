﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Mappers
{
    public class RequestToDbMapper
    {
        private readonly AppDbContext context;

        public RequestToDbMapper(AppDbContext context)
        {
            this.context = context;
        }

        public ActivityEntry? ActivityMapper(ActivityEntryRequest model)
        {
            try
            {
                return new ActivityEntry()
                {
                    ActivityTypeId = model.ActivityTypeId,
                    ActivityStatusId = model.ActivityStatusId,
                    Duration = model.Duration,
                    Description = model.Description,
                    Title = model.Title,
                    SequenceOrder = model.SequenceOrder,
                    Status = model.Status,
                    ActivityStatus = context.ActivityStatuses.First(x => x.ActivityStatusId == model.ActivityStatusId),
                    ActivityType = context.ActivityTypes.First(x => x.ActivityTypeId == model.ActivityTypeId),
                };
            }
            catch
            {
                return null;
            }
        }

        public ActivityStatus? ActivitStatusMapper(ActivityStatusRequest model)
        {
            try
            {
                return new ActivityStatus()
                {
                    
                    ActivityStatusId = model.ActivityStatusId,
                    Astatus = model.Astatus,
                    Description = model.Description,
                    Status = model.Status,
                   
                };
            }
            catch
            {
                return null;
            }
        }



        public OrderStatus? OrderStatusMapper(OrderStatusRequest model)
        {
            try
            {
                return new OrderStatus()
                {
                    Ostatus = model.Ostatus,
                    Description = model.Description,
                    Status = model.Status,
                };
            }
            catch
            {
                return null;
            }
        }

        public ActivityType ActivityTypeMapper(ActivityTypeRequest model)
        {
            return new ActivityType()
            {
                Description = model.Description,
                Type = model.Type,
                Status = model.Status,
            };
        }

        public Greenhouse? GreenhouseMapper(GreenhouseRequest model)
        {
            try
            {
                return new Greenhouse()
                {
                    GreenhouseStatusDescId = model.GreenhouseStatusDescId,
                    GreenhouseNumber = model.GreenhouseNumber,
                    Status = model.Status,
                    GreenhouseStatusDesc = context.GreenhouseStatusDescriptions.First(x => x.GreenhouseStatusDescId == model.GreenhouseStatusDescId),
                };
            }
            catch
            {
                return null;
            }
        }

        public GreenhouseTable? GreenhouseTableMapper(GreenhouseTableRequest model)
        {
            try
            {
                return new GreenhouseTable()
                {
                    TableTotalCrates = model.TableTotalCrates,
                    Status = model.Status,
                    GreenhouseId = model.GreenhouseId,
                    BlockId = model.BlockId,
                    Greenhouse = context.Greenhouses.First(x => x.GreenhouseId == model.GreenhouseId),
                    Block = context.Blocks.First(x => x.BlockId == model.BlockId),
                };
            }
            catch
            {
                return null;
            }
        }

        public GreenhouseProductionInventory? GhProductionInventoryMapper(GreenhouseProductionInventoryRequest model)
        {
            try
            {
                return new GreenhouseProductionInventory()
                {
                    GreenhouseId = model.GreenhouseId,
                    ProductionInvId = model.ProductionInvId,
                    Status = model.Status,
                    Greenhouse = context.Greenhouses.First(x => x.GreenhouseId == model.GreenhouseId),
                    ProductionInv = context.ProductionInventories.First(x => x.ProductionInvId == model.ProductionInvId)
                };
            }
            catch
            {
                return null;
            }

        }

        public GreenhouseCultivarCount? GreenhouseCultivarMapper(GreenhouseCultivarCountRequest model)
        {
            try
            {
                return new GreenhouseCultivarCount()
                {
                    GreenhouseId = model.GreenhouseId,
                    CultivarId = model.CultivarId,
                    Count = model.Count,
                    Greenhouse = context.Greenhouses.First(x => x.GreenhouseId == model.GreenhouseId),
                    Cultivar = context.Cultivars.First(x => x.CultivarId == model.CultivarId),
                    CultivarName = context.Cultivars.First(x => x.CultivarId == model.CultivarId).Name,
                    GreenhouseNumber = context.Greenhouses.First(x => x.GreenhouseId == model.GreenhouseId).GreenhouseNumber,
                };
            }
            catch
            {
                return null;
            }
        }

        public Cultivar? CultivarMapper(CultivarRequest model)
        {
            try
            {
                return new Cultivar()
                {
                    CommodityId = model.CommodityId,
                    Name = model.Name,
                    Description = model.Description,
                    Status = model.Status,
                    Commodity = context.Commodities.First(x => x.CommodityId == model.CommodityId)
                };
            }
            catch
            {
                return null;
            }
        }

        public Commodity CommodityMapper(CommodityRequest model)
        {
            return new Commodity()
            {
                Name = model.Name,
                Description = model.Description,
                Status = model.Status,
            };
        }
        public Coldroom ColdroomMapper(ColdroomRequest model)
        {
            return new Coldroom()
            {
                Name = model.Name,
                Description = model.Description,
                Status = model.Status,
            };
        }
        public Defect DefectMapper(DefectRequest model)
        {
            return new Defect()
            {
                Defect1 = model.Defect1,
                Image = model.Image,
                Description = model.Description,
                Status = model.Status,
            };
        }

        public Supplier SupplierMapper(SupplierRequest model)
        {
            return new()
            {
                Name = model.Name,
                Description = model.Description,
                ContactNr = model.ContactNr,
                Email = model.Email,
                Status = model.Status,
            };
        }
        public ProductInventoryType? ProductionInventoryTypeMapper(ProductionInventoryTypeRequest model)
        {
            try
            {
                return new()
                {

                  
                    Name = model.Name,
                    Description = model.Description,
                    Status = model.Status,
                    
                };
            }
            catch
            {
                return null;
            }
        }
        public ProductionInventoryCost? ProductionInventoryCostMapper(ProductionInventoryCostRequest model)
        {         // parse date
            DateTime? cleanDate = null;
            if (model.Date != null)
            {
                try
                {
                    cleanDate = DateTime.ParseExact(model.Date!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanDate = null;
                }
            }
            try
            {
                return new()
                {

                    Cost = model.Cost,
                    Date = cleanDate,
                    Status = model.Status,

                };
            }
            catch
            {
                return null;
            }
        }
        public ProductionInventoryOrder? ProductionInventoryOrderMapper(ProductionInventoryOrderRequest model)
        {
            try
            {
                return new()
                {

                    ProdctionInvOrderStatusId = model.ProdctionInvOrderStatusId,
                    SupplierId = model.SupplierId,
                    Status = model.Status,

                };
            }
            catch
            {
                return null;
            }
        }
        public GreenhouseStatusDescription? GreenhouseStatusDescriptionMapper(GreenhouseStatusDescriptionRequest model)
        {
            try
            {
                return new()
                {
                    GreenhouseStatusId = model.GreenhouseStatusId,
                    Description = model.Description,
                    Status = model.Status,
                    GreenhouseStatus = context.GreenhouseStatuses.First(x => x.GreenhouseStatusId == model.GreenhouseStatusId)
                };
            }
            catch
            {
                return null;
            }
        }
        public ProductionInventoryWriteOff? ProductionInventoryWriteOffMapper(ProductionInventoryWriteOffRequest model)
        {
            try
            {
                return new()
                {
                    Name = model.Name,
                    Description = model.Description,
                    Quantity = model.Quantity,
                    Status = model.Status

                };
            }
            catch
            {
                return null;
            }
        }
        public Metric? MetricMapper(MetricRequest model)
        {
            try
            {
                return new()
                {

                    MetricId = model.MetricId,
                    Name = model.Name,
                    Description = model.Description,
                    
                };
            }
            catch
            {
                return null;
            }
        }
        public EmployeeActivity? EmployeeActivityMapper(EmployeeActivityRequest model)
        {            // parse date
            DateTime? cleanStartDate = null;
            if (model.StartDate != null)
            {
                try
                {
                    cleanStartDate = DateTime.ParseExact(model.StartDate!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanStartDate = null;
                }
            }
            // parse date
            DateTime? cleanEndDate = null;
            if (model.EndDate != null)
            {
                try
                {
                    cleanEndDate = DateTime.ParseExact(model.EndDate!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanEndDate = null;
                }
            }
            try
            {
                return new()
                {
                    EmpId = model.EmpId,
                    GreenhouseActivityId = model.GreenhouseActivityId,
                    StartDate = cleanStartDate,
                    EndDate = cleanEndDate,
                    Status = model.Status,
                    Emp = context.Employees.First(x => x.EmpId == model.EmpId),
                    GreenhouseActivity = context.GreenhouseActivities.First(x => x.GreenhouseActivityId == model.GreenhouseActivityId),
                };
            }
            catch
            {
                return null;

            }
        }

        public GreenhouseActivity? GreenhouseActivityMapper(GreenhouseActivityRequest model)
        {            // parse date
            DateTime? cleanStartDate = null;
            if (model.StartDate != null)
            {
                try
                {
                    cleanStartDate = DateTime.ParseExact(model.StartDate!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanStartDate = null;
                }
            }
            // parse date
            DateTime? cleanEndDate = null;
            if (model.EndDate != null)
            {
                try
                {
                    cleanEndDate = DateTime.ParseExact(model.EndDate!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanEndDate = null;
                }
            }
            try
            {
                return new()
                {
                    GreenhouseId = model.GreenhouseId,
                    ActivityEntryId = model.ActivityEntryId,
                    StartDate = cleanStartDate,
                    EndDate = cleanEndDate,
                    Status = model.Status,
                    Greenhouse = context.Greenhouses.First(x => x.GreenhouseId == model.GreenhouseId),
                    ActivityEntry = context.ActivityEntries.First(x => x.ActivityEntryId == model.ActivityEntryId),
                };
            }
            catch
            {
                return null;

            }
        }
        public ProductionInventory? ProductionInventoryMapper(ProductionInventoryRequest model)
        {
            try
            {
                return new()
                {
                    ProductionInvCostId = model.ProductionInvCostId,
                    ProductionInventoryWriteOffId = model.ProductionInventoryWriteOffId,
                    ProductInventoryTypeId = model.ProductInventoryTypeId,
                    MetricId = model.MetricId,
                    Name = model.Name,
                    Description = model.Description,
                    Quantity = model.Quantity,
                    Threshold = model.Threshold,
                    Status = model.Status,
                    // added for test
                    //MetricId = (int)model.MetricId,
                    ProductionInvCost = context.ProductionInventoryCosts.First(x => x.ProductionInvCostId == model.ProductionInvCostId),
                    ProductionInventoryWriteOff = context.ProductionInventoryWriteOffs.First(x => x.ProductionInventoryWriteOffId == model.ProductionInventoryWriteOffId),
                    ProductInventoryType = context.ProductInventoryTypes.First(x => x.ProductInventoryTypeId == model.ProductInventoryTypeId),
                };
            }
            catch
            {
                return null;
            }
        }
        
        public Client ClientMapper(ClientRequest model)
        {
            return new()
            {
                Name = model.Name,
                ContractNr = model.ContractNr,
                Email = model.Email,
                Address = model.Address,
                Status = model.Status,
            };
        }
        public Employee? EmployeeMapper(EmployeeRequest model)
        {
            try
            {
                return new()
                {
                    AccessLevelAreaId = model.AccessLevelAreaId,
                    EmpTypeId = model.EmpTypeId,
                    Name = model.Name,
                    Surname = model.Surname,
                    ContactNr = model.ContactNr,
                    NationalId = model.NationalId,
                    Email = model.Email,
                    StartDate = model.StartDate,
                    EndDate = model.EndDate,
                    Status = model.Status,
                    AccessLevelArea = context.AccessLevelAreas.First(x => x.AccessLevelAreaId == model.AccessLevelAreaId),
                    EmpType = context.EmployeeTypes.First(x => x.EmpTypeId == model.EmpTypeId),
                };
            }
            catch
            {
                return null;
            }
        }

        public LabResult? LabResultMapper(LabResultRequest model)
        {
            // parse date
            DateTime? cleanDate = null;
            if (model.Date != null)
            {
                try
                {
                    cleanDate = DateTime.ParseExact(model.Date!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanDate = null;
                }
            }
            try
            {
                return new()
                {
                    BatchId = model.BatchId,
                    TestResultStatusId = model.TestResultStatusId,
                    Date = cleanDate,
                    FilePath = model.FilePath,
                    Description = model.Description,
                    Comment = model.Comment,
                    Status = model.Status,
                    Batch = context.Batches.First(x => x.BatchId == model.BatchId),
                    TestResultStatus = context.TestResultStatuses.First(x => x.TestResultStatusId == model.TestResultStatusId),
                };
            }
            catch
            {
                return null;
            }
        }

        public Batch? BatchMapper(BatchRequest model)
        {
            DateTime? PlantDate = null;
            if (model.PlantDate != null) {
                try
                { PlantDate = DateTime.ParseExact(model.PlantDate!, "yyyy-MM-dd", null); }
                catch
                { PlantDate = null; } }
            
            DateTime? HarvestDate = null;
            if (model.HarvestDate != null)
            {
                try
                { HarvestDate = DateTime.ParseExact(model.HarvestDate!, "yyyy-MM-dd", null); }
                catch
                {
                    HarvestDate = null;
                }
            }
            DateTime? ColdroomDateIn = null;
            if (model.ColdroomDateIn != null)
            {
                try
                {
                    ColdroomDateIn = DateTime.ParseExact(model.ColdroomDateIn!, "yyyy-MM-dd", null);
                }
                catch
                {
                    ColdroomDateIn = null;
                }
            }
            DateTime? ColdroomDateOut = null;
            if (model.ColdroomDateOut != null)
            {
                try
                {
                    ColdroomDateOut = DateTime.ParseExact(model.ColdroomDateOut!, "yyyy-MM-dd", null);
                }
                catch
                {
                    ColdroomDateOut = null;
                }
            }
            try
            {
                var clientName = context.ClientOrders.First(x => x.ClientOrderId == model.ClientOrderId).ClientName;
                var cultivarName = context.Cultivars.First(x => x.CultivarId == model.CultivarId).Name;
                return new()
                {
                    ColdroomId = model.ColdroomId,
                    ClientOrderId = model.ClientOrderId,
                    CultivarId = model.CultivarId,
                    ClientName = clientName,
                    CultivarName = cultivarName,
                    RegistrationNr = model.RegistrationNr,
                    PlantDate = PlantDate,
                    TotalPlanted = model.TotalPlanted,
                    HarvestDate = HarvestDate,
                    TotalYield = model.TotalYield,
                    Scrap = model.Scrap,
                    Sample = model.Sample,
                    ColdroomDateIn = ColdroomDateIn,
                    ColdroomDateOut = ColdroomDateOut,
                    TotalBags = model.TotalBags,
                    AvgYield = model.AvgYield,
                    Status = model.Status,
                    Coldroom = context.Coldrooms.FirstOrDefault(x => x.ColdroomId == model.ColdroomId),
                    ClientOrder = context.ClientOrders.First(x => x.ClientOrderId == model.ClientOrderId),
                    Cultivar = context.Cultivars.First(x => x.CultivarId == model.CultivarId)
                };
            }
            catch
            {
                return null;
            }
        }

        public BatchSizeYield? BatchSizeYieldMapper(BatchSizeYieldRequest model)
        {
            try
            {
                return new()
                {
                    BatchId = model.BatchId,
                    CommditySizeId = model.CommditySizeId,
                    Description = model.Description,
                    Yield = model.Yield,
                    Status = model.Status,
                    Batch = context.Batches.First(x => x.BatchId == model.BatchId),
                    CommditySize = context.CommoditySizes.First(x => x.CommoditySizeId == model.CommditySizeId),
                };
            }
            catch
            {
                return null;
            }
        }

        public Block? BlockMapper(BlockRequest model)
        {
            try
            {
                return new()
                {
                    BatchId = model.BatchId,
                    Description = model.Description,
                    Status = model.Status,
                    Batch = context.Batches.First(x => x.BatchId == model.BatchId),
                };
            }
            catch
            {
                return null;
            }
        }

        public ClientOrder? ClientOrderMapper(ClientOrderRequest model)
        {
            // parse date
            DateTime? cleanDatePlaced = null;
            if (model.DatePlaced != null)
            {
                try
                {
                    cleanDatePlaced = DateTime.ParseExact(model.DatePlaced!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanDatePlaced = null;
                }
            }
            // parse date
            DateTime? cleanDateRequired = null;
            if (model.DateRequired != null)
            {
                try
                {
                    cleanDateRequired = DateTime.ParseExact(model.DateRequired!, "yyyy-MM-dd", null);
                }
                catch
                {
                    cleanDateRequired = null;
                }
            }
            try
            {
                return new()
                {
                    OrderStatusId = model.OrderStatusId,
                    ClientId = model.ClientId,
                    ClientName = model.ClientName,
                    DatePlaced = cleanDatePlaced,
                    DateRequired = cleanDateRequired,
                    Description = model.Description,
                    Status = model.Status,
                    OrderStatus = context.OrderStatuses.First(x => x.OrderStatusId == model.OrderStatusId),
                    Client = context.Clients.First(x => x.ClientId == model.ClientId),
                };
        
            }
            catch
            {
                return null;
            }
        }

        public Backup? BackupMapper(BackupRequest model)
        {
            // parse date
            DateTime? Date = null;
            if (model.Date != null)
            {
                try
                {
                    Date = DateTime.ParseExact(model.Date!, "yyyy-MM-dd", null);
                }
                catch
                {
                    Date = null;
                }
            }
            // parse date
            DateTime? Time = null;
            if (model.Time != null)
            {
                try
                {
                    Time = DateTime.ParseExact(model.Time!, "yyyy-MM-dd", null);
                }
                catch
                {
                    Time = null;
                }
            }
            try
            {
                return new()
                {
                    Date = Date,
                    Time = Time,
                    Description = model.Description,
                    Status = model.Status
                };

            }
            catch
            {
                return null;
            }
        }

        public Restore? RestoreMapper(RestoreRequest model)
        {
            // parse date
            DateTime? Date = null;
            if (model.Date != null)
            {
                try
                {
                    Date = DateTime.ParseExact(model.Date!, "yyyy-MM-dd", null);
                }
                catch
                {
                    Date = null;
                }
            }
            // parse date
            DateTime? Time = null;
            if (model.Time != null)
            {
                try
                {
                    Time = DateTime.ParseExact(model.Time!, "yyyy-MM-dd", null);
                }
                catch
                {
                    Time = null;
                }
            }
            try
            {
                return new()
                {
                    Date = Date,
                    BackupId = model.BackupId,
                    Time = Time,
                    Description = model.Description,
                    Status = model.Status,
                    Backup = context.Backups.First(x => x.BackupId == model.BackupId)
                };

            }
            catch
            {
                return null;
            }
        }

        public TestResultStatus? TestResultStatusMapper(TestResultStatusRequest model)
        {
            try
            {
                return new()
                {
                    Trstatus = model.Trstatus,
                    Description = model.Description,
                    Status = model.Status,
                };
            }
            catch
            {
                return null;
            }
        }

        public LabResultDefect? LabResultDefectMapper(LabResultDefectRequest model)
        {
            try
            {
                return new ()
                {
                    LabResultsId = model.LabResultsId,
                    DefectId = model.DefectId,
                    Status = model.Status,
                    LabResults = context.LabResults.First(x => x.LabResultsId == model.LabResultsId),
                    Defect = context.Defects.First(x => x.DefectId == model.DefectId),
                };
            }
            catch
            {
                return null;
            }
        }

        public User? UserMapper(Register model)
        {
            try
            {
                return new()
                {
                    Email = model.Email,
                    Password = model.Password,
                    RoleId = model.RoleId,
                    Role = context.UserRoles.First(x => x.UserRoleId == model.RoleId)
                };
            }
            catch
            {
                return null;
            }
        }
    }
}

