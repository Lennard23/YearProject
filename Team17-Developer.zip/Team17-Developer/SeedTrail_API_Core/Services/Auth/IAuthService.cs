﻿using SeedTrail_API_Core.Request_Models;
using SeedTrail_API_Core.Response_Models;

namespace SeedTrail_API_Core.Services.Auth
{
    public interface IAuthService
    {
        Task<UserResponse?> Login(Login userRequest);

        Task<bool> Register(Register userRequest, bool generateEmail = false);

        Task<bool> ResetPassword(EmailResetModel model);
        Task<bool> Reset(string email);
        Task<bool> RemoveUserById(int id);
    }
}
