﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SeedTrail_API_Core.Helpers;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Models.Email;
using SeedTrail_API_Core.Request_Models;
using SeedTrail_API_Core.Response_Models;
using System.IdentityModel.Tokens.Jwt;
using System.Runtime.Caching;
using System.Security.Claims;
using System.Text;

namespace SeedTrail_API_Core.Services.Auth
{
    public class AuthService : IAuthService
    {
        public IConfiguration Configuration;
        public readonly AppDbContext context;
        public readonly RequestToDbMapper mapper;
        public readonly IEmailService emailService;
        public readonly EmailConfiguration emailConfig;

        private const string CACHE_NAME = "email_links";


        public AuthService(AppDbContext context, IConfiguration configuration, IEmailService emailService, EmailConfiguration config)
        {
            this.context = context;
            Configuration = configuration;
            this.context = context;
            mapper = new RequestToDbMapper(context);
            this.emailService = emailService;
            this.emailConfig = config;
        }

        public async Task<UserResponse?> Login(Login userRequest)
        {
            if (userRequest == null || userRequest.Email == null || userRequest.Password == null)
                return null;

            User? user = await context.Users.FirstOrDefaultAsync(u => u.Email == userRequest.Email && u.Password == Hashers.HashPassword(userRequest.Password));

            if (user == null)
                return null;

            UserRole? role = await context.UserRoles.FirstOrDefaultAsync(x => x.UserRoleId == user.RoleId);

            if (role == null)
                throw new Exception("Role not found");

            //create claims details based on the user information
            var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, Configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("UserId", user.UserId.ToString()),
                        new Claim("Role", role.Name.ToString()),
                        new Claim("Email", user.Email)
                    };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                Configuration["Jwt:Issuer"],
                Configuration["Jwt:Audience"],
                claims,
                expires: DateTime.UtcNow.AddMinutes(60),
                signingCredentials: signIn);

            return new UserResponse()
            {
                Email = user.Email,
                RoleId = role.UserRoleId,
                RoleName = role.Name,
                Token = new JwtSecurityTokenHandler().WriteToken(token)
            };
        }

        public async Task<bool> Register(Register userRequest, bool generateEmail = false)
        {
            User? user = await context.Users.FirstOrDefaultAsync(user => user.Email == userRequest.Email);

            if (user != null)
                return false;

            User? newUser = mapper.UserMapper(userRequest);

            if (newUser == null)
                throw new Exception();

            newUser.Password = Hashers.HashPassword(newUser.Password);

            User userDb = (await context.Users.AddAsync(newUser)).Entity;

            context.SaveChanges();

            if (generateEmail)
            {
                var requestDetails = new List<string>()
            {
                "Link valid only for 5 minutes. If you did not request this email you can safely ignore this.",
                "Username: " + userRequest.Email,
                "Password: " + userRequest.Password,
                Configuration["FrontEnd"]
            };

                // hardcoded subject
                var subject = "SeedTrail Account Created";
                var message = new Message("accountCreatedTemplate.html", requestDetails);

                try
                {
                    await emailService.SendAsync(userRequest.Email, subject, message);
                }
                catch (Exception ex)
                {
                    throw new Exception("Something went wrong sending email: " + ex.Message);
                }
            }

            return true;
        }

        public async Task<bool> ResetPassword(EmailResetModel model)
        {
            User? user = this.context.Users.FirstOrDefault(x => x.Email == model.Email);

            if (user == null)
                return false;

            if (!MemoryCache.Default.Contains($"{CACHE_NAME}_{model.Email}"))
                return false;

            string? cache = MemoryCache.Default.Get($"{CACHE_NAME}_{model.Email}").ToString();


            if (cache == null)
                throw new Exception();

            string[] parts = cache.Split('/');

            if (parts[0] != model.Email || model.Link != parts[1])
                return false;

            user.Password = Hashers.HashPassword(model.Password);

            context.SaveChanges();

            return true;
        }

        public async Task<bool> Reset(string email)
        {
            User? user = this.context.Users.FirstOrDefault(x => x.Email == email);

            if (user == null)
                return false;

            string resetLink = GenerateLink();

            MemoryCache.Default.Add($"{CACHE_NAME}_{email}", $"{email}/{resetLink}", DateTime.Now.AddMinutes(5));

            var requestDetails = new List<string>()
            {
                "Link valid only for 5 minutes. If you did not request this email you can safely ignore this.",
                Configuration["FrontEnd"] + "/reset-password/" + resetLink,
                Configuration["FrontEnd"] + "/reset-password/" + resetLink
            };

            // hardcoded subject
            var subject = "SeedTrail Password Reset";
            var message = new Message("forgotPasswordEmailTemplate.html", requestDetails);

            try
            {
                await emailService.SendAsync(email, subject, message);
            }
            catch (Exception ex)
            {
                throw new Exception("Something went wrong sending email: " + ex.Message);
            }

            return true;
        }

        private string GenerateLink()
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
            var stringChars = new char[20];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            return new string(stringChars);
        }

        public async Task<bool> RemoveUserById(int id)
        {
            User? user = context.Users.FirstOrDefault(x => x.UserId == id);

            if (user == null)
                return false;

            context.Users.Remove(user);
            context.SaveChanges();

            return true;
        }
    }
}
