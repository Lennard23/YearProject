﻿namespace SeedTrail_API_Core.Request_Models
{
    public class BlockRequest
    {
        public int? BatchId { get; set; }
        public string? Description { get; set; }
        public bool? Status { get; set; }
    }
}
