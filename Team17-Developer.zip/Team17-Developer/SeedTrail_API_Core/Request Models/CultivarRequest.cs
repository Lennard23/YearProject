﻿namespace SeedTrail_API_Core.Request_Models
{
    public class CultivarRequest
    {
        public int CommodityId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; } 
        public bool Status { get; set; }
    }
}
