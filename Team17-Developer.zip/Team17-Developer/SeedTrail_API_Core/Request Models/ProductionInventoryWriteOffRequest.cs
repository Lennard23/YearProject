﻿namespace SeedTrail_API_Core.Request_Models
{
    public class ProductionInventoryWriteOffRequest
    {
        public int ProductionInventoryWriteOffId { get; set; }
        
        public string Name { get; set; } = null!;
       
        public string? Description { get; set; }
        public int Quantity { get; set; }
        public bool? Status { get; set; }
    }
}
