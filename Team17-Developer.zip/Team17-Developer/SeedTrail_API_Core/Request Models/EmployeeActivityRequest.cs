﻿namespace SeedTrail_API_Core.Request_Models
{
    public class EmployeeActivityRequest
    {
       /// <summary>
       /// public int EmployeeActivityId { get; set; }
       /// </summary>

      
        public int GreenhouseActivityId { get; set; }

      
        public int EmpId { get; set; }
  
        public string? StartDate { get; set; }
  
        public string? EndDate { get; set; }
        public bool? Status { get; set; }
    }
}
