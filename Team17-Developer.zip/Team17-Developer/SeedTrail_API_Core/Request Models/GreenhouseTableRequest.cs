﻿namespace SeedTrail_API_Core.Request_Models
{
    public class GreenhouseTableRequest
    {
        public int BlockId { get; set; }
        public int GreenhouseId { get; set; }
        public int? TableTotalCrates { get; set; }
        public bool? Status { get; set; }
    }
}
