﻿namespace SeedTrail_API_Core.Request_Models
{
    public class EmployeeRequest
    {
        public int AccessLevelAreaId { get; set; }
        public int EmpTypeId { get; set; }
        public string Name { get; set; } = null!;
        public string Surname { get; set; } = null!;
        public string ContactNr { get; set; } = null!;
        public string NationalId { get; set; } = null!;
        public string Email { get; set; } = null!;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool? Status { get; set; }
    }
}
