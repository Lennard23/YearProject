﻿namespace SeedTrail_API_Core.Request_Models
{
    public class SupplierRequest
    {
        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string ContactNr { get; set; } = null!;
        public string Email { get; set; } = null!;
        public bool? Status { get; set; }
    }
}
