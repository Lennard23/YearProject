﻿namespace SeedTrail_API_Core.Request_Models
{
    public class LabResultDefectRequest
    {
        public int LabResultsId { get; set; }
        public int DefectId { get; set; }
        public bool? Status { get; set; }
    }
}
