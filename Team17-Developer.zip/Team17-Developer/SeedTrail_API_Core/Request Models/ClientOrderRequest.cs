﻿
namespace SeedTrail_API_Core.Request_Models
{
    public class ClientOrderRequest
    {
        public int OrderStatusId { get; set; }
        public int ClientId { get; set; }
        public string ClientName { get; set; } = null!;
        public string? DatePlaced { get; set; }
        public string? DateRequired { get; set; }
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }
    }
}
