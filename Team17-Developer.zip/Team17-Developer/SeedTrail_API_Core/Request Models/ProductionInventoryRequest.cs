﻿
namespace SeedTrail_API_Core.Request_Models
{
    public class ProductionInventoryRequest
    {
        public int ProductionInvCostId { get; set; }
        public int ProductionInventoryWriteOffId { get; set; }
        public int ProductInventoryTypeId { get; set; }

        public int MetricId { get; set; }
        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public int Quantity { get; set; }
        //test 
       // public int? MetricId { get; set; }
        public int? Threshold { get; set; }
        public bool? Status { get; set; }
    }
}
