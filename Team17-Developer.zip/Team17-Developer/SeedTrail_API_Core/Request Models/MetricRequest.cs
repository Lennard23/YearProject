﻿namespace SeedTrail_API_Core.Request_Models
{
    public class MetricRequest
    {
        public int MetricId { get; set; }
        
        public string Name { get; set; }
       
        public string Description { get; set; }

    }
}
