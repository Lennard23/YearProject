﻿namespace SeedTrail_API_Core.Request_Models
{
    public class LabResultRequest
    {
        public int BatchId { get; set; }
        public int TestResultStatusId { get; set; }
        public string? Date { get; set; }
        public string FilePath { get; set; } = null!;
        public string? Description { get; set; }
        public string? Comment { get; set; }
        public bool? Status { get; set; }
    }
}
