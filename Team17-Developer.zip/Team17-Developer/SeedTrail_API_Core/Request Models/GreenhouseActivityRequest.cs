﻿namespace SeedTrail_API_Core.Request_Models
{
    public class GreenhouseActivityRequest
    {
        public int GreenhouseId { get; set; }

        public int ActivityEntryId { get; set; }

        public string? StartDate { get; set; }

        public string? EndDate { get; set; }

        public bool? Status { get; set; }

    }
}