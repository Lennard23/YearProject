﻿namespace SeedTrail_API_Core.Request_Models
{
    public class BatchSizeYieldRequest
    {
        public int BatchId { get; set; }
        public int CommditySizeId { get; set; }
        public string? Description { get; set; }
        public int Yield { get; set; }
        public bool? Status { get; set; }
    }
}
