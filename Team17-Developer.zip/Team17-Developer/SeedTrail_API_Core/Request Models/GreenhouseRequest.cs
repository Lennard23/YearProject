﻿namespace SeedTrail_API_Core.Request_Models
{
    public class GreenhouseRequest
    {
        public int GreenhouseStatusDescId { get; set; }
        public int GreenhouseNumber { get; set; }
        public bool Status { get; set; }
    }
}
