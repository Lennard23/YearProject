﻿namespace SeedTrail_API_Core.Request_Models
{
    public class Register
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public int RoleId { get; set; }
    }

    public class Login
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
