﻿namespace SeedTrail_API_Core.Request_Models
{
    public class ProductionInventoryTypeRequest
    {
        public int ProductInventoryTypeId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public bool? Status { get; set; }
        public int MetricId { get; set; }
    }
}
