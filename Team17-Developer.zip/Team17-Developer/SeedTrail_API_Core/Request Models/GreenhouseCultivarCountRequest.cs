﻿namespace SeedTrail_API_Core.Request_Models
{
    public class GreenhouseCultivarCountRequest
    {
        public int GreenhouseId { get; set; }
        public int CultivarId { get; set; }
        public int Count { get; set; }
    }
}
