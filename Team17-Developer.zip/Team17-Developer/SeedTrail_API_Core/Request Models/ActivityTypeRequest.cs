﻿namespace SeedTrail_API_Core.Request_Models
{
    public class ActivityTypeRequest
    {
        public string Description { get; set; } = null!;
        public string Type { get; set; } = null!;
        public bool? Status { get; set; }
    }
}
