﻿namespace SeedTrail_API_Core.Request_Models
{
    public class ProductionInventoryOrderRequest
    {
        public int ProductionInvOrderId { get; set; }
    
        public int SupplierId { get; set; }
       
        public int ProdctionInvOrderStatusId { get; set; }
        public bool? Status { get; set; }
    }
}
