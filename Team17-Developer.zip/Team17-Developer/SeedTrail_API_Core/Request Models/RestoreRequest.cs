﻿namespace SeedTrail_API_Core.Request_Models
{
    public class RestoreRequest
    {
        public int BackupId { get; set; }
        public string? Date { get; set; }
        public string Description { get; set; } = null!;
        public string? Time { get; set; }
        public bool? Status { get; set; }
    }
}
