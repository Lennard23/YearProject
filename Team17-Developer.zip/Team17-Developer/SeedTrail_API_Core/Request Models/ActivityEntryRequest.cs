﻿namespace SeedTrail_API_Core.Request_Models
{
    public class ActivityEntryRequest
    {
        public int ActivityTypeId { get; set; }
        public int ActivityStatusId { get; set; }
        public int Duration { get; set; }
        public string Description { get; set; } = null!;
        public string Title { get; set; } = null!;
        public int SequenceOrder { get; set; }
        public bool? Status { get; set; }
    }
}
