﻿namespace SeedTrail_API_Core.Request_Models
{
    public class GreenhouseStatusDescriptionRequest
    {
        public int GreenhouseStatusId { get; set; }
        public string? Description { get; set; }
        public bool? Status { get; set; }
    }
}
