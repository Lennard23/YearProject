﻿
namespace SeedTrail_API_Core.Request_Models
{
    public class ClientRequest
    {
        public string Name { get; set; } = null!;
        public string ContractNr { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string? Address { get; set; }
        public bool? Status { get; set; }
    }
}
