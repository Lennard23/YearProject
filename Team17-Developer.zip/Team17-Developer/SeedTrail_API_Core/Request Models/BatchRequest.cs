﻿namespace SeedTrail_API_Core.Request_Models
{
    public class BatchRequest
    {
        public int? ColdroomId { get; set; }
        public int ClientOrderId { get; set; }
        public int CultivarId { get; set; }
        public string? RegistrationNr { get; set; }
        public string? PlantDate { get; set; }
        public int? TotalPlanted { get; set; }
        public string? HarvestDate { get; set; }
        public int? TotalYield { get; set; }
        public int? Scrap { get; set; }
        public int? Sample { get; set; }
        public string? ColdroomDateIn { get; set; }
        public string? ColdroomDateOut { get; set; }
        public int? TotalBags { get; set; }
        public decimal? AvgYield { get; set; }
        public bool? Status { get; set; }
    }
}
