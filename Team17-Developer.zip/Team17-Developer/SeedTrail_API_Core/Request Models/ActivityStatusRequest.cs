﻿namespace SeedTrail_API_Core.Request_Models
{
    public class ActivityStatusRequest
    {
        public int ActivityStatusId { get; set; }
       
        public string Astatus { get; set; } = null!;
  
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }
    }
}
