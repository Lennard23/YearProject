﻿namespace SeedTrail_API_Core.Request_Models
{
    public class EmailResetModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string Link { get; set; }
    }
}
