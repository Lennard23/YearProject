﻿namespace SeedTrail_API_Core.Request_Models
{
    public class GreenhouseProductionInventoryRequest
    {
        public int GreenhouseId { get; set; }
        public int ProductionInvId { get; set; }
        public bool? Status { get; set; }
    }
}
