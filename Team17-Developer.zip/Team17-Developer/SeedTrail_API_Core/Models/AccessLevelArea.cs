﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("AccessLevelArea")]
    public partial class AccessLevelArea
    {
        public AccessLevelArea()
        {
            Employees = new HashSet<Employee>();
        }

        [Key]
        [Column("AccessLevelArea_ID")]
        public int AccessLevelAreaId { get; set; }
        [Column("AccessArea_ID")]
        public int AccessAreaId { get; set; }
        [Column("AccessLevel_ID")]
        public int AccessLevelId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [ForeignKey("AccessAreaId")]
        [InverseProperty("AccessLevelAreas")]
        public virtual AccessArea AccessArea { get; set; } = null!;
        [ForeignKey("AccessLevelId")]
        [InverseProperty("AccessLevelAreas")]
        public virtual AccessLevel AccessLevel { get; set; } = null!;
        [InverseProperty("AccessLevelArea")]
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
