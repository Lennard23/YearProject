﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("GreenhouseActivity")]
    public partial class GreenhouseActivity


    {
        public GreenhouseActivity()
        { EmployeeActivities = new HashSet<EmployeeActivity>();
        }



        [Key]
        [Column("GreenhouseActivity_ID")]
        public int GreenhouseActivityId { get; set; }
        [Column("Greenhouse_ID")]
        public int GreenhouseId { get; set; }
        [Column("ActivityEntry_ID")]
        public int ActivityEntryId { get; set; }
        [Column("Start_Date", TypeName = "datetime")]
        public DateTime? StartDate { get; set; }
        [Column("End_Date", TypeName = "datetime")]
        public DateTime? EndDate { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("ActivityEntryId")]
        [InverseProperty("GreenhouseActivities")]
        public virtual ActivityEntry ActivityEntry { get; set; } = null!;

        [InverseProperty("GreenhouseActivity")]
        public virtual ICollection<EmployeeActivity> EmployeeActivities { get; set; }

        [InverseProperty("GreenhouseActivities")]


        public virtual Greenhouse Greenhouse { get; set; } = null!;
    }
}
