﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Cultivar")]
    public partial class Cultivar
    {
        public Cultivar()
        {
            Batches = new HashSet<Batch>();
            GreenhouseCultivarCounts = new HashSet<GreenhouseCultivarCount>();
        }

        [Key]
        [Column("Cultivar_ID")]
        public int CultivarId { get; set; }
        [Column("Commodity_ID")]
        public int CommodityId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [ForeignKey("CommodityId")]
        [InverseProperty("Cultivars")]
        public virtual Commodity Commodity { get; set; } = null!;
        [InverseProperty("Cultivar")]
        public virtual ICollection<Batch> Batches { get; set; }
        [InverseProperty("Cultivar")]
        public virtual ICollection<GreenhouseCultivarCount> GreenhouseCultivarCounts { get; set; }
    }
}
