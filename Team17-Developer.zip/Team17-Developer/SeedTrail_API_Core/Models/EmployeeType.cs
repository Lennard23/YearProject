﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("EmployeeType")]
    public partial class EmployeeType
    {
        public EmployeeType()
        {
            Employees = new HashSet<Employee>();
        }

        [Key]
        [Column("EmpType_ID")]
        public int EmpTypeId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Type { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("EmpType")]
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
