﻿namespace SeedTrail_API_Core.Models
{
    public class GhRepStatus : IGhRepStatus
    {
        public int BlockCount { get; set; }
        public int TableCount { get; set; }
        public int BatchCount { get; set; }
        public GreenhouseStatus GhStatus { get; set; } = null!;
    }
}
