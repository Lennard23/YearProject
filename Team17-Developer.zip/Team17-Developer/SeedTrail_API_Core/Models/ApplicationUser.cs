﻿using Microsoft.AspNetCore.Identity;

namespace SeedTrail_API_Core.Models
{
    public class ApplicationUser : IdentityUser
    {

        public string FullName { get; set; }


    }
}
