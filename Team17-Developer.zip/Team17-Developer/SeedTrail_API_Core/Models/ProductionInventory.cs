﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ProductionInventory")]
    public partial class ProductionInventory
    {
        public ProductionInventory()
        {
            GreenhouseProductionInventories = new HashSet<GreenhouseProductionInventory>();
            ProductionInventoryOrderDetails = new HashSet<ProductionInventoryOrderDetail>();
        }

        [Key]
        [Column("ProductionInv_ID")]
        public int ProductionInvId { get; set; }
        [Column("ProductionInvCost_ID")]
        public int ProductionInvCostId { get; set; }
        [Column("ProductionInventoryWriteOff_ID")]
        public int ProductionInventoryWriteOffId { get; set; }
        [Column("ProductInventoryType_ID")]
        public int ProductInventoryTypeId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public int Quantity { get; set; }



        [Column("Metric_ID")]
        public int MetricId { get; set; }
        [ForeignKey("MetricId")]
        [InverseProperty("ProductionInventories")]
        public Metric Metric { get; set; }
        public int? Threshold { get; set; } 

        public bool? Status { get; set; }


        [ForeignKey("ProductionInvCostId")]
        [InverseProperty("ProductionInventories")]
        public virtual ProductionInventoryCost ProductionInvCost { get; set; } = null!;

        [ForeignKey("ProductionInventoryWriteOffId")]
        [InverseProperty("ProductionInventories")]
        public virtual ProductionInventoryWriteOff ProductionInventoryWriteOff { get; set; } = null!;
        [InverseProperty("ProductionInventories")]
        public virtual ProductInventoryType ProductInventoryType { get; set; } = null!;
        [InverseProperty("ProductionInv")]
        public virtual ICollection<GreenhouseProductionInventory> GreenhouseProductionInventories { get; set; }
        [InverseProperty("ProductionInventory")]
        public virtual ICollection<ProductionInventoryOrderDetail> ProductionInventoryOrderDetails { get; set; }
    }
}
