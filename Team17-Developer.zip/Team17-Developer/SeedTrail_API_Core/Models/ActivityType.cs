﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ActivityType")]
    public partial class ActivityType
    {
        public ActivityType()
        {
            ActivityEntries = new HashSet<ActivityEntry>();
        }

        [Key]
        [Column("ActivityType_ID")]
        public int ActivityTypeId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        [StringLength(30)]
        [Unicode(false)]
        public string Type { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("ActivityType")]
        public virtual ICollection<ActivityEntry> ActivityEntries { get; set; }
    }
}
