﻿namespace SeedTrail_API_Core.Models
{
    public class NewClientOrder
    {
        public int ClientOrderId { get; set; }

        public int OrderStatusId { get; set; }

        public int ClientId { get; set; }

        public DateTime? DatePlaced { get; set; }

        public DateTime? DateRequired { get; set; }

        public string? Description { get; set; }

        public bool? Status { get; set; }
    }
}
