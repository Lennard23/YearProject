﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ProductionInventoryOrderStatus")]
    public partial class ProductionInventoryOrderStatus
    {
        public ProductionInventoryOrderStatus()
        {
            ProductionInventoryOrders = new HashSet<ProductionInventoryOrder>();
        }

        [Key]
        [Column("ProductionInvOrderStatus_ID")]
        public int ProductionInvOrderStatusId { get; set; }
        [Column("PIStatus")]
        [StringLength(30)]
        [Unicode(false)]
        public string Pistatus { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("ProdctionInvOrderStatus")]
        public virtual ICollection<ProductionInventoryOrder> ProductionInventoryOrders { get; set; }
    }
}
