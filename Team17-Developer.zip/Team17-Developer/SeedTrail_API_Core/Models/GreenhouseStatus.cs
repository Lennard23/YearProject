﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("GreenhouseStatus")]
    public partial class GreenhouseStatus
    {
        public GreenhouseStatus()
        {
            GreenhouseStatusDescriptions = new HashSet<GreenhouseStatusDescription>();
        }

        [Key]
        [Column("GreenhouseStatus_ID")]
        public int GreenhouseStatusId { get; set; }
        [Column("GHStatus")]
        [StringLength(30)]
        [Unicode(false)]
        public string Ghstatus { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("GreenhouseStatus")]
        public virtual ICollection<GreenhouseStatusDescription> GreenhouseStatusDescriptions { get; set; }
    }
}
