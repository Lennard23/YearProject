﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ActiveLogin")]
    public partial class ActiveLogin
    {
        public ActiveLogin()
        {
        }

        [Key]
        [Column("ActiveLogin_ID")]
        public int ActiveLoginId { get; set; }
        [Column("EmpLogin_ID")]
        public int EmpLoginId { get; set; }
        [Column("Start_Time", TypeName = "datetime")]
        public DateTime? StartTime { get; set; }
        [Column("End_Time", TypeName = "datetime")]
        public DateTime? EndTime { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("EmpLoginId")]
        [InverseProperty("ActiveLogins")]
        public virtual EmployeeLogin EmpLogin { get; set; } = null!;
    }
}
