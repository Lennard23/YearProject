﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("GreenhouseStatusDescription")]
    public partial class GreenhouseStatusDescription
    {
        public GreenhouseStatusDescription()
        {
            Greenhouses = new HashSet<Greenhouse>();
        }

        [Key]
        [Column("GreenhouseStatusDesc_ID")]
        public int GreenhouseStatusDescId { get; set; }
        [Column("GreenhouseStatus_ID")]
        public int GreenhouseStatusId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("GreenhouseStatusId")]
        [InverseProperty("GreenhouseStatusDescriptions")]
        public virtual GreenhouseStatus GreenhouseStatus { get; set; } = null!;
        [InverseProperty("GreenhouseStatusDesc")]
        public virtual ICollection<Greenhouse> Greenhouses { get; set; }
    }
}
