﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    public partial class LabResult
    {
        public LabResult()
        {
            LabResultDefects = new HashSet<LabResultDefect>();
        }

        [Key]
        [Column("LabResults_ID")]
        public int LabResultsId { get; set; }
        [Column("Batch_ID")]
        public int BatchId { get; set; }
        [Column("TestResultStatus_ID")]
        public int TestResultStatusId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string FilePath { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Comment { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("BatchId")]
        [InverseProperty("LabResults")]
        public virtual Batch Batch { get; set; } = null!;
        [ForeignKey("TestResultStatusId")]
        [InverseProperty("LabResults")]
        public virtual TestResultStatus TestResultStatus { get; set; } = null!;
        [InverseProperty("LabResults")]
        public virtual ICollection<LabResultDefect> LabResultDefects { get; set; }
    }
}
