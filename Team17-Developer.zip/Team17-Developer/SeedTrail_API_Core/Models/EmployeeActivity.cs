﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("EmployeeActivity")]
    public partial class EmployeeActivity
    {
        [Key]
        [Column("EmployeeActivity_ID")]
        public int EmployeeActivityId { get; set; }

        [Column("GreenhouseActivity_ID")]
        public int GreenhouseActivityId { get; set; }
        
        [Column("Emp_ID")]
        public int EmpId { get; set; }
        [Column("Start_Date", TypeName = "datetime")]
        public DateTime? StartDate { get; set; }
        [Column("End_Date", TypeName = "datetime")]
        public DateTime? EndDate { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("GreenhouseActivityId")]
        [InverseProperty("EmployeeActivities")]
        public virtual GreenhouseActivity GreenhouseActivity { get; set; } = null!;
        [ForeignKey("EmpId")]
        [InverseProperty("EmployeeActivities")]
        public virtual Employee Emp { get; set; } = null!;
    }
}
