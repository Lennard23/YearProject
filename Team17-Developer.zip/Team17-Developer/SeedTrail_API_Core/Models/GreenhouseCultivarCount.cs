﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SeedTrail_API_Core.Models
{
    public class GreenhouseCultivarCount
    {
        [Key]
        [Column("GreenhouseCultivarCount_ID")]
        public int GreenhouseCultivarCountId { get; set; }
        [Column("Greenhouse_ID")]
        public int GreenhouseId { get; set; }
        [Column("Cultivar_ID")]
        public int CultivarId { get; set; }
        [Column("Count")]
        public int Count { get; set; }
        [Column("GreenhouseNumber")]
        public int GreenhouseNumber { get; set; }
        [Column("CultivarName")]
        [StringLength(30)]
        [Unicode(false)]
        public string CultivarName { get; set; } = null!;

        [ForeignKey("GreenhouseId")]
        [InverseProperty("GreenhouseCultivarCounts")]
        public virtual Greenhouse Greenhouse { get; set; } = null!;
        [ForeignKey("CultivarId")]
        [InverseProperty("GreenhouseCultivarCounts")]
        public virtual Cultivar Cultivar { get; set; } = null!;
    }
}
