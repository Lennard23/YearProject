﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("OrderStatus")]
    public partial class OrderStatus
    {
        public OrderStatus()
        {
            ClientOrders = new HashSet<ClientOrder>();
        }

        [Key]
        [Column("OrderStatus_ID")]
        public int OrderStatusId { get; set; }
        [Column("OStatus")]
        [StringLength(30)]
        [Unicode(false)]
        public string Ostatus { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("OrderStatus")]
        public virtual ICollection<ClientOrder> ClientOrders { get; set; }
    }
}
