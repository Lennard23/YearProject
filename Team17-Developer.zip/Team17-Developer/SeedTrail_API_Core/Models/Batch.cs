﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Batch")]
    public partial class Batch
    {
        public Batch()
        {
            BatchSizeYields = new HashSet<BatchSizeYield>();
            Blocks = new HashSet<Block>();
            LabResults = new HashSet<LabResult>();
        }

        [Key]
        [Column("Batch_ID")]
        public int BatchId { get; set; }
        [Column("Coldroom_ID")]
        public int? ColdroomId { get; set; }
        [Column("ClientOrder_ID")]
        public int ClientOrderId { get; set; }
        [Column("Cultivar_ID")]
        public int CultivarId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        [Column("RegistrationNr")]
        public string? RegistrationNr { get; set; }
        [Column("ClientName")]
        [StringLength(60)]
        [Unicode(false)]
        public string ClientName { get; set; } = null!;
        [Column("CultivarName")]
        [StringLength(60)]
        [Unicode(false)]
        public string CultivarName { get; set; } = null!;
        [Column("Plant_Date", TypeName = "datetime")]
        public DateTime? PlantDate { get; set; }
        [Column("Total_Planted")]
        public int? TotalPlanted { get; set; }
        [Column("Harvest_Date", TypeName = "datetime")]
        public DateTime? HarvestDate { get; set; }
        [Column("Total_Yield")]
        public int? TotalYield { get; set; }
        [Column("Scrap")]
        public int? Scrap { get; set; }
        [Column("Sample")]
        public int? Sample { get; set; }
        [Column("Coldroom_Date_In", TypeName = "datetime")]
        public DateTime? ColdroomDateIn { get; set; }
        [Column("Coldroom_Date_Out", TypeName = "datetime")]
        public DateTime? ColdroomDateOut { get; set; }
        [Column("Total_Bags")]
        public int? TotalBags { get; set; }
        [Column("Avg_Yield", TypeName = "decimal(10, 2)")]
        public decimal? AvgYield { get; set; }
        [Column("Status")]
        public bool? Status { get; set; }

        [ForeignKey("ClientOrderId")]
        [InverseProperty("Batches")]
        public virtual ClientOrder ClientOrder { get; set; } = null!;
        [ForeignKey("ColdroomId")]
        [InverseProperty("Batches")]
        public virtual Coldroom? Coldroom { get; set; }
        [ForeignKey("CultivarId")]
        [InverseProperty("Batches")]
        public virtual Cultivar Cultivar { get; set; } = null!;
        [InverseProperty("Batch")]
        public virtual ICollection<BatchSizeYield> BatchSizeYields { get; set; }
        [InverseProperty("Batch")]
        public virtual ICollection<Block> Blocks { get; set; }
        [InverseProperty("Batch")]
        public virtual ICollection<LabResult> LabResults { get; set; }
    }
}
