﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    public partial class Restore
    {
        [Key]
        [Column("Restore_ID")]
        public int RestoreId { get; set; }
        [Column("Backup_ID")]
        public int BackupId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Time { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("BackupId")]
        [InverseProperty("Restores")]
        public virtual Backup? Backup { get; set; }
    }
}
