﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("LabResultDefect")]
    public partial class LabResultDefect
    {
        [Key]
        [Column("LabResultDefect_ID")]
        public int LabResultDefectId { get; set; }
        [Column("LabResults_ID")]
        public int LabResultsId { get; set; }
        [Column("Defect_ID")]
        public int DefectId { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("DefectId")]
        [InverseProperty("LabResultDefects")]
        public virtual Defect Defect { get; set; } = null!;
        [ForeignKey("LabResultsId")]
        [InverseProperty("LabResultDefects")]
        public virtual LabResult LabResults { get; set; } = null!;
    }
}
