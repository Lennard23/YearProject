﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Greenhouse")]
    public partial class Greenhouse
    {
        public Greenhouse()
        {
            GreenhouseActivities = new HashSet<GreenhouseActivity>();
            GreenhouseProductionInventories = new HashSet<GreenhouseProductionInventory>();
            GreenhouseTables = new HashSet<GreenhouseTable>();
            GreenhouseCultivarCounts = new HashSet<GreenhouseCultivarCount>();
        }

        [Key]
        [Column("Greenhouse_ID")]
        public int GreenhouseId { get; set; }
        [Column("GreenhouseStatusDesc_ID")]
        public int GreenhouseStatusDescId { get; set; }
        [Column("Greenhouse_Number")]
        public int GreenhouseNumber { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("GreenhouseStatusDescId")]
        [InverseProperty("Greenhouses")]
        public virtual GreenhouseStatusDescription GreenhouseStatusDesc { get; set; } = null!;
        [InverseProperty("Greenhouse")]
        public virtual ICollection<GreenhouseActivity> GreenhouseActivities { get; set; }
        [InverseProperty("Greenhouse")]
        public virtual ICollection<GreenhouseProductionInventory> GreenhouseProductionInventories { get; set; }
        [InverseProperty("Greenhouse")]
        public virtual ICollection<GreenhouseTable> GreenhouseTables { get; set; }
        [InverseProperty("Greenhouse")]
        public virtual ICollection<GreenhouseCultivarCount> GreenhouseCultivarCounts { get; set; }
    }
}
