﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace SeedTrail_API_Core.Models
{
    public partial class AppDbContext : IdentityDbContext<ApplicationUser>
    {
        public AppDbContext()
        {
        }

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AccessArea> AccessAreas { get; set; } = null!;
        public virtual DbSet<AccessLevel> AccessLevels { get; set; } = null!;
        public virtual DbSet<AccessLevelArea> AccessLevelAreas { get; set; } = null!;
        public virtual DbSet<ActiveLogin> ActiveLogins { get; set; } = null!;
        public virtual DbSet<ActivityEntry> ActivityEntries { get; set; } = null!;
        public virtual DbSet<ActivityStatus> ActivityStatuses { get; set; } = null!;
        public virtual DbSet<ActivityType> ActivityTypes { get; set; } = null!;
        public virtual DbSet<Backup> Backups { get; set; } = null!;
        public virtual DbSet<Batch> Batches { get; set; } = null!;
        public virtual DbSet<BatchSizeYield> BatchSizeYields { get; set; } = null!;
        public virtual DbSet<Block> Blocks { get; set; } = null!;
        public virtual DbSet<Client> Clients { get; set; } = null!;
        public virtual DbSet<ClientOrder> ClientOrders { get; set; } = null!;
        public virtual DbSet<Coldroom> Coldrooms { get; set; } = null!;
        public virtual DbSet<Commodity> Commodities { get; set; } = null!;
        public virtual DbSet<CommoditySize> CommoditySizes { get; set; } = null!;
        public virtual DbSet<Cultivar> Cultivars { get; set; } = null!;
        public virtual DbSet<Defect> Defects { get; set; } = null!;
        public virtual DbSet<Employee> Employees { get; set; } = null!;
        public virtual DbSet<EmployeeActivity> EmployeeActivities { get; set; } = null!;
        public virtual DbSet<EmployeeLogin> EmployeeLogins { get; set; } = null!;
        public virtual DbSet<EmployeeType> EmployeeTypes { get; set; } = null!;
        public virtual DbSet<Greenhouse> Greenhouses { get; set; } = null!;
        public virtual DbSet<GreenhouseActivity> GreenhouseActivities { get; set; } = null!;
        public virtual DbSet<GreenhouseProductionInventory> GreenhouseProductionInventories { get; set; } = null!;
        public virtual DbSet<GreenhouseStatus> GreenhouseStatuses { get; set; } = null!;
        public virtual DbSet<GreenhouseStatusDescription> GreenhouseStatusDescriptions { get; set; } = null!;
        public virtual DbSet<GreenhouseTable> GreenhouseTables { get; set; } = null!;
        public virtual DbSet<LabResult> LabResults { get; set; } = null!;
        public virtual DbSet<LabResultDefect> LabResultDefects { get; set; } = null!;
        public virtual DbSet<GreenhouseCultivarCount> GreenhouseCultivarCounts { get; set; } = null!;
        public virtual DbSet<OrderStatus> OrderStatuses { get; set; } = null!;
        public virtual DbSet<ProductionInventory> ProductionInventories { get; set; } = null!;
        public virtual DbSet<ProductionInventoryCost> ProductionInventoryCosts { get; set; } = null!;
        public virtual DbSet<ProductionInventoryOrder> ProductionInventoryOrders { get; set; } = null!;
        public virtual DbSet<ProductionInventoryOrderStatus> ProductionInventoryOrderStatuses { get; set; } = null!;
        public virtual DbSet<ProductionInventoryWriteOff> ProductionInventoryWriteOffs { get; set; } = null!;
        public virtual DbSet<Restore> Restores { get; set; } = null!;
        public virtual DbSet<Supplier> Suppliers { get; set; } = null!;
        public virtual DbSet<TestResultStatus> TestResultStatuses { get; set; } = null!;
        public virtual DbSet<Metric> Metrics { get; set; } = null!;
        public virtual DbSet<ProductInventoryType> ProductInventoryTypes { get; set; } = null!;
        public virtual DbSet<ProductionInventoryOrderDetail> ProductionInventoryOrderDetails { get; set; } = null!;
        public virtual DbSet<User> Users{ get; set; } = null!;
        public virtual DbSet<UserRole> UserRoles{ get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                .AddJsonFile("appsettings.json")
                .Build();
                optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<TestResultStatus>(entity =>
            {
                entity.Property(e => e.Status).HasDefaultValueSql("((1))");
            });
        }
    }
}
