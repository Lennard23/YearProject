﻿namespace SeedTrail_API_Core.Models
{
    public interface IGhRepStatus
    {
        public int BatchCount { get; set; }
        public int BlockCount { get; set; }
        public int TableCount { get; set; }
        public GreenhouseStatus GhStatus { get; set; }
    }
}
