﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ClientOrder")]
    public partial class ClientOrder
    {
        public ClientOrder()
        {
            Batches = new HashSet<Batch>();
        }

        [Key]
        [Column("ClientOrder_ID")]
        public int ClientOrderId { get; set; }
        [Column("OrderStatus_ID")]
        public int OrderStatusId { get; set; }
        [Column("Client_ID")]
        public int ClientId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string ClientName { get; set; } = null!;
        [Column("Date_Placed", TypeName = "datetime")]
        public DateTime? DatePlaced { get; set; }
        [Column("Date_Required", TypeName = "datetime")]
        public DateTime? DateRequired { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [ForeignKey("ClientId")]
        [InverseProperty("ClientOrders")]
        public virtual Client Client { get; set; } = null!;
        [ForeignKey("OrderStatusId")]
        [InverseProperty("ClientOrders")]
        public virtual OrderStatus OrderStatus { get; set; } = null!;
        [InverseProperty("ClientOrder")]
        public virtual ICollection<Batch> Batches { get; set; }
    }
}
