﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Users")]

    public class User
    {
        [Key]
        [Column("User_ID")]
        public int UserId { get; set; }
        [Column("User_Email")]
        public string Email { get; set; }
        [Column("User_Password")]
        public string Password { get; set; }
        [Column("User_Role_Id")]
        public int RoleId { get; set; }
        [ForeignKey("UserRoleId")]
        [InverseProperty("Users")]
        public virtual UserRole Role { get; set; } = null!;
    }
}
