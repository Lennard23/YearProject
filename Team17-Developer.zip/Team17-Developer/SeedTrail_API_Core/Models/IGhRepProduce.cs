﻿namespace SeedTrail_API_Core.Models
{
    public interface IGhRepProduce
    {
        public int? TotalYield { get; set; }
        public decimal? AverageYield { get; set; }
        public int? TotalBags { get; set; }
        public BatchSizeYield[]? BatchSizeYields { get; set; }
        public int? Scrap { get; set; }
    }
}
