﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ActivityEntry")]
    public partial class ActivityEntry
    {
        public ActivityEntry()
        {
            
            GreenhouseActivities = new HashSet<GreenhouseActivity>();
        }

        [Key]
        [Column("ActivityEntry_ID")]
        public int ActivityEntryId { get; set; }
        [Column("ActivityType_ID")]
        public int ActivityTypeId { get; set; }
        [Column("ActivityStatus_ID")]
        public int ActivityStatusId { get; set; }
        public int Duration { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        [StringLength(30)]
        [Unicode(false)]
        public string Title { get; set; } = null!;
        [Column("Sequence_Order")]
        public int SequenceOrder { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("ActivityStatusId")]
        [InverseProperty("ActivityEntries")]
        public virtual ActivityStatus ActivityStatus { get; set; } = null!;
        [ForeignKey("ActivityTypeId")]
        [InverseProperty("ActivityEntries")]
        public virtual ActivityType ActivityType { get; set; } = null!;
        [InverseProperty("ActivityEntry")]
        
        public virtual ICollection<GreenhouseActivity> GreenhouseActivities { get; set; }
    }
}
