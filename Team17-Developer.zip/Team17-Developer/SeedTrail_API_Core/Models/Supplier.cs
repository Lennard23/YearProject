﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Supplier")]
    [Index("Email", Name = "UQ__Supplier__A9D1053419882BF8", IsUnique = true)]
    public partial class Supplier
    {
        public Supplier()
        {
            ProductionInventoryOrders = new HashSet<ProductionInventoryOrder>();
        }

        [Key]
        [Column("Supplier_ID")]
        public int SupplierId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        [Column("Contact_Nr")]
        [StringLength(100)]
        [Unicode(false)]
        public string ContactNr { get; set; } = null!;
        [StringLength(40)]
        [Unicode(false)]
        public string Email { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("Supplier")]
        public virtual ICollection<ProductionInventoryOrder> ProductionInventoryOrders { get; set; }
    }
}
