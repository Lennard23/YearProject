﻿namespace SeedTrail_API_Core.Models.Email
{
    public interface IEmailService
    {
#pragma warning disable CS8625 // Cannot convert null literal to non-nullable reference type.
        Task SendAsync(string to, string subject, Message message, string from = null);
#pragma warning restore CS8625 // Cannot convert null literal to non-nullable reference type.
    }
}