﻿namespace SeedTrail_API_Core.Models.Email
{
    public class EmailConfiguration
    {
#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
        public string From { get; set; }
        public string SmtpServer { get; set; }
        public int Port { get; set; }
        public string User { get; set; }
        public string Key { get; set; }
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider declaring as nullable.
    }
}
