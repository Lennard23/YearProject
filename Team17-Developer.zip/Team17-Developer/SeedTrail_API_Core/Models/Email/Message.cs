﻿namespace SeedTrail_API_Core.Models.Email
{
    public class Message
    {
        public List<string> InputData { get; set; }
        public string OutputData { get; } // is built in the constructor
        public string TemplatePath { get; set; }
        public Message(string templatePath, List<string> inputData)
        {
            InputData = inputData;
            TemplatePath = templatePath;
            // Read the template file into a string.
            var template = File.ReadAllText(Directory.GetCurrentDirectory() + "/Models/Email/" + templatePath);
            for (int i = 0; i < InputData.Count; i++)
            {
                // Replace the template string placeholders with the input values.
                template = template.Replace("{" + i + "}", InputData[i].ToString());
            }
            // set the output data to the modified template string.
            OutputData = template;
        }
    }
}
