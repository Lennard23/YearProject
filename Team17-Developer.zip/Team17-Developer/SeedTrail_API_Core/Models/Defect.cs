﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Defect")]
    public partial class Defect
    {
        public Defect()
        {
            LabResultDefects = new HashSet<LabResultDefect>();
        }

        [Key]
        [Column("Defect_ID")]
        public int DefectId { get; set; }
        [Column("Defect")]
        [StringLength(15)]
        [Unicode(false)]
        public string Defect1 { get; set; } = null!;
        [Column("Image")]
        [Unicode(false)]
        public string Image { get; set; } = null!;
        [StringLength(50)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("Defect")]
        public virtual ICollection<LabResultDefect> LabResultDefects { get; set; }
    }
}
