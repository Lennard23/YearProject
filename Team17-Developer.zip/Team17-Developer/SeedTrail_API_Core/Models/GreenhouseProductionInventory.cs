﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("GreenhouseProductionInventory")]
    public partial class GreenhouseProductionInventory
    {
        [Key]
        [Column("GreenhouseProductionInventory_ID")]
        public int GreenhouseProductionInventoryId { get; set; }
        [Column("Greenhouse_ID")]
        public int GreenhouseId { get; set; }
        [Column("ProductionInv_ID")]
        public int ProductionInvId { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("GreenhouseId")]
        [InverseProperty("GreenhouseProductionInventories")]
        public virtual Greenhouse Greenhouse { get; set; } = null!;
        [ForeignKey("ProductionInvId")]
        [InverseProperty("GreenhouseProductionInventories")]
        public virtual ProductionInventory ProductionInv { get; set; } = null!;
    }
}
