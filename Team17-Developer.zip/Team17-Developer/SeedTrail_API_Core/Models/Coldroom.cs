﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Coldroom")]
    public partial class Coldroom
    {
        public Coldroom()
        {
            Batches = new HashSet<Batch>();
        }

        [Key]
        [Column("Coldroom_ID")]
        public int ColdroomId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("Coldroom")]
        public virtual ICollection<Batch> Batches { get; set; }
    }
}
