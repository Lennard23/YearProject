﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("AccessLevel")]
    public partial class AccessLevel
    {
        public AccessLevel()
        {
            AccessLevelAreas = new HashSet<AccessLevelArea>();
        }

        [Key]
        [Column("AccessLevel_ID")]
        public int AccessLevelId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        [Column("Access_Level")]
        [StringLength(30)]
        [Unicode(false)]
        public string AccessLevel1 { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("AccessLevel")]
        public virtual ICollection<AccessLevelArea> AccessLevelAreas { get; set; }
    }
}
