﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    public partial class BatchSizeYield
    {
        [Key]
        [Column("BatchSizeYield_ID")]
        public int BatchSizeYieldId { get; set; }
        [Column("Batch_ID")]
        public int BatchId { get; set; }
        [Column("CommditySize_ID")]
        public int CommditySizeId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public int Yield { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("BatchId")]
        [InverseProperty("BatchSizeYields")]
        public virtual Batch Batch { get; set; } = null!;
        [ForeignKey("CommditySizeId")]
        [InverseProperty("BatchSizeYields")]
        public virtual CommoditySize CommditySize { get; set; } = null!;
    }
}
