﻿namespace SeedTrail_API_Core.Models
{
    public interface IBatchRep
    {
        Cultivar Cultivar { get; set; }
        int CommodityId { get; set; }
        string? RegistrationNr { get; set; }
        int ClientOrderId { get; set; }
        Client Client { get; set; }
        DateTime? PlantDate { get; set; }
        DateTime? HarvestDate { get; set; }
        DateTime? ColdroomDateIn { get; set; }
        DateTime? ColdroomDateOut { get; set; }
        int? TotalBags { get; set; }
        int? TotalPlanted { get; set; }
        int? TotalYield { get; set; }
        decimal? AvgYield { get; set; }
        int? Scrap { get; set; }
        int? Sample { get; set; }
        List<BatchSizeYield> BatchSizeYields { get; set; }
        List<CommoditySize> CommoditySizes { get; set; }
    }
}
