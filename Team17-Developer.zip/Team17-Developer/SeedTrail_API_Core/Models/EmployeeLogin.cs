﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("EmployeeLogin")]
    public partial class EmployeeLogin
    {
        public EmployeeLogin()
        {
            ActiveLogins = new HashSet<ActiveLogin>();
        }

        [Key]
        [Column("EmpLogin_ID")]
        public int EmpLoginId { get; set; }
        [Column("Emp_ID")]
        public int EmpId { get; set; }
        [StringLength(40)]
        [Unicode(false)]
        public string Username { get; set; } = null!;
        [StringLength(30)]
        [Unicode(false)]
        public string Password { get; set; } = null!;
        public bool? Status { get; set; }

        [ForeignKey("EmpId")]
        [InverseProperty("EmployeeLogins")]
        public virtual Employee Emp { get; set; } = null!;
        [InverseProperty("EmpLogin")]
        public virtual ICollection<ActiveLogin> ActiveLogins { get; set; }
    }
}
