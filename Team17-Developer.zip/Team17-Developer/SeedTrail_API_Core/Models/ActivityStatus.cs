﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ActivityStatus")]
    public partial class ActivityStatus
    {
        public ActivityStatus()
        {
            ActivityEntries = new HashSet<ActivityEntry>();
        }

        [Key]
        [Column("ActivityStatus_ID")]
        public int ActivityStatusId { get; set; }
        [Column("AStatus")]
        [StringLength(30)]
        [Unicode(false)]
        public string Astatus { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("ActivityStatus")]
        public virtual ICollection<ActivityEntry> ActivityEntries { get; set; }
    }
}
