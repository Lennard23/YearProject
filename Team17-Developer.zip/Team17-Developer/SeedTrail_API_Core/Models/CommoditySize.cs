﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    public partial class CommoditySize
    {
        public CommoditySize()
        {
            BatchSizeYields = new HashSet<BatchSizeYield>();
        }

        [Key]
        [Column("CommoditySize_ID")]
        public int CommoditySizeId { get; set; }
        [Column("Commodity_ID")]
        public int CommodityId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Size { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        public bool? Status { get; set; }

        [ForeignKey("CommodityId")]
        [InverseProperty("CommoditySizes")]
        public virtual Commodity Commodity { get; set; } = null!;
        [InverseProperty("CommditySize")]
        public virtual ICollection<BatchSizeYield> BatchSizeYields { get; set; }
    }
}
