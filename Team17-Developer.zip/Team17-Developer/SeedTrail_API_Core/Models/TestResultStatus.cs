﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("TestResultStatus")]
    public partial class TestResultStatus
    {
        public TestResultStatus()
        {
            LabResults = new HashSet<LabResult>();
        }

        [Key]
        [Column("TestResultStatus_ID")]
        public int TestResultStatusId { get; set; }
        [Column("TRStatus")]
        [StringLength(30)]
        [Unicode(false)]
        public string Trstatus { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("TestResultStatus")]
        public virtual ICollection<LabResult> LabResults { get; set; }
    }
}
