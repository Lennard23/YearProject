﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Block")]
    public partial class Block
    {
        public Block()
        {
            GreenhouseTables = new HashSet<GreenhouseTable>();
        }

        [Key]
        [Column("Block_ID")]
        public int BlockId { get; set; }
        [Column("Batch_ID")]
        public int? BatchId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("BatchId")]
        [InverseProperty("Blocks")]
        public virtual Batch? Batch { get; set; }
        [InverseProperty("Block")]
        public virtual ICollection<GreenhouseTable> GreenhouseTables { get; set; }
    }
}
