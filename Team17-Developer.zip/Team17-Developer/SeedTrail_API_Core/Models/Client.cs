﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Client")]
    [Index("Email", Name = "UQ__Client__A9D10534DAE37486", IsUnique = true)]
    public partial class Client
    {
        public Client()
        {
            ClientOrders = new HashSet<ClientOrder>();
        }

        [Key]
        [Column("Client_ID")]
        public int ClientId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [Column("Contract_Nr")]
        [StringLength(13)]
        [Unicode(false)]
        public string ContractNr { get; set; } = null!;
        [StringLength(40)]
        [Unicode(false)]
        public string Email { get; set; } = null!;
        [StringLength(60)]
        [Unicode(false)]
        public string? Address { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("Client")]
        public virtual ICollection<ClientOrder> ClientOrders { get; set; }
    }
}
