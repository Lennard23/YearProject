﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ProductionInventoryOrder")]
    public partial class ProductionInventoryOrder
    {
        public ProductionInventoryOrder()
        {
            ProductionInvOrderDetails = new HashSet<ProductionInventoryOrderDetail>();
        }

        [Key]
        [Column("ProductionInvOrder_ID")]
        public int ProductionInvOrderId { get; set; }
        [Column("Supplier_ID")]
        public int SupplierId { get; set; }
        [Column("ProdctionInvOrderStatus_ID")]
        public int ProdctionInvOrderStatusId { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("ProdctionInvOrderStatusId")]
        [InverseProperty("ProductionInventoryOrders")]
        public virtual ProductionInventoryOrderStatus ProdctionInvOrderStatus { get; set; } = null!;
        [ForeignKey("SupplierId")]
        [InverseProperty("ProductionInventoryOrders")]
        public virtual Supplier Supplier { get; set; } = null!;
        [InverseProperty("ProductionInvOrder")]
        public virtual ICollection<ProductionInventoryOrderDetail> ProductionInvOrderDetails { get; set; }
    }
}
