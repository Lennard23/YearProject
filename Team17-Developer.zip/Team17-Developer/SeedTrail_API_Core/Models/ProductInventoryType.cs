﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ProductInventoryType")]
    public class ProductInventoryType
    {
        public ProductInventoryType()
        {
            ProductionInventories = new HashSet<ProductionInventory>();
        }

        [Key]
        [Column("ProductInventoryType_ID")]
        public int ProductInventoryTypeId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; }
        public bool? Status { get; set; }
       


        [InverseProperty("ProductInventoryType")]
        public virtual ICollection<ProductionInventory> ProductionInventories { get; set; }
    }
}
