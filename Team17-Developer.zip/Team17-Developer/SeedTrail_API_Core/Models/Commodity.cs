﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Commodity")]
    public partial class Commodity
    {
        public Commodity()
        {
            CommoditySizes = new HashSet<CommoditySize>();
            Cultivars = new HashSet<Cultivar>();
        }

        [Key]
        [Column("Commodity_ID")]
        public int CommodityId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("Commodity")]
        public virtual ICollection<CommoditySize> CommoditySizes { get; set; }
        [InverseProperty("Commodity")]
        public virtual ICollection<Cultivar> Cultivars { get; set; }
    }
}
