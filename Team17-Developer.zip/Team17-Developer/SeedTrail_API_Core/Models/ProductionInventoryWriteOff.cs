﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ProductionInventoryWriteOff")]
    public partial class ProductionInventoryWriteOff
    {
        public ProductionInventoryWriteOff()
        {
            ProductionInventories = new HashSet<ProductionInventory>();
        }

        [Key]
        [Column("ProductionInventoryWriteOff_ID")]
        public int ProductionInventoryWriteOffId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        public int Quantity { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("ProductionInventoryWriteOff")]
        public virtual ICollection<ProductionInventory> ProductionInventories { get; set; }
    }
}
