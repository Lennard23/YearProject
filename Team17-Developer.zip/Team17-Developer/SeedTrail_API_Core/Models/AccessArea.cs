﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("AccessArea")]
    public partial class AccessArea
    {
        public AccessArea()
        {
            AccessLevelAreas = new HashSet<AccessLevelArea>();
        }

        [Key]
        [Column("AccessArea_ID")]
        public int AccessAreaId { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; } = null!;
        [StringLength(30)]
        [Unicode(false)]
        public string Title { get; set; } = null!;
        public bool? Status { get; set; }

        [InverseProperty("AccessArea")]
        public virtual ICollection<AccessLevelArea> AccessLevelAreas { get; set; }
    }
}
