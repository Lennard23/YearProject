﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    public class ProductionInventoryOrderDetail
    {
        [Key]
        [Column("ProductionInvOrderDetail_ID")]
        public int ProductionInventoryOrderDetailId { get; set; }
        public int Quantity { get; set; }
        public bool? Status { get; set; }

        [Column("ProductionInvOrder_ID")]
        public int ProductionInvOrderId { get; set; }

        [Column("ProductionInventories_ID")]
        public int ProductionInventoriesId { get; set; }
        [ForeignKey("ProductionInvId")]
        [InverseProperty("ProductionInventoryOrderDetails")]
        public virtual ProductionInventory ProductionInventory { get; set; } = null!;
        [ForeignKey("ProductionInvOrderId")]
        [InverseProperty("ProductionInvOrderDetails")]
        public virtual ProductionInventoryOrder ProductionInvOrder { get; set; } = null!;
    }
}
