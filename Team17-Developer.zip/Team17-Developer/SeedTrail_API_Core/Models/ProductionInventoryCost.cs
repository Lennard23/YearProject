﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("ProductionInventoryCost")]
    public partial class ProductionInventoryCost
    {
        public ProductionInventoryCost()
        {
            ProductionInventories = new HashSet<ProductionInventory>();
        }

        [Key]
        [Column("ProductionInvCost_ID")]
        public int ProductionInvCostId { get; set; }
        [Column(TypeName = "money")]
        public decimal? Cost { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("ProductionInvCost")]
        public virtual ICollection<ProductionInventory> ProductionInventories { get; set; }
    }
}
