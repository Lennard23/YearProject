﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("GreenhouseTable")]
    public partial class GreenhouseTable
    {
        [Key]
        [Column("Table_ID")]
        public int TableId { get; set; }
        [Column("Block_ID")]
        public int BlockId { get; set; }
        [Column("Greenhouse_ID")]
        public int GreenhouseId { get; set; }
        [Column("Table_Total_Crates")]
        public int? TableTotalCrates { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("BlockId")]
        [InverseProperty("GreenhouseTables")]
        public virtual Block Block { get; set; } = null!;
        [ForeignKey("GreenhouseId")]
        [InverseProperty("GreenhouseTables")]
        public virtual Greenhouse Greenhouse { get; set; } = null!;
    }
}
