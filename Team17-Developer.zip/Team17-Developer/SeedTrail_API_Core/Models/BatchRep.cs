﻿namespace SeedTrail_API_Core.Models
{
    public class BatchRep : IBatchRep
    {
        public Cultivar Cultivar { get; set; } = null!;
        public int CommodityId { get; set; }
        public string? RegistrationNr { get; set; }
        public int ClientOrderId { get; set; }
        public Client Client { get; set; } = null!;
        public DateTime? PlantDate { get; set; }
        public DateTime? HarvestDate { get; set; }
        public DateTime? ColdroomDateIn { get; set; }
        public DateTime? ColdroomDateOut { get; set; }
        public int? TotalBags { get; set; }
        public int? TotalPlanted { get; set; }
        public int? TotalYield { get; set; }
        public decimal? AvgYield { get; set; }
        public int? Scrap { get; set; }
        public int? Sample { get; set; }
        public List<BatchSizeYield> BatchSizeYields { get; set; } = null!;
        public List<CommoditySize> CommoditySizes { get; set; } = null!;
    }
}
