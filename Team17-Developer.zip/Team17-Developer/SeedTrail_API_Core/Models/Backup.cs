﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    public partial class Backup
    {
        public Backup()
        {
            Restores = new HashSet<Restore>();
        }
        
        [Key]
        [Column("Backup_ID")]
        public int BackupId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? Date { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string? Description { get; set; }
        [Unicode(false)]
        public string FileName { get; set; } = null!;
        [Column(TypeName = "datetime")]
        public DateTime? Time { get; set; }
        public bool? Status { get; set; }

        [InverseProperty("Backup")]
        public virtual ICollection<Restore> Restores { get; set; }
    }
}
