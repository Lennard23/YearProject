﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Employee")]
    [Index("Email", Name = "UQ__Employee__A9D10534BDF6C2AD", IsUnique = true)]
    public partial class Employee
    {
        public Employee()
        {
            EmployeeActivities = new HashSet<EmployeeActivity>();
            EmployeeLogins = new HashSet<EmployeeLogin>();
        }

        [Key]
        [Column("Emp_ID")]
        public int EmpId { get; set; }
        [Column("AccessLevelArea_ID")]
        public int AccessLevelAreaId { get; set; }
        [Column("EmpType_ID")]
        public int EmpTypeId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; } = null!;
        [StringLength(30)]
        [Unicode(false)]
        public string Surname { get; set; } = null!;
        [Column("Contact_Nr")]
        [StringLength(13)]
        [Unicode(false)]
        public string ContactNr { get; set; } = null!;
        [Column("National_ID")]
        [StringLength(30)]
        [Unicode(false)]
        public string NationalId { get; set; } = null!;
        [StringLength(40)]
        [Unicode(false)]
        public string? Email { get; set; }
        [Column("Start_Date", TypeName = "datetime")]
        public DateTime? StartDate { get; set; }
        [Column("End_Date", TypeName = "datetime")]
        public DateTime? EndDate { get; set; }
        public bool? Status { get; set; }

        [ForeignKey("AccessLevelAreaId")]
        [InverseProperty("Employees")]
        public virtual AccessLevelArea AccessLevelArea { get; set; } = null!;
        [ForeignKey("EmpTypeId")]
        [InverseProperty("Employees")]
        public virtual EmployeeType EmpType { get; set; } = null!;
        [InverseProperty("Emp")]
        public virtual ICollection<EmployeeActivity> EmployeeActivities { get; set; }
        [InverseProperty("Emp")]
        public virtual ICollection<EmployeeLogin> EmployeeLogins { get; set; }
    }
}
