﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SeedTrail_API_Core.Models
{
    [Table("Metric")]

    public class Metric
    {
        public Metric()
        {
            ProductionInventories = new HashSet<ProductionInventory>();
        }
        [Key]
        [Column("Metric_ID")]
        public int MetricId { get; set; }
        [StringLength(30)]
        [Unicode(false)]
        public string Name { get; set; }
        [StringLength(255)]
        [Unicode(false)]
        public string Description { get; set; }
        [InverseProperty("Metric")]
        public virtual ICollection<ProductionInventory> ProductionInventories { get; set; }
    }

}

