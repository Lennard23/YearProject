﻿namespace SeedTrail_API_Core.Response_Models
{
    public class UserResponse
    {
        public string Email { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public string Token { get; set; }
    }
}
