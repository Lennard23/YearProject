﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class ghcultivarcounts : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "GreenhouseCultivarCounts",
                columns: table => new
                {
                    GreenhouseCultivarCount_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Greenhouse_ID = table.Column<int>(type: "int", nullable: false),
                    Cultivar_ID = table.Column<int>(type: "int", nullable: false),
                    Count = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GreenhouseCultivarCounts", x => x.GreenhouseCultivarCount_ID);
                    table.ForeignKey(
                        name: "FK_GreenhouseCultivarCounts_Cultivar_Cultivar_ID",
                        column: x => x.Cultivar_ID,
                        principalTable: "Cultivar",
                        principalColumn: "Cultivar_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GreenhouseCultivarCounts_Greenhouse_Greenhouse_ID",
                        column: x => x.Greenhouse_ID,
                        principalTable: "Greenhouse",
                        principalColumn: "Greenhouse_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseCultivarCounts_Cultivar_ID",
                table: "GreenhouseCultivarCounts",
                column: "Cultivar_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseCultivarCounts_Greenhouse_ID",
                table: "GreenhouseCultivarCounts",
                column: "Greenhouse_ID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "GreenhouseCultivarCounts");
        }
    }
}
