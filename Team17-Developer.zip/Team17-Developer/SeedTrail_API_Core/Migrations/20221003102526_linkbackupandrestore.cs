﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class linkbackupandrestore : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Restores",
                type: "varchar(255)",
                unicode: false,
                maxLength: 255,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(255)",
                oldUnicode: false,
                oldMaxLength: 255);

            migrationBuilder.AddColumn<int>(
                name: "Backup_ID",
                table: "Restores",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Backups",
                type: "varchar(255)",
                unicode: false,
                maxLength: 255,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(255)",
                oldUnicode: false,
                oldMaxLength: 255);

            migrationBuilder.AddColumn<string>(
                name: "FileName",
                table: "Backups",
                type: "varchar(max)",
                unicode: false,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Restores_Backup_ID",
                table: "Restores",
                column: "Backup_ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Restores_Backups_Backup_ID",
                table: "Restores",
                column: "Backup_ID",
                principalTable: "Backups",
                principalColumn: "Backup_ID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Restores_Backups_Backup_ID",
                table: "Restores");

            migrationBuilder.DropIndex(
                name: "IX_Restores_Backup_ID",
                table: "Restores");

            migrationBuilder.DropColumn(
                name: "Backup_ID",
                table: "Restores");

            migrationBuilder.DropColumn(
                name: "FileName",
                table: "Backups");

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Restores",
                type: "varchar(255)",
                unicode: false,
                maxLength: 255,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "varchar(255)",
                oldUnicode: false,
                oldMaxLength: 255,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "Backups",
                type: "varchar(255)",
                unicode: false,
                maxLength: 255,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "varchar(255)",
                oldUnicode: false,
                oldMaxLength: 255,
                oldNullable: true);
        }
    }
}
