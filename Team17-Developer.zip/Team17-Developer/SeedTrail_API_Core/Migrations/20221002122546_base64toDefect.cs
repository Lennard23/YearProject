﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class base64toDefect : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Image",
                table: "Defect",
                type: "varchar(max)",
                unicode: false,
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Image",
                table: "Defect");
        }
    }
}
