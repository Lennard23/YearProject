﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class fixes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
