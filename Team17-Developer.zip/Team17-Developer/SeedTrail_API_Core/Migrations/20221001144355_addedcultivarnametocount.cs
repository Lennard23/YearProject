﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class addedcultivarnametocount : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CultivarName",
                table: "GreenhouseCultivarCounts",
                type: "varchar(30)",
                unicode: false,
                maxLength: 30,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "GreenhouseNumber",
                table: "GreenhouseCultivarCounts",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CultivarName",
                table: "GreenhouseCultivarCounts");

            migrationBuilder.DropColumn(
                name: "GreenhouseNumber",
                table: "GreenhouseCultivarCounts");
        }
    }
}
