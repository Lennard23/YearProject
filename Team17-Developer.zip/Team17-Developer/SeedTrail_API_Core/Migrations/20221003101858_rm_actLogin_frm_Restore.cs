﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class rm_actLogin_frm_Restore : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Restores_ActiveLogin_ActiveLogin_ID",
                table: "Restores");

            migrationBuilder.DropTable(
                name: "TransactionLog");

            migrationBuilder.DropIndex(
                name: "IX_Restores_ActiveLogin_ID",
                table: "Restores");

            migrationBuilder.DropColumn(
                name: "ActiveLogin_ID",
                table: "Restores");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ActiveLogin_ID",
                table: "Restores",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "TransactionLog",
                columns: table => new
                {
                    TransactionLog_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Backup_ID = table.Column<int>(type: "int", nullable: false),
                    Restore_ID = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransactionLog", x => x.TransactionLog_ID);
                    table.ForeignKey(
                        name: "FK_TransactionLog_Backups_Backup_ID",
                        column: x => x.Backup_ID,
                        principalTable: "Backups",
                        principalColumn: "Backup_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TransactionLog_Restores_Restore_ID",
                        column: x => x.Restore_ID,
                        principalTable: "Restores",
                        principalColumn: "Restore_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Restores_ActiveLogin_ID",
                table: "Restores",
                column: "ActiveLogin_ID");

            migrationBuilder.CreateIndex(
                name: "IX_TransactionLog_Backup_ID",
                table: "TransactionLog",
                column: "Backup_ID");

            migrationBuilder.CreateIndex(
                name: "IX_TransactionLog_Restore_ID",
                table: "TransactionLog",
                column: "Restore_ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Restores_ActiveLogin_ActiveLogin_ID",
                table: "Restores",
                column: "ActiveLogin_ID",
                principalTable: "ActiveLogin",
                principalColumn: "ActiveLogin_ID");
        }
    }
}
