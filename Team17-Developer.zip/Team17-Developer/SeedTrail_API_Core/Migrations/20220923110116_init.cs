﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SeedTrail_API_Core.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AccessArea",
                columns: table => new
                {
                    AccessArea_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Title = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccessArea", x => x.AccessArea_ID);
                });

            migrationBuilder.CreateTable(
                name: "AccessLevel",
                columns: table => new
                {
                    AccessLevel_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Access_Level = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccessLevel", x => x.AccessLevel_ID);
                });

            migrationBuilder.CreateTable(
                name: "ActivityStatus",
                columns: table => new
                {
                    ActivityStatus_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AStatus = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActivityStatus", x => x.ActivityStatus_ID);
                });

            migrationBuilder.CreateTable(
                name: "ActivityType",
                columns: table => new
                {
                    ActivityType_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Type = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActivityType", x => x.ActivityType_ID);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Backups",
                columns: table => new
                {
                    Backup_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Time = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Backups", x => x.Backup_ID);
                });

            migrationBuilder.CreateTable(
                name: "Client",
                columns: table => new
                {
                    Client_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Contract_Nr = table.Column<string>(type: "varchar(13)", unicode: false, maxLength: 13, nullable: false),
                    Email = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    Address = table.Column<string>(type: "varchar(60)", unicode: false, maxLength: 60, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Client", x => x.Client_ID);
                });

            migrationBuilder.CreateTable(
                name: "Coldroom",
                columns: table => new
                {
                    Coldroom_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Coldroom", x => x.Coldroom_ID);
                });

            migrationBuilder.CreateTable(
                name: "Commodity",
                columns: table => new
                {
                    Commodity_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Commodity", x => x.Commodity_ID);
                });

            migrationBuilder.CreateTable(
                name: "Defect",
                columns: table => new
                {
                    Defect_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Defect = table.Column<string>(type: "varchar(15)", unicode: false, maxLength: 15, nullable: false),
                    Description = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Defect", x => x.Defect_ID);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeType",
                columns: table => new
                {
                    EmpType_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeType", x => x.EmpType_ID);
                });

            migrationBuilder.CreateTable(
                name: "GreenhouseStatus",
                columns: table => new
                {
                    GreenhouseStatus_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GHStatus = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GreenhouseStatus", x => x.GreenhouseStatus_ID);
                });

            migrationBuilder.CreateTable(
                name: "Metric",
                columns: table => new
                {
                    Metric_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Metric", x => x.Metric_ID);
                });

            migrationBuilder.CreateTable(
                name: "OrderStatus",
                columns: table => new
                {
                    OrderStatus_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OStatus = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderStatus", x => x.OrderStatus_ID);
                });

            migrationBuilder.CreateTable(
                name: "ProductInventoryType",
                columns: table => new
                {
                    ProductInventoryType_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductInventoryType", x => x.ProductInventoryType_ID);
                });

            migrationBuilder.CreateTable(
                name: "ProductionInventoryCost",
                columns: table => new
                {
                    ProductionInvCost_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Cost = table.Column<decimal>(type: "money", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionInventoryCost", x => x.ProductionInvCost_ID);
                });

            migrationBuilder.CreateTable(
                name: "ProductionInventoryOrderStatus",
                columns: table => new
                {
                    ProductionInvOrderStatus_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PIStatus = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionInventoryOrderStatus", x => x.ProductionInvOrderStatus_ID);
                });

            migrationBuilder.CreateTable(
                name: "ProductionInventoryWriteOff",
                columns: table => new
                {
                    ProductionInventoryWriteOff_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionInventoryWriteOff", x => x.ProductionInventoryWriteOff_ID);
                });

            migrationBuilder.CreateTable(
                name: "Supplier",
                columns: table => new
                {
                    Supplier_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Contact_Nr = table.Column<string>(type: "varchar(100)", unicode: false, maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Supplier", x => x.Supplier_ID);
                });

            migrationBuilder.CreateTable(
                name: "TestResultStatus",
                columns: table => new
                {
                    TestResultStatus_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TRStatus = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true, defaultValueSql: "((1))")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TestResultStatus", x => x.TestResultStatus_ID);
                });

            migrationBuilder.CreateTable(
                name: "UserRoles",
                columns: table => new
                {
                    User_Role_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserRoles", x => x.User_Role_ID);
                });

            migrationBuilder.CreateTable(
                name: "AccessLevelArea",
                columns: table => new
                {
                    AccessLevelArea_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccessArea_ID = table.Column<int>(type: "int", nullable: false),
                    AccessLevel_ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccessLevelArea", x => x.AccessLevelArea_ID);
                    table.ForeignKey(
                        name: "FK_AccessLevelArea_AccessArea_AccessArea_ID",
                        column: x => x.AccessArea_ID,
                        principalTable: "AccessArea",
                        principalColumn: "AccessArea_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AccessLevelArea_AccessLevel_AccessLevel_ID",
                        column: x => x.AccessLevel_ID,
                        principalTable: "AccessLevel",
                        principalColumn: "AccessLevel_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ActivityEntry",
                columns: table => new
                {
                    ActivityEntry_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActivityType_ID = table.Column<int>(type: "int", nullable: false),
                    ActivityStatus_ID = table.Column<int>(type: "int", nullable: false),
                    Duration = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Title = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Sequence_Order = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActivityEntry", x => x.ActivityEntry_ID);
                    table.ForeignKey(
                        name: "FK_ActivityEntry_ActivityStatus_ActivityStatus_ID",
                        column: x => x.ActivityStatus_ID,
                        principalTable: "ActivityStatus",
                        principalColumn: "ActivityStatus_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ActivityEntry_ActivityType_ActivityType_ID",
                        column: x => x.ActivityType_ID,
                        principalTable: "ActivityType",
                        principalColumn: "ActivityType_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CommoditySizes",
                columns: table => new
                {
                    CommoditySize_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Commodity_ID = table.Column<int>(type: "int", nullable: false),
                    Size = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CommoditySizes", x => x.CommoditySize_ID);
                    table.ForeignKey(
                        name: "FK_CommoditySizes_Commodity_Commodity_ID",
                        column: x => x.Commodity_ID,
                        principalTable: "Commodity",
                        principalColumn: "Commodity_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Cultivar",
                columns: table => new
                {
                    Cultivar_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Commodity_ID = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Cultivar", x => x.Cultivar_ID);
                    table.ForeignKey(
                        name: "FK_Cultivar_Commodity_Commodity_ID",
                        column: x => x.Commodity_ID,
                        principalTable: "Commodity",
                        principalColumn: "Commodity_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "GreenhouseStatusDescription",
                columns: table => new
                {
                    GreenhouseStatusDesc_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GreenhouseStatus_ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GreenhouseStatusDescription", x => x.GreenhouseStatusDesc_ID);
                    table.ForeignKey(
                        name: "FK_GreenhouseStatusDescription_GreenhouseStatus_GreenhouseStatus_ID",
                        column: x => x.GreenhouseStatus_ID,
                        principalTable: "GreenhouseStatus",
                        principalColumn: "GreenhouseStatus_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClientOrder",
                columns: table => new
                {
                    ClientOrder_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrderStatus_ID = table.Column<int>(type: "int", nullable: false),
                    Client_ID = table.Column<int>(type: "int", nullable: false),
                    ClientName = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Date_Placed = table.Column<DateTime>(type: "datetime", nullable: true),
                    Date_Required = table.Column<DateTime>(type: "datetime", nullable: true),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClientOrder", x => x.ClientOrder_ID);
                    table.ForeignKey(
                        name: "FK_ClientOrder_Client_Client_ID",
                        column: x => x.Client_ID,
                        principalTable: "Client",
                        principalColumn: "Client_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClientOrder_OrderStatus_OrderStatus_ID",
                        column: x => x.OrderStatus_ID,
                        principalTable: "OrderStatus",
                        principalColumn: "OrderStatus_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductionInventory",
                columns: table => new
                {
                    ProductionInv_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProductionInvCost_ID = table.Column<int>(type: "int", nullable: false),
                    ProductionInventoryWriteOff_ID = table.Column<int>(type: "int", nullable: false),
                    ProductInventoryType_ID = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Metric_ID = table.Column<int>(type: "int", nullable: false),
                    Threshold = table.Column<int>(type: "int", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionInventory", x => x.ProductionInv_ID);
                    table.ForeignKey(
                        name: "FK_ProductionInventory_Metric_Metric_ID",
                        column: x => x.Metric_ID,
                        principalTable: "Metric",
                        principalColumn: "Metric_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductionInventory_ProductInventoryType_ProductInventoryType_ID",
                        column: x => x.ProductInventoryType_ID,
                        principalTable: "ProductInventoryType",
                        principalColumn: "ProductInventoryType_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductionInventory_ProductionInventoryCost_ProductionInvCost_ID",
                        column: x => x.ProductionInvCost_ID,
                        principalTable: "ProductionInventoryCost",
                        principalColumn: "ProductionInvCost_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductionInventory_ProductionInventoryWriteOff_ProductionInventoryWriteOff_ID",
                        column: x => x.ProductionInventoryWriteOff_ID,
                        principalTable: "ProductionInventoryWriteOff",
                        principalColumn: "ProductionInventoryWriteOff_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductionInventoryOrder",
                columns: table => new
                {
                    ProductionInvOrder_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Supplier_ID = table.Column<int>(type: "int", nullable: false),
                    ProdctionInvOrderStatus_ID = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionInventoryOrder", x => x.ProductionInvOrder_ID);
                    table.ForeignKey(
                        name: "FK_ProductionInventoryOrder_ProductionInventoryOrderStatus_ProdctionInvOrderStatus_ID",
                        column: x => x.ProdctionInvOrderStatus_ID,
                        principalTable: "ProductionInventoryOrderStatus",
                        principalColumn: "ProductionInvOrderStatus_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductionInventoryOrder_Supplier_Supplier_ID",
                        column: x => x.Supplier_ID,
                        principalTable: "Supplier",
                        principalColumn: "Supplier_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    User_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    User_Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    User_Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    User_Role_Id = table.Column<int>(type: "int", nullable: false),
                    UserRoleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.User_ID);
                    table.ForeignKey(
                        name: "FK_Users_UserRoles_UserRoleId",
                        column: x => x.UserRoleId,
                        principalTable: "UserRoles",
                        principalColumn: "User_Role_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    Emp_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AccessLevelArea_ID = table.Column<int>(type: "int", nullable: false),
                    EmpType_ID = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Surname = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Contact_Nr = table.Column<string>(type: "varchar(13)", unicode: false, maxLength: 13, nullable: false),
                    National_ID = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Email = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: true),
                    Start_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    End_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.Emp_ID);
                    table.ForeignKey(
                        name: "FK_Employee_AccessLevelArea_AccessLevelArea_ID",
                        column: x => x.AccessLevelArea_ID,
                        principalTable: "AccessLevelArea",
                        principalColumn: "AccessLevelArea_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Employee_EmployeeType_EmpType_ID",
                        column: x => x.EmpType_ID,
                        principalTable: "EmployeeType",
                        principalColumn: "EmpType_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Greenhouse",
                columns: table => new
                {
                    Greenhouse_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GreenhouseStatusDesc_ID = table.Column<int>(type: "int", nullable: false),
                    Greenhouse_Number = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Greenhouse", x => x.Greenhouse_ID);
                    table.ForeignKey(
                        name: "FK_Greenhouse_GreenhouseStatusDescription_GreenhouseStatusDesc_ID",
                        column: x => x.GreenhouseStatusDesc_ID,
                        principalTable: "GreenhouseStatusDescription",
                        principalColumn: "GreenhouseStatusDesc_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Batch",
                columns: table => new
                {
                    Batch_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Coldroom_ID = table.Column<int>(type: "int", nullable: true),
                    ClientOrder_ID = table.Column<int>(type: "int", nullable: false),
                    Cultivar_ID = table.Column<int>(type: "int", nullable: false),
                    RegistrationNr = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Plant_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Total_Planted = table.Column<int>(type: "int", nullable: true),
                    Harvest_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Total_Yield = table.Column<int>(type: "int", nullable: true),
                    Scrap = table.Column<int>(type: "int", nullable: true),
                    Sample = table.Column<int>(type: "int", nullable: true),
                    Coldroom_Date_In = table.Column<DateTime>(type: "datetime", nullable: true),
                    Coldroom_Date_Out = table.Column<DateTime>(type: "datetime", nullable: true),
                    Total_Bags = table.Column<int>(type: "int", nullable: true),
                    Avg_Yield = table.Column<decimal>(type: "decimal(10,2)", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Batch", x => x.Batch_ID);
                    table.ForeignKey(
                        name: "FK_Batch_ClientOrder_ClientOrder_ID",
                        column: x => x.ClientOrder_ID,
                        principalTable: "ClientOrder",
                        principalColumn: "ClientOrder_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Batch_Coldroom_Coldroom_ID",
                        column: x => x.Coldroom_ID,
                        principalTable: "Coldroom",
                        principalColumn: "Coldroom_ID");
                    table.ForeignKey(
                        name: "FK_Batch_Cultivar_Cultivar_ID",
                        column: x => x.Cultivar_ID,
                        principalTable: "Cultivar",
                        principalColumn: "Cultivar_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ProductionInventoryOrderDetails",
                columns: table => new
                {
                    ProductionInvOrderDetail_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true),
                    ProductionInvOrder_ID = table.Column<int>(type: "int", nullable: false),
                    ProductionInventories_ID = table.Column<int>(type: "int", nullable: false),
                    ProductionInvId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductionInventoryOrderDetails", x => x.ProductionInvOrderDetail_ID);
                    table.ForeignKey(
                        name: "FK_ProductionInventoryOrderDetails_ProductionInventory_ProductionInvId",
                        column: x => x.ProductionInvId,
                        principalTable: "ProductionInventory",
                        principalColumn: "ProductionInv_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProductionInventoryOrderDetails_ProductionInventoryOrder_ProductionInvOrder_ID",
                        column: x => x.ProductionInvOrder_ID,
                        principalTable: "ProductionInventoryOrder",
                        principalColumn: "ProductionInvOrder_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeLogin",
                columns: table => new
                {
                    EmpLogin_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Emp_ID = table.Column<int>(type: "int", nullable: false),
                    Username = table.Column<string>(type: "varchar(40)", unicode: false, maxLength: 40, nullable: false),
                    Password = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeLogin", x => x.EmpLogin_ID);
                    table.ForeignKey(
                        name: "FK_EmployeeLogin_Employee_Emp_ID",
                        column: x => x.Emp_ID,
                        principalTable: "Employee",
                        principalColumn: "Emp_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "GreenhouseActivity",
                columns: table => new
                {
                    GreenhouseActivity_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Greenhouse_ID = table.Column<int>(type: "int", nullable: false),
                    ActivityEntry_ID = table.Column<int>(type: "int", nullable: false),
                    Start_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    End_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GreenhouseActivity", x => x.GreenhouseActivity_ID);
                    table.ForeignKey(
                        name: "FK_GreenhouseActivity_ActivityEntry_ActivityEntry_ID",
                        column: x => x.ActivityEntry_ID,
                        principalTable: "ActivityEntry",
                        principalColumn: "ActivityEntry_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GreenhouseActivity_Greenhouse_Greenhouse_ID",
                        column: x => x.Greenhouse_ID,
                        principalTable: "Greenhouse",
                        principalColumn: "Greenhouse_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "GreenhouseProductionInventory",
                columns: table => new
                {
                    GreenhouseProductionInventory_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Greenhouse_ID = table.Column<int>(type: "int", nullable: false),
                    ProductionInv_ID = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GreenhouseProductionInventory", x => x.GreenhouseProductionInventory_ID);
                    table.ForeignKey(
                        name: "FK_GreenhouseProductionInventory_Greenhouse_Greenhouse_ID",
                        column: x => x.Greenhouse_ID,
                        principalTable: "Greenhouse",
                        principalColumn: "Greenhouse_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GreenhouseProductionInventory_ProductionInventory_ProductionInv_ID",
                        column: x => x.ProductionInv_ID,
                        principalTable: "ProductionInventory",
                        principalColumn: "ProductionInv_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "BatchSizeYields",
                columns: table => new
                {
                    BatchSizeYield_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Batch_ID = table.Column<int>(type: "int", nullable: false),
                    CommditySize_ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Yield = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BatchSizeYields", x => x.BatchSizeYield_ID);
                    table.ForeignKey(
                        name: "FK_BatchSizeYields_Batch_Batch_ID",
                        column: x => x.Batch_ID,
                        principalTable: "Batch",
                        principalColumn: "Batch_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BatchSizeYields_CommoditySizes_CommditySize_ID",
                        column: x => x.CommditySize_ID,
                        principalTable: "CommoditySizes",
                        principalColumn: "CommoditySize_ID");
                });

            migrationBuilder.CreateTable(
                name: "Block",
                columns: table => new
                {
                    Block_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Batch_ID = table.Column<int>(type: "int", nullable: true),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Block", x => x.Block_ID);
                    table.ForeignKey(
                        name: "FK_Block_Batch_Batch_ID",
                        column: x => x.Batch_ID,
                        principalTable: "Batch",
                        principalColumn: "Batch_ID");
                });

            migrationBuilder.CreateTable(
                name: "LabResults",
                columns: table => new
                {
                    LabResults_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Batch_ID = table.Column<int>(type: "int", nullable: false),
                    TestResultStatus_ID = table.Column<int>(type: "int", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    FilePath = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Comment = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LabResults", x => x.LabResults_ID);
                    table.ForeignKey(
                        name: "FK_LabResults_Batch_Batch_ID",
                        column: x => x.Batch_ID,
                        principalTable: "Batch",
                        principalColumn: "Batch_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_LabResults_TestResultStatus_TestResultStatus_ID",
                        column: x => x.TestResultStatus_ID,
                        principalTable: "TestResultStatus",
                        principalColumn: "TestResultStatus_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ActiveLogin",
                columns: table => new
                {
                    ActiveLogin_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EmpLogin_ID = table.Column<int>(type: "int", nullable: false),
                    Start_Time = table.Column<DateTime>(type: "datetime", nullable: true),
                    End_Time = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ActiveLogin", x => x.ActiveLogin_ID);
                    table.ForeignKey(
                        name: "FK_ActiveLogin_EmployeeLogin_EmpLogin_ID",
                        column: x => x.EmpLogin_ID,
                        principalTable: "EmployeeLogin",
                        principalColumn: "EmpLogin_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EmployeeActivity",
                columns: table => new
                {
                    EmployeeActivity_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GreenhouseActivity_ID = table.Column<int>(type: "int", nullable: false),
                    Emp_ID = table.Column<int>(type: "int", nullable: false),
                    Start_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    End_Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeActivity", x => x.EmployeeActivity_ID);
                    table.ForeignKey(
                        name: "FK_EmployeeActivity_Employee_Emp_ID",
                        column: x => x.Emp_ID,
                        principalTable: "Employee",
                        principalColumn: "Emp_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EmployeeActivity_GreenhouseActivity_GreenhouseActivity_ID",
                        column: x => x.GreenhouseActivity_ID,
                        principalTable: "GreenhouseActivity",
                        principalColumn: "GreenhouseActivity_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "GreenhouseTable",
                columns: table => new
                {
                    Table_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Block_ID = table.Column<int>(type: "int", nullable: false),
                    Greenhouse_ID = table.Column<int>(type: "int", nullable: false),
                    Table_Total_Crates = table.Column<int>(type: "int", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GreenhouseTable", x => x.Table_ID);
                    table.ForeignKey(
                        name: "FK_GreenhouseTable_Block_Block_ID",
                        column: x => x.Block_ID,
                        principalTable: "Block",
                        principalColumn: "Block_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GreenhouseTable_Greenhouse_Greenhouse_ID",
                        column: x => x.Greenhouse_ID,
                        principalTable: "Greenhouse",
                        principalColumn: "Greenhouse_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "LabResultDefect",
                columns: table => new
                {
                    LabResultDefect_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LabResults_ID = table.Column<int>(type: "int", nullable: false),
                    Defect_ID = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LabResultDefect", x => x.LabResultDefect_ID);
                    table.ForeignKey(
                        name: "FK_LabResultDefect_Defect_Defect_ID",
                        column: x => x.Defect_ID,
                        principalTable: "Defect",
                        principalColumn: "Defect_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_LabResultDefect_LabResults_LabResults_ID",
                        column: x => x.LabResults_ID,
                        principalTable: "LabResults",
                        principalColumn: "LabResults_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Restores",
                columns: table => new
                {
                    Restore_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActiveLogin_ID = table.Column<int>(type: "int", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime", nullable: true),
                    Description = table.Column<string>(type: "varchar(255)", unicode: false, maxLength: 255, nullable: false),
                    Time = table.Column<DateTime>(type: "datetime", nullable: true),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Restores", x => x.Restore_ID);
                    table.ForeignKey(
                        name: "FK_Restores_ActiveLogin_ActiveLogin_ID",
                        column: x => x.ActiveLogin_ID,
                        principalTable: "ActiveLogin",
                        principalColumn: "ActiveLogin_ID");
                });

            migrationBuilder.CreateTable(
                name: "TransactionLog",
                columns: table => new
                {
                    TransactionLog_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Backup_ID = table.Column<int>(type: "int", nullable: false),
                    Restore_ID = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TransactionLog", x => x.TransactionLog_ID);
                    table.ForeignKey(
                        name: "FK_TransactionLog_Backups_Backup_ID",
                        column: x => x.Backup_ID,
                        principalTable: "Backups",
                        principalColumn: "Backup_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TransactionLog_Restores_Restore_ID",
                        column: x => x.Restore_ID,
                        principalTable: "Restores",
                        principalColumn: "Restore_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AccessLevelArea_AccessArea_ID",
                table: "AccessLevelArea",
                column: "AccessArea_ID");

            migrationBuilder.CreateIndex(
                name: "IX_AccessLevelArea_AccessLevel_ID",
                table: "AccessLevelArea",
                column: "AccessLevel_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ActiveLogin_EmpLogin_ID",
                table: "ActiveLogin",
                column: "EmpLogin_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ActivityEntry_ActivityStatus_ID",
                table: "ActivityEntry",
                column: "ActivityStatus_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ActivityEntry_ActivityType_ID",
                table: "ActivityEntry",
                column: "ActivityType_ID");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Batch_ClientOrder_ID",
                table: "Batch",
                column: "ClientOrder_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Batch_Coldroom_ID",
                table: "Batch",
                column: "Coldroom_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Batch_Cultivar_ID",
                table: "Batch",
                column: "Cultivar_ID");

            migrationBuilder.CreateIndex(
                name: "IX_BatchSizeYields_Batch_ID",
                table: "BatchSizeYields",
                column: "Batch_ID");

            migrationBuilder.CreateIndex(
                name: "IX_BatchSizeYields_CommditySize_ID",
                table: "BatchSizeYields",
                column: "CommditySize_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Block_Batch_ID",
                table: "Block",
                column: "Batch_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__Client__A9D10534DAE37486",
                table: "Client",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ClientOrder_Client_ID",
                table: "ClientOrder",
                column: "Client_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ClientOrder_OrderStatus_ID",
                table: "ClientOrder",
                column: "OrderStatus_ID");

            migrationBuilder.CreateIndex(
                name: "IX_CommoditySizes_Commodity_ID",
                table: "CommoditySizes",
                column: "Commodity_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Cultivar_Commodity_ID",
                table: "Cultivar",
                column: "Commodity_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_AccessLevelArea_ID",
                table: "Employee",
                column: "AccessLevelArea_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_EmpType_ID",
                table: "Employee",
                column: "EmpType_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__Employee__A9D10534BDF6C2AD",
                table: "Employee",
                column: "Email",
                unique: true,
                filter: "[Email] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeActivity_Emp_ID",
                table: "EmployeeActivity",
                column: "Emp_ID");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeActivity_GreenhouseActivity_ID",
                table: "EmployeeActivity",
                column: "GreenhouseActivity_ID");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeeLogin_Emp_ID",
                table: "EmployeeLogin",
                column: "Emp_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Greenhouse_GreenhouseStatusDesc_ID",
                table: "Greenhouse",
                column: "GreenhouseStatusDesc_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseActivity_ActivityEntry_ID",
                table: "GreenhouseActivity",
                column: "ActivityEntry_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseActivity_Greenhouse_ID",
                table: "GreenhouseActivity",
                column: "Greenhouse_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseProductionInventory_Greenhouse_ID",
                table: "GreenhouseProductionInventory",
                column: "Greenhouse_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseProductionInventory_ProductionInv_ID",
                table: "GreenhouseProductionInventory",
                column: "ProductionInv_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseStatusDescription_GreenhouseStatus_ID",
                table: "GreenhouseStatusDescription",
                column: "GreenhouseStatus_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseTable_Block_ID",
                table: "GreenhouseTable",
                column: "Block_ID");

            migrationBuilder.CreateIndex(
                name: "IX_GreenhouseTable_Greenhouse_ID",
                table: "GreenhouseTable",
                column: "Greenhouse_ID");

            migrationBuilder.CreateIndex(
                name: "IX_LabResultDefect_Defect_ID",
                table: "LabResultDefect",
                column: "Defect_ID");

            migrationBuilder.CreateIndex(
                name: "IX_LabResultDefect_LabResults_ID",
                table: "LabResultDefect",
                column: "LabResults_ID");

            migrationBuilder.CreateIndex(
                name: "IX_LabResults_Batch_ID",
                table: "LabResults",
                column: "Batch_ID");

            migrationBuilder.CreateIndex(
                name: "IX_LabResults_TestResultStatus_ID",
                table: "LabResults",
                column: "TestResultStatus_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventory_Metric_ID",
                table: "ProductionInventory",
                column: "Metric_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventory_ProductInventoryType_ID",
                table: "ProductionInventory",
                column: "ProductInventoryType_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventory_ProductionInvCost_ID",
                table: "ProductionInventory",
                column: "ProductionInvCost_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventory_ProductionInventoryWriteOff_ID",
                table: "ProductionInventory",
                column: "ProductionInventoryWriteOff_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventoryOrder_ProdctionInvOrderStatus_ID",
                table: "ProductionInventoryOrder",
                column: "ProdctionInvOrderStatus_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventoryOrder_Supplier_ID",
                table: "ProductionInventoryOrder",
                column: "Supplier_ID");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventoryOrderDetails_ProductionInvId",
                table: "ProductionInventoryOrderDetails",
                column: "ProductionInvId");

            migrationBuilder.CreateIndex(
                name: "IX_ProductionInventoryOrderDetails_ProductionInvOrder_ID",
                table: "ProductionInventoryOrderDetails",
                column: "ProductionInvOrder_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Restores_ActiveLogin_ID",
                table: "Restores",
                column: "ActiveLogin_ID");

            migrationBuilder.CreateIndex(
                name: "UQ__Supplier__A9D1053419882BF8",
                table: "Supplier",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TransactionLog_Backup_ID",
                table: "TransactionLog",
                column: "Backup_ID");

            migrationBuilder.CreateIndex(
                name: "IX_TransactionLog_Restore_ID",
                table: "TransactionLog",
                column: "Restore_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Users_UserRoleId",
                table: "Users",
                column: "UserRoleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "BatchSizeYields");

            migrationBuilder.DropTable(
                name: "EmployeeActivity");

            migrationBuilder.DropTable(
                name: "GreenhouseProductionInventory");

            migrationBuilder.DropTable(
                name: "GreenhouseTable");

            migrationBuilder.DropTable(
                name: "LabResultDefect");

            migrationBuilder.DropTable(
                name: "ProductionInventoryOrderDetails");

            migrationBuilder.DropTable(
                name: "TransactionLog");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "CommoditySizes");

            migrationBuilder.DropTable(
                name: "GreenhouseActivity");

            migrationBuilder.DropTable(
                name: "Block");

            migrationBuilder.DropTable(
                name: "Defect");

            migrationBuilder.DropTable(
                name: "LabResults");

            migrationBuilder.DropTable(
                name: "ProductionInventory");

            migrationBuilder.DropTable(
                name: "ProductionInventoryOrder");

            migrationBuilder.DropTable(
                name: "Backups");

            migrationBuilder.DropTable(
                name: "Restores");

            migrationBuilder.DropTable(
                name: "UserRoles");

            migrationBuilder.DropTable(
                name: "ActivityEntry");

            migrationBuilder.DropTable(
                name: "Greenhouse");

            migrationBuilder.DropTable(
                name: "Batch");

            migrationBuilder.DropTable(
                name: "TestResultStatus");

            migrationBuilder.DropTable(
                name: "Metric");

            migrationBuilder.DropTable(
                name: "ProductInventoryType");

            migrationBuilder.DropTable(
                name: "ProductionInventoryCost");

            migrationBuilder.DropTable(
                name: "ProductionInventoryWriteOff");

            migrationBuilder.DropTable(
                name: "ProductionInventoryOrderStatus");

            migrationBuilder.DropTable(
                name: "Supplier");

            migrationBuilder.DropTable(
                name: "ActiveLogin");

            migrationBuilder.DropTable(
                name: "ActivityStatus");

            migrationBuilder.DropTable(
                name: "ActivityType");

            migrationBuilder.DropTable(
                name: "GreenhouseStatusDescription");

            migrationBuilder.DropTable(
                name: "ClientOrder");

            migrationBuilder.DropTable(
                name: "Coldroom");

            migrationBuilder.DropTable(
                name: "Cultivar");

            migrationBuilder.DropTable(
                name: "EmployeeLogin");

            migrationBuilder.DropTable(
                name: "GreenhouseStatus");

            migrationBuilder.DropTable(
                name: "Client");

            migrationBuilder.DropTable(
                name: "OrderStatus");

            migrationBuilder.DropTable(
                name: "Commodity");

            migrationBuilder.DropTable(
                name: "Employee");

            migrationBuilder.DropTable(
                name: "AccessLevelArea");

            migrationBuilder.DropTable(
                name: "EmployeeType");

            migrationBuilder.DropTable(
                name: "AccessArea");

            migrationBuilder.DropTable(
                name: "AccessLevel");
        }
    }
}
