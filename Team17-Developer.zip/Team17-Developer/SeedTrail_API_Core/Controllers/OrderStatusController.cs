﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class OrderStatusController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public OrderStatusController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/OrderStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderStatus>>> GetOrderStatuss()
        {
            if (_context.OrderStatuses == null)
            {
                return NotFound();
            }
            return await _context.OrderStatuses.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/OrderStatus/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<OrderStatus>>> GetAllOrderStatuss()
        {
            if (_context.OrderStatuses == null)
            {
                return NotFound();
            }
            return await _context.OrderStatuses.OrderBy(o => o.OrderStatusId).ToListAsync();
        }

        // GET: api/OrderStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderStatus>> GetOrderStatus(int id)
        {
            if (_context.OrderStatuses == null)
            {
                return NotFound();
            }
            var orderStatus = await _context.OrderStatuses.FindAsync(id);

            if (orderStatus == null || orderStatus.Status == false)
            {
                return NotFound();
            }

            return orderStatus;
        }

        // PUT: api/OrderStatus/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOrderStatus(int id, OrderStatusRequest orderStatus)
        {
            if (orderStatus == null)
            {
                return BadRequest("No Order Status found for given id");
            }
            OrderStatus? status = await _context.OrderStatuses.FirstOrDefaultAsync(x => x.OrderStatusId == id);
            if (status == null)
            {
                return NotFound();
            }
            OrderStatus? newResult = mapper.OrderStatusMapper(orderStatus);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                status.Ostatus = newResult.Ostatus;
                status.Description = newResult.Description;
                status.Status = newResult.Status;

                _context.Entry(status).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // POST: api/OrderStatus
        [HttpPost]
        public async Task<ActionResult<OrderStatus>> PostOrderStatus(OrderStatusRequest orderStatus)
        {
            if (_context.OrderStatuses == null)
            {
                return Problem("Entity set 'AppDbContext.OrderStatuses'  is null.");
            }
            try
            {
                OrderStatus? newStatus = mapper.OrderStatusMapper(orderStatus);
                if (newStatus == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.OrderStatuses.Add(newStatus);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.InnerException.Message);
                }
                return newStatus;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        //DELETE: api/OrderStatus/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteOrderStatus(int id)
        {
            if (_context.OrderStatuses == null)
            {
                return NotFound();
            }
            var orderStatus = await _context.OrderStatuses.FindAsync(id);
            if (orderStatus == null)
            {
                return NotFound();
            }

            _context.OrderStatuses.Remove(orderStatus);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrderStatusExists(int id)
        {
            return (_context.OrderStatuses?.Any(e => e.OrderStatusId == id)).GetValueOrDefault();
        }
    }
}