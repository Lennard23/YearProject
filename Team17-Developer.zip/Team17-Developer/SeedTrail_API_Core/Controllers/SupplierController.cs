﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public SupplierController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/Supplier
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetSuppliers()
        {
            if (_context.Suppliers == null)
            {
                return NotFound();
            }
            return await _context.Suppliers.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Supplier/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetAllSuppliers()
        {
            if (_context.Suppliers == null)
            {
                return NotFound();
            }
            return await _context.Suppliers.ToListAsync();
        }

        // GET: api/Supplier/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Supplier>> GetSupplier(int id)
        {
            if (_context.Suppliers == null)
            {
                return NotFound();
            }
            var supplier = await _context.Suppliers.FindAsync(id);

            if (supplier == null || supplier.Status == false)
            {
                return NotFound();
            }

            return supplier;
        }

        // PUT: api/Supplier/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSupplier(int id, SupplierRequest supplier)
        {
            if (supplier == null)
                return BadRequest();

            Supplier? supplierDb = _context.Suppliers.FirstOrDefault(x => x.SupplierId == id);

            if (supplierDb == null)
                return NotFound();

            supplierDb.Name = supplier.Name;
            supplierDb.Description = supplier.Description;
            supplierDb.ContactNr = supplier.ContactNr;
            supplierDb.Email = supplier.Email;
            supplierDb.Status = supplier.Status;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Supplier
        [HttpPost]
        public async Task<ActionResult<Supplier>> PostSupplier(SupplierRequest supplier)
        {
            if (supplier == null)
                return BadRequest();

            Supplier newSupplier = mapper.SupplierMapper(supplier);

            _context.Suppliers.Add(newSupplier);
            _context.SaveChanges();

            return Ok();
        }

        // DELETE: api/Supplier/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSupplier(int id)
        {
            Supplier? supplier = _context.Suppliers.FirstOrDefault(x => x.SupplierId == id);

            if (supplier == null)
                return NotFound();

            _context.Suppliers.Remove(supplier);
            _context.SaveChanges();

            return NoContent();
        }

    }
}
