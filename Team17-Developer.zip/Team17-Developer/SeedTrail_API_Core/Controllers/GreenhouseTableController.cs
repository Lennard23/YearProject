﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseTableController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public GreenhouseTableController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // POST: api/GreenhouseTable
        [HttpPost]
        public async Task<ActionResult<GreenhouseTable>> PostGreenhouseTable(GreenhouseTableRequest newGht)
        {
            if (_context.GreenhouseTables == null)
            {
                return Problem("Entity set 'AppDbContext.GreenhouseTables'  is null.");
            }
            try
            {
                GreenhouseTable? newResult = mapper.GreenhouseTableMapper(newGht);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.GreenhouseTables.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/GreenhouseTable
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GreenhouseTable>>> GetGreenhouseTables()
        {
            if (_context.GreenhouseTables == null)
            {
                return NotFound("The GreenhouseTables entity does not exist.");
            }
            try
            {
                // select only the GHTs with Status = true
                List<GreenhouseTable>? result = await _context.GreenhouseTables
                    .Where(a => a.Status == true)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/GreenhouseTable/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<GreenhouseTable>>> GetAllGreenhouseTables()
        {
            if (_context.GreenhouseTables == null)
            {
                return NotFound("The GreenhouseTables entity does not exist.");
            }
            try
            {
                List<GreenhouseTable>? result = await _context.GreenhouseTables.ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/GreenhouseTable/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GreenhouseTable>> GetGreenhouseTable(int id)
        {
            if (_context.GreenhouseTables == null)
            {
                return NotFound("The Greenhouse Tables entity does not exist.");
            }
            try
            {
                GreenhouseTable? result = await _context.GreenhouseTables.FindAsync(id);
                if (result == null || result.Status == false)
                {
                    return NotFound("No Greenhouse Table found for given id");
                }
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT: api/GreenhouseTable/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGreenhouseTable(int id, GreenhouseTableRequest ght)
        {
            if (ght == null)
            {
                return BadRequest("No Block found for given id");
            }
            GreenhouseTable? result = await _context.GreenhouseTables.FirstOrDefaultAsync(x => x.TableId == id);
            if (result == null)
            {
                return NotFound();
            }
            GreenhouseTable? newResult = mapper.GreenhouseTableMapper(ght);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.BlockId = newResult.BlockId;
                result.GreenhouseId = newResult.GreenhouseId;
                result.Status = newResult.Status;
                result.Block = newResult.Block;
                result.TableTotalCrates = newResult.TableTotalCrates;
                result.Greenhouse = newResult.Greenhouse;

                _context.Entry(result).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        //DELETE: api/GreenhouseTable/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGreenhouseTable(int id)
        {
            GreenhouseTable? ght = _context.GreenhouseTables.FirstOrDefault(x => x.TableId == id);

            if (ght == null)
                return NotFound();

            _context.GreenhouseTables.Remove(ght);

            _context.SaveChanges();

            return NoContent();
        }
    }
}
