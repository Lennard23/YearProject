﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class BatchReportController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BatchReportController(AppDbContext context)
        {
            _context = context;
        }

        // Batch Info
        [HttpGet("{id}")]
        public async Task<ActionResult<IBatchRep>> GetBatchInfo(int id)
        {
            // check that the necessary entities exist
            if (_context.Batches == null ||
                _context.Cultivars == null ||
                _context.Commodities == null ||
                _context.Clients == null ||
                _context.BatchSizeYields == null ||
                _context.CommoditySizes == null)
            {
                return Problem("An entity set referenced in IBatchRep is null.");
            }

            // get batch and include related tables
            var batch = await _context.Batches
                .Include(b => b.Cultivar)
                .Include(b => b.BatchSizeYields)
                .Include(b => b.ClientOrder)
                .SingleOrDefaultAsync(b => b.BatchId == id);
            if (batch == null)
            {
                return NotFound("Batch not found.");
            }

            // get cultivar, commodityId and commoditySizes
            var cult = batch.Cultivar;
            var comId = cult.CommodityId;
            var com = await _context.Commodities
                .Include(c => c.CommoditySizes)
                .SingleOrDefaultAsync(c => c.CommodityId == comId);
            if (com == null)
            {
                return Problem("Commodity not found.");
            }
            var comSizes = com.CommoditySizes;
            if (comSizes == null)
            {
                return Problem("CommoditySizes not found.");
            }

            // get remaining table entries
            var regNr = batch.RegistrationNr;
            var pd = batch.PlantDate;
            var cdi = batch.ColdroomDateIn;
            var hd = batch.HarvestDate;
            var cdo = batch.ColdroomDateOut;
            var tb = batch.TotalBags;
            var tp = batch.TotalPlanted;
            var ty = batch.TotalYield;
            var ay = batch.AvgYield;
            var scrap = batch.Scrap;
            var samp = batch.Sample;
            var coId = batch.ClientOrderId;
            var clientId = batch.ClientOrder.ClientId;
            var client = await _context.Clients.SingleOrDefaultAsync(c => c.ClientId == batch.ClientOrder.ClientId);
            var bsy = batch.BatchSizeYields;

            // build BatchRep class
            var batchRep = new BatchRep             // Data Types:
            {
                RegistrationNr = regNr,             // string
                PlantDate = pd,                     // DateTime
                ColdroomDateIn = cdi,               // DateTime
                HarvestDate = hd,                   // DateTime
                ColdroomDateOut = cdo,              // DateTime
                TotalBags = tb,                     // int
                TotalPlanted = tp,                  // int
                TotalYield = ty,                    // int
                AvgYield = ay,                      // decimal
                Scrap = scrap,                      // int
                Sample = samp,                      // int
                ClientOrderId = coId,               // int
                Client = client!,                    // Client
                BatchSizeYields = bsy.ToList(),     // List<BatchSizeYield>
                Cultivar = cult,                    // Cultivar
                CommodityId = com.CommodityId,      // int
                CommoditySizes = comSizes.ToList()  // List<CommoditySize>
            };

            // reply
            return Ok(batchRep);
        }

        // Date-filtered Batch Info
        [HttpGet("DateFilteredBatch")]
        public async Task<ActionResult<List<IBatchRep>>> GetDateFilteredBatchInfo(string dateRange)
        {
            // check that the necessary entities exist
            if (_context.Batches == null ||
                _context.Cultivars == null ||
                _context.Commodities == null ||
                _context.Clients == null ||
                _context.BatchSizeYields == null ||
                _context.CommoditySizes == null)
            {
                return Problem("An entity set referenced in IBatchRep is null.");
            }

            // parse date data
            var startDate = dateRange.Split('p')[0];
            var endDate = dateRange.Split('p')[1];
            DateTime startDateNew = DateTime.ParseExact(startDate.ToString()!, "yyyy-MM-dd", null);
            DateTime endDateNew = DateTime.ParseExact(endDate.ToString()!, "yyyy-MM-dd", null);

            // find batches
            var batches = await _context.Batches
                .Include(b => b.Cultivar)
                .Include(b => b.BatchSizeYields)
                .Include(b => b.ClientOrder)
                .Where(b => b.PlantDate >= startDateNew && b.PlantDate <= endDateNew)
                .ToListAsync();
            if (batches == null)
            {
                return NotFound("Batches not found.");
            }

            // get cultivar, commodityId and commoditySizes for each item in batches
            var cults = batches.Select(b => b.Cultivar);
            var comIds = cults.Select(c => c.CommodityId);
            var coms = await _context.Commodities
                .Include(c => c.CommoditySizes)
                .Where(c => comIds.Contains(c.CommodityId))
                .ToListAsync();
            if (coms == null)
            {
                return Problem("Commodities not found.");
            }
            var comSizes = coms.SelectMany(c => c.CommoditySizes);
            if (comSizes == null)
            {
                return Problem("CommoditySizes not found.");
            }

            // get remaining table entries
            var regNrs = batches.Select(b => b.RegistrationNr);
            var pds = batches.Select(b => b.PlantDate);
            var cdis = batches.Select(b => b.ColdroomDateIn);
            var hds = batches.Select(b => b.HarvestDate);
            var cdos = batches.Select(b => b.ColdroomDateOut);
            var tbs = batches.Select(b => b.TotalBags);
            var tps = batches.Select(b => b.TotalPlanted);
            var tys = batches.Select(b => b.TotalYield);
            var ays = batches.Select(b => b.AvgYield);
            var scraps = batches.Select(b => b.Scrap);
            var samps = batches.Select(b => b.Sample);
            var coIds = batches.Select(b => b.ClientOrderId);
            var clients = batches.Select(b => b.ClientOrder.ClientId);
            var bsy = batches.SelectMany(b => b.BatchSizeYields);

            // build BatchRep classes
            var batchReps = new List<IBatchRep>();
            foreach (var batch in batches)
            {
                var batchRep = new BatchRep                             // Data Types:
                {
                    RegistrationNr = batch.RegistrationNr,              // string
                    PlantDate = batch.PlantDate,                        // DateTime
                    ColdroomDateIn = batch.ColdroomDateIn,              // DateTime
                    HarvestDate = batch.HarvestDate,                    // DateTime
                    ColdroomDateOut = batch.ColdroomDateOut,            // DateTime
                    TotalBags = batch.TotalBags,                        // int
                    TotalPlanted = batch.TotalPlanted,                  // int
                    TotalYield = batch.TotalYield,                      // int
                    AvgYield = batch.AvgYield,                          // decimal
                    Scrap = batch.Scrap,                                // int
                    Sample = batch.Sample,                              // int
                    ClientOrderId = batch.ClientOrderId,                // int
                    Client = batch.ClientOrder.Client,                  // Client
                    BatchSizeYields = batch.BatchSizeYields.ToList(),   // List<BatchSizeYield>
                    Cultivar = batch.Cultivar,                          // Cultivar
                    CommodityId = batch.Cultivar.CommodityId,           // int
                    CommoditySizes = comSizes.ToList()                  // List<CommoditySize>
                };
                batchReps.Add(batchRep);
            }

            // reply
            return Ok(batchReps);
        }
    }
}
