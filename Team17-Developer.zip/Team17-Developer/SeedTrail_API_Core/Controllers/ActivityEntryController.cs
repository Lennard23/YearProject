﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityEntryController : ControllerBase
       {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public ActivityEntryController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/ActivityEntry
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ActivityEntry>>> GetActivityEntries()
        {
            if (_context.ActivityEntries == null)
            {
                return NotFound();
            }
            // return tables where status = true
            return await _context.ActivityEntries.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/ActivityStatuses
        [HttpGet("getActivityStatuses")]
        public async Task<ActionResult<IEnumerable<ActivityStatus>>> GetActivityStatuses()
        {
            if (_context.ActivityStatuses == null)
            {
                return NotFound();
            }
            // return tables where status = true
            return await _context.ActivityStatuses.Where(o => o.Status == true).ToListAsync();
        }



        // GET: api/ActivityEntry/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<ActivityEntry>>> GetAllActivityEntries()
        {
            if (_context.ActivityEntries == null)
            {
                return NotFound();
            }
            // return all tables
            return await _context.ActivityEntries.OrderByDescending(o => o.ActivityEntryId).ToListAsync();
        }

        // GET: api/ActivityEntry/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ActivityEntry>> GetActivityEntry(int id)
        {
            if (_context.ActivityEntries == null)
            {
                return NotFound();
            }
            var activityEntry = await _context.ActivityEntries.FindAsync(id);

            if (activityEntry == null || activityEntry.Status == false)
            {
                return NotFound();
            }

            return activityEntry;
        }

        // PUT: api/ActivityEntry/5
        [HttpPut("put{id}")]
        public async Task<IActionResult> PutActivityEntry(int id, ActivityEntryRequest activityEntry)
        {
            if (activityEntry == null)
                return BadRequest();

            ActivityEntry? newEntry = _context.ActivityEntries.FirstOrDefault(x => x.ActivityEntryId == id);

            if (newEntry == null)
                return NotFound();

            //ActivityEntry? newEntry = mapper.ActivityMapper(activityEntry);

           // if (newEntry == null)
           //     return BadRequest();

            newEntry.ActivityTypeId = activityEntry.ActivityTypeId;
            newEntry.ActivityStatusId = activityEntry.ActivityStatusId;
            newEntry.Duration = activityEntry.Duration;
            newEntry.Description = activityEntry.Description;
            newEntry.Title = activityEntry.Title;
            newEntry.SequenceOrder = activityEntry.SequenceOrder;
            newEntry.Status = activityEntry.Status;
            //newEntry.ActivityStatus = activityEntry.ActivityStatus;
            //newEntry.ActivityType = activityEntry.ActivityType;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/ActivityEntry
        [HttpPost]
        public async Task<ActionResult<ActivityEntry>> PostActivityEntry(ActivityEntryRequest activityEntry)
        {
            if (activityEntry == null)
                return BadRequest();

            ActivityEntry? newEntry = mapper.ActivityMapper(activityEntry);

            if (newEntry == null)
                return BadRequest();

            ActivityEntry entity = _context.ActivityEntries.Add(newEntry).Entity;
            _context.SaveChanges();

            return Ok(entity);
        }


        // GET: api/Client/CheckRefIntegrity/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckActivityEntryRefIntegrity(int id)
        {
            if (_context.ActivityEntries == null)
            {
                return false;
            }
            var activityEntry = await _context.ActivityEntries.Include(o => o.GreenhouseActivities).FirstOrDefaultAsync(o => o.ActivityEntryId == id);

            if (activityEntry == null || activityEntry.Status == false)
            {
                return false;
            }

            if (activityEntry.GreenhouseActivities.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // DELETE: api/ActivityEntry/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteActivityEntry(int id)
        {
            ActivityEntry entry = _context.ActivityEntries.FirstOrDefault(x => x.ActivityEntryId == id);

            if (entry == null)
                return NotFound();

            _context.ActivityEntries.Remove(entry);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
