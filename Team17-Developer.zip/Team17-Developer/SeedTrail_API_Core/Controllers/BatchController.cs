﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileSystemGlobbing;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class BatchController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public BatchController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // POST: api/Batch
        [HttpPost]
        public async Task<ActionResult<Batch>> PostBatch(BatchRequest newBatch)
        {
            if (_context.Batches == null)
            {
                return Problem("Entity set 'AppDbContext.Batches'  is null.");
            }
            try
            {
                Batch? newResult = mapper.BatchMapper(newBatch);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.Batches.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Batch
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Batch>>> GetBatches()
        {
            if (_context.Batches == null)
            {
                return NotFound("The Batches entity does not exist.");
            }
            try
            {
                // select only the Batches with Status = true
                List<Batch>? result = await _context.Batches
                    .Where(a => a.Status == true)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Batch/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Batch>>> GetAllBatches()
        {
            if (_context.Batches == null)
            {
                return NotFound("The Batches entity does not exist.");
            }
            try
            {
                List<Batch>? result = await _context.Batches.ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Batch/CheckRefIntegrity/5
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckRefIntegrity(int id)
        {
            if (_context.Batches == null)
            {
                return NotFound("The Batches entity does not exist.");
            }
            try
            {
                Batch? result = await _context.Batches
                    .Include(o => o.Blocks.Where(a => a.Status == true))
                    .Include(o => o.BatchSizeYields.Where(a => a.Status == true))
                    .Include(b => b.LabResults.Where(a => a.Status == true))
                    .FirstOrDefaultAsync(o => o.BatchId == id);
                
                if (result == null)
                {
                    return BadRequest();
                }
                if (result.LabResults.Count > 0)
                {
                    return false;
                }
                else if (result.Blocks.Count > 0)
                {
                    return false;
                }
                else if (result.BatchSizeYields.Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Batch/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Batch>> GetBatch(int id)
        {
            if (_context.Batches == null)
            {
                return NotFound("The Batches entity does not exist.");
            }
            try
            {
                Batch? result = await _context.Batches.FindAsync(id);
                if (result == null || result.Status == false)
                {
                    return NotFound("No Batch found for given id");
                }
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Batch/BatchInfo/5
        [HttpGet("BatchInfo/{id}")]
        public async Task<ActionResult<object>> GetBatchInfo(int id)
        {
            if (_context.Batches == null)
            {
                return NotFound("The Batches entity does not exist.");
            }
            try
            {
                Batch? result = await _context.Batches
                    .Include(o => o.LabResults)
                    .Include(b => b.Blocks)
                    .Include(c => c.BatchSizeYields)
                    .FirstOrDefaultAsync(a => a.BatchId == id);
                if (result == null || result.Status == false)
                {
                    return NotFound("No Batch found for given id");
                }
                return Ok(new
                {
                    blocks = result.Blocks.ToList(),
                    labResults = result.LabResults.ToList(),
                    batchSizeYields = result.BatchSizeYields.ToList()
                });
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // Link Batch to Block with PUT
        // PUT: api/Batch/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBatch(int id, BatchRequest batch)
        {
            if (batch == null)
            {
                return BadRequest("No Batch found for given id");
            }
            Batch? result = await _context.Batches.FirstOrDefaultAsync(x => x.BatchId == id);
            if (result == null)
            {
                return NotFound();
            }
            Batch? newResult = mapper.BatchMapper(batch);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.ColdroomId = newResult.ColdroomId;
                result.ClientOrderId = newResult.ClientOrderId;
                result.CultivarId = newResult.CultivarId;
                result.AvgYield = newResult.AvgYield;
                result.TotalPlanted = newResult.TotalPlanted;
                result.TotalYield = newResult.TotalYield;
                result.TotalBags = newResult.TotalBags;
                result.RegistrationNr = newResult.RegistrationNr;
                result.CultivarName = newResult.CultivarName;
                result.ClientName = newResult.ClientName;
                result.Sample = newResult.Sample;
                result.Scrap = newResult.Scrap;
                result.Status = newResult.Status;
                result.ColdroomDateIn = newResult.ColdroomDateIn;
                result.ColdroomDateOut = newResult.ColdroomDateOut;
                result.Coldroom = newResult.Coldroom;
                result.Cultivar = newResult.Cultivar;
                result.ClientOrder = newResult.ClientOrder;
                result.PlantDate = newResult.PlantDate;
                result.HarvestDate = newResult.HarvestDate;

                _context.Entry(result).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        //DELETE: api/Batch/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBatch(int id)
        {
            Batch? batch = _context.Batches.FirstOrDefault(x => x.BatchId == id);

            if (batch == null)
                return NotFound();

            _context.Batches.Remove(batch);

            _context.SaveChanges();

            return NoContent();
        }
    }
}
