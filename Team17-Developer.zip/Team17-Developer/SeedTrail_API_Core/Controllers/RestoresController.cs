﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;
using System;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class RestoresController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;
        // Inject DB Context
        public RestoresController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }


        /************************************
         *                                  *
         *        'CREATE' ENDPOINT         *
         *                                  *
         ************************************/


        // POST: api/Restores

        [HttpPost]
        public async Task<ActionResult<Restore>> PostRestore(RestoreRequest newrestore)
        {

            // check for entity in AppDbContext, else return Problem()
            if (_context.Restores == null)
            {
                return Problem("Entity set 'AppDbContext.Restores'  is null.");
            }
            Restore? restore = mapper.RestoreMapper(newrestore);
            if (restore == null)
            {
                return Problem("Restore object is null.");
            }
            // get backup from DB
            Backup? backup = await _context.Backups.FindAsync(restore.BackupId);
            if (backup == null)
            {
                return Problem("Backup does not exist.");
            }
            restore.Description = backup.Description;
            restore.Date = DateTime.Now;
            restore.Time = DateTime.Now;
            var backups = _context.Backups.ToListAsync();
            // get connection string from appsettings.json
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
            string connectionString = config.GetConnectionString("DefaultConnection");   // <- set connection string to a variable

            var folderName = Path.Combine("Resources", "Backups", backup.FileName);
            // note, you can just keep adding sub folders if you want, just add more commas and folder names
            // BUT, the first one must be "Resources" ( the folder set in Program.cs )

            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

            if (System.IO.File.Exists(pathToSave) == false)
            {
                var r = "File doesn't exist";
                return Problem(r);
            }

            // restoreCommand to restore and overwrite (REPLACE) the database
            string restoreCommand = "USE [master] ALTER DATABASE [SeedTrail] SET Single_User WITH Rollback Immediate; RESTORE DATABASE [SeedTrail] FROM DISK = '" + pathToSave.ToString()+"' WITH REPLACE;";

            // create a new sql connection to execute the restore command
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(restoreCommand, connection))
                {
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        // add restore to DB
                        restore.Date = DateTime.Now;
                        restore.Time = DateTime.Now;
                        // for each backup in backups remove PK and re add to DB
                        foreach (Backup b in backups.Result)
                        {
                            b.BackupId = 0;
                            _context.Backups.Add(b);
                        }
                        _context.Restores.Add(restore);
                        await _context.SaveChangesAsync();
                        return Ok();
                    }
                    // catch and return exception
                    catch (Exception ex)
                    {
                        connection.Close();
                        return Problem(restore.BackupId.ToString() + " " + ex.InnerException.Message);
                    }
                }
            }
        }

        /***************************************
         *                                     *
         *         OTHER CRUD ENDPOINTS        *
         *                                     *
         ***************************************/


        // GET: api/Restores/ExistingBackups

        [HttpGet("ExistingBackups")]
        public async Task<ActionResult<Int32>> GetExistingBackups()  // GETs the number of backups recorded in the database
        {
            try
            {
                var list = await _context.Backups.Where(a => a.Status == true).ToListAsync();
                return Ok(list.Count);
            }
            catch
            {
                return Problem("Error: Could not get existing backups from database.");
            }

        }

        // GET: api/Restores

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Restore>>> GetRestores()
        {
            if (_context.Restores == null)
            {
                return NotFound();
            }
            return await _context.Restores.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Restores/5

        [HttpGet("{id}")]
        public async Task<ActionResult<Restore>> GetRestore(int id)
        {
            if (_context.Restores == null)
            {
                return NotFound();
            }
            var restore = await _context.Restores.FindAsync(id);

            if (restore == null || restore.Status == false)
            {
                return NotFound();
            }

            return restore;
        }

        // DELETE: api/Restore/5

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRestore(int id)
        {
            if (_context.Restores == null)
            {
                return NotFound();
            }
            var restore = await _context.Restores.FindAsync(id);
            if (restore == null)
            {
                return NotFound();
            }

            _context.Restores.Remove(restore);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // EXISTS function

        private bool RestoreExists(int id)
        {
            return _context.Restores.Any(e => e.RestoreId == id);
        }
    }
}
