﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    /// <summary>
    /// [Authorize(Policy = "Supervisor")]
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class ProductionInventoryController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public ProductionInventoryController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/ProductionInventory
        [Authorize(Policy = "Supervisor")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductionInventory>>> GetProductionInventories()
        {
            if (_context.ProductionInventories == null)
            {
                return NotFound();
            }
            return await _context.ProductionInventories

                .Where(o => o.Status == true)
                .ToListAsync();
        }

        // GET: api/ProductionInventory
        [Authorize(Policy = "Supervisor")]
        [HttpGet("PdtId")]
        public async Task<ActionResult<IEnumerable<ProductionInventory>>> GetProductionInventoriesById(int PdtId)
        {
            if (_context.ProductionInventories == null)
            {
                return NotFound();
            }
            return await _context.ProductionInventories

                .Where(o => o.Status == true && o.ProductInventoryTypeId == PdtId)
                .ToListAsync();
        }


        // GET: api/ProductionInventory/All
        [Authorize(Policy = "Supervisor")]
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<ProductionInventory>>> GetAllProductionInventories()
        {
            if (_context.ProductionInventories == null)
            {
                return NotFound();
            }

            return Ok((from productionInventory in _context.ProductionInventories
                       join productType in _context.ProductInventoryTypes on productionInventory.ProductInventoryTypeId equals productType.ProductInventoryTypeId
                       join metric in _context.Metrics on productionInventory.MetricId equals metric.MetricId
                       join productInvCost in _context.ProductionInventoryCosts on productionInventory.ProductionInvCostId equals productInvCost.ProductionInvCostId
                       join productionInvOrderDetails in _context.ProductionInventoryOrderDetails on productionInventory.ProductionInvId equals productionInvOrderDetails.ProductionInventoriesId
                       join productionInvOrder in _context.ProductionInventoryOrders on productionInvOrderDetails.ProductionInvOrderId equals productionInvOrder.ProductionInvOrderId
                       join supplier in _context.Suppliers on productionInvOrder.SupplierId equals supplier.SupplierId
                       join productionInventoryWriteOff in _context.ProductionInventoryWriteOffs on productionInventory.ProductionInventoryWriteOffId equals productionInventoryWriteOff.ProductionInventoryWriteOffId
                       select new
                       {
                           description = productionInventory.Description,
                           name = productionInventory.Name,
                           productInventoryType = productType,
                           productionInvCost = productInvCost,
                           productionInvId = productionInventory.ProductionInvId,
                           productionInvOrder = productionInvOrder,
                           productionInvOrderDetails = productionInvOrderDetails,
                           productionInventoryWriteOff = productionInventoryWriteOff,
                           quantity = productionInventory.Quantity,
                           status = productionInventory.Status,
                           threshold = productionInventory.Threshold,
                           metric = metric,
                           supplier = supplier
                       }).ToList());
        }

        // GET: api/ProductionInventory/GetTypes
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetTypes")]
        public async Task<IActionResult> GetTypes()
        {
            return Ok((from productType in _context.ProductInventoryTypes

                       
                       select new {
                           productInventoryTypeId = productType.ProductInventoryTypeId,
                           description = productType.Description,
                           name = productType.Name,
                           status = productType.Status
                       }

                       ).ToList());
        }

        // GET: api/ProductionInventory/GetCosts
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetCosts")]
        public async Task<IActionResult> GetCosts()
        {
            return Ok((from productionInventoryCost in _context.ProductionInventoryCosts


                       select new
                       {
                           cost = productionInventoryCost.Cost,
                           date = productionInventoryCost.Date,
                           status = productionInventoryCost.Status
                       }

                       ).ToList());
        }

        // GET: api/ProductionInventory/GetCosts
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetCosts/{id}")]
        public async Task<ActionResult<ProductionInventoryCost>> GetCostbyId(int id)
        {
            if (_context.ProductionInventoryCosts == null)
            {
                return NotFound();
            }
            var  productionInventoryCost = await _context.ProductionInventoryCosts.FindAsync(id);

            if (productionInventoryCost == null || productionInventoryCost.Status == false)
            {
                return NotFound();
            }

            return productionInventoryCost;
        }

        // GET: api/ProductionInventory/GetTypes
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetTypes/{id}")]
        public async Task<ActionResult<ProductInventoryType>> GetTypebyId(int id)
        {
            if (_context.ProductInventoryTypes == null)
            {
                return NotFound();
            }
            var productInventoryType = await _context.ProductInventoryTypes.FindAsync(id);

            if (productInventoryType == null || productInventoryType.Status == false)
            {
                return NotFound();
            }

            return productInventoryType;
        }

        // GET: api/ProductionInventory/GetOrders
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetOrders")]
        public async Task<IActionResult> GetOrders()
        {
            return Ok((from productionInventoryOrder in _context.ProductionInventoryOrders


                       select new
                       {

                           ProdctionInvOrderStatusId = productionInventoryOrder.ProdctionInvOrderStatusId,
                           supplierId = productionInventoryOrder.SupplierId,
                           status = productionInventoryOrder.Status
                       }

                       ).ToList());
        }

        // GET: api/ProductionInventory/GetOrders
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetOrders/{id}")]
        public async Task<ActionResult<ProductionInventoryOrder>> GetOrderbyId(int id)
        {
            if (_context.ProductionInventoryOrders == null)
            {
                return NotFound();
            }
            var productionInventoryOrder = await _context.ProductionInventoryOrders.FindAsync(id);

            if (productionInventoryOrder == null || productionInventoryOrder.Status == false)
            {
                return NotFound();
            }

            return productionInventoryOrder;
        }

        // GET: api/ProductionInventory/GetWriteOffs
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetWriteOffs")]
        public async Task<IActionResult> GetWriteOffs()
        {
            return Ok((from productionInventoryWriteOff in _context.ProductionInventoryWriteOffs


                       select new
                       {

                           Name = productionInventoryWriteOff.Name,
                           Description = productionInventoryWriteOff.Description,
                           Quantity = productionInventoryWriteOff.Quantity,
                           status = productionInventoryWriteOff.Status
                       }

                       ).ToList());
        }

        // GET: api/ProductionInventory/GetWriteOffs
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetWriteOffs/{id}")]
        public async Task<ActionResult<ProductionInventoryWriteOff>> GetWriteOffbyId(int id)
        {
            if (_context.ProductionInventoryWriteOffs == null)
            {
                return NotFound();
            }
            var productionInventoryWriteOff = await _context.ProductionInventoryWriteOffs.FindAsync(id);

            if (productionInventoryWriteOff == null || productionInventoryWriteOff.Status == false)
            {
                return NotFound();
            }

            return productionInventoryWriteOff;
        }
        // GET: api/ProductionInventory/GetMetrics
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetMetrics")]
        public async Task<IActionResult> GetMetrics()
        {
            return Ok((from metric in _context.Metrics


                       select new
                       {
                           MetricId = metric.MetricId,
                           Name = metric.Name,
                           Description = metric.Description,

                       }

                       ).ToList());
        }

        // GET: api/ProductionInventory/GetMetrics
        [Authorize(Policy = "Supervisor")]
        [HttpGet("GetMetrics/{id}")]
        public async Task<ActionResult<Metric>> GetMetricbyId(int id)
        {
            if (_context.Metrics == null)
            {
                return NotFound();
            }
            var metric = await _context.Metrics.FindAsync(id);

            if (metric == null)
            {
                return NotFound();
            }

            return metric;
        }


        // GET: api/ProductionInventory/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductionInventory>> GetProductionInventory(int id)
        {
            if (_context.ProductionInventories == null)
            {
                return NotFound();
            }
            var productionInventory = await _context.ProductionInventories.FindAsync(id);

            if (productionInventory == null || productionInventory.Status == false)
            {
                return NotFound();
            }

            return productionInventory;
        }

        // GET: api/ProductionInventory/CheckRefIntegrity/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckRefIntegrity(int id)
        {
            if (_context.ProductionInventories == null)
            {
                return false;
            }

            var productionInventory = await _context.ProductionInventories.FindAsync(id);

            if (productionInventory == null || productionInventory.Status == false)
            {
                return false;
            }
            // Check:
            // ProductionInventoryOrderDetail
            var productionInventoryOrderDetail = await _context.ProductionInventoryOrderDetails.Where(x => x.ProductionInventoryOrderDetailId == id).ToListAsync();
            // GreenhouseProductionInventories
            var greenhouseProductionInventories = await _context.GreenhouseProductionInventories.Where(x => x.GreenhouseId == id).ToListAsync();
            // return true if there's a clash
            if (productionInventoryOrderDetail.Count > 0 || greenhouseProductionInventories.Count > 0 )
            {
                return true;
            }
            return false;
        }

        // PUT: api/ProductionInventory/5
        [Authorize(Policy = "Manager")]
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProductionInventory(int id, ProductionInventoryRequest productionInventory)
        {
            if (productionInventory == null)
                return BadRequest();

            ProductionInventory? inv = _context.ProductionInventories.FirstOrDefault(x => x.ProductionInvId == id);

            if (inv == null)
                return NotFound();

            ProductionInventory? newInv = mapper.ProductionInventoryMapper(productionInventory);

            if (newInv == null)
                return BadRequest();

            inv.ProductionInvCostId = newInv.ProductionInvCostId;
            inv.ProductionInventoryWriteOffId = newInv.ProductionInventoryWriteOffId;
            inv.ProductInventoryTypeId = newInv.ProductInventoryTypeId;
            inv.Name = newInv.Name;
            inv.Description = newInv.Description;
            inv.Quantity = newInv.Quantity;
            inv.Threshold = newInv.Threshold;
            inv.Status = newInv.Status;
            inv.ProductionInvCost = newInv.ProductionInvCost;
            inv.ProductionInventoryWriteOff = newInv.ProductionInventoryWriteOff;
            inv.ProductInventoryType = newInv.ProductInventoryType;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/ProductionInventory
        [Authorize(Policy = "Manager")]
        [HttpPost]
        public async Task<ActionResult<ProductionInventory>> PostProductionInventory(ProductionInventoryRequest productionInventory)
        {
            if (productionInventory == null)
                return BadRequest();

            ProductionInventory? newInv = mapper.ProductionInventoryMapper(productionInventory);

            if (newInv == null)
                return BadRequest();

            // old
            // ProductionInventory entity = _context.ProductionInventories.Add(newInv).Entity;
            ProductionInventory newProd = mapper.ProductionInventoryMapper(productionInventory);
     
            _context.ProductionInventories.Add(newProd);
            _context.SaveChanges();

            return Ok();
        }

        // DELETE: api/ProductionInventory/5
        [Authorize(Policy = "Manager")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProductionInventory(int id)
        {
           // return Forbid();
            ProductionInventory? inv = _context.ProductionInventories.FirstOrDefault(x => x.ProductionInvId == id);

            if (inv == null)
                return NotFound();

            _context.ProductionInventories.Remove(inv);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // PUT: api/ProductionInventory/ProductionInventoryType/5
        [Authorize(Policy = "Manager")]
        [HttpPut("ProductionInventoryType/{id}")]
        public async Task<IActionResult> PutProductionInventoryType(int id, ProductionInventoryTypeRequest productionInventory)
        {
            if (productionInventory == null)
                return BadRequest();

            ProductInventoryType? type = _context.ProductInventoryTypes.FirstOrDefault(x => x.ProductInventoryTypeId == id);

            if (type == null)
                return NotFound();

            ProductInventoryType? newType = mapper.ProductionInventoryTypeMapper(productionInventory);

            if (newType == null)
                return BadRequest();

            type.ProductInventoryTypeId = newType.ProductInventoryTypeId;
            type.Name = newType.Name;
            type.Description = newType.Description;
            type.Status = newType.Status;
           

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/ProductionInventory/ProductionInventoryType
        [Authorize(Policy = "Manager")]
        [HttpPost("ProductionInventoryType")]
        public async Task<ActionResult<ProductInventoryType>> PostProductionInventoryType(ProductionInventoryTypeRequest productionInventory)
        {
            if (productionInventory == null)
                return BadRequest();

            ProductInventoryType? newType = mapper.ProductionInventoryTypeMapper(productionInventory);

            if (newType == null)
                return BadRequest();

            ProductInventoryType entity = _context.ProductInventoryTypes.Add(newType).Entity;
            _context.SaveChanges();

            return Ok(entity);
        }

        // DELETE: api/ProductionInventory/ProductionInventoryType/5
        [Authorize(Policy = "Manager")]
        [HttpDelete("ProductionInventoryType/{id}")]
        public async Task<IActionResult> DeleteProductionInventoryType(int id)
        {
            ProductInventoryType? type = _context.ProductInventoryTypes.FirstOrDefault(x => x.ProductInventoryTypeId == id);

            if (type == null)
                return NotFound();

            _context.ProductInventoryTypes.Remove(type);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
