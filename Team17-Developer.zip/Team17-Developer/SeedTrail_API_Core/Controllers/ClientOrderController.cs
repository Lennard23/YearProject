﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class ClientOrderController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public ClientOrderController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/ClientOrder
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ClientOrder>>> GetClientOrders()
        {
            if (_context.ClientOrders == null)
            {
                return NotFound();
            }
            return await _context.ClientOrders.Include(a => a.Batches).Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/ClientOrder/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<ClientOrder>>> GetAllClientOrders()
        {
            if (_context.ClientOrders == null)
            {
                return NotFound();
            }
            return await _context.ClientOrders.Include(a => a.Batches).ToListAsync();
        }

        // GET: api/ClientOrder/Incomplete
        [HttpGet("Incomplete")]
        public async Task<ActionResult<IEnumerable<ClientOrder>>> GetIncompleteClientOrders()
        {
            if (_context.ClientOrders == null)
            {
                return NotFound();
            }
            // only include ClientOrders with an OrderStatus.Ostatus == "Complete"
            return await _context.ClientOrders
                .Include(o => o.OrderStatus)
                .Where(o => o.OrderStatus.Ostatus != "Completed" && o.Status == true)
                .ToListAsync();
        }
        
        // GET: api/ClientOrder/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ClientOrder>> GetClientOrder(int id)
        {
            if (_context.ClientOrders == null)
            {
                return NotFound();
            }
            var clientOrder = await _context.ClientOrders.Include(a => a.Batches).FirstOrDefaultAsync(a => a.ClientOrderId == id);

            if (clientOrder == null || clientOrder.Status == false)
            {
                return NotFound();
            }

            return clientOrder;
        }

        // GET: api/ClientOrder/CheckRefIntegrity/5
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckRefIntegrity(int id)
        {
            if (_context.ClientOrders == null)
            {
                return NotFound();
            }
            var clientOrder = await _context.ClientOrders.FindAsync(id);

            if (clientOrder == null || clientOrder.Status == false)
            {
                return NotFound();
            }

            // check if there are any Batches associated with this ClientOrder
            var batches = await _context.Batches
                .Where(o => o.ClientOrderId == id && o.Status == true)
                .ToListAsync();

            if (batches.Count > 0)
            {
                return false;
            }

            return true;
        }

        // PUT: api/ClientOrder/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutClientOrder(int id, ClientOrderRequest clientOrder)
        {
            if (clientOrder == null)
            {
                return BadRequest();
            }
            ClientOrder? result = await _context.ClientOrders.FirstOrDefaultAsync(x => x.ClientOrderId == id);
            if (result == null)
            {
                return NotFound();
            }
            ClientOrder? newResult = mapper.ClientOrderMapper(clientOrder);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.OrderStatusId = newResult.OrderStatusId;
                result.ClientId = newResult.ClientId;
                result.ClientName = newResult.ClientName;
                result.DatePlaced = result.DatePlaced;
                result.DateRequired = newResult.DateRequired;
                result.Description = newResult.Description;
                result.Status = newResult.Status;
                result.Client = newResult.Client;
                result.OrderStatus = newResult.OrderStatus;

                _context.SaveChanges();

                return NoContent();
            }
            catch
            {
                return Problem();
            }
        }

        // POST: api/ClientOrder
        [HttpPost]
        public async Task<ActionResult<ClientOrder>> PostClientOrder(ClientOrderRequest clientOrder)
        {
            if (clientOrder == null)
                return BadRequest();

            ClientOrder? newClientOrder = mapper.ClientOrderMapper(clientOrder);
            newClientOrder.DatePlaced = DateTime.Now;

            _context.ClientOrders.Add(newClientOrder!);
            _context.SaveChanges();

            return Ok();
        }

        // DELETE: api/ClientOrder/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteClientOrder(int id)
        {
            ClientOrder? clientOrder = _context.ClientOrders.FirstOrDefault(x => x.ClientOrderId == id);

            if (clientOrder == null)
                return NotFound();

            _context.ClientOrders.Remove(clientOrder);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
