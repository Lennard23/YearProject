﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityTypeController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public ActivityTypeController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/ActivityType
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ActivityType>>> GetActivityTypes()
        {
            if (_context.ActivityTypes == null)
            {
                return NotFound();
            }
            // only return tables where status = true
            return await _context.ActivityTypes.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/ActivityType/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<ActivityType>>> GetAllActivityTypes()
        {
            if (_context.ActivityTypes == null)
            {
                return NotFound();
            }
            // return all tables
            return await _context.ActivityTypes.OrderByDescending(a => a.ActivityTypeId).ToListAsync();
        }

        // GET: api/ActivityType/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ActivityType>> GetActivityType(int id)
        {
            if (_context.ActivityTypes == null)
            {
                return NotFound();
            }
            var activityType = await _context.ActivityTypes.FindAsync(id);

            if (activityType == null || activityType.Status == false)
            {
                return NotFound();
            }

            return activityType;
        }

        // PUT: api/ActivityType/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutActivityType(int id, ActivityTypeRequest activityType)
        {
            if (activityType == null)
                return BadRequest();

            ActivityType? type = _context.ActivityTypes.FirstOrDefault(x => x.ActivityTypeId == id);

            if (type == null)
                return NotFound();

            ActivityType newType = mapper.ActivityTypeMapper(activityType);

            type.Description = newType.Description;
            type.Type = newType.Type;
            type.Status = newType.Status;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/ActivityType
        [HttpPost]
        public async Task<ActionResult<ActivityType>> PostActivityType(ActivityTypeRequest activityType)
        {
            if (activityType == null)
                return BadRequest();

            ActivityType newType = mapper.ActivityTypeMapper(activityType);

            ActivityType entity = _context.ActivityTypes.Add(newType).Entity;
            _context.SaveChanges();

            return Ok(entity);
        }

        // GET: api/Client/CheckRefIntegrity/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckActivityTypeRefIntegrity(int id)
        {
            if (_context.ActivityTypes == null)
            {
                return false;
            }
            var activityType = await _context.ActivityTypes.Include(o => o.ActivityEntries).FirstOrDefaultAsync(o => o.ActivityTypeId == id);

            if (activityType == null || activityType.Status == false)
            {
                return false;
            }

            if (activityType.ActivityEntries.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        // DELETE: api/ActivityType/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteActivityType(int id)
        {
            ActivityType? type = _context.ActivityTypes.FirstOrDefault(x => x.ActivityTypeId == id);

            if (type == null)
                return NotFound();

            _context.ActivityTypes.Remove(type);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
