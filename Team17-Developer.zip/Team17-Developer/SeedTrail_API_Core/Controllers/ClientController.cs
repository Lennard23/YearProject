﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public ClientController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/Client
        [Authorize(Policy = "Supervisor")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Client>>> GetClients()
        {
            if (_context.Clients == null)
            {
                return NotFound();
            }
            return await _context.Clients.Where(o => o.Status == true).OrderBy(o => o.ClientId).ToListAsync();
        }

        // GET: api/Client/All
        [Authorize(Policy = "Supervisor")]
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Client>>> GetAllClients()
        {
            if (_context.Clients == null)
            {
                return NotFound();
            }
            return await _context.Clients.OrderBy(o => o.ClientId).ToListAsync();
        }

        // GET: api/Client/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("{id}")]
        public async Task<ActionResult<Client>> GetClient(int id)
        {
            if (_context.Clients == null)
            {
                return NotFound();
            }
            var client = await _context.Clients.FindAsync(id);

            if (client == null || client.Status == false)
            {
                return NotFound();
            }

            return client;
        }

        // GET: api/Client/IsEmailUnique/email@test.com
        [Authorize(Policy = "Supervisor")]
        [HttpGet("IsEmailUnique/{email}")]
        public async Task<ActionResult<bool>> IsEmailUnique(string email)
        {
            if (_context.Clients == null)
            {
                return NotFound();
            }
            var client = await _context.Clients.Where(o => o.Email == email.Trim()).FirstOrDefaultAsync();

            if (client == null)
            {
                return true;
            }

            return false;
        }

        // GET: api/Client/IsEmailUniqueUpdate/5/email@test.com
        [Authorize(Policy = "Supervisor")]
        [HttpGet("IsEmailUniqueUpdate/{id}/{email}")]
        public async Task<ActionResult<bool>> IsEmailUniqueUpdate(int id, string email)
        {
            if (_context.Clients == null)
            {
                return NotFound();
            }
            var client = await _context.Clients.Where(o => o.Email == email.Trim() && o.ClientId != id).FirstOrDefaultAsync();

            if (client == null)
            {
                return true;
            }

            return false;
        }

        // GET: api/Client/CheckRefIntegrity/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckClientRefIntegrity(int id)
        {
            if (_context.Clients == null)
            {
                return false;
            }
            var client = await _context.Clients
                .Include(o => o.ClientOrders.Where(a => a.Status == true))
                .FirstOrDefaultAsync(o => o.ClientId == id);

            if (client == null || client.Status == false)
            {
                return false;
            }

            if (client.ClientOrders.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // PUT: api/Client/5
        [Authorize(Policy = "Manager")]
        [HttpPut("{id}")]
        public async Task<IActionResult> PutClient(int id, ClientRequest client)
        {

            if (client == null)
                return BadRequest();

            Client? clientDb = _context.Clients.FirstOrDefault(x => x.ClientId == id);

            if (clientDb == null)
                return NotFound();

            clientDb.Name = client.Name;
            clientDb.ContractNr = client.ContractNr;
            clientDb.Email = client.Email;
            clientDb.Address = client.Address;
            clientDb.Status = client.Status;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Client
        [Authorize(Policy = "Manager")]
        [HttpPost]
        public async Task<ActionResult<Client>> PostClient(ClientRequest client)
        {
            if (client == null)
                return BadRequest();

            Client newClient = mapper.ClientMapper(client);
            newClient.Email = newClient.Email.Trim();

            _context.Clients.Add(newClient);
            _context.SaveChanges();

            return Ok();
        }

        //DELETE: api/Client/5
        [Authorize(Policy = "Manager")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteClient(int id)
        {
            Client? client = _context.Clients.FirstOrDefault(x => x.ClientId == id);

            if (client == null)
                return NotFound();

            _context.Clients.Remove(client);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
