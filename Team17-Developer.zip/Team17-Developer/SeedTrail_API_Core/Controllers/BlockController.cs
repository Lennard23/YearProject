﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class BlockController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public BlockController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }


        // POST: api/Block
        [HttpPost]
        public async Task<ActionResult<Block>> PostBlock(BlockRequest newBlock)
        {
            if (_context.Blocks == null)
            {
                return Problem("Entity set 'AppDbContext.Blocks'  is null.");
            }
            try
            {
                Block? newResult = mapper.BlockMapper(newBlock);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.Blocks.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Block
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Block>>> GetBlocks()
        {
            if (_context.Blocks == null)
            {
                return NotFound("The Blocks entity does not exist.");
            }
            try
            {
                // select only the Batches with Status = true
                List<Block>? result = await _context.Blocks
                    .Where(a => a.Status == true)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Block/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Block>>> GetAllBlocks()
        {
            if (_context.Blocks == null)
            {
                return NotFound("The Blocks entity does not exist.");
            }
            try
            {
                List<Block>? result = await _context.Blocks.ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Block/CheckRefIntegrity/5
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckRefIntegrity(int id)
        {
            if (_context.Blocks == null)
            {
                return NotFound("The Blocks entity does not exist.");
            }
            try
            {
                Block? result = await _context.Blocks
                    .Include(o => o.GreenhouseTables.Where(a => a.Status == true))
                    .FirstOrDefaultAsync(o => o.BlockId == id);
                if (result == null)
                {
                    return BadRequest();
                }
                if (result.GreenhouseTables.Count > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Block/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Block>> GetBlock(int id)
        {
            if (_context.Blocks == null)
            {
                return NotFound("The Blocks entity does not exist.");
            }
            try
            {
                Block? result = await _context.Blocks.FindAsync(id);
                if (result == null || result.Status == false)
                {
                    return NotFound("No Block found for given id");
                }
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Block/BlockTables/5
        [HttpGet("BlockTables/{id}")]
        public async Task<ActionResult<IEnumerable<GreenhouseTable>>> GetBlockTables(int id)
        {
            if (_context.Blocks == null || _context.GreenhouseTables == null)
            {
                return NotFound("The Blocks or GreenhouseTables entity does not exist.");
            }
            try
            {
                Block? result = await _context.Blocks
                    .Include(o => o.GreenhouseTables)
                    .FirstOrDefaultAsync(a => a.BlockId == id);
                if (result == null || result.Status == false)
                {
                    return NotFound("No Batch found for given id");
                }
                return Ok(result.GreenhouseTables);
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT: api/Block/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBlock(int id, BlockRequest block)
        {
            if (block == null)
            {
                return BadRequest("No Block found for given id");
            }
            Block? result = await _context.Blocks.FirstOrDefaultAsync(x => x.BlockId == id);
            if (result == null)
            {
                return NotFound();
            }
            Block? newResult = mapper.BlockMapper(block);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.BatchId = newResult.BatchId;
                result.Description = newResult.Description;
                result.Status = newResult.Status;
                result.Batch = newResult.Batch;

                _context.Entry(result).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        //DELETE: api/Block/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBlock(int id)
        {
            Block? block = _context.Blocks.FirstOrDefault(x => x.BlockId == id);

            if (block == null)
                return NotFound();

            _context.Blocks.Remove(block);

            _context.SaveChanges();

            return NoContent();
        }
    }
}
