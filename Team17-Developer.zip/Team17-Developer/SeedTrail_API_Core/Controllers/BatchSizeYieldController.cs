﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class BatchSizeYieldController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public BatchSizeYieldController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // POST api/BatchSizeYield
        [HttpPost]
        public async Task<ActionResult<BatchSizeYield>> PostBatchSizeYield(BatchSizeYieldRequest newBatchSizeYield)
        {
            if (_context.BatchSizeYields == null)
            {
                return Problem("Entity set 'AppDbContext.BatchSizeYields'  is null.");
            }
            try
            {
                BatchSizeYield? newResult = mapper.BatchSizeYieldMapper(newBatchSizeYield);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.BatchSizeYields.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET api/BatchSizeYield
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BatchSizeYield>>> GetBatchSizeYields()
        {
            if (_context.BatchSizeYields == null)
            {
                return Problem("Entity set 'AppDbContext.BatchSizeYields'  is null.");
            }
            try
            {
                return await _context.BatchSizeYields
                    .Where(a => a.Status == true)
                    .ToListAsync();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET api/BatchSizeYield/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<BatchSizeYield>>> GetAllBatchSizeYields()
        {
            if (_context.BatchSizeYields == null)
            {
                return Problem("Entity set 'AppDbContext.BatchSizeYields'  is null.");
            }
            try
            {
                return await _context.BatchSizeYields
                    .ToListAsync();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET api/BatchSizeYield/5
        [HttpGet("{id}")]
        public async Task<ActionResult<BatchSizeYield>> GetBatchSizeYield(int id)
        {
            if (_context.BatchSizeYields == null)
            {
                return Problem("Entity set 'AppDbContext.BatchSizeYields'  is null.");
            }
            try
            {
                var batchSizeYield = await _context.BatchSizeYields.FindAsync(id);

                if (batchSizeYield == null)
                {
                    return NotFound();
                }

                return batchSizeYield;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT api/BatchSizeYield/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBatchSizeYield(int id, BatchSizeYieldRequest updatedBatchSizeYield)
        {
            if (_context.BatchSizeYields == null)
            {
                return Problem("Entity set 'AppDbContext.BatchSizeYields'  is null.");
            }
            try
            {
                BatchSizeYield? original = await _context.BatchSizeYields.FindAsync(id);
                BatchSizeYield? updatedResult = mapper.BatchSizeYieldMapper(updatedBatchSizeYield);
                if (updatedResult == null)
                {
                    return Problem("could not map result");
                }
                if (original == null)
                {
                    return NotFound();
                }
                original.BatchId = updatedResult.BatchId;
                original.CommditySizeId = updatedResult.CommditySizeId;
                original.Yield = updatedResult.Yield;
                original.Status = updatedResult.Status;
                original.Description = updatedResult.Description;
                original.Batch = updatedResult.Batch;
                original.CommditySize = updatedResult.CommditySize;

                try
                {
                    _context.Entry(original).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                    return NoContent();
                }
                catch (DbUpdateConcurrencyException error)
                {
                    return Problem(error.Message);
                }

            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // DELETE api/BatchSizeYield/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<BatchSizeYield>> DeleteBatchSizeYield(int id)
        {
            if (_context.BatchSizeYields == null)
            {
                return Problem("Entity set 'AppDbContext.BatchSizeYields'  is null.");
            }
            try
            {
                var batchSizeYield = await _context.BatchSizeYields.FindAsync(id);
                if (batchSizeYield == null)
                {
                    return NotFound();
                }

                _context.BatchSizeYields.Remove(batchSizeYield);
                await _context.SaveChangesAsync();

                return batchSizeYield;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }
    }
}
