﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseReportController : ControllerBase
    {
        private readonly AppDbContext _context;

        public GreenhouseReportController(AppDbContext context)
        {
            _context = context;
        }

        // Status report
        [HttpGet("Status")]
        public async Task<ActionResult<IGhRepStatus>> GetStatus(int greenhouseId)
        {
            if (_context.Blocks == null || _context.Batches == null || _context.GreenhouseTables == null)
            {
                return Problem("An Entity set referenced in IGhRepStatus is null.");
            }
            // find greenhouse
            var gh = await _context.Greenhouses.FindAsync(greenhouseId);
            if (gh == null)
            {
                return NotFound("No match found for specified Greenhouse ID");
            }
            // find status desc
            int ghsdid = gh.GreenhouseStatusDescId;
            var ghsd = await _context.GreenhouseStatusDescriptions.FindAsync(ghsdid);
            if (ghsd == null)
            {
                return NotFound("No related GreenhouseStatusDescription ID for specified Greenhouse");
            }
            // find status
            int ghsid = ghsd.GreenhouseStatusId;
            var ghs = await _context.GreenhouseStatuses.FindAsync(ghsid);
            if (ghs == null)
            {
                return NotFound("No related GreenhouseStatus ID for specified Greenhouse");
            }
            // gh table count
            int tableCount = gh.GreenhouseTables.Count!;
            // get tables related to greenhouse
            var ghts = await _context.GreenhouseTables.Where(a => a.GreenhouseId == greenhouseId).ToListAsync();
            if (ghts == null)
            {
                return NotFound("No related GreenhouseTables for specified Greenhouse");
            }
            // find the blocks that include ghts
            var blocks = await _context.Blocks.Where(a => a.GreenhouseTables.Any(b => ghts.Contains(b))).ToListAsync();
            if (blocks == null)
            {
                return NotFound("No related Blocks for specified Greenhouse");
            }
            int blockCount = blocks.Count!;
            // find batches related to var blocks
            var batches = await _context.Batches.Where(a => a.Blocks.Any(b => blocks.Contains(b))).ToListAsync();
            if (batches == null)
            {
                return NotFound("No related Batches for specified Greenhouse");
            }
            int batchCount = batches.Count!;
            var reply = new GhRepStatus
            {
                GhStatus = ghs,
                TableCount = tableCount,
                BlockCount = blockCount,
                BatchCount = batchCount
            };
            return Ok(reply);
        }

        // Activities report
        [HttpGet("Activities")]
        public async Task<ActionResult<IEnumerable<GreenhouseActivity>>> GetActivities(int greenhouseId)
        {
            if (_context.GreenhouseActivities == null || _context.Greenhouses == null)
            {
                return Problem("An Entity set referenced in IGreenhouseActivity is null.");
            }
            // find greenhouse
            var gh = await _context.Greenhouses.FindAsync(greenhouseId);
            if (gh == null)
            {
                return NotFound("No match found for specified Greenhouse ID");
            }
            // find greenhouse activities related to greenhouse
            var ghas = await _context.GreenhouseActivities.Where(a => a.GreenhouseId == greenhouseId).ToListAsync();
            if (ghas == null)
            {
                return NotFound("No related GreenhouseActivities for specified Greenhouse");
            }
            return Ok(ghas);
        }

        // Produce report
        //[HttpGet("Produce")]
        //public async Task<ActionResult<IGhRepProduce>> GetProduce(int greenhouseId)
        //{
        //    var reply = new GhRepProduce
        //    {

        //    };
        //    return reply;
        //}
    }
}
