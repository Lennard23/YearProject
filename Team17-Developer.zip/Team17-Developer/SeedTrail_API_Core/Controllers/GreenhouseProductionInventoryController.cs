﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseProductionInventoryController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public GreenhouseProductionInventoryController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/GreenhouseProductionInventory
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GreenhouseProductionInventory>>> GetGhProductionInventories()
        {
            if (_context.GreenhouseProductionInventories == null)
            {
                return NotFound();
            }
            return await _context.GreenhouseProductionInventories.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/GreenhouseProductionInventory/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<GreenhouseProductionInventory>>> GetAllGhProductionInventories()
        {
            if (_context.GreenhouseProductionInventories == null)
            {
                return NotFound();
            }
            return await _context.GreenhouseProductionInventories.ToListAsync();
        }

        // GET: api/GreenhouseProductionInventory/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GreenhouseProductionInventory>> GetGhProductionInventoryById(int id)
        {
            if (_context.GreenhouseProductionInventories == null)
            {
                return NotFound();
            }
            var ghpi = await _context.GreenhouseProductionInventories.FindAsync(id);
            if (ghpi == null || ghpi.Status == false)
            {
                return NotFound();
            }
            return ghpi;
        }

        // POST: api/GreenhouseProductionInventory
        [HttpPost]
        public async Task<ActionResult<GreenhouseProductionInventory>> PostGhProductionInventory(GreenhouseProductionInventoryRequest request)
        {
            if (_context.GreenhouseProductionInventories == null)
            {
                return NotFound();
            }
            GreenhouseProductionInventory? ghpi = mapper.GhProductionInventoryMapper(request);
            if (ghpi == null)
            {
                BadRequest();
            }
            try
            {
                _context.GreenhouseProductionInventories.Add(ghpi!);
                await _context.SaveChangesAsync();
                return CreatedAtAction("GetGhProductionInventoryById", new { id = ghpi!.GreenhouseProductionInventoryId }, ghpi);
            }
            catch(DbUpdateException ex)
            {
                if (ex.InnerException != null)
                {
                    if (ex.InnerException.Message.Contains("UNIQUE KEY constraint"))
                    {
                        return Conflict();
                    }
                    else
                    {
                        return Problem(ex.InnerException.Message);
                    }
                }
                return Problem(ex.Message);
            }
        }

        // PUT: api/GreenhouseProductionInventory/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGhProductionInventory(int id, GreenhouseProductionInventoryRequest request)
        {
            if (request == null)
            {
                return BadRequest();
            }
            GreenhouseProductionInventory? ghpi = _context.GreenhouseProductionInventories
                .FirstOrDefault(x => x.GreenhouseProductionInventoryId == id);
            if (ghpi == null)
            {
                return NotFound();
            }
            GreenhouseProductionInventory? newGhpi = mapper.GhProductionInventoryMapper(request);
            if (newGhpi == null)
            {
                return BadRequest();
            }
            try
            {
                ghpi.Status = newGhpi.Status;
                ghpi.GreenhouseId = newGhpi.GreenhouseId;
                ghpi.Greenhouse = newGhpi.Greenhouse;
                ghpi.ProductionInvId = newGhpi.ProductionInvId;
                ghpi.ProductionInv = newGhpi.ProductionInv;
                
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (DbUpdateException ex)
            {
                if (ex.InnerException != null)
                {
                    return Problem(ex.InnerException.Message);
                }
                return Problem(ex.Message);
            }
        }

        // GET: api/GreenhouseProductionInventory/AllProdInvsForGhId/5
        [HttpGet("AllProdInvsForGhId/{id}")]
        public async Task<ActionResult<IEnumerable<GreenhouseProductionInventory>>> GetAllProdInvsForGhId(int id)
        {
            if (_context.GreenhouseProductionInventories == null || _context.Greenhouses == null)
            {
                return NotFound();
            }
            var ghpis = await _context.GreenhouseProductionInventories.Where(o => o.GreenhouseId == id).ToListAsync();
            if (ghpis == null || ghpis.Count == 0)
            {
                return NotFound();
            }
            return ghpis;
        }

        // DELETE: api/GreenhouseProductionInventory/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGhProductionInventory (int id)
        {
            if (_context.GreenhouseProductionInventories == null)
            {
                return NotFound();
            }
            GreenhouseProductionInventory? ghpi = _context.GreenhouseProductionInventories.Find(id);
            if (ghpi == null)
            {
                return NotFound();
            }
            try
            {
                _context.GreenhouseProductionInventories.Remove(ghpi!);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                if (ex.InnerException != null)
                {

                    return Problem(ex.InnerException.Message);

                }
                return Problem(ex.Message);
            }
            return NoContent();
        }
    }
}
