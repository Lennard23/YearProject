﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;
using SeedTrail_API_Core.Services.Auth;
using System.Text;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Manager")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;
        private readonly IAuthService authService;

        public EmployeeController(AppDbContext context, IAuthService authService)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
            this.authService = authService;
        }

        // GET: api/Employee
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployees()
        {
            if (_context.Employees == null)
            {
                return NotFound();
            }
            return await _context.Employees.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Employee/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Employee>>> GetAllEmployees()
        {
            if (_context.Employees == null)
            {
                return NotFound();
            }
            return await _context.Employees.ToListAsync();
        }

        // GET: api/Employee/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            if (_context.Employees == null)
            {
                return NotFound();
            }
            var employee = await _context.Employees.FindAsync(id);

            if (employee == null || employee.Status == false)
            {
                return NotFound();
            }

            return employee;
        }

        // PUT: api/Employee/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployee(int id, EmployeeRequest employee)
        {
            if (_context.EmployeeActivities.Include(x=>x.Emp).FirstOrDefault(x => x.Emp.EmpId == id) != null)
            {
                return BadRequest();
            }

            if (employee == null)
                return BadRequest();

            Employee? employeeDb = _context.Employees.FirstOrDefault(x => x.EmpId == id);

            if (employeeDb == null)
                return NotFound();

            employeeDb.AccessLevelAreaId = employee.AccessLevelAreaId;
            employeeDb.EmpTypeId = employee.EmpTypeId;
            employeeDb.Name = employee.Name;
            employeeDb.Surname = employee.Surname;
            employeeDb.ContactNr = employee.ContactNr;
            employeeDb.NationalId = employee.NationalId;
            employeeDb.Email = employee.Email;
            employeeDb.StartDate = employee.StartDate;
            employeeDb.EndDate = employee.EndDate;
            employeeDb.Status = employee.Status;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Employee
        [HttpPost]
        public async Task<ActionResult<Employee>> PostEmployee(EmployeeRequest employee)
        {
            if (employee == null)
                return BadRequest();

            Employee newEmp = mapper.EmployeeMapper(employee);

            _context.Employees.Add(newEmp);
            _context.SaveChanges();

            Register register = new()
            {
                Email = employee.Email,
                Password = Helpers.Generators.PasswordGenerator(8),
                RoleId = 1,
            };

            await authService.Register(register, true);

            return Ok();
        }
        // GET: api/Client/CheckRefIntegrity/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckEmployeeRefIntegrity(int id)
        {
            if (_context.Employees == null)
            {
                return false;
            }
            var employee = await _context.Employees.Include(o => o.EmployeeActivities).FirstOrDefaultAsync(o => o.EmpId == id);

            if (employee == null || employee.Status == false)
            {
                return false;
            }

            if (employee.EmployeeActivities.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // DELETE: api/Employee/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {


            Employee? employee = _context.Employees.FirstOrDefault(x => x.EmpId == id);

            if (employee == null)
                return NotFound();

            _context.Employees.Remove(employee);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
