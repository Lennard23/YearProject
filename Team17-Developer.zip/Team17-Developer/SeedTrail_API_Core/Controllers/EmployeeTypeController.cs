﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeTypeController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeeTypeController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/EmployeeType
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeType>>> GetEmployeeTypes()
        {
            if (_context.EmployeeTypes == null)
            {
                return NotFound();
            }
            return await _context.EmployeeTypes.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/EmployeeType/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<EmployeeType>>> GetAllEmployeeTypes()
        {
            if (_context.EmployeeTypes == null)
            {
                return NotFound();
            }
            return await _context.EmployeeTypes.ToListAsync();
        }

        // GET: api/EmployeeType/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EmployeeType>> GetEmployeeType(int id)
        {
            if (_context.EmployeeTypes == null)
            {
                return NotFound();
            }
            var employeeType = await _context.EmployeeTypes.FindAsync(id);

            if (employeeType == null || employeeType.Status == false)
            {
                return NotFound();
            }

            return employeeType;
        }

        // PUT: api/EmployeeType/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEmployeeType(int id, EmployeeType employeeType)
        {
            if (id != employeeType.EmpTypeId)
            {
                return BadRequest();
            }

            _context.Entry(employeeType).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeTypeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EmployeeType
        [HttpPost]
        public async Task<ActionResult<EmployeeType>> PostEmployeeType(EmployeeType employeeType)
        {
            if (_context.EmployeeTypes == null)
            {
                return Problem("Entity set 'AppDbContext.EmployeeTypes'  is null.");
            }
            _context.EmployeeTypes.Add(employeeType);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (EmployeeTypeExists(employeeType.EmpTypeId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetEmployeeType", new { id = employeeType.EmpTypeId }, employeeType);
        }

        //DELETE: api/EmployeeType/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployeeType(int id)
        {
            if (_context.EmployeeTypes == null)
            {
                return NotFound();
            }
            var employeeType = await _context.EmployeeTypes.FindAsync(id);
            if (employeeType == null)
            {
                return NotFound();
            }

            _context.EmployeeTypes.Remove(employeeType);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmployeeTypeExists(int id)
        {
            return (_context.EmployeeTypes?.Any(e => e.EmpTypeId == id)).GetValueOrDefault();
        }
    }
}
