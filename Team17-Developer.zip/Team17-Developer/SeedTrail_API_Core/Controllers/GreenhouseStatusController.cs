﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;


namespace SeedTrail_API_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseStatusController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public GreenhouseStatusController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }
        // GET: api/GreenhouseStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GreenhouseStatus>>> GetGreenhouseStatuses()
        {
            if (_context.GreenhouseStatuses == null)
            {
                return NotFound();
            }
            return await _context.GreenhouseStatuses.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/GreenhouseStatus/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<GreenhouseStatus>>> GetAllGreenhouseStatuses()
        {
            if (_context.GreenhouseStatuses == null)
            {
                return NotFound();
            }
            return await _context.GreenhouseStatuses.ToListAsync();
        }

        // GET: api/GreenhouseStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GreenhouseStatus>> GetGreenhouseStatus(int id)
        {
            if (_context.GreenhouseStatuses == null)
            {
                return NotFound();
            }
            var greenhouseStatus = await _context.GreenhouseStatuses.FindAsync(id);

            if (greenhouseStatus == null || greenhouseStatus.Status == false)
            {
                return NotFound();
            }

            return greenhouseStatus;
        }
    }
}
