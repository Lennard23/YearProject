﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class CultivarController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public CultivarController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/Cultivar
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cultivar>>> GetCultivars()
        {
            if (_context.Cultivars == null)
            {
                return NotFound();
            }
            return await _context.Cultivars
                .Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Cultivar/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Cultivar>>> GetAllCultivars()
        {
            if (_context.Cultivars == null)
            {
                return NotFound();
            }
            return await _context.Cultivars.ToListAsync();
        }

        // GET: api/Cultivar/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Cultivar>> GetCultivar(int id)
        {
            if (_context.Cultivars == null)
            {
                return NotFound();
            }
            var cultivar = await _context.Cultivars.FindAsync(id);

            if (cultivar == null || cultivar.Status == false)
            {
                return NotFound();
            }

            return cultivar;
        }

        // PUT: api/Cultivar/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCultivar(int id, CultivarRequest cultivar)
        {
            if (cultivar == null)
                return BadRequest();

            Cultivar? cultivarDB = _context.Cultivars.FirstOrDefault(x => x.CultivarId == id);

            if (cultivarDB == null)
                return NotFound();

            Cultivar? newCultivar = mapper.CultivarMapper(cultivar);

            if (newCultivar == null)
                return BadRequest();

            cultivarDB.CommodityId = newCultivar.CommodityId;
            cultivarDB.Name = newCultivar.Name;
            cultivarDB.Description = newCultivar.Description;
            cultivarDB.Status = newCultivar.Status;
            cultivarDB.Commodity = newCultivar.Commodity;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Cultivar
        [HttpPost]
        public async Task<ActionResult<Cultivar>> PostCultivar(CultivarRequest cultivar)
        {
            if (cultivar == null)
                return BadRequest();

            Cultivar? newCultivar = mapper.CultivarMapper(cultivar);

            if (newCultivar == null)
                return BadRequest();

            Cultivar entity = _context.Cultivars.Add(newCultivar).Entity;

            _context.SaveChanges();

            return Ok(entity);
        }

        //DELETE: api/Cultivar/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCultivar(int id)
        {
            Cultivar entity = _context.Cultivars.FirstOrDefault(x => x.CultivarId == id);

            if (entity == null)
                return NotFound();

            _context.Remove(entity);

            _context.SaveChanges();

            return NoContent();
        }

        [HttpGet("GetCultivarByCommodityId")]
        public async Task<IActionResult> GetCultivarByCommodityId([FromQuery] int id, [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] int? cultivarId)
        {
            var data = _context.BatchSizeYields
                .Include(x => x.Batch)
                .Include(x => x.Batch.Coldroom)
                .Include(x => x.Batch.ClientOrder)
                .Include(x => x.Batch.Cultivar)
                .Include(x => x.Batch.Cultivar.Commodity)
                .Include(x => x.CommditySize);


            List<BatchSizeYield> filteredData;

            filteredData = data.Where(x => x.Batch.Cultivar.Commodity.CommodityId == id).ToList();

            if (from.HasValue && to.HasValue)
            {
                filteredData = filteredData.Where(x =>
                        x.Batch.HarvestDate > from
                        && x.Batch.HarvestDate < to)
                    .ToList();
            }

            if (cultivarId.HasValue)
            {
                filteredData = filteredData.Where(x => x.Batch.Cultivar.CultivarId == cultivarId).ToList();
            }

            return Ok(filteredData);
        }
    }
}
