﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class AccessLevelAreaController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AccessLevelAreaController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/AccessLevelArea
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AccessLevelArea>>> GetAccessLevelAreas()
        {
            if (_context.AccessLevelAreas == null)
            {
                return NotFound();
            }
            return await _context.AccessLevelAreas.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/AccessLevelArea/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<AccessLevelArea>>> GetAllAccessLevelAreas()
        {
            if (_context.AccessLevelAreas == null)
            {
                return NotFound();
            }
            return await _context.AccessLevelAreas.ToListAsync();
        }

        // GET: api/AccessLevelArea/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AccessLevelArea>> GetAccessLevelArea(int id)
        {
            if (_context.AccessLevelAreas == null)
            {
                return NotFound();
            }
            var accessLevelArea = await _context.AccessLevelAreas.FindAsync(id);

            if (accessLevelArea == null || accessLevelArea.Status == false)
            {
                return NotFound();
            }

            return accessLevelArea;
        }

        // PUT: api/AccessLevelArea/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAccessLevelArea(int id, AccessLevelArea accessLevelArea)
        {
            if (id != accessLevelArea.AccessLevelAreaId)
            {
                return BadRequest();
            }

            _context.Entry(accessLevelArea).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AccessLevelAreaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AccessLevelArea
        [HttpPost]
        public async Task<ActionResult<AccessLevelArea>> PostAccessLevelArea(AccessLevelArea accessLevelArea)
        {
            if (_context.AccessLevelAreas == null)
            {
                return Problem("Entity set 'AppDbContext.AccessLevelAreas'  is null.");
            }
            _context.AccessLevelAreas.Add(accessLevelArea);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AccessLevelAreaExists(accessLevelArea.AccessLevelAreaId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAccessLevelArea", new { id = accessLevelArea.AccessLevelAreaId }, accessLevelArea);
        }

        //DELETE: api/AccessLevelArea/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAccessLevelArea(int id)
        {
            if (_context.AccessLevelAreas == null)
            {
                return NotFound();
            }
            var accessLevelArea = await _context.AccessLevelAreas.FindAsync(id);
            if (accessLevelArea == null)
            {
                return NotFound();
            }

            _context.AccessLevelAreas.Remove(accessLevelArea);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AccessLevelAreaExists(int id)
        {
            return (_context.AccessLevelAreas?.Any(e => e.AccessLevelAreaId == id)).GetValueOrDefault();
        }
    }
}
