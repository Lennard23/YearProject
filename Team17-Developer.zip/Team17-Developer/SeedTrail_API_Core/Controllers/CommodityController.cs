﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class CommodityController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public CommodityController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/Commodity
        [Authorize(Policy = "Supervisor")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Commodity>>> GetCommodities()
        {
            if (_context.Commodities == null)
            {
                return NotFound();
            }
            return await _context.Commodities.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Commodity/All
        [Authorize(Policy = "Supervisor")]
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Commodity>>> GetAllCommodities()
        {
            if (_context.Commodities == null)
            {
                return NotFound();
            }
            return await _context.Commodities.ToListAsync();
        }

        // GET: api/Commodity/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("{id}")]
        public async Task<ActionResult<Commodity>> GetCommodity(int id)
        {
            if (_context.Commodities == null)
            {
                return NotFound();
            }
            var commodity = await _context.Commodities.FindAsync(id);

            if (commodity == null || commodity.Status == false)
            {
                return NotFound();
            }

            return commodity;
        }

        // GET: api/Commodity/CheckRefIntegrity/5
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckRefIntegrity(int id)
        {
            if (_context.Commodities == null)
            {
                return false;
            }

            var commodity = await _context.Commodities.Include(o => o.Cultivars).FirstOrDefaultAsync(o => o.CommodityId == id);
            

            if (commodity == null || commodity.Status == false)
            {
                return false;
            }
            // Check:
            // CommoditySize
            //var commoditySize = await _context.CommoditySizes.Where(x => x.CommoditySizeId == id).ToListAsync();
            // Cultivar
            var cultivar = await _context.Cultivars.Where(x => x.CultivarId == id).ToListAsync();
            // return true if there's a clash
            
            //if (commoditySize.Count > 0 || cultivar.Count > 0)
            if (commodity.Cultivars.Count >0)
            {
                return true;
            }
            return false;
        }

        // PUT: api/Commodity/5
        [Authorize(Policy = "Manager")]
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCommodity(int id, CommodityRequest commodity)
        {
            if (commodity == null)
                return BadRequest();

            Commodity? com = _context.Commodities.FirstOrDefault(x => x.CommodityId == id);

            if (com == null)
                return NotFound();

            Commodity newCom = mapper.CommodityMapper(commodity);

            com.Name = newCom.Name;
            com.Description = newCom.Description;
            com.Status = newCom.Status;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Commodity
        [Authorize(Policy = "Manager")]
        [HttpPost]
        public async Task<ActionResult<Commodity>> PostCommodity(CommodityRequest commodity)
        {
            Commodity newCom = mapper.CommodityMapper(commodity);

            Commodity com = _context.Commodities.Add(newCom).Entity;

            _context.SaveChanges();

            return Ok(com);
        }

        // DELETE: api/Commodity/5
        [Authorize(Policy = "Manager")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCommodity(int id)
        {
            Commodity? com = _context.Commodities.FirstOrDefault(x => x.CommodityId == id);

            if (com == null)
                return NotFound();

            _context.Commodities.Remove(com);
            _context.SaveChanges();

            return NoContent();
        }

    }
}
