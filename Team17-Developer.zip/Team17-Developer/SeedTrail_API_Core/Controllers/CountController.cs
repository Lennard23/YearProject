﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;
using System.Linq;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class CountController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public CountController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // get the counts for a specific cultivar in a specific greenhouse
        // GET: api/Count/Cultivar/5/5
        [HttpGet("Cultivar/{greenhouseId}/{cultivarId}")]
        public async Task<ActionResult<Int32>> GetCultivarCount(int greenhouseId, int cultivarId)
        {
            var gh = await _context.Greenhouses
                .Include(o => o.GreenhouseTables)
                .ThenInclude(o => o.Block)
                .FirstOrDefaultAsync(o => o.GreenhouseId == greenhouseId);
            var cv = await _context.Cultivars.FindAsync(cultivarId);
            if (gh == null || cv == null)
            {
                return NotFound();
            }
            List<int> blockIds = new();
            foreach (var table in gh.GreenhouseTables)
            {
                if (!blockIds.Contains(table.BlockId))
                {
                    blockIds.Add(table.BlockId);
                }
            }
            List<Block> blocks = new();
            foreach (var id in blockIds)
            {
                var block = await _context.Blocks.FindAsync(id);
                blocks.Add(block!);
            }
            List<int> batchIds = new();
            foreach (var block in blocks)
            {
                if (!batchIds.Contains((int)block.BatchId!))
                {
                    batchIds.Add((int)block.BatchId);
                }
            }
            List<Batch> batches = new();
            foreach (var id in batchIds)
            {
                var batch = await _context.Batches.FindAsync(id);
                if (batch!.CultivarId == cultivarId)
                {
                    batches.Add(batch);
                }
            }
            List<BatchSizeYield> batchYields = new();
            foreach (var batch in batches)
            {
                var yields = await _context.BatchSizeYields
                    .Where(o => o.BatchId == batch.BatchId)
                    .ToListAsync();
                foreach (var yield in yields)
                {
                    batchYields.Add(yield);
                }
            }
            return batchYields.Sum(o => o.Yield);
        }

        // get the counts for a specific commodity in a specific greenhouse
        // GET: api/Count/Commodity/5/5
        [HttpGet("Commodity/{greenhouseId}/{commodityId}")]
        public async Task<ActionResult<Int32>> GetCommodityCount(int greenhouseId, int commodityId)
        {
            var gh = await _context.Greenhouses
                .Include(o => o.GreenhouseTables)
                .ThenInclude(o => o.Block)
                .FirstOrDefaultAsync(o => o.GreenhouseId == greenhouseId);
            var cv = await _context.Commodities.FindAsync(commodityId);
            if (gh == null || cv == null)
            {
                return NotFound();
            }
            List<int> blockIds = new();
            foreach (var table in gh.GreenhouseTables)
            {
                if (!blockIds.Contains(table.BlockId))
                {
                    blockIds.Add(table.BlockId);
                }
            }
            List<Block> blocks = new();
            foreach (var id in blockIds)
            {
                var block = await _context.Blocks.FindAsync(id);
                blocks.Add(block!);
            }
            List<int> batchIds = new();
            foreach (var block in blocks)
            {
                if (!batchIds.Contains((int)block.BatchId!))
                {
                    batchIds.Add((int)block.BatchId);
                }
            }
            List<int> cultivarIds = new();
            foreach (var id in batchIds)
            {
                var batch = await _context.Batches.FindAsync(id);
                if (!cultivarIds.Contains((int)batch!.CultivarId!))
                {
                    cultivarIds.Add((int)batch.CultivarId);
                }
            }
            List<Cultivar> cultivars = new();
            foreach (var id in cultivarIds)
            {
                var cultivar = await _context.Cultivars.FindAsync(id);
                cultivars.Add(cultivar!);
            }
            List<Batch> batches = new();
            foreach (var cultivar in cultivars)
            {
                if (cultivar.CommodityId == commodityId)
                {
                    var batch = await _context.Batches.FindAsync(cultivar.CultivarId);
                    batches.Add(batch!);
                }
            }
            List<BatchSizeYield> batchYields = new();
            foreach (var batch in batches)
            {
                var yields = await _context.BatchSizeYields
                    .Where(o => o.BatchId == batch.BatchId)
                    .ToListAsync();
                foreach (var yield in yields)
                {
                    batchYields.Add(yield);
                }
            }
            return batchYields.Sum(o => o.Yield);
        }

        // GET: api/Count/GreenhouseCultivarCounts
        [HttpGet("GreenhouseCultivarCounts")]
        public async Task<ActionResult<IEnumerable<GreenhouseCultivarCount>>> GetGreenhouseCultivarCounts()
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                // select only the Batches with Status = true
                List<GreenhouseCultivarCount>? result = await _context.GreenhouseCultivarCounts
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // get by greenhouse id
        // GET: api/Count/GreenhouseCultivarCounts/Greenhouse/5
        [HttpGet("GreenhouseCultivarCounts/Greenhouse/{greenhouseId}")]
        public async Task<ActionResult<IEnumerable<GreenhouseCultivarCount>>> GetGreenhouseCultivarCounts(int greenhouseId)
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                // select only the Batches with Status = true
                List<GreenhouseCultivarCount>? result = await _context.GreenhouseCultivarCounts
                    .Where(o => o.GreenhouseId == greenhouseId)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // get by cultivar id and greenhouse id
        // GET: api/Count/GreenhouseCultivarCounts/5/5
        [HttpGet("GreenhouseCultivarCounts/{greenhouseId}/{cultivarId}")]
        public async Task<ActionResult<GreenhouseCultivarCount>> GetGreenhouseCultivarCount(int greenhouseId, int cultivarId)
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                // select only the Batches with Status = true
                GreenhouseCultivarCount? result = await _context.GreenhouseCultivarCounts
                    .FirstOrDefaultAsync(o => o.GreenhouseId == greenhouseId && o.CultivarId == cultivarId);
                if (result == null)
                {
                    return NotFound("No matches found");
                }
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/Count/GreenhouseCultivarCounts/IsUnique/5/5
        [HttpGet("GreenhouseCultivarCounts/IsUnique/{greenhouseId}/{cultivarId}")]
        public async Task<ActionResult<Boolean>> IsGreenhouseCultivarCountUnique(int greenhouseId, int cultivarId)
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                // select only the Batches with Status = true
                GreenhouseCultivarCount? result = await _context.GreenhouseCultivarCounts
                    .FirstOrDefaultAsync(o => o.GreenhouseId == greenhouseId && o.CultivarId == cultivarId);
                if (result == null)
                {
                    return true;
                }
                return false;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // POST: api/Count
        [HttpPost]
        public async Task<ActionResult<GreenhouseCultivarCount>> PostGreenhouseCultivarCount(GreenhouseCultivarCountRequest request)
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                GreenhouseCultivarCount? mapped = mapper.GreenhouseCultivarMapper(request);
                if (mapped == null)
                {
                    return BadRequest("The request could not be mapped to a GreenhouseCultivarCount object.");
                }
                // check if mapped's greenhouseId + cultivarId combo doesn't exist already
                GreenhouseCultivarCount? existing = await _context.GreenhouseCultivarCounts
                    .FirstOrDefaultAsync(o => o.GreenhouseId == mapped.GreenhouseId && o.CultivarId == mapped.CultivarId);
                if (existing != null)
                {
                    return Conflict("The GreenhouseCultivarCount object already exists.");
                }
                _context.GreenhouseCultivarCounts.Add(mapped);
                await _context.SaveChangesAsync();
                return Ok();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT: api/Count/GreenhouseCultivarCounts
        [HttpPut("GreenhouseCultivarCounts")]
        public async Task<ActionResult<GreenhouseCultivarCount>> PutGreenhouseCultivarCounts(GreenhouseCultivarCountRequest request)
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                GreenhouseCultivarCount? original = await _context.GreenhouseCultivarCounts
                    .FirstOrDefaultAsync(o => o.GreenhouseId == request.GreenhouseId && o.CultivarId == request.CultivarId);
                if (original == null)
                {
                    return NotFound("The GreenhouseCultivarCount object does not exist.");
                }
                GreenhouseCultivarCount? mapped = mapper.GreenhouseCultivarMapper(request);
                if (mapped == null)
                {
                    return BadRequest("The request could not be mapped to a GreenhouseCultivarCount object.");
                }
                // check if mapped's greenhouseId + cultivarId combo doesn't exist already
                GreenhouseCultivarCount? existing = await _context.GreenhouseCultivarCounts
                    .FirstOrDefaultAsync(o => o.GreenhouseId == mapped.GreenhouseId && o.CultivarId == mapped.CultivarId && o.GreenhouseCultivarCountId != original.GreenhouseCultivarCountId);
                if (existing != null)
                {
                    return Conflict("The GreenhouseCultivarCount object already exists.");
                }
                original.GreenhouseId = mapped.GreenhouseId;
                original.CultivarId = mapped.CultivarId;
                original.Count = mapped.Count;
                original.CultivarName = mapped.CultivarName;
                original.GreenhouseNumber = mapped.GreenhouseNumber;
                original.Cultivar = mapped.Cultivar;
                original.Greenhouse = mapped.Greenhouse;

                _context.Entry(original).State = EntityState.Modified;
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // DELETE: api/Count/GreenhouseCultivarCounts/5
        [HttpDelete("GreenhouseCultivarCounts/{id}")]
        public async Task<ActionResult<GreenhouseCultivarCount>> DeleteGreenhouseCultivarCounts(int id)
        {
            if (_context.GreenhouseCultivarCounts == null)
            {
                return NotFound("The GreenhouseCultivarCounts entity does not exist.");
            }
            try
            {
                GreenhouseCultivarCount? original = await _context.GreenhouseCultivarCounts.FindAsync(id);
                if (original == null)
                {
                    return NotFound("The GreenhouseCultivarCount object does not exist.");
                }
                _context.GreenhouseCultivarCounts.Remove(original);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }
    }
}
