﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeActivityController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public EmployeeActivityController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/EmployeeActivities/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<EmployeeActivity>>> GetAllEmployeeActivities()
        {
            if (_context.EmployeeActivities == null)
            {
                return NotFound();
            }
            return await _context.EmployeeActivities.Include(o => o.GreenhouseActivity).
                                                 Include(o => o.GreenhouseActivity.Greenhouse).
                                                 Include(o => o.GreenhouseActivity.ActivityEntry).
                                                 Include(o => o.Emp).
                                                 OrderBy(o => o.EmployeeActivityId).ToListAsync()
                ;

            
        }

        // GET: api/EmployeeActivity/
        [HttpGet()]
        [Route("EmployeeActivitiesById/{ghaId}")]
        public async Task<ActionResult<IEnumerable<EmployeeActivity>>> GetEmployeeActivitiesbyGhaId(int ghaId)
        {
            if (_context.EmployeeActivities == null)
            {
                return NotFound();
            }
            // return tables where status = true
            return await _context.EmployeeActivities.Where(o => o.Status == true && o.GreenhouseActivityId == ghaId).ToListAsync();
        }

        // GET: api/EmployeeActivity
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeActivity>>> GetEmployeeActivities()
        {
            if (_context.EmployeeActivities == null)
            {
                return NotFound();
            }
            return await _context.EmployeeActivities.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/EmployeeActivity/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EmployeeActivity>> GetEmployeeActivity(int id)
        {
            if (_context.EmployeeActivities == null)
            {
                return NotFound();
            }
            var employeeActivity = await _context.EmployeeActivities.FindAsync(id);

            if (employeeActivity == null || employeeActivity.Status == false)
            {
                return NotFound();
            }

            return employeeActivity;
        }

   

        // PUT: api/EmployeeActivity/5
        [HttpPut()]
        [Route("UpdateEmployeeActivityById/{id}")]
        public async Task<IActionResult> PutEmployeeActivity(int id, EmployeeActivityRequest employeeActivity)
        {
            if (employeeActivity == null)
            {
                return BadRequest();
            }
            EmployeeActivity? result = await _context.EmployeeActivities.FirstOrDefaultAsync(x => x.EmployeeActivityId == id);
            if (result == null)
            {
                return NotFound();
            }
            EmployeeActivity? newResult = mapper.EmployeeActivityMapper(employeeActivity);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.EmpId = newResult.EmpId;
                result.GreenhouseActivityId = newResult.GreenhouseActivityId;
                result.StartDate = newResult.StartDate;
                result.EndDate = newResult.EndDate;
                result.Status = newResult.Status;

                _context.SaveChanges();

                return NoContent();
            }
            catch
            {
                return Problem();
            }
        }


        // POST: api/EmployeeActivity
        [HttpPost]
        public async Task<ActionResult<EmployeeActivity>> PostEmployeeActivity(EmployeeActivityRequest employeeActivity)
        {
            if (_context.EmployeeActivities == null)
            {
                return Problem("Entity set 'AppDbContext.EmployeeActivities'  is null.");
            }
            try
            {
                EmployeeActivity? newResult = mapper.EmployeeActivityMapper(employeeActivity);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.EmployeeActivities.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.InnerException.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        //DELETE: api/EmployeeActivity/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployeeActivity(int id)
        {
            if (_context.EmployeeActivities == null)
            {
                return NotFound();
            }
            var employeeActivity = await _context.EmployeeActivities.FindAsync(id);
            if (employeeActivity == null)
            {
                return NotFound();
            }

            _context.EmployeeActivities.Remove(employeeActivity);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EmployeeActivityExists(int id)
        {
            return (_context.EmployeeActivities?.Any(e => e.EmployeeActivityId == id)).GetValueOrDefault();
        }
    }
}
