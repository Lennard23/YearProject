﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class LabResultsDefectController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public LabResultsDefectController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // POST: api/LabResultsDefect
        [HttpPost]
        public async Task<ActionResult<LabResultDefect>> PostLabResultsDefect(LabResultDefectRequest labResultDefect)
        {
            if (_context.LabResultDefects == null)
            {
                return Problem("Entity set 'AppDbContext.LabResultDefects'  is null.");
            }
            try
            {
                LabResultDefect? newResult = mapper.LabResultDefectMapper(labResultDefect);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.LabResultDefects.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.InnerException.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/LabResultsDefect
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LabResultDefect>>> GetLabResultsDefects()
        {
            if (_context.LabResultDefects == null)
            {
                return NotFound("The Lab Result Defects entity does not exist.");
            }
            try
            {
                // select only the LabResultDefects with Status = true
                List<LabResultDefect>? result = await _context.LabResultDefects
                    .Where(a => a.Status == true)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/LabResultsDefects/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<LabResultDefect>>> GetAllLabResultsDefects()
        {
            if (_context.LabResultDefects == null)
            {
                return NotFound("The Lab Result Defects entity does not exist.");
            }
            try
            {
                List<LabResultDefect>? result = await _context.LabResultDefects.ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/LabResultsDefect/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LabResultDefect>> GetLabResultsDefect(int id)
        {
            if (_context.LabResultDefects == null)
            {
                return NotFound("The Lab Result Defects entity does not exist.");
            }
            try
            {
                LabResultDefect? labResult = await _context.LabResultDefects.FindAsync(id);
                if (labResult == null || labResult.Status == false)
                {
                    return NotFound("No Lab Result Defect found for given id");
                }
                return labResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT: api/LabResultsDefect/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLabResultsDefect(int id, LabResultDefectRequest labResult)
        {
            if (labResult == null)
            {
                return BadRequest();
            }
            LabResultDefect? result = await _context.LabResultDefects.FirstOrDefaultAsync(x => x.LabResultDefectId == id);
            if (result == null)
            {
                return NotFound();
            }
            LabResultDefect? newResult = mapper.LabResultDefectMapper(labResult);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.LabResultsId = newResult.LabResultsId;
                result.DefectId = newResult.DefectId;
                result.Status = newResult.Status;

                _context.Entry(result).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // DELETE: api/LabResultsDefect/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLabResultsDefect(int id)
        {
            if (_context.LabResultDefects == null)
            {
                return NotFound();
            }
            LabResultDefect? result = _context.LabResultDefects.Find(id);
            if (result == null)
            {
                return NotFound();
            }
            _context.LabResultDefects.Remove(result!);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
