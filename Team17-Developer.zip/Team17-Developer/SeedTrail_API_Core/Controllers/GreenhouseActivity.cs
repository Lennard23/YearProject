﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseActivityController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public GreenhouseActivityController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/GreenhouseActivity
        [HttpGet]
        
        public async Task<ActionResult<IEnumerable<GreenhouseActivity>>> GetGreenhouseActivity()
        {
            if (_context.GreenhouseActivities == null)
            {
                return NotFound();
            }
            // return tables where status = true
            return await _context.GreenhouseActivities.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/GreenhouseActivity/
        [HttpGet]
        [Route("GreenhouseActivitiesById/{ghId}")]

        public async Task<ActionResult<IEnumerable<GreenhouseActivity>>> GetGreenhouseActivitiesbyGhId(int ghId)
        {
            if (_context.GreenhouseActivities == null)
            {
                return NotFound();
            }
            // return tables where status = true
            return await _context.GreenhouseActivities.
                Include(o => o.ActivityEntry).
                ThenInclude(o => o.ActivityType).
                Where(o => o.Status == true && o.GreenhouseId == ghId).ToListAsync();
        }

        // GET: api/GreenhouseActivity/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<GreenhouseActivity>>> GetAllActivityEntries()
        {
            if (_context.GreenhouseActivities == null)
            {
                return NotFound();
            }
            // return all tables
            return await _context.GreenhouseActivities.OrderByDescending(o => o.GreenhouseActivityId).ToListAsync();
        }


 
        // PUT: api/GreenhouseActivity/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGreenhouseActivity(int id, GreenhouseActivityRequest greenhouseActivity)
        {
            if (greenhouseActivity == null)
            {
                return BadRequest();
            }
            GreenhouseActivity? result = await _context.GreenhouseActivities.FirstOrDefaultAsync(x => x.GreenhouseActivityId == id);
            if (result == null)
            {
                return NotFound();
            }
            GreenhouseActivity? newResult = mapper.GreenhouseActivityMapper(greenhouseActivity);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.GreenhouseId = newResult.GreenhouseId;
                result.ActivityEntryId = newResult.ActivityEntryId;
                result.StartDate = newResult.StartDate;
                result.EndDate = newResult.EndDate;
                result.Status = newResult.Status;

                _context.SaveChanges();

                return NoContent();
            }
            catch
            {
                return Problem();
            }
        }

   
        // POST: api/GreenhouseActivity
        [HttpPost]
        public async Task<ActionResult<GreenhouseActivity>> PostGreenhouseActivity(GreenhouseActivityRequest greenhouseActivity)
        {
            if (_context.GreenhouseActivities == null)
            {
                return Problem("Entity set 'AppDbContext.GreenhouseActivities'  is null.");
            }
            try
            {
                GreenhouseActivity? newResult = mapper.GreenhouseActivityMapper(greenhouseActivity);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.GreenhouseActivities.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.InnerException.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }
        // DELETE: api/GreenhouseActivity/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGreenhouseActivity(int id)
        {
            GreenhouseActivity? entry = _context.GreenhouseActivities.FirstOrDefault(x => x.GreenhouseActivityId == id);

            if (entry == null)
                return NotFound();

            _context.GreenhouseActivities.Remove(entry);
            _context.SaveChanges();

            return NoContent();
        }

        // GET: api/GreenhouseActivity/5
        [HttpGet]
        [Route("GreenhouseActivityById/{id}")]
        public async Task<ActionResult<GreenhouseActivity>> GetGreenhouseActivityById(int id)
        {
            if (_context.GreenhouseActivities == null)
            {
                return NotFound();
            }
            var greenhouseActivity = await _context.GreenhouseActivities.FindAsync(id);

            if (greenhouseActivity == null || greenhouseActivity.Status == false)
            {
                return NotFound();
            }

            return greenhouseActivity;

        }

        [HttpGet("{GetActList}")]

        public object JoinActivity()
        {
            var query =
            (from GreenhouseActivity in _context.GreenhouseActivities
             join EmployeeActivity in _context.EmployeeActivities on GreenhouseActivity.GreenhouseActivityId equals EmployeeActivity.GreenhouseActivityId
             join Employee in _context.Employees on EmployeeActivity.EmpId equals Employee.EmpId
             join ActivityEntry in _context.ActivityEntries on GreenhouseActivity.ActivityEntryId equals ActivityEntry.ActivityEntryId
             join Greenhouse in _context.Greenhouses on GreenhouseActivity.GreenhouseId equals Greenhouse.GreenhouseId
             select new
             {
                 EmpName = Employee.Name,
                 ActTitle = ActivityEntry.Title,
                 Sd = EmployeeActivity.StartDate,
                 GhNum = Greenhouse.GreenhouseNumber,
                 //Ed = EmployeeActivity.EndDate
             }).ToList();

            return query;
        }


    }
}