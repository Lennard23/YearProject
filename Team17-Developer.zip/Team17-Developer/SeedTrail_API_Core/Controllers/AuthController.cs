﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using SeedTrail_API_Core.Helpers;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Models.Email;
using SeedTrail_API_Core.Request_Models;
using SeedTrail_API_Core.Response_Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Runtime.Caching;
using SeedTrail_API_Core.Services.Auth;

namespace SeedTrail_API_Core.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService authService;

        public AuthController(IAuthService authService)
        {
            this.authService = authService;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login(Login userRequest)
        {
            UserResponse? resp = await authService.Login(userRequest);

            if (resp == null)
                return BadRequest("Invalid Credentials");

            return Ok(resp);
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register(Register userRequest)
        {
            if (userRequest == null || userRequest.Email == null || userRequest.Password == null)
                return BadRequest();

            try
            {
                bool res = await authService.Register(userRequest);

                return res ? Ok() : Forbid("User already exist");
            }
            catch (Exception ex)
            {
                throw new Exception("Something went wrong: " + ex.Message);
            }
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] EmailResetModel model)
        {
            bool res = await authService.ResetPassword(model);

            return res ? Ok() : Forbid("Forbidden");
        }

        [HttpGet("generate-reset-email")]
        public async Task<IActionResult> Reset([FromQuery] string email)
        {
            return (await authService.Reset(email)) ? Ok() : Forbid();
        }
    }
}
