﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class TestResultStatusController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public TestResultStatusController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // POST: api/TestResultStatus
        [HttpPost]
        public async Task<ActionResult<TestResultStatus>> PostTestResultStatus(TestResultStatusRequest testResultStatus)
        {
            if (_context.TestResultStatuses == null)
            {
                return Problem("Entity set 'AppDbContext.TestResultStatuses'  is null.");
            }
            try
            {
                TestResultStatus newResult = mapper.TestResultStatusMapper(testResultStatus);
                _context.TestResultStatuses.Add(newResult);
                await _context.SaveChangesAsync();
                return Ok(newResult);
            }
            catch (DbUpdateException err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.InnerException!.Message);
            }
        }
        
        // GET: api/TestResultStatus
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TestResultStatus>>> GetTestResultStatuses()
        {
            if (_context.TestResultStatuses == null)
            {
                return NotFound();
            }
            try
            {
                List<TestResultStatus> result = await _context.TestResultStatuses
                    .Where(a => a.Status == true)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/TestResultStatus/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<TestResultStatus>>> GetAllTestResultStatuses()
        {
            if (_context.TestResultStatuses == null)
            {
                return NotFound();
            }
            try
            {
                List<TestResultStatus> result = await _context.TestResultStatuses
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/TestResultStatus/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TestResultStatus>> GetTestResultStatus(int id)
        {
            if (_context.TestResultStatuses == null)
            {
                return NotFound();
            }
            try
            {
                TestResultStatus? testResultStatus = await _context.TestResultStatuses
                    .FindAsync(id);
                if (testResultStatus == null || testResultStatus.Status == null)
                {
                    return NotFound();
                }
                return testResultStatus;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT: api/TestResultStatus/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTestResultStatus(int id, TestResultStatusRequest testResultStatus)
        {
            if (testResultStatus == null)
            {
                return BadRequest("No Lab Result found for given id");
            }
            TestResultStatus? result = await _context.TestResultStatuses.FirstOrDefaultAsync(x => x.TestResultStatusId == id);
            if (result == null)
            {
                return NotFound();
            }
            TestResultStatus? newResult = mapper.TestResultStatusMapper(testResultStatus);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.Trstatus = newResult.Trstatus;
                result.Description = newResult.Description;
                result.Status = newResult.Status;

                _context.Entry(result).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // DELETE: api/TestResultStatus/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTestResultStatus(int id)
        {
            if (_context.TestResultStatuses == null)
            {
                return NotFound();
            }
            var testResultStatus = await _context.TestResultStatuses.FindAsync(id);
            if (testResultStatus == null)
            {
                return NotFound();
            }
            try
            {
                _context.TestResultStatuses.Remove(testResultStatus);
                await _context.SaveChangesAsync();
                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }
    }
}
