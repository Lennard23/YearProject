﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;
using System.Net;
using System.Net.Http;
using static System.Net.WebRequestMethods;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class DefectController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public DefectController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        private const string wiki = "http://en.wikipedia.org/w/api.php?action=query&origin=*&prop=pageimages&format=json&piprop=original&titles=";

        // GET: api/Defect
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Defect>>> GetDefects()
        {
            if (_context.Defects == null)
            {
                return NotFound();
            }
            return await _context.Defects.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Defect/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Defect>>> GetAllDefects()
        {
            if (_context.Defects == null)
            {
                return NotFound();
            }
            return await _context.Defects.ToListAsync();
        }

        // GET: api/Defect/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Defect>> GetDefect(int id)
        {
            if (_context.Defects == null)
            {
                return NotFound();
            }
            var defect = await _context.Defects.FindAsync(id);

            if (defect == null || defect.Status == false)
            {
                return NotFound();
            }

            return defect;
        }

        // upload defect and image
        // PUT: api/Defect/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}"), DisableRequestSizeLimit]
        public async Task<IActionResult> PutDefect(int id, DefectRequest defect)
        {
            if (defect == null)
                return BadRequest();
            var base64 = "";
            if (defect.Image == "")
            {
                // create user-agent header
                var userAgent = new WebHeaderCollection();
                userAgent.Add("User-Agent: SeedTrail");
                // -------- GET WIKIPEDIA IMAGE -------------
                var nameString = defect.Defect1.Trim();
                // convert spaces to %20 for url
                var title = nameString.Replace(" ", "%20");
                // create api call
                var url = wiki + title;
                // get json from api using httpClient
                var client = new HttpClient();
                client.DefaultRequestHeaders.UserAgent.ParseAdd("PotatoSeedProduction/1.0 (potatoseedserver@gmail.com) bot");
                var response = await client.GetAsync(url);
                var json = await response.Content.ReadAsStringAsync();
                try
                {
                    // parse json and get image url
                    var jObject = JObject.Parse(json);
                    var pages = jObject["query"]!["pages"];
                    var page = pages!.First!.First;
                    if (page == null)
                        throw new Exception();
                    var original = page!["original"];
                    if (original == null)
                        throw new Exception();
                    var source = original!["source"];
                    if (source == null)
                        throw new Exception();
                    var imageUrl = source.ToString();
                    // append width and height (600px x 600px) to url
                    imageUrl += "?width=600&height=600";
                    // download image from url and convert to base64
                    var image = await client.GetByteArrayAsync(imageUrl);
                    // save the image to /Resources
                    //var path = Path.Combine(Directory.GetCurrentDirectory(), "Resources", nameString + ".jpg");
                    //System.IO.File.WriteAllBytes(path, image);
                    // convert image to base64
                    base64 = Convert.ToBase64String(image);
                }
                catch
                {
                    // use NoImage.png instead
                    var path = Path.Combine(Directory.GetCurrentDirectory(), "Resources", "NoImage.png");
                    var image = System.IO.File.ReadAllBytes(path);
                    base64 = Convert.ToBase64String(image);
                }

            }
            else
            {
                base64 = defect.Image;
            }
            

            Defect? defectDb = _context.Defects.FirstOrDefault(x => x.DefectId == id);

            if (defectDb == null)
                return NotFound();

            defectDb.Defect1 = defect.Defect1;
            defectDb.Image = base64;
            defectDb.Description = defect.Description;
            defectDb.Status = defect.Status;

            _context.Entry(defectDb).State = EntityState.Modified;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Defect
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Defect>> PostDefect(DefectRequest defect)
        {
            if (defect == null)
                return BadRequest();
            var postBase64 = "";
            // -------- GET WIKIPEDIA IMAGE -------------
            var nameString = defect.Defect1.Trim();
            // convert spaces to %20 for url
            var title = nameString.Replace(" ", "%20");
            // create api call
            var url = wiki + title;
            // get json from api using httpClient
            var client = new HttpClient();
            client.DefaultRequestHeaders.UserAgent.ParseAdd("PotatoSeedProduction/1.0 (potatoseedserver@gmail.com) bot");
            var response = await client.GetAsync(url);
            var json = await response.Content.ReadAsStringAsync();
            try
            {
                // parse json and get image url
                var jObject = JObject.Parse(json);
                var pages = jObject["query"]!["pages"];
                var page = pages!.First!.First;
                if (page == null)
                    throw new Exception();
                var original = page!["original"];
                if (original == null)
                    throw new Exception();
                var source = original!["source"];
                if (source == null)
                    throw new Exception();
                var imageUrl = source.ToString();
                // append width and height (600px x 600px) to url
                imageUrl += "?width=600&height=600";
                // download image from url and convert to base64
                var image = await client.GetByteArrayAsync(imageUrl);
                // save the image to /Resources
                //var path = Path.Combine(Directory.GetCurrentDirectory(), "Resources", nameString + ".jpg");
                //System.IO.File.WriteAllBytes(path, image);
                // convert image to base64
                postBase64 = Convert.ToBase64String(image);
            }
            catch
            {
                // use NoImage.png instead
                var path = Path.Combine(Directory.GetCurrentDirectory(), "Resources", "NoImage.png");
                var image = System.IO.File.ReadAllBytes(path);
                postBase64 = Convert.ToBase64String(image);
            }

            Defect newDefect = mapper.DefectMapper(defect);
            // add image to defect
            newDefect.Image = postBase64;

            _context.Defects.Add(newDefect);
            _context.SaveChanges();

            return Ok();
        }

        // DELETE: api/Defect/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDefect(int id)
        {
            Defect? defect = _context.Defects.FirstOrDefault(x => x.DefectId == id);

            if (defect == null)
                return NotFound();

            _context.Defects.Remove(defect);
            _context.SaveChanges();

            return NoContent();
        }

    }
}
