﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public GreenhouseController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/Greenhouse
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Greenhouse>>> GetGreenhouses()
        {
            if (_context.Greenhouses == null)
            {
                return NotFound();
            }
            return await _context.Greenhouses.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Greenhouse/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Greenhouse>>> GetAllGreenhouses()
        {
            if (_context.Greenhouses == null)
            {
                return NotFound();
            }
            return await _context.Greenhouses.ToListAsync();
        }

        // GET: api/Greenhouse/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Greenhouse>> GetGreenhouse(int id)
        {
            if (_context.Greenhouses == null)
            {
                return NotFound();
            }
            var greenhouse = await _context.Greenhouses.FindAsync(id);

            if (greenhouse == null || greenhouse.Status == false)
            {
                return NotFound();
            }

            return greenhouse;
        }

        // GET: api/Greenhouse/Status/5
        [HttpGet("Status/{id}")]
        public async Task<ActionResult<GreenhouseStatusDescription>> GetStatus(int id)
        {
            if (_context.Greenhouses == null)
            {
                return NotFound();
            }

            // find the greenhouse status description for the given greenhouse id
            var greenhouse = await _context.Greenhouses.FindAsync(id);
            var descriptionId = greenhouse!.GreenhouseStatusDescId;
            var description = await _context.GreenhouseStatusDescriptions.FindAsync(descriptionId);

            if (description == null || greenhouse.Status == false)
            {
                return NotFound();
            }

            return description;
        }

        // PUT: api/Greenhouse/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGreenhouse(int id, GreenhouseRequest greenhouse)
        {
            if (greenhouse == null)
                return BadRequest();

            Greenhouse? house = _context.Greenhouses.FirstOrDefault(x => x.GreenhouseId == id);

            if (house == null)
                return NotFound();

            Greenhouse? newHouse = mapper.GreenhouseMapper(greenhouse);

            if (newHouse == null)
                return BadRequest();

            house.GreenhouseStatusDescId = newHouse.GreenhouseStatusDescId;
            house.GreenhouseNumber = newHouse.GreenhouseNumber;
            house.Status = newHouse.Status;
            house.GreenhouseStatusDesc = newHouse.GreenhouseStatusDesc;

            _context.SaveChanges();

            return NoContent();
        }

        // GET: api/Greenhouse/IsNumberUnique/66
        [HttpGet("IsNumberUnique/{number}")]
        public async Task<ActionResult<bool>> IsNumberUnique(int number)
        {
            if (_context.Greenhouses == null)
            {
                return NotFound();
            }
            // look for any greenhouses with the same Greenhouse number as number
            var greenhouse = await _context.Greenhouses.FirstOrDefaultAsync(o => o.GreenhouseNumber == number);
            if (greenhouse == null)
            {
                return true;
            }
            return false;
        }

        // GET: api/Greenhouse/IsNumberUniqueUpdate/5/66
        [HttpGet("IsNumberUniqueUpdate/{id}/{number}")]
        public async Task<ActionResult<bool>> IsNumberUniqueUpdate(int id, int number)
        {
            if (_context.Greenhouses == null)
            {
                return NotFound();
            }
            // look for any greenhouses with the same Greenhouse number as number
            var originalGreenhouse = await _context.Greenhouses.FindAsync(id);
            if (originalGreenhouse == null)
            {
                return NotFound();
            }
            var greenhouse = await _context.Greenhouses.FirstOrDefaultAsync(o => o.GreenhouseNumber == number);
            if (greenhouse == null || originalGreenhouse.GreenhouseNumber == number)
            {
                return true;
            }
            return false;
        }

        // GET: api/Greenhouse/BasicInfo/5
        [Authorize(Policy = "Supervisor")]
        [HttpGet("BasicInfo/{id}")]
        public async Task<ActionResult<object>> GetBasicGhInfo(int id)
        {
            if (_context.Greenhouses == null)
            {
                return Problem();
            }
            var gh = await _context.Greenhouses
                .Include(o => o.GreenhouseTables)
                .Include(o => o.GreenhouseActivities)
                .Include(o => o.GreenhouseProductionInventories)
                .FirstOrDefaultAsync(o => o.GreenhouseId == id);

            if (gh == null || gh.Status == false)
            {
                return NotFound();
            }
            List<GreenhouseTable>? tables = gh.GreenhouseTables.ToList();
            // select the blocks whose tables are all included in the tables list
            List<Block> blocks = new List<Block>();
            for (int i = 0; i < tables.Count ; i++)
            {
                if (blocks.Contains(tables[i].Block) == false)
                {
                    blocks.Add(tables[i].Block);
                }  
            }
            List<GreenhouseActivity>? activities = gh.GreenhouseActivities.ToList();
            List<GreenhouseProductionInventory>? inventories = gh.GreenhouseProductionInventories.ToList();
            return Ok(new
            {
                tables,
                activities,
                inventories,
                blocks
            });
        }

        // POST: api/Greenhouse
        [HttpPost]
        public async Task<ActionResult<Greenhouse>> PostGreenhouse(GreenhouseRequest greenhouse)
        {
            if (greenhouse == null)
                return BadRequest();

            Greenhouse? newGh = mapper.GreenhouseMapper(greenhouse);

            _context.Greenhouses.Add(newGh!);
            _context.SaveChanges();

            return Ok();
        }

        // GET: api/Greenhouse/CheckRefIntegrity/5
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckRefIntegrity(int id)
        {
            if (_context.Greenhouses == null)
            {
                return false;
            }
            
            var greenhouse = await _context.Greenhouses.FindAsync(id);

            if (greenhouse == null || greenhouse.Status == false)
            {
                return false;
            }
            // Check:
            // GreenhouseActivities
            var greenhouseActivities = await _context.GreenhouseActivities.Where(x => x.GreenhouseId == id).ToListAsync();
            // GreenhouseProductionInventories
            var greenhouseProductionInventories = await _context.GreenhouseProductionInventories.Where(x => x.GreenhouseId == id).ToListAsync();
            // GreenhouseTables
            var greenhouseTables = await _context.GreenhouseTables.Where(x => x.GreenhouseId == id).ToListAsync();
            // return true if there's a clash
            if (greenhouseActivities.Count > 0 || greenhouseProductionInventories.Count > 0 || greenhouseTables.Count > 0)
            {
                return true;
            }
            return false;
        }

        // DELETE: api/Greenhouse/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGreenhouse(int id)
        {
            Greenhouse? house = _context.Greenhouses.FirstOrDefault(x => x.GreenhouseId == id);

            if (house == null)
                return NotFound();

            _context.Greenhouses.Remove(house);

            _context.SaveChanges();

            return NoContent();
        }
    }
}
