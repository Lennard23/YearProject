﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class BackupsController : ControllerBase
    {

        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;
        // Inject DB Context
        public BackupsController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        /************************************
         *                                  *
         *        'CREATE' ENDPOINT         *
         *                                  *
         ************************************/


        // POST: api/Backup

        [HttpPost("New")]
        public async Task<ActionResult<Backup>> CreateBackup(BackupRequest newbackup)
        {
            if (_context.Backups == null)
            {
                return Problem("Entity set 'AppDbContext.Backups'  is null.");
            }
            Backup? backup = mapper.BackupMapper(newbackup);
            if (backup == null)
            {
                return Problem("Backup object is null.");
            }

            // attempt backup
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();
            string connectionString = config.GetConnectionString("MasterConnection");
            var folderName = Path.Combine("Resources", "Backups");
            var backupLocation = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            //check if directory location exists, else create the location
            if (!Directory.Exists(backupLocation))
            {
                Directory.CreateDirectory(backupLocation);
            }

            // build SQL command for creating a new backup
            string backupName = "SeedTrail_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".bak";
            string backupCommand = "BACKUP DATABASE [SeedTrail] TO DISK = '" + backupLocation + "\\" + backupName + "'";

            // connect to DB to execute the command
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(backupCommand, connection))
                {
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                    catch (Exception ex)
                    {
                        return Problem(ex.Message);
                        connection.Close();
                    }
                }
            }

            // try update database
            try
            {
                backup.FileName = backupName;
                backup.Date = DateTime.Now;
                backup.Time = DateTime.Now;
                _context.Backups.Add(backup);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (BackupExists(backup.BackupId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            // if successful...
            return CreatedAtAction("GetBackup", new { id = backup.BackupId }, backup);

        }

        /***************************************
         *                                     *
         *         OTHER CRUD ENDPOINTS        *
         *                                     *
         ***************************************/


        // GET: api/Backups/LastBackup

        [HttpGet("LastBackup")]
        public async Task<ActionResult<Backup>> GetLastBackup()
        {
            // get and order the backups so that the last backup is first
            var orderedBackup = await _context.Backups.FindAsync
            (
                _context.Backups.Where(a => a.Status == true).OrderByDescending(b => b.BackupId).FirstOrDefault()?.BackupId
            );
            // if no backups exist, return NotFound()
            if (orderedBackup == null)
            {
                return NotFound();
            }
            //return Last Backup
            return orderedBackup;
        }

        // GET: api/Backups

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Backup>>> GetBackups()
        {
            if (_context.Backups == null)
            {
                return NotFound();
            }
            return await _context.Backups.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/Backups/5

        [HttpGet("{id}")]
        public async Task<ActionResult<Backup>> GetBackup(int id)
        {
            if (_context.Backups == null)
            {
                return NotFound();
            }
            var backup = await _context.Backups.FindAsync(id);

            if (backup == null || backup.Status == false)
            {
                return NotFound();
            }

            return backup;
        }

        // DELETE: api/Backup/5     (does not delete backup file)

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBackup(int id)
        {
            if (_context.Backups == null)
            {
                return NotFound();
            }
            var backup = await _context.Backups.FindAsync(id);
            if (backup == null)
            {
                return NotFound();
            }

            _context.Backups.Remove(backup);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // EXISTS function

        private bool BackupExists(int id)
        {
            return (_context.Backups?.Any(e => e.BackupId == id)).GetValueOrDefault();
        }
    }
}
