﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class AccessLevelController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AccessLevelController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/AccessLevel
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AccessLevel>>> GetAccessLevels()
        {
            if (_context.AccessLevels == null)
            {
                return NotFound();
            }
            // only return tables with status = true
            return await _context.AccessLevels.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/AccessLevel/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<AccessLevel>>> GetAllAccessLevels()
        {
            if (_context.AccessLevels == null)
            {
                return NotFound();
            }
            // return all tables
            return await _context.AccessLevels.OrderByDescending(o => o.AccessLevelId).ToListAsync();
        }

        // GET: api/AccessLevel/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AccessLevel>> GetAccessLevel(int id)
        {
            if (_context.AccessLevels == null)
            {
                return NotFound();
            }
            var accessLevel = await _context.AccessLevels.FindAsync(id);

            if (accessLevel == null || accessLevel.Status == false)
            {
                return NotFound();
            }

            return accessLevel;
        }

        // PUT: api/AccessLevel/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAccessLevel(int id, AccessLevel accessLevel)
        {
            if (id != accessLevel.AccessLevelId)
            {
                return BadRequest();
            }

            _context.Entry(accessLevel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AccessLevelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/AccessLevel
        [HttpPost]
        public async Task<ActionResult<AccessLevel>> PostAccessLevel(AccessLevel accessLevel)
        {
            if (_context.AccessLevels == null)
            {
                return Problem("Entity set 'AppDbContext.AccessLevels'  is null.");
            }
            _context.AccessLevels.Add(accessLevel);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (AccessLevelExists(accessLevel.AccessLevelId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetAccessLevel", new { id = accessLevel.AccessLevelId }, accessLevel);
        }

        // DELETE: api/AccessLevel/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAccessLevel(int id)
        {
            if (_context.AccessLevels == null)
            {
                return NotFound();
            }
            var accessLevel = await _context.AccessLevels.FindAsync(id);
            if (accessLevel == null)
            {
                return NotFound();
            }

            _context.AccessLevels.Remove(accessLevel);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AccessLevelExists(int id)
        {
            return (_context.AccessLevels?.Any(e => e.AccessLevelId == id)).GetValueOrDefault();
        }
    }
}
