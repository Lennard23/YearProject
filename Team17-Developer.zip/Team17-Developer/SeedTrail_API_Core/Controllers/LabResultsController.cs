﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class LabResultsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public LabResultsController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // POST: api/LabResults/Upload
        [HttpPost("Upload"), DisableRequestSizeLimit]
        public async Task<IActionResult> UploadLabResult()
        {
            try
            {
                var formCollection = await Request.ReadFormAsync();
                var file = formCollection.Files.First(); 
                var folderName = Path.Combine("Resources", "Files", "pdf");
                // note, you can just keep adding sub folders if you want, just add more commas and folder names
                // BUT, the first one must be "Resources" ( the folder set in Program.cs )

                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

                if (file.Length > 0)
                {
                    // check if file already exists
                    if (System.IO.File.Exists(Path.Combine(pathToSave, file.FileName)))
                    {
                        return BadRequest("File already exists");
                    }
                    else
                    {
                        var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName!.Trim('"');
                        var fullPath = Path.Combine(pathToSave, fileName);
                        var dbPath = Path.Combine(folderName, fileName);
                        using (var stream = new FileStream(fullPath, FileMode.Create))
                        {
                            file.CopyTo(stream);
                        }
                        return Ok(new { dbPath });
                    }
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // POST: api/LabResults
        [HttpPost]
        public async Task<ActionResult<LabResult>> PostLabResult(LabResultRequest labResult)
        {
            if (_context.LabResults == null)
            {
                return Problem("Entity set 'AppDbContext.LabResults'  is null.");
            }
            try
            {
                LabResult? newResult = mapper.LabResultMapper(labResult);
                // parse date
                if (newResult == null)
                {
                    return Problem("could not map result");
                }
                try
                {
                    _context.LabResults.Add(newResult);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.InnerException.Message);
                }
                return newResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/LabResults
        [HttpGet]
        public async Task<ActionResult<IEnumerable<LabResult>>> GetLabResults()
        {
            if (_context.LabResults == null)
            {
                return NotFound("The Lab Results entity does not exist.");
            }
            try
            {
                // select only the LabResults with Status = true
                List<LabResult>? result = await _context.LabResults
                    .Where(a => a.Status == true)
                    .ToListAsync();
                return result;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/LabResults/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<LabResult>>> GetAllLabResults()
        {
            if (_context.LabResults == null)
            {
                return NotFound("The Lab Results entity does not exist.");
            }
            try
            {
                List<LabResult>? result = await _context.LabResults.ToListAsync();
                return result;
            } 
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // GET: api/LabResults/5
        [HttpGet("{id}")]
        public async Task<ActionResult<LabResult>> GetLabResult(int id)
        {
            if (_context.LabResults == null)
            {
                return NotFound("The Lab Results entity does not exist.");
            }
            try
            {
                LabResult? labResult = await _context.LabResults.FindAsync(id);
                if (labResult == null || labResult.Status == false)
                {
                    return NotFound("No Lab Result found for given id");
                }
                return labResult;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // PUT: api/LabResults/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutLabResult(int id, LabResultRequest labResult)
        {
            if (labResult == null)
            {
                return BadRequest("No Lab Result found for given id");
            }
            LabResult? result = await _context.LabResults.FirstOrDefaultAsync(x => x.LabResultsId == id);
            if (result == null)
            {
                return NotFound();
            }
            LabResult? newResult = mapper.LabResultMapper(labResult);
            if (newResult == null)
            {
                return BadRequest();
            }
            try
            {
                result.BatchId = newResult.BatchId;
                result.TestResultStatusId = newResult.TestResultStatusId;
                result.Date = newResult.Date ?? result.Date;
                result.FilePath = newResult.FilePath;
                result.Description = newResult.Description;
                result.Comment = newResult.Comment;
                result.Status = newResult.Status;

                _context.Entry(result).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            } 
        }

        // DELETE: api/LabResults/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteLabResult(int id)
        {
            if (_context.LabResults == null)
            {
                return NotFound();
            }
            LabResult? result = _context.LabResults.Find(id);
            if (result == null)
            {
                return NotFound();
            }
            string filepath = result.FilePath;
            var fileToDelete = Path.Combine(Directory.GetCurrentDirectory(), filepath);
            // delete fileToDelete at file path e.g. delete "Resources/Files/pdf/batch-report.pdf"
            try
            {
                _context.LabResults.Remove(result!);
                System.IO.File.Delete(fileToDelete);
                await _context.SaveChangesAsync();
            }
            catch (Exception err)
            {
                return Problem(err.Message);
            }

            return NoContent();
        }
    }
}
