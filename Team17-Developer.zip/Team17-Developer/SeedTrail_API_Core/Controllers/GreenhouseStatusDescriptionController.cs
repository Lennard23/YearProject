﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Build.Evaluation;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class GreenhouseStatusDescriptionController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public GreenhouseStatusDescriptionController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/GreenhouseStatusDescription
        [HttpGet]
        public async Task<ActionResult<IEnumerable<GreenhouseStatusDescription>>> GetGreenhouseStatusDescriptions()
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return NotFound();
            }
            return await _context.GreenhouseStatusDescriptions.Where(o => o.Status == true).ToListAsync();
        }

        // GET: api/GreenhouseStatusDescription/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<GreenhouseStatusDescription>>> GetAllGreenhouseStatusDescriptions()
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return NotFound();
            }
            return await _context.GreenhouseStatusDescriptions.ToListAsync();
        }

        // GET: api/GreenhouseStatusDescription/5
        [HttpGet("{id}")]
        public async Task<ActionResult<GreenhouseStatusDescription>> GetGreenhouseStatusDescription(int id)
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return NotFound();
            }
            var greenhouseStatusDescription = await _context.GreenhouseStatusDescriptions.FindAsync(id);

            if (greenhouseStatusDescription == null || greenhouseStatusDescription.Status == false)
            {
                return NotFound();
            }

            return greenhouseStatusDescription;
        }

        // GET: api/GreenhouseStatusDescription/CheckRefIntegrity/5
        [HttpGet("CheckRefIntegrity/{id}")]
        public async Task<ActionResult<bool>> CheckGreenhouseStatusDescriptionRefIntegrity(int id)
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return NotFound();
            }
            var ghsd = await _context.GreenhouseStatusDescriptions
                .Include(o => o.Greenhouses)
                .FirstOrDefaultAsync(o => o.GreenhouseStatusDescId == id);

            if (ghsd == null || ghsd.Status == false)
            {
                return NotFound();
            }

            if (ghsd.Greenhouses.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // GET: api/GreenhouseStatusDescription/CheckCount/5
        [HttpGet("CheckCount/{id}")]
        public async Task<ActionResult<Int32>> CheckGreenhouseStatusDescriptionCount(int id)
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return NotFound();
            }
            GreenhouseStatusDescription? greenhouseStatusDescription = await _context.GreenhouseStatusDescriptions
                .Include(a => a.Greenhouses).FirstOrDefaultAsync(a => a.GreenhouseStatusDescId == id);

            if (greenhouseStatusDescription == null || greenhouseStatusDescription.Status == false)
            {
                return NotFound();
            }

            if (greenhouseStatusDescription.Greenhouses.Count > 0)
            {
                return Ok(greenhouseStatusDescription.Greenhouses.Count);
            }
            else
            {
                return 0;
            }
        }

        // PUT: api/GreenhouseStatusDescription/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutGreenhouseStatusDescription(int id, GreenhouseStatusDescriptionRequest update)
        {
            if (update == null)
            {
                return BadRequest();
            }
            GreenhouseStatusDescription? current = await _context.GreenhouseStatusDescriptions.FirstOrDefaultAsync(x => x.GreenhouseStatusDescId == id);
            if (current == null)
            {
                return NotFound();
            }
            GreenhouseStatusDescription? newUpdate = mapper.GreenhouseStatusDescriptionMapper(update);
            if (newUpdate == null)
            {
                return BadRequest("Could not map request object");
            }
            try
            {
                current.GreenhouseStatusId = newUpdate.GreenhouseStatusId;
                current.Description = newUpdate.Description;
                current.Status = newUpdate.Status;
                current.GreenhouseStatus = newUpdate.GreenhouseStatus;
                
                _context.Entry(current).State = EntityState.Modified;
                _context.SaveChanges();

                return NoContent();
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // POST: api/GreenhouseStatusDescription
        [HttpPost]
        public async Task<ActionResult<GreenhouseStatusDescription>> PostGreenhouseStatusDescription(GreenhouseStatusDescriptionRequest request)
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return Problem("Entity set 'AppDbContext.GreenhouseStatusDescriptions' is null.");
            }
            try
            {
                GreenhouseStatusDescription? newStatus = mapper.GreenhouseStatusDescriptionMapper(request);
                if (newStatus == null)
                {
                    return Problem("Could not map request");
                }
                try
                {
                    _context.GreenhouseStatusDescriptions.Add(newStatus);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateException err)
                {
                    return Problem(err.InnerException.Message);
                }
                return newStatus;
            }
            catch (Exception err)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, err.Message);
            }
        }

        // DELETE: api/GreenhouseStatusDescription/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteGreenhouseStatusDescription(int id)
        {
            if (_context.GreenhouseStatusDescriptions == null)
            {
                return NotFound();
            }
            var greenhouseStatusDescription = await _context.GreenhouseStatusDescriptions.FindAsync(id);
            if (greenhouseStatusDescription == null)
            {
                return NotFound();
            }

            _context.GreenhouseStatusDescriptions.Remove(greenhouseStatusDescription);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
