﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class CommoditySizeController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CommoditySizeController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/CommoditySize
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CommoditySize>>> GetCommoditySizes()
        {
            if (_context.CommoditySizes == null)
            {
                return NotFound();
            }
            return await _context.CommoditySizes.ToListAsync();
        }

        // GET: api/CommoditySize/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CommoditySize>> GetCommoditySize(int id)
        {
            if (_context.CommoditySizes == null)
            {
                return NotFound();
            }
            var commoditySize = await _context.CommoditySizes.FindAsync(id);

            if (commoditySize == null || commoditySize.Status == false)
            {
                return NotFound();
            }

            return commoditySize;
        }

        // GET: api/CommoditySize/PerCultivar/5
        [HttpGet("PerCultivar/{id}")]
        public async Task<ActionResult<IEnumerable<CommoditySize>>> GetCommoditySizesPerCultivar(int id)
        {
            if (_context.CommoditySizes == null)
            {
                return NotFound();
            }
            // find matching cultivar
            var cultivar = await _context.Cultivars.FindAsync(id);
            if (cultivar == null || cultivar.Status == false)
            {
                return NotFound();
            }
            // find commodity sizes with the same commodity ID as the cultivar
            var commoditySizes = await _context.CommoditySizes.Where(c => c.CommodityId == cultivar.CommodityId).ToListAsync();
            if (commoditySizes == null || commoditySizes.Count == 0)
            {
                return NotFound();
            }
            return commoditySizes;
        }

        // GET: api/CommoditySize/PerCommodity/5
        [HttpGet("PerCommodity/{id}")]
        public async Task<ActionResult<IEnumerable<CommoditySize>>> GetCommoditySizePerCommodity(int id)
        {
            if (_context.CommoditySizes == null)
            {
                return NotFound();
            }
            // find matching commodity
            var commoditySize = await _context.CommoditySizes.Where(x => x.CommodityId == id).ToListAsync();
            if (commoditySize == null || commoditySize.Count == 0)
            {
                return NotFound();
            }
            return commoditySize;
        }
    }
}
