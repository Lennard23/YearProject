﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SeedTrail_API_Core.Models.Email;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmailController : ControllerBase
    {
        private readonly IEmailService _emailService;
        private readonly EmailConfiguration _config;

        public EmailController(IEmailService emailService, EmailConfiguration config)
        {
            _emailService = emailService;
            _config = config;
        }

        // constants for the amount of list items the *EmailTemplate.html requires
        private const int COURIER_TEMPLATE_VALUE_COUNT = 7;
        private const int SUPPLIER_TEMPLATE_VALUE_COUNT = 5;
        private const int PASSWORDRESET_TEMPLATE_VALUE_COUNT = 3;

        // Send general Email endpoint
        // POST api/Email
        [HttpPost]
        public async Task<IActionResult> SendEmail(string to, string subject, List<string> input, string? from)
        {
            // send badrequest if data contains nulls
            if (to == null)
            {
                return BadRequest("Email address cannot be null.");
            }
            else if (input == null)
            {
                return BadRequest("Input cannot be null.");
            }
            else if (subject == null)
            {
                return BadRequest("Subject cannot be null.");
            }
            // send email
            else
            {
                if (from == null)
                {
                    // if from is null, use the default email address (potatoseedserver@gmail.com)
                    from = _config.From;
                }
                try
                {
                    // build message
                    var newMessage = new Message("supplierEmailTemplate.html", input);
                    // send email
                    await _emailService.SendAsync(to, subject, newMessage, from);
                    // if successful return Ok() status code with message
                    return Ok("To: " + to +
                    "\nFrom: " + from +
                    "\nSubject: " + subject +
                    "\nHTML message:\n" + newMessage.OutputData);
                }
                catch (Exception ex)
                {
                    // if failure send error message
                    return BadRequest(ex.Message);
                }
            }
        }

        // Send Courier Email endpoint
        // POST api/Email/Courier
        [HttpPost("Courier")]
        public async Task<IActionResult> SendCourierEmail(string to, string subject, List<string> inputData)
        {
            // send badrequest if data contains nulls or empty
            if (inputData == null || inputData.Count == 0)
            {
                return BadRequest("Message data cannot be empty or null.");
            }
            // inputData values must be equal to the amount of values in the Courier template
            else if (inputData.Count != COURIER_TEMPLATE_VALUE_COUNT)
            {
                return BadRequest("message.inputData requires " + COURIER_TEMPLATE_VALUE_COUNT.ToString() +
                                  " list items, not " + inputData.Count.ToString());
            }
            else
            {
                if (subject == null)
                {
                    // TODO: replace
                    subject = "Order Available for Collection";
                }
                if (to == null)
                {
                    // TODO: replace with real emails
                    to = "ggraydn@gmail.com"; ;
                }
                try
                {
                    var newMessage = new Message("courierEmailTemplate.html", inputData);
                    await _emailService.SendAsync(to, subject, newMessage);
                    return Ok("To: " + to +
                        "\nFrom: " + _config.From +
                        "\nSubject: " + subject +
                        "\nHTML message:\n" + newMessage.OutputData);
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        // Send Supplier Email endpoint
        // POST api/Email/Supplier
        [HttpPost("Supplier")]
        public async Task<IActionResult> SendSupplierEmail(string to, string subject, List<string> input)
        {
            // send badrequest if data contains nulls or empty
            if (input == null || input.Count == 0)
            {
                return BadRequest("Message data cannot be empty or null.");
            }
            // inputData values must be equal to the amount of values in the Supplier template
            else if (input.Count != SUPPLIER_TEMPLATE_VALUE_COUNT)
            {
                return BadRequest("message.inputData requires " + SUPPLIER_TEMPLATE_VALUE_COUNT.ToString() +
                                  " list item, not " + input.Count.ToString());
            }
            else
            {
                if (subject == null)
                {
                    // TODO: replace
                    subject = "Automated Place Order Email";
                }
                if (to == null)
                {
                    // TODO: replace with real emails
                    to = "ggraydn@gmail.com"; ;
                }
                try
                {
                    // generate new message
                    var newMessage = new Message("supplierEmailTemplate.html", input);
                    // send e-mail
                    await _emailService.SendAsync(to, subject, newMessage, _config.From);
                    return Ok("To: " + to +
                        "\nFrom: " + _config.From +
                        "\nSubject: " + subject +
                        "\nHTML message:\n" + newMessage.OutputData);
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }

        [HttpPost("ForgotPassword")]
        public async Task<IActionResult> SendForgotPasswordEmail(string to, List<string> requestDetails)
        {
            // send badrequest if data is not valid 
            if (to == null)
            {
                return BadRequest("Email address cannot be null.");
            }
            else if (requestDetails == null || requestDetails.Count != PASSWORDRESET_TEMPLATE_VALUE_COUNT)
            {
                return BadRequest("Request details list must have " + PASSWORDRESET_TEMPLATE_VALUE_COUNT.ToString() +
                                  " list items and cannot be null.");
            }
            else
            {
                // hardcoded subject
                var subject = "SeedTrail Password Reset";
                var message = new Message("forgotPasswordEmailTemplate.html", requestDetails);
                try
                {
                    // send
                    await _emailService.SendAsync(to, subject, message);
                    // don't return sensitive info
                    return Ok("To: " + to +
                    "\nFrom: " + _config.From +
                    "\nSubject: SeedTrail Password Reset" +
                    "\n -- Body -- ");
                }
                catch (Exception e)
                {
                    return BadRequest(e.Message);
                }
            }
        }
    }
}
