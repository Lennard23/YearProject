﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SeedTrail_API_Core.Mappers;
using SeedTrail_API_Core.Models;
using SeedTrail_API_Core.Request_Models;

namespace SeedTrail_API_Core.Controllers
{
    [Authorize(Policy = "Supervisor")]
    [Route("api/[controller]")]
    [ApiController]
    public class ColdroomController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly RequestToDbMapper mapper;

        public ColdroomController(AppDbContext context)
        {
            _context = context;
            mapper = new RequestToDbMapper(context);
        }

        // GET: api/Coldroom
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Coldroom>>> GetColdrooms()
        {
            if (_context.Coldrooms == null)
            {
                return NotFound();
            }
            return await _context.Coldrooms.Where(o => o.Status == true).OrderBy(o => o.ColdroomId).ToListAsync();
        }

        // GET: api/Coldroom/All
        [HttpGet("All")]
        public async Task<ActionResult<IEnumerable<Coldroom>>> GetAllColdrooms()
        {
            if (_context.Coldrooms == null)
            {
                return NotFound();
            }
            return await _context.Coldrooms.OrderBy(o => o.ColdroomId).ToListAsync();
        }

        // GET: api/Coldroom/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Coldroom>> GetColdroom(int id)
        {
            if (_context.Coldrooms == null)
            {
                return NotFound();
            }
            var coldroom = await _context.Coldrooms.FindAsync(id);

            if (coldroom == null || coldroom.Status == false)
            {
                return NotFound();
            }

            return coldroom;
        }

        // PUT: api/Coldroom/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutColdroom(int id, ColdroomRequest coldroom)
        {
            if (coldroom == null)
                return BadRequest();

            Coldroom? coldroomDb = _context.Coldrooms.FirstOrDefault(x => x.ColdroomId == id);

            if (coldroomDb == null)
                return NotFound();

            coldroomDb.Name = coldroom.Name;
            coldroomDb.Description = coldroom.Description;
            coldroomDb.Status = coldroom.Status;

            _context.SaveChanges();

            return NoContent();
        }

        // POST: api/Coldroom
        [HttpPost]
        public async Task<ActionResult<Coldroom>> PostColdroom(ColdroomRequest coldroom)
        {
            if (coldroom == null)
                return BadRequest();

            Coldroom entity = _context.Coldrooms.Add(mapper.ColdroomMapper(coldroom)).Entity;
            _context.SaveChanges();

            return Ok(entity);
        }

        //DELETE: api/Coldroom/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteColdroom(int id)
        {
            Coldroom? coldroomDb = _context.Coldrooms.FirstOrDefault(x => x.ColdroomId == id);

            if (coldroomDb == null)
                return NotFound();

            _context.Coldrooms.Remove(coldroomDb);
            _context.SaveChanges();

            return NoContent();
        }

    }
}
