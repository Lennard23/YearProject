﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Text;

namespace SeedTrail_API_Core.Helpers
{
    public static class Hashers
    {
        public static string HashPassword(string password)
        {
            byte[] salt = Encoding.ASCII.GetBytes("SALT");

            return Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password!,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 100000,
                numBytesRequested: 256 / 8));
        }
    }
}
