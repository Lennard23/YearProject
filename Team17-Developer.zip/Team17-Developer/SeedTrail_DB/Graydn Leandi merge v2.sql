USE [master]
GO

Drop Database SeedTrail
Go

/****** Object:  Database [SeedTrail]    Script Date: 2022/09/02 11:38:32 ******/
CREATE DATABASE [SeedTrail]
 
GO
USE [SeedTrail]
GO
/****** Object:  Table [dbo].[AccessArea]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AccessArea](
	[AccessArea_ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Title] [varchar](30) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AccessArea_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AccessLevel]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AccessLevel](
	[AccessLevel_ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Access_Level] [varchar](30) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AccessLevel_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AccessLevelArea]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AccessLevelArea](
	[AccessLevelArea_ID] [int] IDENTITY(1,1) NOT NULL,
	[AccessArea_ID] [int] NOT NULL,
	[AccessLevel_ID] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AccessLevelArea_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ActiveLogin]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ActiveLogin](
	[ActiveLogin_ID] [int] IDENTITY(1,1) NOT NULL,
	[EmpLogin_ID] [int] NOT NULL,
	[Start_Time] [datetime] NULL,
	[End_Time] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ActiveLogin_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ActivityEntry]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ActivityEntry](
	[ActivityEntry_ID] [int] IDENTITY(1,1) NOT NULL,
	[ActivityType_ID] [int] NOT NULL,
	[ActivityStatus_ID] [int] NOT NULL,
	[Duration] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Title] [varchar](30) NOT NULL,
	[Sequence_Order] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ActivityEntry_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ActivityStatus]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ActivityStatus](
	[ActivityStatus_ID] [int] IDENTITY(1,1) NOT NULL,
	[AStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ActivityStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ActivityType]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ActivityType](
	[ActivityType_ID] [int] IDENTITY(1,1) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Type] [varchar](30) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ActivityType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AspNetRoleClaims]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoleClaims](
	[Id] [int] IDENTITY(1,1)  NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetRoles]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetRoles](
	[Id] [nvarchar](450) NOT NULL,
	[Name] [nvarchar](256) NULL,
	[NormalizedName] [nvarchar](256) NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetRoles] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserClaims]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserClaims](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [nvarchar](450) NOT NULL,
	[ClaimType] [nvarchar](max) NULL,
	[ClaimValue] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserLogins]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserLogins](
	[LoginProvider] [nvarchar](450)  NOT NULL,
	[ProviderKey] [nvarchar](450) NOT NULL,
	[ProviderDisplayName] [nvarchar](max) NULL,
	[UserId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY CLUSTERED 
(
	[LoginProvider] ASC,
	[ProviderKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserRoles]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserRoles](
	[UserId] [nvarchar](450)  NOT NULL,
	[RoleId] [nvarchar](450) NOT NULL,
 CONSTRAINT [PK_AspNetUserRoles] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUsers]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUsers](
	[Id] [nvarchar](450)  NOT NULL,
	[FullName] [nvarchar](max) NOT NULL,
	[UserName] [nvarchar](256) NULL,
	[NormalizedUserName] [nvarchar](256) NULL,
	[Email] [nvarchar](256) NULL,
	[NormalizedEmail] [nvarchar](256) NULL,
	[EmailConfirmed] [bit] NOT NULL,
	[PasswordHash] [nvarchar](max) NULL,
	[SecurityStamp] [nvarchar](max) NULL,
	[ConcurrencyStamp] [nvarchar](max) NULL,
	[PhoneNumber] [nvarchar](max) NULL,
	[PhoneNumberConfirmed] [bit] NOT NULL,
	[TwoFactorEnabled] [bit] NOT NULL,
	[LockoutEnd] [datetimeoffset](7) NULL,
	[LockoutEnabled] [bit] NOT NULL,
	[AccessFailedCount] [int] NOT NULL,
 CONSTRAINT [PK_AspNetUsers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[AspNetUserTokens]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AspNetUserTokens](
	[UserId] [nvarchar](450) NOT NULL,
	[LoginProvider] [nvarchar](450) NOT NULL,
	[Name] [nvarchar](450) NOT NULL,
	[Value] [nvarchar](max) NULL,
 CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[LoginProvider] ASC,
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Backups]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Backups](
	[Backup_ID] [int] IDENTITY(1,1) NOT NULL,
	[Date] [datetime] NULL,
	[Description] [varchar](255) NOT NULL,
	[Time] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Backup_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Batch]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING OFF
GO
CREATE TABLE [dbo].[Batch](
	[Batch_ID] [int] IDENTITY(1,1) NOT NULL,
	[Coldroom_ID] [int] NULL DEFAULT (NULL),
	[ClientOrder_ID] [int] NOT NULL,
	[Cultivar_ID] [int] NOT NULL,
	[RegistrationNr] [varchar](255) NULL,
	[Plant_Date] [datetime] NULL DEFAULT (NULL),
	[Total_Planted] [int] NULL DEFAULT (NULL),
	[Harvest_Date] [datetime] NULL DEFAULT (NULL),
	[Total_Yield] [int] NULL DEFAULT (NULL),
	[Scrap] [int] NULL DEFAULT (NULL),
	[Sample] [int] NULL DEFAULT (NULL),
	[Coldroom_Date_In] [datetime] NULL DEFAULT (NULL),
	[Coldroom_Date_Out] [datetime] NULL DEFAULT (NULL),
	[Total_Bags] [int] NULL DEFAULT (NULL),
	[Avg_Yield] [decimal](10, 2) NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Batch_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[BatchSizeYields]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchSizeYields](
	[BatchSizeYield_ID] [int] IDENTITY(1,1) NOT NULL,
	[Batch_ID] [int] NOT NULL,
	[CommditySize_ID] [int] NOT NULL,
	[Description] [varchar](255) NULL DEFAULT (NULL),
	[Yield] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[BatchSizeYield_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Block]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Block](
	[Block_ID] [int] IDENTITY(1,1) NOT NULL,
	[Batch_ID] [int] NULL,
	[Table_Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Block_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Client]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Client](
	[Client_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Contract_Nr] [varchar](13) NOT NULL,
	[Email] [varchar](40) NOT NULL,
	[Address] [varchar](60) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Client_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ClientOrder]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ClientOrder](
	[ClientOrder_ID] [int] IDENTITY(1,1) NOT NULL,
	[OrderStatus_ID] [int] NOT NULL,
	[Client_ID] [int] NOT NULL,
	[ClientName] [varchar](30) NOT NULL,
	[Date_Placed] [datetime] NULL DEFAULT (NULL),
	[Date_Required] [datetime] NULL DEFAULT (NULL),
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ClientOrder_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Coldroom]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Coldroom](
	[Coldroom_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Coldroom_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Commodity]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Commodity](
	[Commodity_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Commodity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CommoditySizes]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CommoditySizes](
	[CommoditySize_ID] [int] IDENTITY(1,1) NOT NULL,
	[Commodity_ID] [int] NOT NULL,
	[Size] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[CommoditySize_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Cultivar]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Cultivar](
	[Cultivar_ID] [int] IDENTITY(1,1) NOT NULL,
	[Commodity_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Cultivar_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Defect]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Defect](
	[Defect_ID] [int] IDENTITY(1,1) NOT NULL,
	[Defect] [varchar](1) NOT NULL,
	[Description] [varchar](50) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Defect_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Employee](
	[Emp_ID] [int] IDENTITY(1,1) NOT NULL,
	[AccessLevelArea_ID] [int] NOT NULL,
	[EmpType_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Surname] [varchar](30) NOT NULL,
	[Contact_Nr] [varchar](13) NOT NULL,
	[National_ID] [varchar](30) NOT NULL,
	[Email] [varchar](40) NULL DEFAULT (NULL),
	[Start_Date] [datetime] NULL DEFAULT (NULL),
	[End_Date] [datetime] NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Emp_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EmployeeActivity]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeActivity](
	[EmployeeActivity_ID] [int] IDENTITY(1,1) NOT NULL,
	[GreenhouseActivity_ID] [int] NOT NULL,
	[Emp_ID] [int] NOT NULL,
	[Start_Date] [datetime] NULL DEFAULT (NULL),
	[End_Date] [datetime] NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[EmployeeActivity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[EmployeeLogin]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EmployeeLogin](
	[EmpLogin_ID] [int] IDENTITY(1,1) NOT NULL,
	[Emp_ID] [int] NOT NULL,
	[Username] [varchar](40) NOT NULL,
	[Password] [varchar](30) NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpLogin_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EmployeeType]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EmployeeType](
	[EmpType_ID] [int] IDENTITY(1,1) NOT NULL,
	[Type] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[EmpType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Greenhouse]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Greenhouse](
	[Greenhouse_ID] [int] IDENTITY(1,1) NOT NULL,
	[GreenhouseStatusDesc_ID] [int] NOT NULL,
	[Greenhouse_Number] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Greenhouse_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[GreenhouseActivity]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GreenhouseActivity](
	[GreenhouseActivity_ID] [int] IDENTITY(1,1) NOT NULL,
	[Greenhouse_ID] [int] NOT NULL,
	[ActivityEntry_ID] [int] NOT NULL,
	[Start_Date] [datetime] NULL,
	[End_Date] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[GreenhouseActivity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[GreenhouseProductionInventory]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GreenhouseProductionInventory](
	[GreenhouseProductionInventory_ID] [int] IDENTITY(1,1) NOT NULL,
	[Greenhouse_ID] [int] NOT NULL,
	[ProductionInv_ID] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[GreenhouseProductionInventory_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[GreenhouseStatus]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[GreenhouseStatus](
	[GreenhouseStatus_ID] [int] IDENTITY(1,1) NOT NULL,
	[GHStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[GreenhouseStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[GreenhouseStatusDescription]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[GreenhouseStatusDescription](
	[GreenhouseStatusDesc_ID] [int] IDENTITY(1,1) NOT NULL,
	[GreenhouseStatus_ID] [int] NOT NULL,
	[Description] [varchar](30) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[GreenhouseStatusDesc_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[GreenhouseTable]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GreenhouseTable](
	[Table_ID] [int] IDENTITY(1,1) NOT NULL,
	[Block_ID] [int] NOT NULL,
	[Greenhouse_ID] [int] NOT NULL,
	[Table_Total_Crates] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Table_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LabResultDefect]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LabResultDefect](
	[LabResultDefect_ID] [int] IDENTITY(1,1) NOT NULL,
	[LabResults_ID] [int] NOT NULL,
	[Defect_ID] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[LabResultDefect_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LabResults]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[LabResults](
	[LabResults_ID] [int] IDENTITY(1,1) NOT NULL,
	[Batch_ID] [int] NOT NULL,
	[TestResultStatus_ID] [int] NOT NULL,
	[Date] [datetime] NULL DEFAULT (NULL),
	[FilePath] [varchar](255) NOT NULL,
	[Description] [varchar](255) NULL DEFAULT (NULL),
	[Comment] [varchar](255) NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[LabResults_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Metric]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Metric](
	[Metric_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Metric_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[OrderStatus]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OrderStatus](
	[OrderStatus_ID] [int] IDENTITY(1,1) NOT NULL,
	[OStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[OrderStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductInventoryType]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductInventoryType](
	[ProductInventoryType_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductInventoryType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductionInventory]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductionInventory](
	[ProductionInv_ID] [int] IDENTITY(1,1) NOT NULL,
	[ProductionInvCost_ID] [int] NOT NULL,
	[ProductionInventoryWriteOff_ID] [int] NOT NULL,
	[ProductInventoryType_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Metric_ID] [int] NOT NULL,
	[Status] [bit] NULL,
	[Threshold] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInv_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductionInventoryCost]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductionInventoryCost](
	[ProductionInvCost_ID] [int] IDENTITY(1,1) NOT NULL,
	[Cost] [money] NULL,
	[Date] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInvCost_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ProductionInventoryOrder]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductionInventoryOrder](
	[ProductionInvOrder_ID] [int] IDENTITY(1,1) NOT NULL,
	[Supplier_ID] [int] NOT NULL,
	[ProdctionInvOrderStatus_ID] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInvOrder_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ProductionInventoryOrderDetails]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductionInventoryOrderDetails](
	[ProductionInvOrderDetail_ID] [int] IDENTITY(1,1) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
	[ProductionInvId] [int] NOT NULL,
	[ProductionInvOrder_ID] [int] NOT NULL,
	[ProductionInventories_ID] [int] NOT NULL DEFAULT ((0)),
PRIMARY KEY CLUSTERED 
(
	[ProductionInvOrderDetail_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ProductionInventoryOrderStatus]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductionInventoryOrderStatus](
	[ProductionInvOrderStatus_ID] [int] IDENTITY(1,1) NOT NULL,
	[PIStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInvOrderStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductionInventoryWriteOff]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductionInventoryWriteOff](
	[ProductionInventoryWriteOff_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInventoryWriteOff_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Restores]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Restores](
	[Restore_ID] [int] IDENTITY(1,1) NOT NULL,
	[ActiveLogin_ID] [int] NOT NULL,
	[Date] [datetime] NULL DEFAULT (NULL),
	[Description] [varchar](255) NOT NULL,
	[Time] [datetime] NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Restore_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Supplier]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Supplier](
	[Supplier_ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Contact_Nr] [varchar](100) NOT NULL,
	[Email] [varchar](40) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Supplier_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[TestResultStatus]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[TestResultStatus](
	[TestResultStatus_ID] [int] IDENTITY(1,1) NOT NULL,
	[TRStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[TestResultStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[TransactionLog]    Script Date: 2022/09/02 11:38:32 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TransactionLog](
	[TransactionLog_ID] [int] IDENTITY(1,1) NOT NULL,
	[Backup_ID] [int] NOT NULL,
	[Restore_ID] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[TransactionLog_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
INSERT [dbo].[AccessArea] ( [Description], [Title], [Status]) VALUES ( N'Reports', N'Reports', 1)
GO
INSERT [dbo].[AccessArea] ( [Description], [Title], [Status]) VALUES ( N'CRUD''s', N'CRUD''s', 1)
GO
INSERT [dbo].[AccessArea] ( [Description], [Title], [Status]) VALUES ( N'Schedule', N'Schedule', 1)
GO
INSERT [dbo].[AccessArea] ( [Description], [Title], [Status]) VALUES ( N'Capture Quantities', N'Quantities', 1)
GO
INSERT [dbo].[AccessLevel] ( [Description], [Access_Level], [Status]) VALUES ( N'Manager', N'Highest Access Level', 1)
GO
INSERT [dbo].[AccessLevel] ( [Description], [Access_Level], [Status]) VALUES ( N'Supervisor', N'Middle Access Level', 1)
GO
INSERT [dbo].[AccessLevel] ( [Description], [Access_Level], [Status]) VALUES ( N'Owner', N'Lowest Access Level', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 1, 1, N'Manager Reports', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 2, 1, N'Manager CRUD', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 3, 1, N'Manager Schedule', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 4, 1, N'Manager Quantities', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 3, 2, N'SuperVisor Schedule', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 4, 2, N'Supervisor Quantities', 1)
GO
INSERT [dbo].[AccessLevelArea] ( [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES ( 1, 3, N'Owner Reports', 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 3, N'Harvest', N'Harvest', 1, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 3, N'Clean and Maintenance', N'Clean and Maintenance', 2, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 1, N'Pack Crates', N'Pack Crates', 3, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 1, N'Fill up Planting Medium', N'Fill up planting medium', 4, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 1, N'Drench', N'Drench', 5, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 1, N'Plant', N'Plant', 6, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 98, N'Grow', N'Grow', 7, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 5, N'Switch off water', N'Switch off water', 8, 1)
GO
INSERT [dbo].[ActivityEntry] ( [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES ( 3, 1, 5, N'Pull halmes', N'Pull halmes', 9, 1)
GO
INSERT [dbo].[ActivityStatus] ( [AStatus], [Description], [Status]) VALUES ( N'Not Started', N'Activity haven''t started yet', 1)
GO
INSERT [dbo].[ActivityStatus] ( [AStatus], [Description], [Status]) VALUES ( N'In progress', N'Activity is in progress', 1)
GO
INSERT [dbo].[ActivityStatus] ( [AStatus], [Description], [Status]) VALUES ( N'Complete', N'Activity is Complete', 1)
GO
INSERT [dbo].[ActivityType] ( [Description], [Type], [Status]) VALUES ( N'Plant', N'Plant', 1)
GO
INSERT [dbo].[ActivityType] ( [Description], [Type], [Status]) VALUES ( N'Harvest', N'Harvest', 1)
GO
INSERT [dbo].[ActivityType] ( [Description], [Type], [Status]) VALUES ( N'Prepare', N'Prepare', 1)
GO
INSERT [dbo].[ActivityType] ( [Description], [Type], [Status]) VALUES ( N'Insecticide', N'Insecticide', 1)
GO
INSERT [dbo].[ActivityType] ( [Description], [Type], [Status]) VALUES ( N'Pesticide', N'Pesticide', 1)
GO
INSERT [dbo].[ActivityType] ( [Description], [Type], [Status]) VALUES ( N'Foliar', N'Foliar', 1)
GO
INSERT [dbo].[Batch] ( [Coldroom_ID], [ClientOrder_ID], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date], [Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status]) VALUES ( 1, 1, 20, NULL, CAST(N'2021-12-01 00:00:00.000' AS DateTime), 30000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1)
GO
INSERT [dbo].[Batch] ( [Coldroom_ID], [ClientOrder_ID], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date], [Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status]) VALUES ( 1, 2, 7, NULL, CAST(N'2014-07-29 00:00:00.000' AS DateTime), 26880, CAST(N'2014-11-17 00:00:00.000' AS DateTime), 118770, 0, 0, CAST(N'2014-11-18 00:00:00.000' AS DateTime), CAST(N'2015-05-27 00:00:00.000' AS DateTime), 789, CAST(4.42 AS Decimal(10, 2)), 1)
GO
INSERT [dbo].[Batch] ( [Coldroom_ID], [ClientOrder_ID], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date], [Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status]) VALUES ( NULL, 1, 3, N'uyhuiy', CAST(N'2022-08-02 00:00:00.000' AS DateTime), 30, CAST(N'2022-08-16 00:00:00.000' AS DateTime), 0, 0, 0, NULL, NULL, 0, CAST(0.00 AS Decimal(10, 2)), 1)
GO
INSERT [dbo].[BatchSizeYields] ( [Batch_ID], [CommditySize_ID], [Description], [Yield], [Status]) VALUES ( 2, 1, NULL, 11835, 1)
GO
INSERT [dbo].[BatchSizeYields] ( [Batch_ID], [CommditySize_ID], [Description], [Yield], [Status]) VALUES ( 2, 2, NULL, 27274, 1)
GO
INSERT [dbo].[BatchSizeYields] ( [Batch_ID], [CommditySize_ID], [Description], [Yield], [Status]) VALUES ( 2, 3, NULL, 4600, 1)
GO
INSERT [dbo].[BatchSizeYields] ( [Batch_ID], [CommditySize_ID], [Description], [Yield], [Status]) VALUES ( 2, 4, NULL, 47471, 1)
GO
INSERT [dbo].[BatchSizeYields] ( [Batch_ID], [CommditySize_ID], [Description], [Yield], [Status]) VALUES ( 2, 5, NULL, 27590, 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Du Toit Groente', N'0', N'0', N'0', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt IHF', N'o', N'o', N'o', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Simba', N'1', N'1', N'1', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'FPD', N'2', N'2', N'2', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt GV', N'3', N'3', N'3', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt JP', N'4', N'4', N'4', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt GC', N'5', N'5', N'5', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt SR', N'6', N'6', N'6', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'GWK', N'7', N'7', N'7', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'RSA Raad', N'8', N'8', N'8', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'McCain', N'9', N'9', N'9', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt VZVM', N'10', N'101', N'10', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt TK', N'11', N'11', N'11', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'AI3 Boerdery', N'12', N'12', N'12', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Seed Potato Co-op', N'13', N'13', N'13', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt CE ', N'14', N'14', N'14', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Kli�nt MOG ', N'15', N'15', N'15', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Ortus Bdy', N'16', N'16', N'16', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'Johan Holsthauzen', N'17', N'17', N'17', 1)
GO
INSERT [dbo].[Client] ( [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES ( N'PSP', N'20', N'20', N'20', 1)
GO
INSERT [dbo].[ClientOrder] ( [OrderStatus_ID], [Client_ID], [ClientName], [Date_Placed], [Date_Required], [Description], [Status]) VALUES ( 3, 1, N'Du Toit Groente', CAST(N'2021-12-01 00:00:00.000' AS DateTime), CAST(N'2022-01-24 00:00:00.000' AS DateTime), N'Du Toit Groente, Fassan, Fianna, F/L 2108, F/l 2006. ', 1)
GO
INSERT [dbo].[ClientOrder] ( [OrderStatus_ID], [Client_ID], [ClientName], [Date_Placed], [Date_Required], [Description], [Status]) VALUES ( 1, 20, N'PSP', CAST(N'2014-02-17 00:00:00.000' AS DateTime), CAST(N'2015-05-27 00:00:00.000' AS DateTime), N'PSP', 1)
GO
INSERT [dbo].[Coldroom] ( [Name], [Description], [Status]) VALUES ( N'Coldroom 1', N'Coldroom 1', 1)
GO
INSERT [dbo].[Commodity] ( [Name], [Description], [Status]) VALUES ( N'Potato Seeds', N'Potato Seeds', 1)
GO
INSERT [dbo].[Commodity] ( [Name], [Description], [Status]) VALUES ( N'Lettuce', N'Lettuce', 1)
GO
INSERT [dbo].[CommoditySizes] ( [Commodity_ID], [Size], [Description], [Status]) VALUES ( 1, N'<2gr', N'<2gr', 1)
GO
INSERT [dbo].[CommoditySizes] ( [Commodity_ID], [Size], [Description], [Status]) VALUES ( 1, N'2-5gr', N'2-5gr', 1)
GO
INSERT [dbo].[CommoditySizes] ( [Commodity_ID], [Size], [Description], [Status]) VALUES ( 1, N'5-10gr', N'5-10gr', 1)
GO
INSERT [dbo].[CommoditySizes] ( [Commodity_ID], [Size], [Description], [Status]) VALUES ( 1, N'10-30gr', N'10-30gr', 1)
GO
INSERT [dbo].[CommoditySizes] ( [Commodity_ID], [Size], [Description], [Status]) VALUES ( 1, N'>30gr', N'>30gr', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Amethyst', N'Amethyst', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Amigo', N'Amigo', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Apache', N'Apache', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Argos', N'Argos', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Almera', N'Almera', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Avalanche', N'Avalanche', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'BP1', N'BP1', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'BFP', N'BFP', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Calibra', N'Calibra', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Caruso', N'Caruso', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Cimega', N'Cimega', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Chellah', N'Chellah', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Colorado Rose', N'Colorado Rose', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Dakota', N'Dakota', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'DANEPSO', N'DANEPSO', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Daisy', N'Daisy', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Diamant', N'Diamant', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Diva ca99-1', N'Diva ca99-1', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'El Mundo', N'El Mundo', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Eos', N'Eos', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Eryn', N'Eryn', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Fasan', N'Fasan', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Fianna', N'Fianna', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FLx26', N'FLx26', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FL 2006', N'FL 2006', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FL 2221', N'FL 2221', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FL 2018', N'FL 2018', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FL 2377', N'FL 2377', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FL 2387', N'FL 2387', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'FL 2400', N'FL 2400', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Georgina', N'Georgina', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Harmony', N'Harmony', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'166 HVN bute', N'166 HVN bute', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Hertha', N'Hertha', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Hermes', N'Hermes', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Horizo', N'Horizo', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Innovator', N'Innovator', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Jasper', N'jasper', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Jelly', N'Jelly', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Leonata', N'Leonata', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Labadia', N'Labadia', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Lady Nal', N'Lady Nal', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Lanorma', N'lanorma', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Magnum', N'Magnum', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Markies', N'markies', 1)
GO
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Marvel(SM01)', N'Marvel(SM01)', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Mnandi', N'Mnandi', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Mondeo', N'Mondeo', 1)
Go
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Mondial', N'Mondial', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'MonloghtCrop', N'MonloghtCrop', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Paramount', N'Paramount', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'PDell', N'PDell', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Red Eye', N'Red Eye', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Royal', N'Royal', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Rumba', N'Rumba', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Santano', N'Santano', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Shepody', N'Shepody', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Triomphe', N'Triomphe', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'UTD', N'UTD', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Valor', N'Valor', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'VDP ', N'VDP', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Umatilla', N'Umatilla', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Zylem', N'Zylem', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'441', N'441', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'Arno-MC2', N'Arno-MC2', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'98F1641', N'98F1641', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Butter-Faustina', N'Butter-Faustina', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Butter-Arleti', N'Butter-Arleti', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'COS(harder)-Rafael', N'COS(harder)-Rafae', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'COS(harder)-Raulph', N'COS(harder)-Raulph', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Butterfly COS(harder)-Auvona', N'Butterfly COS(harder)-Auvona', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Butterfly COS(harder)-Tacedoma', N'Butterfly COS(harder)-Tacedoma', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Green Oak- Kireve', N'Green Oak- Kireve', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Green Frilly- Mutligreen 3', N'Green Frilly- Mutligreen 3', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Salanova Green Butter- Erasmus', N'Salanova Green Butter- Erasmus', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Red Frilly-Stefano', N'Red Frilly-Stefano', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Salanova Red Butter-Gaugin', N'Salanova Red Butter-Gaugin', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Raddichio - Giove', N'Raddichio - Giove', 1)
GO
INSERT [dbo].[Cultivar]  ([Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Red COS- 41-950', N'Red COS- 41-950', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Crunchita (harder)-Crunchita', N'Crunchita (harder)-Crunchita', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 2, N'Crunchita (harder)-Gourmandine', N'Crunchita (harder)-Gourmandine', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'bfth', N'knjhh', 1)
GO
INSERT [dbo].[Cultivar] ( [Commodity_ID], [Name], [Description], [Status]) VALUES ( 1, N'F/L 2108', N'F/L 2108', 1)
GO
INSERT [dbo].[Defect] ([Defect], [Description], [Status]) VALUES (N'Worms', N'bad', 1)
INSERT [dbo].[Defect] ([Defect], [Description], [Status]) VALUES (N'Early Blight', N'Affects foliage, tuber infections can also occur', 1)
INSERT [dbo].[Defect] ([Defect], [Description], [Status]) VALUES (N'Dry Rot', N'Dry and rotten', 1)
GO

INSERT [dbo].[Employee] ( [AccessLevelArea_ID], [EmpType_ID], [Name], [Surname], [Contact_Nr], [National_ID], [Email], [Start_Date], [End_Date], [Status]) VALUES ( 1, 1, N'Werner', N'Schutte', N'0646849232', N'xxxxxxxxxxxxxxxxxx', N'werner', NULL, NULL, 1)
GO

INSERT [dbo].[EmployeeActivity] ( [GreenhouseActivity_ID], [Emp_ID], [Start_Date], [End_Date], [Status]) VALUES ( 1, 1, CAST(N'2022-06-22 00:00:00.000' AS DateTime), NULL, 1)
GO
INSERT [dbo].[EmployeeType] ( [Type], [Description], [Status]) VALUES ( N'Greenhouse Manager', N'Manages the greenhouses and has the most authority over the system.', 1)
GO
INSERT [dbo].[EmployeeType] ( [Type], [Description], [Status]) VALUES ( N'Supervisors', N'Supervises the activities and task in the greenhosues.', 1)
GO
INSERT [dbo].[EmployeeType] ( [Type], [Description], [Status]) VALUES ( N'Owner', N'Owner of the company, but does not have authority in the functionality of the system ', 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 1, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 2, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 3, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 4, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 5, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 6, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 7, 1)
GO
INSERT [dbo].[Greenhouse] ( [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES ( 1, 8, 1)
GO
INSERT [dbo].[GreenhouseActivity] ( [Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status]) VALUES ( 1, 1, CAST(N'2022-06-22 00:00:00.000' AS DateTime), NULL, 1)
GO
INSERT [dbo].[GreenhouseStatus] ( [GHStatus], [Description], [Status]) VALUES ( N'Available', N'Greenhouse is in use.', 1)
GO
INSERT [dbo].[GreenhouseStatus] ( [GHStatus], [Description], [Status]) VALUES ( N'Inactive', N'Greenhouse is not in use.', 1)
GO
INSERT [dbo].[GreenhouseStatusDescription] ( [GreenhouseStatus_ID], [Description], [Status]) VALUES ( 1, N'Greenhouse is available', 1)
GO
INSERT [dbo].[GreenhouseStatusDescription] ( [GreenhouseStatus_ID], [Description], [Status]) VALUES ( 2, N'Greenhouse is in use', 1)
GO
INSERT [dbo].[LabResults] ([Batch_ID], [TestResultStatus_ID], [Date], [FilePath], [Description], [Comment], [Status]) VALUES (2, 1, NULL, N'Resources\Files\pdf\batch-report.pdf', N'example description', N'Example report', 1)
GO
INSERT [dbo].[LabResultDefect] ([LabResults_ID], [Defect_ID], [Status]) VALUES (2, 1, 1)
INSERT [dbo].[LabResultDefect] ([LabResults_ID], [Defect_ID], [Status]) VALUES (2, 1, 1)
INSERT [dbo].[LabResultDefect] ([LabResults_ID], [Defect_ID], [Status]) VALUES (2, 1, 1)
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'L', N'Liter')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'kg', N'Kilogram')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'bags', N'bags')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'g', N'Gram')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'mg', N'Miligram')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'seeds', N'individual seeds')
Go
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'tins', N'tins')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'rolls', N'rolls')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'Bundle', N'bundle')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'boxes', N'boxes')
GO
INSERT [dbo].[Metric] ( [Name], [Description]) VALUES ( N'box stickers', N'box stickers')
GO
INSERT [dbo].[OrderStatus] ( [OStatus], [Description], [Status]) VALUES ( N'Placed', N'Order is placed, but not in progress yet. ', 1)
GO
INSERT [dbo].[OrderStatus] ( [OStatus], [Description], [Status]) VALUES ( N'In Progress', N'Order is in progress.', 1)
GO
INSERT [dbo].[OrderStatus] ( [OStatus], [Description], [Status]) VALUES ( N'Completed', N'Order is completed.', 1)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Foliar & Liquid', N'Foliar & Liquid', 1)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Greenhouse Fertilizer', N'Greenhouse Fertilizer', 1)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Greenhouse Packaging', N'Greenhouse Packaging', 1)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Granular', N'Granular', 0)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Irrigation Water & Cleaning', N'Irrigatrion Water & Cleaning', 1)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Greenhouse Chemicals', N'Greenhouse Chemical', 1)
GO
INSERT [dbo].[ProductInventoryType] ( [Name], [Description], [Status]) VALUES ( N'Lettuce Seeds', N'Lettuce Seeds', 1)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'ORGANOCELL	
', N'ORGANOCELL	
', 400, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'RHIZOVATOR	
', N'NURHIZOVATOR	
LL', 35, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'X PLODE
', N'X PLODE
', 0, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'TWILIGHT
', N'TWILIGHT
', 20, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES (1, 1, 1, N'BRILLIANT
', N'BRILLIANT
', 60, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Bacstim
', N'NULBacstim
L', 10, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Codafol Maximus
', N'Codafol Maximus
', 30, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Codasting
', N'Codasting
', 2, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Codamin 150
', N'Codamin 150
', 30, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Biopro
', N'Biopro
', 30, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Atom-8 FM-1
', N'Atom-8 FM-1
', 20, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Atom-8 SM-10
', N'Atom-8 SM-10
', 40, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Goemar 
', N'Goemar 
', 20, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 1, N'Tank Cal
', N'Tank Cal
', 20, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 2, N'CALCIUM NITRATE
', N'CALCIUM NITRATE
', 50, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 2, N'MICREL FE 600
', N'MICREL FE 600
', 10, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 2, N'Basacote Plus
', N'Basacote Plus
', 25, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 3, N'PURPLE
', N'PURPLE
', 400, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 3, N'WHITE
', N'WHITE
', 600, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 3, N'GREEN
', N'GREEN
', 1200, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 3, N'YELLOW
', N'YELLOW
', 2000, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 5, N'Aquacure
', N'Aquacure', 20, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 5, N'Black Dain
', N'Black Dain
', 5, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 5, N'Bleach
', N'Bleach
', 7, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 6, N'PENNFLUID
', N'PENNFLUID
', 8, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 6, N'HIT
', N'HIT
', 5, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 6, N'TUTOR
', N'TUTOR
', 3, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 7, N'Faustina
', N'Faustina
', 6, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 7, N'Crunchita
', N'Crunchita
', 2, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventory] ( [ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID], [Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold]) VALUES ( 1, 1, 7, N'Stefano
', N'Stefano
', 1, 1, 1, 0)
GO
INSERT [dbo].[ProductionInventoryCost] ( [Cost], [Date], [Status]) VALUES ( 0.0000, CAST(N'2022-08-16 00:00:00.000' AS DateTime), 1)
GO
INSERT [dbo].[ProductionInventoryOrder] ( [Supplier_ID], [ProdctionInvOrderStatus_ID], [Quantity], [Status]) VALUES ( 1, 1, 0, 1)
GO
INSERT [dbo].[ProductionInventoryOrder] ( [Supplier_ID], [ProdctionInvOrderStatus_ID], [Quantity], [Status]) VALUES ( 2, 1, 0, 1)
GO
INSERT [dbo].[ProductionInventoryOrder] ( [Supplier_ID], [ProdctionInvOrderStatus_ID], [Quantity], [Status]) VALUES ( 3, 1, 0, 1)
GO
INSERT [dbo].[ProductionInventoryOrderDetails] ( [Quantity], [Status], [ProductionInvId], [ProductionInvOrder_ID], [ProductionInventories_ID]) VALUES ( 25, 1, 15, 1, 15)
GO
INSERT [dbo].[ProductionInventoryOrderDetails] ( [Quantity], [Status], [ProductionInvId], [ProductionInvOrder_ID], [ProductionInventories_ID]) VALUES ( 100, 1, 17, 2, 17)
GO
INSERT [dbo].[ProductionInventoryOrderDetails] ( [Quantity], [Status], [ProductionInvId], [ProductionInvOrder_ID], [ProductionInventories_ID]) VALUES ( 70, 1, 22, 3, 22)
GO
INSERT [dbo].[ProductionInventoryOrderStatus] ( [PIStatus], [Description], [Status]) VALUES ( N'Order Placed', N'Order is placed', 1)
GO
INSERT [dbo].[ProductionInventoryOrderStatus] ( [PIStatus], [Description], [Status]) VALUES ( N'Order Out', N'Order is placed and on it''s way to be delivered', 1)
GO
INSERT [dbo].[ProductionInventoryOrderStatus] ( [PIStatus], [Description], [Status]) VALUES ( N'Delivered', N'Order is delivered', 1)
GO
INSERT [dbo].[ProductionInventoryWriteOff] ( [Name], [Description], [Quantity], [Status]) VALUES ( N'I dunno', N'Really don''t know', 0, 1)
GO
INSERT [dbo].[Supplier] ( [Name], [Description], [Contact_Nr], [Email], [Status]) VALUES ( N'Omnia
', N'Kunsmis
', N'0732499200
', N'Jandre.bekker@omnia.co.za''
', 1)
GO
INSERT [dbo].[Supplier] ( [Name], [Description], [Contact_Nr], [Email], [Status]) VALUES ( N'Drytech Aerogels
', N'Kunsmis', N'0825862811
', N'willie@dry-tech.co.za
', 1)
GO
INSERT [dbo].[Supplier] ( [Name], [Description], [Contact_Nr], [Email], [Status]) VALUES ( N'ICT Loskop
', N'Kunsmis', N'0823760331
', N'clinton@loskopict.co.za
', 1)
GO
INSERT [dbo].[TestResultStatus] ( [TRStatus], [Description], [Status]) VALUES ( N'Positive', N'The lab results came back positive. ', 1)
GO
INSERT [dbo].[TestResultStatus] ( [TRStatus], [Description], [Status]) VALUES ( N'Negative', N'The lab results came back negative', 1)
GO
/****** Object:  Index [IX_AccessLevelArea_AccessArea_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_AccessLevelArea_AccessArea_ID] ON [dbo].[AccessLevelArea]
(
	[AccessArea_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_AccessLevelArea_AccessLevel_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_AccessLevelArea_AccessLevel_ID] ON [dbo].[AccessLevelArea]
(
	[AccessLevel_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ActiveLogin_EmpLogin_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ActiveLogin_EmpLogin_ID] ON [dbo].[ActiveLogin]
(
	[EmpLogin_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ActivityEntry_ActivityStatus_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ActivityEntry_ActivityStatus_ID] ON [dbo].[ActivityEntry]
(
	[ActivityStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ActivityEntry_ActivityType_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ActivityEntry_ActivityType_ID] ON [dbo].[ActivityEntry]
(
	[ActivityType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_AspNetRoleClaims_RoleId]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_AspNetRoleClaims_RoleId] ON [dbo].[AspNetRoleClaims]
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [RoleNameIndex]    Script Date: 2022/09/02 11:38:32 ******/
CREATE UNIQUE NONCLUSTERED INDEX [RoleNameIndex] ON [dbo].[AspNetRoles]
(
	[NormalizedName] ASC
)
WHERE ([NormalizedName] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_AspNetUserClaims_UserId]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_AspNetUserClaims_UserId] ON [dbo].[AspNetUserClaims]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_AspNetUserLogins_UserId]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_AspNetUserLogins_UserId] ON [dbo].[AspNetUserLogins]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [IX_AspNetUserRoles_RoleId]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_AspNetUserRoles_RoleId] ON [dbo].[AspNetUserRoles]
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [EmailIndex]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [EmailIndex] ON [dbo].[AspNetUsers]
(
	[NormalizedEmail] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UserNameIndex]    Script Date: 2022/09/02 11:38:32 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UserNameIndex] ON [dbo].[AspNetUsers]
(
	[NormalizedUserName] ASC
)
WHERE ([NormalizedUserName] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Batch_ClientOrder_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Batch_ClientOrder_ID] ON [dbo].[Batch]
(
	[ClientOrder_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Batch_Coldroom_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Batch_Coldroom_ID] ON [dbo].[Batch]
(
	[Coldroom_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Batch_Cultivar_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Batch_Cultivar_ID] ON [dbo].[Batch]
(
	[Cultivar_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_BatchSizeYields_Batch_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_BatchSizeYields_Batch_ID] ON [dbo].[BatchSizeYields]
(
	[Batch_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_BatchSizeYields_CommditySize_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_BatchSizeYields_CommditySize_ID] ON [dbo].[BatchSizeYields]
(
	[CommditySize_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Block_Batch_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Block_Batch_ID] ON [dbo].[Block]
(
	[Batch_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UQ__Client__A9D10534DAE37486]    Script Date: 2022/09/02 11:38:32 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQ__Client__A9D10534DAE37486] ON [dbo].[Client]
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ClientOrder_Client_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ClientOrder_Client_ID] ON [dbo].[ClientOrder]
(
	[Client_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ClientOrder_OrderStatus_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ClientOrder_OrderStatus_ID] ON [dbo].[ClientOrder]
(
	[OrderStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_CommoditySizes_Commodity_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_CommoditySizes_Commodity_ID] ON [dbo].[CommoditySizes]
(
	[Commodity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Cultivar_Commodity_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Cultivar_Commodity_ID] ON [dbo].[Cultivar]
(
	[Commodity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Employee_AccessLevelArea_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Employee_AccessLevelArea_ID] ON [dbo].[Employee]
(
	[AccessLevelArea_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Employee_EmpType_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Employee_EmpType_ID] ON [dbo].[Employee]
(
	[EmpType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UQ__Employee__A9D10534BDF6C2AD]    Script Date: 2022/09/02 11:38:32 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQ__Employee__A9D10534BDF6C2AD] ON [dbo].[Employee]
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_EmployeeActivity_Emp_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_EmployeeActivity_Emp_ID] ON [dbo].[EmployeeActivity]
(
	[Emp_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_EmployeeActivity_GreenhouseActivity_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_EmployeeActivity_GreenhouseActivity_ID] ON [dbo].[EmployeeActivity]
(
	[GreenhouseActivity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_EmployeeLogin_Emp_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_EmployeeLogin_Emp_ID] ON [dbo].[EmployeeLogin]
(
	[Emp_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Greenhouse_GreenhouseStatusDesc_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Greenhouse_GreenhouseStatusDesc_ID] ON [dbo].[Greenhouse]
(
	[GreenhouseStatusDesc_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseActivity_ActivityEntry_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseActivity_ActivityEntry_ID] ON [dbo].[GreenhouseActivity]
(
	[ActivityEntry_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseActivity_Greenhouse_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseActivity_Greenhouse_ID] ON [dbo].[GreenhouseActivity]
(
	[Greenhouse_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseProductionInventory_Greenhouse_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseProductionInventory_Greenhouse_ID] ON [dbo].[GreenhouseProductionInventory]
(
	[Greenhouse_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseProductionInventory_ProductionInv_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseProductionInventory_ProductionInv_ID] ON [dbo].[GreenhouseProductionInventory]
(
	[ProductionInv_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseStatusDescription_GreenhouseStatus_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseStatusDescription_GreenhouseStatus_ID] ON [dbo].[GreenhouseStatusDescription]
(
	[GreenhouseStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseTable_Block_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseTable_Block_ID] ON [dbo].[GreenhouseTable]
(
	[Block_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_GreenhouseTable_Greenhouse_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_GreenhouseTable_Greenhouse_ID] ON [dbo].[GreenhouseTable]
(
	[Greenhouse_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_LabResultDefect_Defect_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_LabResultDefect_Defect_ID] ON [dbo].[LabResultDefect]
(
	[Defect_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_LabResultDefect_LabResults_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_LabResultDefect_LabResults_ID] ON [dbo].[LabResultDefect]
(
	[LabResults_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_LabResults_Batch_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_LabResults_Batch_ID] ON [dbo].[LabResults]
(
	[Batch_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_LabResults_TestResultStatus_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_LabResults_TestResultStatus_ID] ON [dbo].[LabResults]
(
	[TestResultStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventory_Metric_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventory_Metric_ID] ON [dbo].[ProductionInventory]
(
	[Metric_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventory_ProductInventoryType_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventory_ProductInventoryType_ID] ON [dbo].[ProductionInventory]
(
	[ProductInventoryType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventory_ProductionInvCost_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventory_ProductionInvCost_ID] ON [dbo].[ProductionInventory]
(
	[ProductionInvCost_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventory_ProductionInventoryWriteOff_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventory_ProductionInventoryWriteOff_ID] ON [dbo].[ProductionInventory]
(
	[ProductionInventoryWriteOff_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventoryOrder_ProdctionInvOrderStatus_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventoryOrder_ProdctionInvOrderStatus_ID] ON [dbo].[ProductionInventoryOrder]
(
	[ProdctionInvOrderStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventoryOrder_Supplier_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventoryOrder_Supplier_ID] ON [dbo].[ProductionInventoryOrder]
(
	[Supplier_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventoryOrderDetails_ProductionInvId]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventoryOrderDetails_ProductionInvId] ON [dbo].[ProductionInventoryOrderDetails]
(
	[ProductionInvId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_ProductionInventoryOrderDetails_ProductionInvOrder_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_ProductionInventoryOrderDetails_ProductionInvOrder_ID] ON [dbo].[ProductionInventoryOrderDetails]
(
	[ProductionInvOrder_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_Restores_ActiveLogin_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_Restores_ActiveLogin_ID] ON [dbo].[Restores]
(
	[ActiveLogin_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UQ__Supplier__A9D1053419882BF8]    Script Date: 2022/09/02 11:38:32 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UQ__Supplier__A9D1053419882BF8] ON [dbo].[Supplier]
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_TransactionLog_Backup_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_TransactionLog_Backup_ID] ON [dbo].[TransactionLog]
(
	[Backup_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_TransactionLog_Restore_ID]    Script Date: 2022/09/02 11:38:32 ******/
CREATE NONCLUSTERED INDEX [IX_TransactionLog_Restore_ID] ON [dbo].[TransactionLog]
(
	[Restore_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AccessLevelArea]  WITH CHECK ADD  CONSTRAINT [FK_AccessLevelArea_AccessArea_AccessArea_ID] FOREIGN KEY([AccessArea_ID])
REFERENCES [dbo].[AccessArea] ([AccessArea_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AccessLevelArea] CHECK CONSTRAINT [FK_AccessLevelArea_AccessArea_AccessArea_ID]
GO
ALTER TABLE [dbo].[AccessLevelArea]  WITH CHECK ADD  CONSTRAINT [FK_AccessLevelArea_AccessLevel_AccessLevel_ID] FOREIGN KEY([AccessLevel_ID])
REFERENCES [dbo].[AccessLevel] ([AccessLevel_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AccessLevelArea] CHECK CONSTRAINT [FK_AccessLevelArea_AccessLevel_AccessLevel_ID]
GO
ALTER TABLE [dbo].[ActiveLogin]  WITH CHECK ADD  CONSTRAINT [FK_ActiveLogin_EmployeeLogin_EmpLogin_ID] FOREIGN KEY([EmpLogin_ID])
REFERENCES [dbo].[EmployeeLogin] ([EmpLogin_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ActiveLogin] CHECK CONSTRAINT [FK_ActiveLogin_EmployeeLogin_EmpLogin_ID]
GO
ALTER TABLE [dbo].[ActivityEntry]  WITH CHECK ADD  CONSTRAINT [FK_ActivityEntry_ActivityStatus_ActivityStatus_ID] FOREIGN KEY([ActivityStatus_ID])
REFERENCES [dbo].[ActivityStatus] ([ActivityStatus_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ActivityEntry] CHECK CONSTRAINT [FK_ActivityEntry_ActivityStatus_ActivityStatus_ID]
GO
ALTER TABLE [dbo].[ActivityEntry]  WITH CHECK ADD  CONSTRAINT [FK_ActivityEntry_ActivityType_ActivityType_ID] FOREIGN KEY([ActivityType_ID])
REFERENCES [dbo].[ActivityType] ([ActivityType_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ActivityEntry] CHECK CONSTRAINT [FK_ActivityEntry_ActivityType_ActivityType_ID]
GO
ALTER TABLE [dbo].[AspNetRoleClaims]  WITH CHECK ADD  CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetRoleClaims] CHECK CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserClaims]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserClaims] CHECK CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserLogins]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserLogins] CHECK CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId] FOREIGN KEY([RoleId])
REFERENCES [dbo].[AspNetRoles] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId]
GO
ALTER TABLE [dbo].[AspNetUserRoles]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserRoles] CHECK CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[AspNetUserTokens]  WITH CHECK ADD  CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId] FOREIGN KEY([UserId])
REFERENCES [dbo].[AspNetUsers] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[AspNetUserTokens] CHECK CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId]
GO
ALTER TABLE [dbo].[Batch]  WITH CHECK ADD  CONSTRAINT [FK_Batch_ClientOrder_ClientOrder_ID] FOREIGN KEY([ClientOrder_ID])
REFERENCES [dbo].[ClientOrder] ([ClientOrder_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Batch] CHECK CONSTRAINT [FK_Batch_ClientOrder_ClientOrder_ID]
GO
ALTER TABLE [dbo].[Batch]  WITH CHECK ADD  CONSTRAINT [FK_Batch_Coldroom_Coldroom_ID] FOREIGN KEY([Coldroom_ID])
REFERENCES [dbo].[Coldroom] ([Coldroom_ID])
GO
ALTER TABLE [dbo].[Batch] CHECK CONSTRAINT [FK_Batch_Coldroom_Coldroom_ID]
GO
ALTER TABLE [dbo].[Batch]  WITH CHECK ADD  CONSTRAINT [FK_Batch_Cultivar_Cultivar_ID] FOREIGN KEY([Cultivar_ID])
REFERENCES [dbo].[Cultivar] ([Cultivar_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Batch] CHECK CONSTRAINT [FK_Batch_Cultivar_Cultivar_ID]
GO
ALTER TABLE [dbo].[BatchSizeYields]  WITH CHECK ADD  CONSTRAINT [FK_BatchSizeYields_Batch_Batch_ID] FOREIGN KEY([Batch_ID])
REFERENCES [dbo].[Batch] ([Batch_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[BatchSizeYields] CHECK CONSTRAINT [FK_BatchSizeYields_Batch_Batch_ID]
GO
ALTER TABLE [dbo].[BatchSizeYields]  WITH CHECK ADD  CONSTRAINT [FK_BatchSizeYields_CommoditySizes_CommditySize_ID] FOREIGN KEY([CommditySize_ID])
REFERENCES [dbo].[CommoditySizes] ([CommoditySize_ID])
GO
ALTER TABLE [dbo].[BatchSizeYields] CHECK CONSTRAINT [FK_BatchSizeYields_CommoditySizes_CommditySize_ID]
GO
ALTER TABLE [dbo].[Block]  WITH CHECK ADD  CONSTRAINT [FK_Block_Batch_Batch_ID] FOREIGN KEY([Batch_ID])
REFERENCES [dbo].[Batch] ([Batch_ID])
GO
ALTER TABLE [dbo].[Block] CHECK CONSTRAINT [FK_Block_Batch_Batch_ID]
GO
ALTER TABLE [dbo].[ClientOrder]  WITH CHECK ADD  CONSTRAINT [FK_ClientOrder_Client_Client_ID] FOREIGN KEY([Client_ID])
REFERENCES [dbo].[Client] ([Client_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ClientOrder] CHECK CONSTRAINT [FK_ClientOrder_Client_Client_ID]
GO
ALTER TABLE [dbo].[ClientOrder]  WITH CHECK ADD  CONSTRAINT [FK_ClientOrder_OrderStatus_OrderStatus_ID] FOREIGN KEY([OrderStatus_ID])
REFERENCES [dbo].[OrderStatus] ([OrderStatus_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ClientOrder] CHECK CONSTRAINT [FK_ClientOrder_OrderStatus_OrderStatus_ID]
GO
ALTER TABLE [dbo].[CommoditySizes]  WITH CHECK ADD  CONSTRAINT [FK_CommoditySizes_Commodity_Commodity_ID] FOREIGN KEY([Commodity_ID])
REFERENCES [dbo].[Commodity] ([Commodity_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[CommoditySizes] CHECK CONSTRAINT [FK_CommoditySizes_Commodity_Commodity_ID]
GO
ALTER TABLE [dbo].[Cultivar]  WITH CHECK ADD  CONSTRAINT [FK_Cultivar_Commodity_Commodity_ID] FOREIGN KEY([Commodity_ID])
REFERENCES [dbo].[Commodity] ([Commodity_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Cultivar] CHECK CONSTRAINT [FK_Cultivar_Commodity_Commodity_ID]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_AccessLevelArea_AccessLevelArea_ID] FOREIGN KEY([AccessLevelArea_ID])
REFERENCES [dbo].[AccessLevelArea] ([AccessLevelArea_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_AccessLevelArea_AccessLevelArea_ID]
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD  CONSTRAINT [FK_Employee_EmployeeType_EmpType_ID] FOREIGN KEY([EmpType_ID])
REFERENCES [dbo].[EmployeeType] ([EmpType_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Employee] CHECK CONSTRAINT [FK_Employee_EmployeeType_EmpType_ID]
GO
ALTER TABLE [dbo].[EmployeeActivity]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeActivity_Employee_Emp_ID] FOREIGN KEY([Emp_ID])
REFERENCES [dbo].[Employee] ([Emp_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmployeeActivity] CHECK CONSTRAINT [FK_EmployeeActivity_Employee_Emp_ID]
GO
ALTER TABLE [dbo].[EmployeeActivity]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeActivity_GreenhouseActivity_GreenhouseActivity_ID] FOREIGN KEY([GreenhouseActivity_ID])
REFERENCES [dbo].[GreenhouseActivity] ([GreenhouseActivity_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmployeeActivity] CHECK CONSTRAINT [FK_EmployeeActivity_GreenhouseActivity_GreenhouseActivity_ID]
GO
ALTER TABLE [dbo].[EmployeeLogin]  WITH CHECK ADD  CONSTRAINT [FK_EmployeeLogin_Employee_Emp_ID] FOREIGN KEY([Emp_ID])
REFERENCES [dbo].[Employee] ([Emp_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[EmployeeLogin] CHECK CONSTRAINT [FK_EmployeeLogin_Employee_Emp_ID]
GO
ALTER TABLE [dbo].[Greenhouse]  WITH CHECK ADD  CONSTRAINT [FK_Greenhouse_GreenhouseStatusDescription_GreenhouseStatusDesc_ID] FOREIGN KEY([GreenhouseStatusDesc_ID])
REFERENCES [dbo].[GreenhouseStatusDescription] ([GreenhouseStatusDesc_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Greenhouse] CHECK CONSTRAINT [FK_Greenhouse_GreenhouseStatusDescription_GreenhouseStatusDesc_ID]
GO
ALTER TABLE [dbo].[GreenhouseActivity]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseActivity_ActivityEntry_ActivityEntry_ID] FOREIGN KEY([ActivityEntry_ID])
REFERENCES [dbo].[ActivityEntry] ([ActivityEntry_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseActivity] CHECK CONSTRAINT [FK_GreenhouseActivity_ActivityEntry_ActivityEntry_ID]
GO
ALTER TABLE [dbo].[GreenhouseActivity]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseActivity_Greenhouse_Greenhouse_ID] FOREIGN KEY([Greenhouse_ID])
REFERENCES [dbo].[Greenhouse] ([Greenhouse_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseActivity] CHECK CONSTRAINT [FK_GreenhouseActivity_Greenhouse_Greenhouse_ID]
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseProductionInventory_Greenhouse_Greenhouse_ID] FOREIGN KEY([Greenhouse_ID])
REFERENCES [dbo].[Greenhouse] ([Greenhouse_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory] CHECK CONSTRAINT [FK_GreenhouseProductionInventory_Greenhouse_Greenhouse_ID]
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseProductionInventory_ProductionInventory_ProductionInv_ID] FOREIGN KEY([ProductionInv_ID])
REFERENCES [dbo].[ProductionInventory] ([ProductionInv_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory] CHECK CONSTRAINT [FK_GreenhouseProductionInventory_ProductionInventory_ProductionInv_ID]
GO
ALTER TABLE [dbo].[GreenhouseStatusDescription]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseStatusDescription_GreenhouseStatus_GreenhouseStatus_ID] FOREIGN KEY([GreenhouseStatus_ID])
REFERENCES [dbo].[GreenhouseStatus] ([GreenhouseStatus_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseStatusDescription] CHECK CONSTRAINT [FK_GreenhouseStatusDescription_GreenhouseStatus_GreenhouseStatus_ID]
GO
ALTER TABLE [dbo].[GreenhouseTable]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseTable_Block_Block_ID] FOREIGN KEY([Block_ID])
REFERENCES [dbo].[Block] ([Block_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseTable] CHECK CONSTRAINT [FK_GreenhouseTable_Block_Block_ID]
GO
ALTER TABLE [dbo].[GreenhouseTable]  WITH CHECK ADD  CONSTRAINT [FK_GreenhouseTable_Greenhouse_Greenhouse_ID] FOREIGN KEY([Greenhouse_ID])
REFERENCES [dbo].[Greenhouse] ([Greenhouse_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[GreenhouseTable] CHECK CONSTRAINT [FK_GreenhouseTable_Greenhouse_Greenhouse_ID]
GO
ALTER TABLE [dbo].[LabResultDefect]  WITH CHECK ADD  CONSTRAINT [FK_LabResultDefect_Defect_Defect_ID] FOREIGN KEY([Defect_ID])
REFERENCES [dbo].[Defect] ([Defect_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LabResultDefect] CHECK CONSTRAINT [FK_LabResultDefect_Defect_Defect_ID]
GO
ALTER TABLE [dbo].[LabResultDefect]  WITH CHECK ADD  CONSTRAINT [FK_LabResultDefect_LabResults_LabResults_ID] FOREIGN KEY([LabResults_ID])
REFERENCES [dbo].[LabResults] ([LabResults_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LabResultDefect] CHECK CONSTRAINT [FK_LabResultDefect_LabResults_LabResults_ID]
GO
ALTER TABLE [dbo].[LabResults]  WITH CHECK ADD  CONSTRAINT [FK_LabResults_Batch_Batch_ID] FOREIGN KEY([Batch_ID])
REFERENCES [dbo].[Batch] ([Batch_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LabResults] CHECK CONSTRAINT [FK_LabResults_Batch_Batch_ID]
GO
ALTER TABLE [dbo].[LabResults]  WITH CHECK ADD  CONSTRAINT [FK_LabResults_TestResultStatus_TestResultStatus_ID] FOREIGN KEY([TestResultStatus_ID])
REFERENCES [dbo].[TestResultStatus] ([TestResultStatus_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[LabResults] CHECK CONSTRAINT [FK_LabResults_TestResultStatus_TestResultStatus_ID]
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventory_Metric_Metric_ID] FOREIGN KEY([Metric_ID])
REFERENCES [dbo].[Metric] ([Metric_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventory] CHECK CONSTRAINT [FK_ProductionInventory_Metric_Metric_ID]
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventory_ProductInventoryType_ProductInventoryType_ID] FOREIGN KEY([ProductInventoryType_ID])
REFERENCES [dbo].[ProductInventoryType] ([ProductInventoryType_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventory] CHECK CONSTRAINT [FK_ProductionInventory_ProductInventoryType_ProductInventoryType_ID]
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventory_ProductionInventoryCost_ProductionInvCost_ID] FOREIGN KEY([ProductionInvCost_ID])
REFERENCES [dbo].[ProductionInventoryCost] ([ProductionInvCost_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventory] CHECK CONSTRAINT [FK_ProductionInventory_ProductionInventoryCost_ProductionInvCost_ID]
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventory_ProductionInventoryWriteOff_ProductionInventoryWriteOff_ID] FOREIGN KEY([ProductionInventoryWriteOff_ID])
REFERENCES [dbo].[ProductionInventoryWriteOff] ([ProductionInventoryWriteOff_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventory] CHECK CONSTRAINT [FK_ProductionInventory_ProductionInventoryWriteOff_ProductionInventoryWriteOff_ID]
GO
ALTER TABLE [dbo].[ProductionInventoryOrder]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventoryOrder_ProductionInventoryOrderStatus_ProdctionInvOrderStatus_ID] FOREIGN KEY([ProdctionInvOrderStatus_ID])
REFERENCES [dbo].[ProductionInventoryOrderStatus] ([ProductionInvOrderStatus_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventoryOrder] CHECK CONSTRAINT [FK_ProductionInventoryOrder_ProductionInventoryOrderStatus_ProdctionInvOrderStatus_ID]
GO
ALTER TABLE [dbo].[ProductionInventoryOrder]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventoryOrder_Supplier_Supplier_ID] FOREIGN KEY([Supplier_ID])
REFERENCES [dbo].[Supplier] ([Supplier_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventoryOrder] CHECK CONSTRAINT [FK_ProductionInventoryOrder_Supplier_Supplier_ID]
GO
ALTER TABLE [dbo].[ProductionInventoryOrderDetails]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventoryOrderDetails_ProductionInventory_ProductionInvId] FOREIGN KEY([ProductionInvId])
REFERENCES [dbo].[ProductionInventory] ([ProductionInv_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventoryOrderDetails] CHECK CONSTRAINT [FK_ProductionInventoryOrderDetails_ProductionInventory_ProductionInvId]
GO
ALTER TABLE [dbo].[ProductionInventoryOrderDetails]  WITH CHECK ADD  CONSTRAINT [FK_ProductionInventoryOrderDetails_ProductionInventoryOrder_ProductionInvOrder_ID] FOREIGN KEY([ProductionInvOrder_ID])
REFERENCES [dbo].[ProductionInventoryOrder] ([ProductionInvOrder_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[ProductionInventoryOrderDetails] CHECK CONSTRAINT [FK_ProductionInventoryOrderDetails_ProductionInventoryOrder_ProductionInvOrder_ID]
GO
ALTER TABLE [dbo].[Restores]  WITH CHECK ADD  CONSTRAINT [FK_Restores_ActiveLogin_ActiveLogin_ID] FOREIGN KEY([ActiveLogin_ID])
REFERENCES [dbo].[ActiveLogin] ([ActiveLogin_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Restores] CHECK CONSTRAINT [FK_Restores_ActiveLogin_ActiveLogin_ID]
GO
ALTER TABLE [dbo].[TransactionLog]  WITH CHECK ADD  CONSTRAINT [FK_TransactionLog_Backups_Backup_ID] FOREIGN KEY([Backup_ID])
REFERENCES [dbo].[Backups] ([Backup_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TransactionLog] CHECK CONSTRAINT [FK_TransactionLog_Backups_Backup_ID]
GO
ALTER TABLE [dbo].[TransactionLog]  WITH CHECK ADD  CONSTRAINT [FK_TransactionLog_Restores_Restore_ID] FOREIGN KEY([Restore_ID])
REFERENCES [dbo].[Restores] ([Restore_ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[TransactionLog] CHECK CONSTRAINT [FK_TransactionLog_Restores_Restore_ID]
GO
USE [master]
GO
ALTER DATABASE [SeedTrail] SET  READ_WRITE 
GO
