USE master;
GO

IF DB_ID('SeedTrail') IS NOT NULL
DROP DATABASE SeedTrail;
GO

CREATE DATABASE SeedTrail;
GO

USE SeedTrail;

CREATE TABLE AccessArea (
AccessArea_ID INT PRIMARY KEY,
Description VARCHAR(255) NOT NULL,
Title VARCHAR(30) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE AccessLevel(
AccessLevel_ID INT PRIMARY KEY,
Description VARCHAR(255) NOT NULL,
Access_Level VARCHAR(30) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE AccessLevelArea(
AccessLevelArea_ID INT PRIMARY KEY,
AccessArea_ID INT  REFERENCES AccessArea (AccessArea_ID) NOT NULL,
AccessLevel_ID INT REFERENCES AccessLevel (AccessLevel_ID) NOT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE EmployeeType(
EmpType_ID INT PRIMARY KEY,
Type VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Employee(
Emp_ID INT PRIMARY KEY IDENTITY,
AccessLevelArea_ID INT REFERENCES AccessLevelArea (AccessLevelArea_ID) NOT NULL,
EmpType_ID INT REFERENCES EmployeeType (EmpType_ID) NOT NULL,
Name VARCHAR(30) NOT NULL,
Surname VARCHAR(30) NOT NULL,
Contact_Nr VARCHAR(13) NOT NULL,
National_ID VARCHAR(30) NOT NULL,
Email VARCHAR(40) NOT NULL UNIQUE,
Start_Date DATETIME DEFAULT NULL,
End_Date DATETIME DEFAULT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE EmployeeLogin(
EmpLogin_ID INT PRIMARY KEY NOT NULL,
Emp_ID INT REFERENCES Employee (Emp_ID) NOT NULL,
Username VARCHAR(40) NOT NULL,
Password VARCHAR(30) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ActiveLogin(
ActiveLogin_ID INT PRIMARY KEY,

EmpLogin_ID INT REFERENCES EmployeeLogin (EmpLogin_ID) NOT NULL,
Start_Time DATETIME DEFAULT NULL,
End_Time DATETIME DEFAULT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Restores(
Restore_ID INT PRIMARY KEY,
ActiveLogin_ID INT REFERENCES ActiveLogin (ActiveLogin_ID) NOT NULL,
Date DATETIME DEFAULT NULL,
Description VARCHAR(255) NOT NULL,
Time DATETIME DEFAULT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Backups(
Backup_ID INT PRIMARY KEY,
Date DATETIME DEFAULT NULL,
Description VARCHAR(255) NOT NULL,
Time DATETIME DEFAULT NULL, 
Status BIT DEFAULT 1,
)

CREATE TABLE TransactionLog(
TransactionLog_ID INT PRIMARY KEY,
Backup_ID INT REFERENCES Backups (Backup_ID) NOT NULL,
Restore_ID INT REFERENCES Restores (Restore_ID) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ActivityType(
ActivityType_ID INT PRIMARY KEY,
Description VARCHAR(255) NOT NULL,
Type VARCHAR(30) NOT NULL,
Status BIT DEFAULT 1,
)



CREATE TABLE Commodity(
Commodity_ID INT PRIMARY KEY,
Name VARCHAR(30) NOT NULL,
Description VARCHAR(255),
Status BIT DEFAULT 1,
)

CREATE TABLE Cultivar(
Cultivar_ID INT PRIMARY KEY,
Commodity_ID INT REFERENCES Commodity (Commodity_ID) NOT NULL,
Name VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ActivityStatus(
ActivityStatus_ID INT PRIMARY KEY,
AStatus VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ActivityEntry(
ActivityEntry_ID INT PRIMARY KEY,
ActivityType_ID INT REFERENCES ActivityType (ActivityType_ID) NOT NULL,
ActivityStatus_ID INT REFERENCES ActivityStatus (ActivityStatus_ID) NOT NULL,
Duration VARCHAR(30) NOT NULL,
Description VARCHAR (255) NOT NULL,
Title VARCHAR(30) NOT NULL,
Sequence_Order INT NOT NULL,
Status BIT DEFAULT 1,
)


CREATE TABLE EmployeeActivity(
EmployeeActivity_ID INT PRIMARY KEY,
ActivityEntry_ID INT REFERENCES ActivityEntry (ActivityEntry_ID) NOT NULL,
Emp_ID INT REFERENCES Employee (Emp_ID) NOT NULL,
Start_Date DATETIME DEFAULT NULL,
End_Date DATETIME DEFAULT NULL,
Status BIT DEFAULT 1,

)

CREATE TABLE GreenhouseStatus(
GreenhouseStatus_ID INT PRIMARY KEY,
GHStatus VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL, 
Status BIT DEFAULT 1,
)

CREATE TABLE GreenhouseStatusDescription(
GreenhouseStatusDesc_ID INT PRIMARY KEY,
GreenhouseStatus_ID INT REFERENCES GreenhouseStatus (GreenhouseStatus_ID) NOT NULL,
Description VARCHAR(30),
Status BIT DEFAULT 1,
)

CREATE TABLE Greenhouse(
Greenhouse_ID INT PRIMARY KEY,
GreenhouseStatusDesc_ID INT REFERENCES GreenhouseStatusDescription (GreenhouseStatusDesc_ID) NOT NULL,
Greenhouse_Number INT NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ProductionInventoryOrderStatus(
ProductionInvOrderStatus_ID INT PRIMARY KEY,
PIStatus VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Supplier(
Supplier_ID INT PRIMARY KEY,
Name VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Contact_Nr VARCHAR(100) NOT NULL,
Email VARCHAR(40) NOT NULL UNIQUE,
Status BIT DEFAULT 1,
)

CREATE TABLE ProductionInventoryOrder(
ProductionInvOrder_ID INT PRIMARY KEY,
Supplier_ID INT REFERENCES Supplier (Supplier_ID) NOT NULL,
ProdctionInvOrderStatus_ID INT REFERENCES ProductionInventoryOrderStatus (ProductionInvOrderStatus_ID) NOT NULL,
Quantity INT NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ProductionInventoryCost(
ProductionInvCost_ID INT PRIMARY KEY,
Cost MONEY DEFAULT 0.00,
Date DATETIME DEFAULT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE ProductionInventoryWriteOff(
ProductionInventoryWriteOff_ID INT PRIMARY KEY,
Name VARCHAR(30) NOT NULL,
Description VARCHAR(255),
Quantity INT NOT NULL,
Status BIT DEFAULT 1,
)
CREATE TABLE ProductionInventory(
ProductionInv_ID INT PRIMARY KEY,
ProductionInvOrder_ID INT REFERENCES ProductionInventoryOrder (ProductionInvOrder_ID) NOT NULL,
ProductionInvCost_ID INT REFERENCES ProductionInventoryCost (ProductionInvCost_ID) NOT NULL,
ProductionInventoryWriteOff_ID INT REFERENCES ProductionInventoryWriteOff (ProductionInventoryWriteOff_ID) NOT NULL,
Name VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Quantity INT NOT NULL,
Status BIT DEFAULT 1,
)



CREATE TABLE GreenhouseProductionInventory(
GreenhouseProductionInventory_ID INT PRIMARY KEY,
Greenhouse_ID INT REFERENCES Greenhouse (Greenhouse_ID) NOT NULL,
ProductionInv_ID INT REFERENCES ProductionInventory (ProductionInv_ID) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Defect(
Defect_ID INT PRIMARY KEY,
Defect VARCHAR NOT NULL,
Description VARCHAR(50),
Status BIT DEFAULT 1,
)

CREATE TABLE TestResultStatus(
TestResultStatus_ID INT PRIMARY KEY,
TRStatus VARCHAR(30) NOT NULL,
Description VARCHAR (255),
Status BIT DEFAULT 1,
)

CREATE TABLE Coldroom(
Coldroom_ID INT PRIMARY KEY,
Name VARCHAR(30) NOT NULL,
Description VARCHAR (255),
Status BIT DEFAULT 1,
)

CREATE TABLE CommoditySizes(
CommoditySize_ID INT PRIMARY KEY,
Commodity_ID INT REFERENCES Commodity (Commodity_ID) NOT NULL,
Size VARCHAR(30) NOT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)


CREATE TABLE BatchSizeYields(
BatchSizeYield_ID INT PRIMARY KEY,
Commodity_ID INT REFERENCES Commodity (Commodity_ID) NOT NULL,
CommditySize_ID INT REFERENCES CommoditySizes (CommoditySize_ID) NOT NULL,
Description VARCHAR(255) NOT NULL,
Yield INT NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Client(
Client_ID INT PRIMARY KEY,
Name VARCHAR(30) NOT NULL,
Contract_Nr VARCHAR(13) NOT NULL,
Email VARCHAR(40) NOT NULL UNIQUE,
Address VARCHAR(60),
Status BIT DEFAULT 1,
)

CREATE TABLE OrderStatus(
OrderStatus_ID INT PRIMARY KEY,
OStatus VARCHAR(30) NOT NULL,
Description VARCHAR(255),
Status BIT DEFAULT 1,
)

CREATE TABLE ClientOrder(
ClientOrder_ID INT PRIMARY KEY,
OrderStatus_ID INT REFERENCES OrderStatus (OrderStatus_ID) NOT NULL,
Client_ID INT REFERENCES CLient (Client_ID) NOT NULL,
Date_Placed DATETIME DEFAULT NULL,
Date_Required DATETIME DEFAULT NULL,
Description VARCHAR(255) NOT NULL,
Status BIT DEFAULT 1,
)


CREATE TABLE Batch(
Batch_ID INT PRIMARY KEY,
Coldroom_ID INT REFERENCES Coldroom (Coldroom_ID) NOT NULL,
ClientOrder_ID INT REFERENCES ClientOrder (ClientOrder_ID) NOT NULL,
Cultivar_ID INT REFERENCES Cultivar (Cultivar_ID) NOT NULL,
Plant_Date DATETIME DEFAULT NULL,
Total_Planted INT NOT NULL,
Harvest_Date DATETIME DEFAULT NULL,
Total_Yield INT NOT NULL,
Scrap INT,
BatchSizeYield_ID INT REFERENCES BatchSizeYields (BatchSizeYield_ID) NOT NULL,
Coldroom_Date_In DATETIME DEFAULT NULL,
Coldroom_Date_Out DATETIME DEFAULT NULL,
Total_Bags INT NOT NULL,
Avg_Yield DECIMAL(10,2) NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE Block(
Block_ID INT PRIMARY KEY,
Batch_ID INT REFERENCES Batch (Batch_ID),
Table_Quantity INT NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE GreenhouseTable(
Table_ID INT PRIMARY KEY,
Block_ID INT REFERENCES Block (Block_ID) NOT NULL,
Greenhouse_ID INT REFERENCES Greenhouse (Greenhouse_ID) NOT NULL,
Table_Total_Crates INT NOT NULL,
Status BIT DEFAULT 1,
)

CREATE TABLE GreenhouseActivity(
GreenhouseActivity_ID INT PRIMARY KEY,
Greenhouse_ID INT REFERENCES Greenhouse (Greenhouse_ID) NOT NULL,
ActivityEntry_ID INT REFERENCES ActivityEntry (ActivityEntry_ID) NOT NULL,
Start_Date DATETIME DEFAULT NULL,
End_Date DATETIME DEFAULT NULL,
Status BIT DEFAULT 1,

)

CREATE TABLE LabResults(
LabResults_ID INT PRIMARY KEY,
Batch_ID INT REFERENCES Batch (Batch_ID) NOT NULL,
TestResultStatus_ID INT REFERENCES TestResultStatus (TestResultStatus_ID) NOT NULL,
Date DATETIME DEFAULT NULL,
File_Path VARCHAR(50) NOT NULL, 
Description VARCHAR(255) NOT NULL,
Comment VARCHAR(255),
Status BIT DEFAULT 1,
)

CREATE TABLE LabResultDefect(
LabResultDefect_ID INT PRIMARY KEY,
LabResults_ID INT REFERENCES LabResults (LabResults_ID) NOT NULL,
Defect_ID INT REFERENCES Defect (Defect_ID) NOT NULL,
Status BIT DEFAULT 1,
)
