USE [master]
GO

Drop DATABASE [SeedTrail]
GO

/****** Object:  Database [SeedTrail]    Script Date: 2022/07/31 12:50:33 ******/
CREATE DATABASE [SeedTrail]
Go
USE [SeedTrail]
GO
/****** Object:  Table [dbo].[AccessArea]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AccessArea](
	[AccessArea_ID] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Title] [varchar](30) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AccessArea_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AccessLevel]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AccessLevel](
	[AccessLevel_ID] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Access_Level] [varchar](30) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AccessLevel_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[AccessLevelArea]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[AccessLevelArea](
	[AccessLevelArea_ID] [int] NOT NULL,
	[AccessArea_ID] [int] NOT NULL,
	[AccessLevel_ID] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[AccessLevelArea_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ActiveLogin]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ActiveLogin](
	[ActiveLogin_ID] [int] NOT NULL,
	[EmpLogin_ID] [int] NOT NULL,
	[Start_Time] [datetime] NULL,
	[End_Time] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ActiveLogin_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ActivityEntry]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ActivityEntry](
	[ActivityEntry_ID] [int] NOT NULL,
	[ActivityType_ID] [int] NOT NULL,
	[ActivityStatus_ID] [int] NOT NULL,
	[Duration] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Title] [varchar](30) NOT NULL,
	[Sequence_Order] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ActivityEntry_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ActivityStatus]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ActivityStatus](
	[ActivityStatus_ID] [int] NOT NULL,
	[AStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ActivityStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ActivityType]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ActivityType](
	[ActivityType_ID] [int] NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Type] [varchar](30) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ActivityType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Backups]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Backups](
	[Backup_ID] [int] NOT NULL,
	[Date] [datetime] NULL,
	[Description] [varchar](255) NOT NULL,
	[Time] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Backup_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Batch]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Batch](
	[Batch_ID] [int] NOT NULL,
	[Coldroom_ID] [int] NULL DEFAULT (NULL),
	[ClientOrder_ID] [int] NOT NULL,
	[Cultivar_ID] [int] NOT NULL,
	[Plant_Date] [datetime] NULL DEFAULT (NULL),
	[Total_Planted] [int] NULL DEFAULT (NULL),
	[Harvest_Date] [datetime] NULL DEFAULT (NULL),
	[Total_Yield] [int] NULL DEFAULT (NULL),
	[Scrap] [int] NULL DEFAULT (NULL),

	[Coldroom_Date_In] [datetime] NULL DEFAULT (NULL),
	[Coldroom_Date_Out] [datetime] NULL DEFAULT (NULL),
	[Total_Bags] [int] NULL DEFAULT (NULL),
	[Avg_Yield] [decimal](10, 2) NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Batch_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[BatchSizeYields]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[BatchSizeYields](
	[BatchSizeYield_ID] [int] NOT NULL,
	[Batch_ID] [int] NOT NULL,
	[CommditySize_ID] [int] NOT NULL,
	[Description] [varchar](255) NULL DEFAULT (NULL),
	[Yield] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[BatchSizeYield_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Block]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Block](
	[Block_ID] [int] NOT NULL,
	[Batch_ID] [int] NULL,
	[Table_Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Block_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[Client]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Client](
	[Client_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Contract_Nr] [varchar](13) NOT NULL,
	[Email] [varchar](40) NOT NULL,
	[Address] [varchar](60) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Client_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ClientOrder]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ClientOrder](
	[ClientOrder_ID] [int] NOT NULL,
	[OrderStatus_ID] [int] NOT NULL,
	[Client_ID] [int] NOT NULL,
	[Date_Placed] [datetime] NULL DEFAULT (NULL),
	[Date_Required] [datetime] NULL DEFAULT (NULL),
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[ClientOrder_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Coldroom]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Coldroom](
	[Coldroom_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Coldroom_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Commodity]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Commodity](
	[Commodity_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Commodity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[CommoditySizes]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[CommoditySizes](
	[CommoditySize_ID] [int] NOT NULL,
	[Commodity_ID] [int] NOT NULL,
	[Size] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[CommoditySize_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Cultivar]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Cultivar](
	[Cultivar_ID] [int] NOT NULL,
	[Commodity_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Cultivar_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Defect]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Defect](
	[Defect_ID] [int] NOT NULL,
	[Defect] [varchar](1) NOT NULL,
	[Description] [varchar](50) NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Defect_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Employee]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Employee](
	[Emp_ID] [int] IDENTITY(1,1) NOT NULL,
	[AccessLevelArea_ID] [int] NOT NULL,
	[EmpType_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Surname] [varchar](30) NOT NULL,
	[Contact_Nr] [varchar](13) NOT NULL,
	[National_ID] [varchar](30) NOT NULL,
	[Email] [varchar](40) NOT NULL,
	[Start_Date] [datetime] NULL DEFAULT (NULL),
	[End_Date] [datetime] NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Emp_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EmployeeActivity]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EmployeeActivity](
	[EmployeeActivity_ID] [int] NOT NULL,
	[ActivityEntry_ID] [int] NOT NULL,
	[Emp_ID] [int] NOT NULL,
	[Start_Date] [datetime] NULL DEFAULT (NULL),
	[End_Date] [datetime] NULL DEFAULT (NULL),
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[EmployeeActivity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[EmployeeLogin]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EmployeeLogin](
	[EmpLogin_ID] [int] NOT NULL,
	[Emp_ID] [int] NOT NULL,
	[Username] [varchar](40) NOT NULL,
	[Password] [varchar](30) NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[EmpLogin_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[EmployeeType]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[EmployeeType](
	[EmpType_ID] [int] NOT NULL,
	[Type] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[EmpType_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Greenhouse]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Greenhouse](
	[Greenhouse_ID] [int] NOT NULL,
	[GreenhouseStatusDesc_ID] [int] NOT NULL,
	[Greenhouse_Number] [int] NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[Greenhouse_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[GreenhouseActivity]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GreenhouseActivity](
	[GreenhouseActivity_ID] [int] NOT NULL,
	[Greenhouse_ID] [int] NOT NULL,
	[ActivityEntry_ID] [int] NOT NULL,
	[Start_Date] [datetime] NULL,
	[End_Date] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[GreenhouseActivity_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[GreenhouseProductionInventory]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GreenhouseProductionInventory](
	[GreenhouseProductionInventory_ID] [int] NOT NULL,
	[Greenhouse_ID] [int] NOT NULL,
	[ProductionInv_ID] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[GreenhouseProductionInventory_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[GreenhouseStatus]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[GreenhouseStatus](
	[GreenhouseStatus_ID] [int] NOT NULL,
	[GHStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[GreenhouseStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[GreenhouseStatusDescription]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[GreenhouseStatusDescription](
	[GreenhouseStatusDesc_ID] [int] NOT NULL,
	[GreenhouseStatus_ID] [int] NOT NULL,
	[Description] [varchar](30) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[GreenhouseStatusDesc_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[GreenhouseTable]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GreenhouseTable](
	[Table_ID] [int] NOT NULL,
	[Block_ID] [int] NOT NULL,
	[Greenhouse_ID] [int] NOT NULL,
	[Table_Total_Crates] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Table_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LabResultDefect]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LabResultDefect](
	[LabResultDefect_ID] [int] NOT NULL,
	[LabResults_ID] [int] NOT NULL,
	[Defect_ID] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[LabResultDefect_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[LabResults]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[LabResults](
	[LabResults_ID] [int] NOT NULL,
	[Batch_ID] [int] NOT NULL,
	[TestResultStatus_ID] [int] NOT NULL,
	[Date] [datetime] NULL DEFAULT (NULL),
	[File_Path] [varchar](50) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Comment] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[LabResults_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[OrderStatus]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[OrderStatus](
	[OrderStatus_ID] [int] NOT NULL,
	[OStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[OrderStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductionInventory]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductionInventory](
	[ProductionInv_ID] [int] NOT NULL,
	[ProductionInvOrder_ID] [int] NOT NULL,
	[ProductionInvCost_ID] [int] NOT NULL,
	[ProductionInventoryWriteOff_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInv_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductionInventoryCost]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductionInventoryCost](
	[ProductionInvCost_ID] [int] NOT NULL,
	[Cost] [money] NULL,
	[Date] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInvCost_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ProductionInventoryOrder]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProductionInventoryOrder](
	[ProductionInvOrder_ID] [int] NOT NULL,
	[Supplier_ID] [int] NOT NULL,
	[ProdctionInvOrderStatus_ID] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInvOrder_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[ProductionInventoryOrderStatus]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductionInventoryOrderStatus](
	[ProductionInvOrderStatus_ID] [int] NOT NULL,
	[PIStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInvOrderStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[ProductionInventoryWriteOff]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[ProductionInventoryWriteOff](
	[ProductionInventoryWriteOff_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Quantity] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductionInventoryWriteOff_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Restores]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Restores](
	[Restore_ID] [int] NOT NULL,
	[ActiveLogin_ID] [int] NOT NULL,
	[Date] [datetime] NULL,
	[Description] [varchar](255) NOT NULL,
	[Time] [datetime] NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Restore_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[Supplier]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Supplier](
	[Supplier_ID] [int] NOT NULL,
	[Name] [varchar](30) NOT NULL,
	[Description] [varchar](255) NOT NULL,
	[Contact_Nr] [varchar](100) NOT NULL,
	[Email] [varchar](40) NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[Supplier_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[TestResultStatus]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[TestResultStatus](
	[TestResultStatus_ID] [int] NOT NULL,
	[TRStatus] [varchar](30) NOT NULL,
	[Description] [varchar](255) NULL,
	[Status] [bit] NULL DEFAULT ((1)),
PRIMARY KEY CLUSTERED 
(
	[TestResultStatus_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[TransactionLog]    Script Date: 2022/07/31 12:50:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TransactionLog](
	[TransactionLog_ID] [int] NOT NULL,
	[Backup_ID] [int] NOT NULL,
	[Restore_ID] [int] NOT NULL,
	[Status] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[TransactionLog_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
INSERT [dbo].[AccessArea] ([AccessArea_ID], [Description], [Title], [Status]) VALUES (1, N'Reports', N'Reports', 1)
GO
INSERT [dbo].[AccessArea] ([AccessArea_ID], [Description], [Title], [Status]) VALUES (2, N'CRUD''s', N'CRUD''s', 1)
GO
INSERT [dbo].[AccessArea] ([AccessArea_ID], [Description], [Title], [Status]) VALUES (3, N'Schedule', N'Schedule', 1)
GO
INSERT [dbo].[AccessArea] ([AccessArea_ID], [Description], [Title], [Status]) VALUES (4, N'Capture Quantities', N'Quantities', 1)
GO
INSERT [dbo].[AccessLevel] ([AccessLevel_ID], [Description], [Access_Level], [Status]) VALUES (1, N'Manager', N'Highest Access Level', 1)
GO
INSERT [dbo].[AccessLevel] ([AccessLevel_ID], [Description], [Access_Level], [Status]) VALUES (2, N'Supervisor', N'Middle Access Level', 1)
GO
INSERT [dbo].[AccessLevel] ([AccessLevel_ID], [Description], [Access_Level], [Status]) VALUES (3, N'Owner', N'Lowest Access Level', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (1, 1, 1, N'Manager Reports', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (2, 2, 1, N'Manager CRUD', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (3, 3, 1, N'Manager Schedule', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (4, 4, 1, N'Manager Quantities', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (5, 3, 2, N'SuperVisor Schedule', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (6, 4, 2, N'Supervisor Quantities', 1)
GO
INSERT [dbo].[AccessLevelArea] ([AccessLevelArea_ID], [AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (7, 1, 3, N'Owner Reports', 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (1, 3, 1, 3, N'Harvest', N'Harvest', 1, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (2, 3, 1, 3, N'Clean and Maintenance', N'Clean and Maintenance', 2, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (3, 3, 1, 1, N'Pack Crates', N'Pack Crates', 3, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (4, 3, 1, 1, N'Fill up Planting Medium', N'Fill up planting medium', 4, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (5, 3, 1, 1, N'Drench', N'Drench', 5, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (6, 3, 1, 1, N'Plant', N'Plant', 6, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (7, 3, 1, 98, N'Grow', N'Grow', 7, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (8, 3, 1, 5, N'Switch off water', N'Switch off water', 8, 1)
GO
INSERT [dbo].[ActivityEntry] ([ActivityEntry_ID], [ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status]) VALUES (9, 3, 1, 5, N'Pull halmes', N'Pull halmes', 9, 1)
GO
INSERT [dbo].[ActivityStatus] ([ActivityStatus_ID], [AStatus], [Description], [Status]) VALUES (1, N'Not Started', N'Activity haven''t started yet', 1)
GO
INSERT [dbo].[ActivityStatus] ([ActivityStatus_ID], [AStatus], [Description], [Status]) VALUES (2, N'In progress', N'Activity is in progress', 1)
GO
INSERT [dbo].[ActivityStatus] ([ActivityStatus_ID], [AStatus], [Description], [Status]) VALUES (3, N'Complete', N'Activity is Complete', 1)
GO
INSERT [dbo].[ActivityType] ([ActivityType_ID], [Description], [Type], [Status]) VALUES (1, N'Plant', N'Plant', 1)
GO
INSERT [dbo].[ActivityType] ([ActivityType_ID], [Description], [Type], [Status]) VALUES (2, N'Harvest', N'Harvest', 1)
GO
INSERT [dbo].[ActivityType] ([ActivityType_ID], [Description], [Type], [Status]) VALUES (3, N'Prepare', N'Prepare', 1)
GO
INSERT [dbo].[ActivityType] ([ActivityType_ID], [Description], [Type], [Status]) VALUES (4, N'Insecticide', N'Insecticide', 1)
GO
INSERT [dbo].[ActivityType] ([ActivityType_ID], [Description], [Type], [Status]) VALUES (5, N'Pesticide', N'Pesticide', 1)
GO
INSERT [dbo].[ActivityType] ([ActivityType_ID], [Description], [Type], [Status]) VALUES (6, N'Foliar', N'Foliar', 1)
GO



INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (1, N'Du Toit Groente', N'0', N'0', N'0', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (2, N'Kli�nt IHF', N'o', N'o', N'o', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (3, N'Simba', N'1', N'1', N'1', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (4, N'FPD', N'2', N'2', N'2', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (5, N'Kli�nt GV', N'3', N'3', N'3', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (6, N'Kli�nt JP', N'4', N'4', N'4', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (7, N'Kli�nt GC', N'5', N'5', N'5', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (8, N'Kli�nt SR', N'6', N'6', N'6', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (9, N'GWK', N'7', N'7', N'7', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (10, N'RSA Raad', N'8', N'8', N'8', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (11, N'McCain', N'9', N'9', N'9', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (12, N'Kli�nt VZVM', N'10', N'101', N'10', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (13, N'Kli�nt TK', N'11', N'11', N'11', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (14, N'AI3 Boerdery', N'12', N'12', N'12', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (15, N'Seed Potato Co-op', N'13', N'13', N'13', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (16, N'Kli�nt CE ', N'14', N'14', N'14', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (17, N'Kli�nt MOG ', N'15', N'15', N'15', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (18, N'Ortus Bdy', N'16', N'16', N'16', 1)
GO
INSERT [dbo].[Client] ([Client_ID], [Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (19, N'Johan Holsthauzen', N'17', N'17', N'17', 1)
GO
INSERT [dbo].[ClientOrder] ([ClientOrder_ID], [OrderStatus_ID], [Client_ID], [Date_Placed], [Date_Required], [Description], [Status]) VALUES (1, 3, 1, CAST(N'2021-12-01 00:00:00.000' AS DateTime), CAST(N'2022-01-24 00:00:00.000' AS DateTime), N'Du Toit Groente, Fassan, Fianna, F/L 2108, F/l 2006. ', 1)
GO
INSERT [dbo].[Coldroom] ([Coldroom_ID], [Name], [Description], [Status]) VALUES (1, N'Coldroom 1', N'Coldroom 1', 1)
GO
INSERT [dbo].[Commodity] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Potato Seeds', N'Potato Seeds', 1)
GO
INSERT [dbo].[Commodity] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Lettuce', N'Lettuce', 1)
GO
INSERT [dbo].[CommoditySizes] ([CommoditySize_ID], [Commodity_ID], [Size], [Description], [Status]) VALUES (1, 1, N'<2gr', N'<2gr', 1)
GO
INSERT [dbo].[CommoditySizes] ([CommoditySize_ID], [Commodity_ID], [Size], [Description], [Status]) VALUES (2, 1, N'2-5gr', N'2-5gr', 1)
GO
INSERT [dbo].[CommoditySizes] ([CommoditySize_ID], [Commodity_ID], [Size], [Description], [Status]) VALUES (3, 1, N'5-10gr', N'5-10gr', 1)
GO
INSERT [dbo].[CommoditySizes] ([CommoditySize_ID], [Commodity_ID], [Size], [Description], [Status]) VALUES (4, 1, N'10-30gr', N'10-30gr', 1)
GO
INSERT [dbo].[CommoditySizes] ([CommoditySize_ID], [Commodity_ID], [Size], [Description], [Status]) VALUES (5, 1, N'>30gr', N'>30gr', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (1, 1, N'Amethyst', N'Amethyst', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (2, 1, N'Amigo', N'Amigo', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (3, 1, N'Apache', N'Apache', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (4, 1, N'Argos', N'Argos', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (5, 1, N'Almera', N'Almera', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (6, 1, N'Avalanche', N'Avalanche', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (7, 1, N'BP1', N'BP1', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (8, 1, N'BFP', N'BFP', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (9, 1, N'Calibra', N'Calibra', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (10, 1, N'Caruso', N'Caruso', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (11, 1, N'Cimega', N'Cimega', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (12, 1, N'Chellah', N'Chellah', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (13, 1, N'Colorado Rose', N'Colorado Rose', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (14, 1, N'Dakota', N'Dakota', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (15, 1, N'DANEPSO', N'DANEPSO', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (16, 1, N'Daisy', N'Daisy', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (17, 1, N'Diamant', N'Diamant', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (18, 1, N'Diva ca99-1', N'Diva ca99-1', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (19, 1, N'El Mundo', N'El Mundo', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (20, 1, N'Eos', N'Eos', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (21, 1, N'Eryn', N'Eryn', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (22, 1, N'Fasan', N'Fasan', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (23, 1, N'Fianna', N'Fianna', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (24, 1, N'FLx26', N'FLx26', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (25, 1, N'FL 2006', N'FL 2006', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (26, 1, N'FL 2221', N'FL 2221', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (27, 1, N'FL 2018', N'FL 2018', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (28, 1, N'FL 2377', N'FL 2377', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (29, 1, N'FL 2387', N'FL 2387', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (30, 1, N'FL 2400', N'FL 2400', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (31, 1, N'Georgina', N'Georgina', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (32, 1, N'Harmony', N'Harmony', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (33, 1, N'166 HVN bute', N'166 HVN bute', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (34, 1, N'Hertha', N'Hertha', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (35, 1, N'Hermes', N'Hermes', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (36, 1, N'Horizo', N'Horizo', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (37, 1, N'Innovator', N'Innovator', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (38, 1, N'Jasper', N'jasper', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (39, 1, N'Jelly', N'Jelly', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (40, 1, N'Leonata', N'Leonata', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (41, 1, N'Labadia', N'Labadia', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (42, 1, N'Lady Nal', N'Lady Nal', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (43, 1, N'Lanorma', N'lanorma', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (44, 1, N'Magnum', N'Magnum', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (45, 1, N'Markies', N'markies', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (46, 1, N'Marvel(SM01)', N'Marvel(SM01)', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (47, 1, N'Mnandi', N'Mnandi', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (48, 1, N'Mondeo', N'Mondeo', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (49, 1, N'Mondial', N'Mondial', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (50, 1, N'MonloghtCrop', N'MonloghtCrop', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (51, 1, N'Paramount', N'Paramount', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (52, 1, N'PDell', N'PDell', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (53, 1, N'Red Eye', N'Red Eye', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (54, 1, N'Royal', N'Royal', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (55, 1, N'Rumba', N'Rumba', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (56, 1, N'Santano', N'Santano', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (57, 1, N'Shepody', N'Shepody', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (58, 1, N'Triomphe', N'Triomphe', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (59, 1, N'UTD', N'UTD', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (60, 1, N'Valor', N'Valor', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (61, 1, N'VDP ', N'VDP', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (62, 1, N'Umatilla', N'Umatilla', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (63, 1, N'Zylem', N'Zylem', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (64, 1, N'441', N'441', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (65, 1, N'Arno-MC2', N'Arno-MC2', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (66, 1, N'98F1641', N'98F1641', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (67, 2, N'Butter-Faustina', N'Butter-Faustina', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (68, 2, N'Butter-Arleti', N'Butter-Arleti', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (69, 2, N'COS(harder)-Rafael', N'COS(harder)-Rafae', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (70, 2, N'COS(harder)-Raulph', N'COS(harder)-Raulph', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (71, 2, N'Butterfly COS(harder)-Auvona', N'Butterfly COS(harder)-Auvona', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (72, 2, N'Butterfly COS(harder)-Tacedoma', N'Butterfly COS(harder)-Tacedoma', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (73, 2, N'Green Oak- Kireve', N'Green Oak- Kireve', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (74, 2, N'Green Frilly- Mutligreen 3', N'Green Frilly- Mutligreen 3', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (75, 2, N'Salanova Green Butter- Erasmus', N'Salanova Green Butter- Erasmus', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (76, 2, N'Red Frilly-Stefano', N'Red Frilly-Stefano', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (77, 2, N'Salanova Red Butter-Gaugin', N'Salanova Red Butter-Gaugin', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (78, 2, N'Raddichio - Giove', N'Raddichio - Giove', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (79, 2, N'Red COS- 41-950', N'Red COS- 41-950', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (80, 2, N'Crunchita (harder)-Crunchita', N'Crunchita (harder)-Crunchita', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (81, 2, N'Crunchita (harder)-Gourmandine', N'Crunchita (harder)-Gourmandine', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (82, 1, N'bfth', N'knjhh', 1)
GO
INSERT [dbo].[Cultivar] ([Cultivar_ID], [Commodity_ID], [Name], [Description], [Status]) VALUES (83, 1, N'F/L 2108', N'F/L 2108', 1)
GO
INSERT [dbo].[Defect] ([Defect_ID], [Defect], [Description], [Status]) VALUES (1, N'W', N'Worms', 1)
GO
SET IDENTITY_INSERT [dbo].[Employee] ON 

GO
INSERT [dbo].[Employee] ([Emp_ID], [AccessLevelArea_ID], [EmpType_ID], [Name], [Surname], [Contact_Nr], [National_ID], [Email], [Start_Date], [End_Date], [Status]) VALUES (1, 1, 1, N'Werner', N'Schutte', N'0646849232', N'xxxxxxxxxxxxxxxxxx', N'werner', NULL, NULL, 1)
GO

INSERT [dbo].[EmployeeActivity] ([EmployeeActivity_ID], [ActivityEntry_ID], [Emp_ID], [Start_Date], [End_Date], [Status]) VALUES (1, 1, 1, CAST(N'2022-07-19 19:00:00.000' AS DateTime), CAST(N'2022-07-20 20:00:00.000' AS DateTime), 1)
GO
INSERT [dbo].[EmployeeType] ([EmpType_ID], [Type], [Description], [Status]) VALUES (1, N'Greenhouse Manager', N'Manages the greenhouses and has the most authority over the system.', 1)
GO
INSERT [dbo].[EmployeeType] ([EmpType_ID], [Type], [Description], [Status]) VALUES (2, N'Supervisors', N'Supervises the activities and task in the greenhosues.', 1)
GO
INSERT [dbo].[EmployeeType] ([EmpType_ID], [Type], [Description], [Status]) VALUES (3, N'Owner', N'Owner of the company, but does not have authority in the functionality of the system ', 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (1, 1, 1, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (2, 1, 2, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (3, 1, 3, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (4, 1, 4, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (5, 1, 5, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (6, 1, 6, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (7, 1, 7, 1)
GO
INSERT [dbo].[Greenhouse] ([Greenhouse_ID], [GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (8, 1, 8, 1)
GO
INSERT [dbo].[GreenhouseStatus] ([GreenhouseStatus_ID], [GHStatus], [Description], [Status]) VALUES (1, N'Available', N'Greenhouse is in use.', 1)
GO
INSERT [dbo].[GreenhouseStatus] ([GreenhouseStatus_ID], [GHStatus], [Description], [Status]) VALUES (2, N'Inactive', N'Greenhouse is not in use.', 1)
GO
INSERT [dbo].[GreenhouseStatusDescription] ([GreenhouseStatusDesc_ID], [GreenhouseStatus_ID], [Description], [Status]) VALUES (1, 1, N'Greenhouse is available', 1)
GO
INSERT [dbo].[GreenhouseStatusDescription] ([GreenhouseStatusDesc_ID], [GreenhouseStatus_ID], [Description], [Status]) VALUES (2, 2, N'Greenhouse is in use', 1)
GO

INSERT [dbo].[OrderStatus] ([OrderStatus_ID], [OStatus], [Description], [Status]) VALUES (1, N'Placed', N'Order is placed, but not in progress yet. ', 1)
GO
INSERT [dbo].[OrderStatus] ([OrderStatus_ID], [OStatus], [Description], [Status]) VALUES (2, N'In Progress', N'Order is in progress.', 1)
GO
INSERT [dbo].[OrderStatus] ([OrderStatus_ID], [OStatus], [Description], [Status]) VALUES (3, N'Completed', N'Order is completed.', 1)
GO
INSERT [dbo].[TestResultStatus] ([TestResultStatus_ID], [TRStatus], [Description], [Status]) VALUES (1, N'Positive', N'The lab results came back positive. ', 1)
GO
INSERT [dbo].[TestResultStatus] ([TestResultStatus_ID], [TRStatus], [Description], [Status]) VALUES (2, N'Negative', N'The lab results came back negative', 1)
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UQ__Client__A9D10534F11E5CF9]    Script Date: 2022/07/31 12:50:33 ******/
ALTER TABLE [dbo].[Client] ADD UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UQ__Employee__A9D105346C0973E6]    Script Date: 2022/07/31 12:50:33 ******/
ALTER TABLE [dbo].[Employee] ADD UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON

GO
/****** Object:  Index [UQ__Supplier__A9D10534FB45A726]    Script Date: 2022/07/31 12:50:33 ******/
ALTER TABLE [dbo].[Supplier] ADD UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[ActiveLogin] ADD  DEFAULT (NULL) FOR [Start_Time]
GO
ALTER TABLE [dbo].[ActiveLogin] ADD  DEFAULT (NULL) FOR [End_Time]
GO
ALTER TABLE [dbo].[ActiveLogin] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[Backups] ADD  DEFAULT (NULL) FOR [Date]
GO
ALTER TABLE [dbo].[Backups] ADD  DEFAULT (NULL) FOR [Time]
GO
ALTER TABLE [dbo].[Backups] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[Block] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[Defect] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[EmployeeLogin] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[GreenhouseActivity] ADD  DEFAULT (NULL) FOR [Start_Date]
GO
ALTER TABLE [dbo].[GreenhouseActivity] ADD  DEFAULT (NULL) FOR [End_Date]
GO
ALTER TABLE [dbo].[GreenhouseActivity] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[GreenhouseTable] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[LabResultDefect] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[ProductionInventory] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[ProductionInventoryCost] ADD  DEFAULT ((0.00)) FOR [Cost]
GO
ALTER TABLE [dbo].[ProductionInventoryCost] ADD  DEFAULT (NULL) FOR [Date]
GO
ALTER TABLE [dbo].[ProductionInventoryCost] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[ProductionInventoryOrder] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[ProductionInventoryOrderStatus] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[ProductionInventoryWriteOff] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[Restores] ADD  DEFAULT (NULL) FOR [Date]
GO
ALTER TABLE [dbo].[Restores] ADD  DEFAULT (NULL) FOR [Time]
GO
ALTER TABLE [dbo].[Restores] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[Supplier] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[TransactionLog] ADD  DEFAULT ((1)) FOR [Status]
GO
ALTER TABLE [dbo].[AccessLevelArea]  WITH CHECK ADD FOREIGN KEY([AccessArea_ID])
REFERENCES [dbo].[AccessArea] ([AccessArea_ID])
GO
ALTER TABLE [dbo].[AccessLevelArea]  WITH CHECK ADD FOREIGN KEY([AccessLevel_ID])
REFERENCES [dbo].[AccessLevel] ([AccessLevel_ID])
GO
ALTER TABLE [dbo].[ActiveLogin]  WITH CHECK ADD FOREIGN KEY([EmpLogin_ID])
REFERENCES [dbo].[EmployeeLogin] ([EmpLogin_ID])
GO
ALTER TABLE [dbo].[ActivityEntry]  WITH CHECK ADD FOREIGN KEY([ActivityType_ID])
REFERENCES [dbo].[ActivityType] ([ActivityType_ID])
GO
ALTER TABLE [dbo].[ActivityEntry]  WITH CHECK ADD FOREIGN KEY([ActivityStatus_ID])
REFERENCES [dbo].[ActivityStatus] ([ActivityStatus_ID])
GO

ALTER TABLE [dbo].[Batch]  WITH CHECK ADD FOREIGN KEY([ClientOrder_ID])
REFERENCES [dbo].[ClientOrder] ([ClientOrder_ID])
GO
ALTER TABLE [dbo].[Batch]  WITH CHECK ADD FOREIGN KEY([Coldroom_ID])
REFERENCES [dbo].[Coldroom] ([Coldroom_ID])
GO
ALTER TABLE [dbo].[Batch]  WITH CHECK ADD FOREIGN KEY([Cultivar_ID])
REFERENCES [dbo].[Cultivar] ([Cultivar_ID])
GO

ALTER TABLE [dbo].[BatchSizeYields]  WITH CHECK ADD FOREIGN KEY([Batch_ID])
REFERENCES [dbo].[Batch] ([Batch_ID])
GO

ALTER TABLE [dbo].[BatchSizeYields]  WITH CHECK ADD FOREIGN KEY([CommditySize_ID])
REFERENCES [dbo].[CommoditySizes] ([CommoditySize_ID])
GO
ALTER TABLE [dbo].[Block]  WITH CHECK ADD FOREIGN KEY([Batch_ID])
REFERENCES [dbo].[Batch] ([Batch_ID])
GO
ALTER TABLE [dbo].[ClientOrder]  WITH CHECK ADD FOREIGN KEY([Client_ID])
REFERENCES [dbo].[Client] ([Client_ID])
GO
ALTER TABLE [dbo].[ClientOrder]  WITH CHECK ADD FOREIGN KEY([OrderStatus_ID])
REFERENCES [dbo].[OrderStatus] ([OrderStatus_ID])
GO
ALTER TABLE [dbo].[CommoditySizes]  WITH CHECK ADD FOREIGN KEY([Commodity_ID])
REFERENCES [dbo].[Commodity] ([Commodity_ID])
GO
ALTER TABLE [dbo].[Cultivar]  WITH CHECK ADD FOREIGN KEY([Commodity_ID])
REFERENCES [dbo].[Commodity] ([Commodity_ID])
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD FOREIGN KEY([AccessLevelArea_ID])
REFERENCES [dbo].[AccessLevelArea] ([AccessLevelArea_ID])
GO
ALTER TABLE [dbo].[Employee]  WITH CHECK ADD FOREIGN KEY([EmpType_ID])
REFERENCES [dbo].[EmployeeType] ([EmpType_ID])
GO
ALTER TABLE [dbo].[EmployeeActivity]  WITH CHECK ADD FOREIGN KEY([ActivityEntry_ID])
REFERENCES [dbo].[ActivityEntry] ([ActivityEntry_ID])
GO
ALTER TABLE [dbo].[EmployeeActivity]  WITH CHECK ADD FOREIGN KEY([Emp_ID])
REFERENCES [dbo].[Employee] ([Emp_ID])
GO
ALTER TABLE [dbo].[EmployeeLogin]  WITH CHECK ADD FOREIGN KEY([Emp_ID])
REFERENCES [dbo].[Employee] ([Emp_ID])
GO
ALTER TABLE [dbo].[Greenhouse]  WITH CHECK ADD FOREIGN KEY([GreenhouseStatusDesc_ID])
REFERENCES [dbo].[GreenhouseStatusDescription] ([GreenhouseStatusDesc_ID])
GO
ALTER TABLE [dbo].[GreenhouseActivity]  WITH CHECK ADD FOREIGN KEY([ActivityEntry_ID])
REFERENCES [dbo].[ActivityEntry] ([ActivityEntry_ID])
GO
ALTER TABLE [dbo].[GreenhouseActivity]  WITH CHECK ADD FOREIGN KEY([Greenhouse_ID])
REFERENCES [dbo].[Greenhouse] ([Greenhouse_ID])
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory]  WITH CHECK ADD FOREIGN KEY([Greenhouse_ID])
REFERENCES [dbo].[Greenhouse] ([Greenhouse_ID])
GO
ALTER TABLE [dbo].[GreenhouseProductionInventory]  WITH CHECK ADD FOREIGN KEY([ProductionInv_ID])
REFERENCES [dbo].[ProductionInventory] ([ProductionInv_ID])
GO
ALTER TABLE [dbo].[GreenhouseStatusDescription]  WITH CHECK ADD FOREIGN KEY([GreenhouseStatus_ID])
REFERENCES [dbo].[GreenhouseStatus] ([GreenhouseStatus_ID])
GO
ALTER TABLE [dbo].[GreenhouseTable]  WITH CHECK ADD FOREIGN KEY([Block_ID])
REFERENCES [dbo].[Block] ([Block_ID])
GO
ALTER TABLE [dbo].[GreenhouseTable]  WITH CHECK ADD FOREIGN KEY([Greenhouse_ID])
REFERENCES [dbo].[Greenhouse] ([Greenhouse_ID])
GO
ALTER TABLE [dbo].[LabResultDefect]  WITH CHECK ADD FOREIGN KEY([Defect_ID])
REFERENCES [dbo].[Defect] ([Defect_ID])
GO
ALTER TABLE [dbo].[LabResultDefect]  WITH CHECK ADD FOREIGN KEY([LabResults_ID])
REFERENCES [dbo].[LabResults] ([LabResults_ID])
GO
ALTER TABLE [dbo].[LabResults]  WITH CHECK ADD FOREIGN KEY([Batch_ID])
REFERENCES [dbo].[Batch] ([Batch_ID])
GO
ALTER TABLE [dbo].[LabResults]  WITH CHECK ADD FOREIGN KEY([TestResultStatus_ID])
REFERENCES [dbo].[TestResultStatus] ([TestResultStatus_ID])
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD FOREIGN KEY([ProductionInvOrder_ID])
REFERENCES [dbo].[ProductionInventoryOrder] ([ProductionInvOrder_ID])
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD FOREIGN KEY([ProductionInvCost_ID])
REFERENCES [dbo].[ProductionInventoryCost] ([ProductionInvCost_ID])
GO
ALTER TABLE [dbo].[ProductionInventory]  WITH CHECK ADD FOREIGN KEY([ProductionInventoryWriteOff_ID])
REFERENCES [dbo].[ProductionInventoryWriteOff] ([ProductionInventoryWriteOff_ID])
GO
ALTER TABLE [dbo].[ProductionInventoryOrder]  WITH CHECK ADD FOREIGN KEY([ProdctionInvOrderStatus_ID])
REFERENCES [dbo].[ProductionInventoryOrderStatus] ([ProductionInvOrderStatus_ID])
GO
ALTER TABLE [dbo].[ProductionInventoryOrder]  WITH CHECK ADD FOREIGN KEY([Supplier_ID])
REFERENCES [dbo].[Supplier] ([Supplier_ID])
GO
ALTER TABLE [dbo].[Restores]  WITH CHECK ADD FOREIGN KEY([ActiveLogin_ID])
REFERENCES [dbo].[ActiveLogin] ([ActiveLogin_ID])
GO
ALTER TABLE [dbo].[TransactionLog]  WITH CHECK ADD FOREIGN KEY([Backup_ID])
REFERENCES [dbo].[Backups] ([Backup_ID])
GO
ALTER TABLE [dbo].[TransactionLog]  WITH CHECK ADD FOREIGN KEY([Restore_ID])
REFERENCES [dbo].[Restores] ([Restore_ID])
GO
USE [master]
GO
ALTER DATABASE [SeedTrail] SET  READ_WRITE 
GO
