USE [SeedTrail]
GO

INSERT [dbo].[UserRoles] ([Name])
VALUES (N'Manager'), (N'Supervisor'), (N'General'), (N'Owner')
GO

INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Foliar & Liquid', N'Foliar & Liquid Inventory', (1))
INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Greenhouse Fertilizer', N'Greenhouse Fertilizer Stock', (1))
INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Greenhouse Packaging', N'Greenhouse Packaging Inventory', (1))
INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Granular', N'Granular', (0))
INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Irrigation Water & Cleaning', N'Irrigatrion Water & Cleaning Supplies', (1))
INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Greenhouse Chemicals', N'Greenhouse Chemical', (1))
INSERT [dbo].[ProductInventoryType] ([Name], [Description], [Status]) VALUES (N'Lettuce Seeds', N'Lettuce Seeds Stock', (1))
GO

INSERT [dbo].[ProductionInventoryCost] ([Cost], [Date], [Status]) VALUES (0.0000, CAST(N'2022-08-16 00:00:00.000' AS DateTime), (1))
GO

INSERT [dbo].[ProductionInventoryWriteOff] ([Name], [Description], [Quantity], [Status]) VALUES (N'Torn Bags', N'Greenhouse Packaging bags torn', 6, 1)
GO

INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'L', N'Liter')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'kg', N'Kilogram')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'bags', N'bags')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'g', N'Gram')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'mg', N'Miligram')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'seeds', N'individual seeds')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'tins', N'tins')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'rolls', N'rolls')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'Bundle', N'bundle')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'boxes', N'boxes')
INSERT [dbo].[Metric] ([Name], [Description]) VALUES (N'box stickers', N'box stickers')
GO

INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'ORGANOCELL', N'ORGANOCELL', 400, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'RHIZOVATOR', N'NURHIZOVATORLL', 35, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'X PLODE', N'X PLODE', 0, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'TWILIGHT', N'TWILIGHT', 20, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'BRILLIANT', N'BRILLIANT', 60, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Bacstim', N'NULBacstim', 10, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Codafol Maximus', N'Codafol Maximus', 30, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Codasting', N'Codasting', 2, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Codamin 150', N'Codamin 150', 30, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Biopro', N'Biopro', 30, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Atom-8 FM-1', N'Atom-8 FM-1', 20, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Atom-8 SM-10', N'Atom-8 SM-10', 40, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Goemar ', N'Goemar ', 20, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 1, N'Tank Cal', N'Tank Cal', 20, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 2, N'CALCIUM NITRATE', N'CALCIUM NITRATE', 50, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 2, N'MICREL FE 600', N'MICREL FE 600', 10, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 2, N'Basacote Plus', N'Basacote Plus', 25, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 3, N'PURPLE', N'PURPLE', 400, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 3, N'WHITE', N'WHITE', 600, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 3, N'GREEN', N'GREEN', 1200, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 3, N'YELLOW', N'YELLOW', 2000, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 5, N'Aquacure', N'Aquacure', 20, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 5, N'Black Dain', N'Black Dain', 5, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 5, N'Bleach', N'Bleach', 7, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 6, N'PENNFLUID', N'PENNFLUID', 8, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 6, N'HIT', N'HIT', 5, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 6, N'TUTOR', N'TUTOR', 3, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 7, N'Faustina', N'Faustina', 6, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 7, N'Crunchita', N'Crunchita', 2, 1, (1), 0)
INSERT [dbo].[ProductionInventory]
([ProductionInvCost_ID], [ProductionInventoryWriteOff_ID], [ProductInventoryType_ID],
[Name], [Description], [Quantity], [Metric_ID], [Status], [Threshold])
VALUES (1, 1, 7, N'Stefano', N'Stefano', 1, 1, (1), 0)
GO

INSERT [dbo].[GreenhouseStatus] ([GHStatus], [Description], [Status]) VALUES (N'Active', N'Greenhouse is in use.', (1))
INSERT [dbo].[GreenhouseStatus] ([GHStatus], [Description], [Status]) VALUES (N'Inactive', N'Greenhouse is not in use.', (1))
GO

INSERT [dbo].[GreenhouseStatusDescription] ([GreenhouseStatus_ID], [Description], [Status]) VALUES (1, N'Greenhouse is full', (1))
INSERT [dbo].[GreenhouseStatusDescription] ([GreenhouseStatus_ID], [Description], [Status]) VALUES (1, N'Greenhouse is empty', (1))
INSERT [dbo].[GreenhouseStatusDescription] ([GreenhouseStatus_ID], [Description], [Status]) VALUES (2, N'Under maintainance', (1))
GO

INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (1, 1, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (2, 2, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (1, 3, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (1, 4, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (2, 5, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (2, 6, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (1, 7, (1))
INSERT [dbo].[Greenhouse] ([GreenhouseStatusDesc_ID], [Greenhouse_Number], [Status]) VALUES (1, 8, (1))
GO

INSERT [dbo].[ProductionInventoryOrderStatus] ([PIStatus], [Description], [Status]) VALUES (N'Order Placed', N'Order is placed', (1))
INSERT [dbo].[ProductionInventoryOrderStatus] ([PIStatus], [Description], [Status]) VALUES (N'Order Out', N'Order is placed and on it''s way to be delivered', (1))
INSERT [dbo].[ProductionInventoryOrderStatus] ([PIStatus], [Description], [Status]) VALUES (N'Delivered', N'Order is delivered', (1))
GO

INSERT [dbo].[Supplier]
([Name], [Description], [Contact_Nr], [Email], [Status])
VALUES (
N'Omnia',
N'Kunsmis',
N'0732499200',
N'Jandre.bekker@omnia.co.za', (1))
INSERT [dbo].[Supplier]
([Name], [Description], [Contact_Nr], [Email], [Status])
VALUES (
N'Drytech Aerogels',
N'Kunsmis',
N'0825862811',
N'willie@dry-tech.co.za', (1))
INSERT [dbo].[Supplier]
([Name], [Description], [Contact_Nr], [Email], [Status])
VALUES (
N'ICT Loskop',
N'Kunsmis',
N'0823760331',
N'clinton@loskopict.co.za', (1))
GO

INSERT [dbo].[ProductionInventoryOrder] ([Supplier_ID], [ProdctionInvOrderStatus_ID], [Status]) VALUES (1, 1, (1))
INSERT [dbo].[ProductionInventoryOrder] ([Supplier_ID], [ProdctionInvOrderStatus_ID], [Status]) VALUES (2, 1, (1))
INSERT [dbo].[ProductionInventoryOrder] ([Supplier_ID], [ProdctionInvOrderStatus_ID], [Status]) VALUES (3, 1, (1))
GO

INSERT [dbo].[ProductionInventoryOrderDetails] ([Quantity], [Status], [ProductionInvId], [ProductionInvOrder_ID], [ProductionInventories_ID]) VALUES (25, (1), 15, 1, 15)
INSERT [dbo].[ProductionInventoryOrderDetails] ([Quantity], [Status], [ProductionInvId], [ProductionInvOrder_ID], [ProductionInventories_ID]) VALUES (100, (1), 17, 2, 17)
INSERT [dbo].[ProductionInventoryOrderDetails] ([Quantity], [Status], [ProductionInvId], [ProductionInvOrder_ID], [ProductionInventories_ID]) VALUES (70, (1), 22, 3, 22)
GO

INSERT [dbo].[AccessArea] ([Description], [Title], [Status]) VALUES (N'Reports', N'Reports', (1))
INSERT [dbo].[AccessArea] ([Description], [Title], [Status]) VALUES (N'CRUD''s', N'CRUD''s', (1))
INSERT [dbo].[AccessArea] ([Description], [Title], [Status]) VALUES (N'Schedule', N'Schedule', (1))
INSERT [dbo].[AccessArea] ([Description], [Title], [Status]) VALUES (N'Capture Quantities', N'Quantities', (1))
GO

INSERT [dbo].[AccessLevel] ([Description], [Access_Level], [Status]) VALUES (N'Manager', N'Highest Access Level', (1))
INSERT [dbo].[AccessLevel] ([Description], [Access_Level], [Status]) VALUES (N'Supervisor', N'Middle Access Level', (1))
INSERT [dbo].[AccessLevel] ([Description], [Access_Level], [Status]) VALUES (N'Owner', N'Lowest Access Level', (1))
INSERT [dbo].[AccessLevel] ([Description], [Access_Level], [Status]) VALUES (N'General', N'Limited/No Access', (1))
GO

INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (1, 1, N'Manager Reports', (1))
INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (2, 1, N'Manager CRUD', (1))
INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (3, 1, N'Manager Schedule', (1))
INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (4, 1, N'Manager Quantities', (1))
INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (3, 2, N'SuperVisor Schedule', (1))
INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (4, 2, N'Supervisor Quantities', (1))
INSERT [dbo].[AccessLevelArea] ([AccessArea_ID], [AccessLevel_ID], [Description], [Status]) VALUES (1, 3, N'Owner Reports', (1))
GO

INSERT [dbo].[EmployeeType] ([Type], [Description], [Status]) VALUES (N'Greenhouse Manager', N'Manages the greenhouses and has the most authority over the system.', (1))
INSERT [dbo].[EmployeeType] ([Type], [Description], [Status]) VALUES (N'Supervisors', N'Supervises the activities and task in the greenhosues.', (1))
INSERT [dbo].[EmployeeType] ([Type], [Description], [Status]) VALUES (N'Owner', N'Owner of the company, but does not have authority in the functionality of the system ', (1))
INSERT [dbo].[EmployeeType] ([Type], [Description], [Status]) VALUES (N'General', N'Limited/No access', (1))
GO

INSERT [dbo].[Employee]
([AccessLevelArea_ID], [EmpType_ID],
[Name], [Surname], [Contact_Nr], [National_ID], [Email], [Start_Date], [End_Date], [Status])
VALUES (1, 1, N'Werner', N'Schutte', N'0646849232', N'9506214907098', N'werner@legitmail.com', NULL, NULL, (1))
GO

INSERT [dbo].[TestResultStatus] ([TRStatus], [Description], [Status]) VALUES (N'Positive', N'The lab results came back positive', (1))
INSERT [dbo].[TestResultStatus] ([TRStatus], [Description], [Status]) VALUES (N'Negative', N'The lab results came back negative', (1))
GO

INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Du Toit Groente', N'08622899282', N'dutoit.groente@gmail.com', N'23 Steely', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt IHF', N'0638928761', N'ihf23@ihf.co.za', N'14 Nelson Mandela', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Simba', N'0648930927', N'agric@simba.co.za', N'7 Daventry', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'FPD', N'0836820476', N'fpd@gmail.com', N'98 Lynnwood', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt GV', N'0618927355', N'44 Impala', N'44 Impala', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt JP', N'0872883928', N'jp33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt GC', N'0762538282', N'gc33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt SR', N'0862910843', N'sr33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'GWK', N'0728937202', N'growwithknowledge@gmail.com', N'77 Seven', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'RSA Raad', N'0836274857', N'rsa.raad@gmail.com', N'18 Delphy', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'McCain', N'0810384632', N'thinkagain@gmail.com', N'none', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt VZVM', N'0658201923', N'vzvm33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt TK', N'0745362516', N'tk33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'AI3 Boerdery', N'0632673849', N'ekhouvanplaasbrah3@gmail.com', N'none', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Seed Potato Co-op', N'0862937462', N'cooperativeseed38@gmail.com', N'none', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt CE ', N'0717283041', N'ce33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Kli�nt MOG ', N'0729172637', N'mog33@westside.com', N'33 West Side', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Ortus Bdy', N'+27276293043', N'none@yahoo.com', N'none', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'Johan Holsthauzen', N'0627381923', N'none@gmail.com', N'none', (1))
INSERT [dbo].[Client] ([Name], [Contract_Nr], [Email], [Address], [Status]) VALUES (N'PSP', N'+27647378392', N'pspserver@gmail.com', N'4 Lydenburg', (1))
GO

INSERT [dbo].[OrderStatus] ([OStatus], [Description], [Status]) VALUES (N'Placed', N'Order is placed, but not in progress yet. ', (1))
INSERT [dbo].[OrderStatus] ([OStatus], [Description], [Status]) VALUES (N'In Progress', N'Order is in progress.', (1))
INSERT [dbo].[OrderStatus] ([OStatus], [Description], [Status]) VALUES (N'Completed', N'Order is completed.', (1))
GO

INSERT [dbo].[ClientOrder]
([OrderStatus_ID], [Client_ID], [ClientName], [Date_Placed], [Date_Required], [Description], [Status])
VALUES (3, 1, N'Du Toit Groente', CAST(N'2021-12-01 00:00:00.000' AS DateTime), CAST(N'2022-06-24 00:00:00.000' AS DateTime), N'(Completed) Du Toit Groente | 12 crates BP1', (1))
INSERT [dbo].[ClientOrder]
([OrderStatus_ID], [Client_ID], [ClientName], [Date_Placed], [Date_Required], [Description], [Status])
VALUES (2, 20, N'PSP',  CAST(N'2021-02-17 00:00:00.000' AS DateTime), CAST(N'2022-11-27 00:00:00.000' AS DateTime), N'(In Progress) PSP | 6 BP1, 6 Amethyst', (1))
INSERT [dbo].[ClientOrder]
([OrderStatus_ID], [Client_ID], [ClientName], [Date_Placed], [Date_Required], [Description], [Status])
VALUES (1, 1, N'Du Toit Groente', CAST(N'2022-09-18 00:00:00.000' AS DateTime), CAST(N'2023-02-18 00:00:00.000' AS DateTime), N'(Placed) Du Toit Groente | 6 Amigo', (1))
INSERT [dbo].[ClientOrder]
([OrderStatus_ID], [Client_ID], [ClientName], [Date_Placed], [Date_Required], [Description], [Status])
VALUES (1, 2, N'Kli�nt IHF', CAST(N'2022-09-26 00:00:00.000' AS DateTime), CAST(N'2023-01-13 00:00:00.000' AS DateTime), N'(Placed) Kli�nt IHF | 6 COS(harder)-Rafael', (1))
GO

INSERT [dbo].[Coldroom] ([Name], [Description], [Status]) VALUES (N'Coldroom 1', N'Coldroom 1', (1))
GO

INSERT [dbo].[Commodity] ([Name], [Description], [Status]) VALUES (N'Potato Seeds', N'Potato Seeds', (1))
INSERT [dbo].[Commodity] ([Name], [Description], [Status]) VALUES (N'Lettuce', N'Lettuce', (1))
GO

INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Amethyst', N'Amethyst', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Amigo', N'Amigo', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Apache', N'Apache', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Argos', N'Argos', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Almera', N'Almera', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Avalanche', N'Avalanche', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'BP1', N'BP1', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'BFP', N'BFP', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Calibra', N'Calibra', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Caruso', N'Caruso', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Cimega', N'Cimega', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Chellah', N'Chellah', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Colorado Rose', N'Colorado Rose', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Dakota', N'Dakota', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'DANEPSO', N'DANEPSO', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Daisy', N'Daisy', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Diamant', N'Diamant', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Diva ca99-1', N'Diva ca99-1', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'El Mundo', N'El Mundo', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Eos', N'Eos', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Eryn', N'Eryn', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Fasan', N'Fasan', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Fianna', N'Fianna', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FLx26', N'FLx26', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FL 2006', N'FL 2006', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FL 2221', N'FL 2221', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FL 2018', N'FL 2018', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FL 2377', N'FL 2377', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FL 2387', N'FL 2387', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'FL 2400', N'FL 2400', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Georgina', N'Georgina', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Harmony', N'Harmony', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'166 HVN bute', N'166 HVN bute', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Hertha', N'Hertha', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Hermes', N'Hermes', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Horizo', N'Horizo', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Innovator', N'Innovator', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Jasper', N'jasper', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Jelly', N'Jelly', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Leonata', N'Leonata', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Labadia', N'Labadia', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Lady Nal', N'Lady Nal', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Lanorma', N'lanorma', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Magnum', N'Magnum', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Markies', N'markies', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Marvel(SM01)', N'Marvel(SM01)', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Mnandi', N'Mnandi', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Mondeo', N'Mondeo', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Mondial', N'Mondial', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'MonloghtCrop', N'MonloghtCrop', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Paramount', N'Paramount', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'PDell', N'PDell', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Red Eye', N'Red Eye', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Royal', N'Royal', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Rumba', N'Rumba', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Santano', N'Santano', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Shepody', N'Shepody', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Triomphe', N'Triomphe', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'UTD', N'UTD', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Valor', N'Valor', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'VDP ', N'VDP', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Umatilla', N'Umatilla', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Zylem', N'Zylem', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'441', N'441', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'Arno-MC2', N'Arno-MC2', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'98F1641', N'98F1641', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Butter-Faustina', N'Butter-Faustina', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Butter-Arleti', N'Butter-Arleti', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'COS(harder)-Rafael', N'COS(harder)-Rafae', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'COS(harder)-Raulph', N'COS(harder)-Raulph', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Butterfly COS(harder)-Auvona', N'Butterfly COS(harder)-Auvona', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Butterfly COS(harder)-Tacedoma', N'Butterfly COS(harder)-Tacedoma', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Green Oak- Kireve', N'Green Oak- Kireve', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Green Frilly- Mutligreen 3', N'Green Frilly- Mutligreen 3', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Salanova Green Butter- Erasmus', N'Salanova Green Butter- Erasmus', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Red Frilly-Stefano', N'Red Frilly-Stefano', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Salanova Red Butter-Gaugin', N'Salanova Red Butter-Gaugin', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Raddichio - Giove', N'Raddichio - Giove', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Red COS- 41-950', N'Red COS- 41-950', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Crunchita (harder)-Crunchita', N'Crunchita (harder)-Crunchita', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (2, N'Crunchita (harder)-Gourmandine', N'Crunchita (harder)-Gourmandine', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'TestLettuce', N'Testy', 1)
INSERT [dbo].[Cultivar] ([Commodity_ID], [Name], [Description], [Status]) VALUES (1, N'F/L 2108', N'F/L 2108', 1)
GO

INSERT [dbo].[ActivityStatus] ([AStatus], [Description], [Status]) VALUES (N'Not Started', N'Activity haven''t started yet', 1)
INSERT [dbo].[ActivityStatus] ([AStatus], [Description], [Status]) VALUES (N'In progress', N'Activity is in progress', 1)
INSERT [dbo].[ActivityStatus] ([AStatus], [Description], [Status]) VALUES (N'Complete', N'Activity is Complete', 1)
GO

INSERT [dbo].[ActivityType] ([Description], [Type], [Status]) VALUES (N'Plant', N'Plant', 1)
INSERT [dbo].[ActivityType] ([Description], [Type], [Status]) VALUES (N'Harvest', N'Harvest', 1)
INSERT [dbo].[ActivityType] ([Description], [Type], [Status]) VALUES (N'Prepare', N'Prepare', 1)
INSERT [dbo].[ActivityType] ([Description], [Type], [Status]) VALUES (N'Insecticide', N'Insecticide', 1)
INSERT [dbo].[ActivityType] ([Description], [Type], [Status]) VALUES (N'Pesticide', N'Pesticide', 1)
INSERT [dbo].[ActivityType] ([Description], [Type], [Status]) VALUES (N'Foliar', N'Foliar', 1)
GO

INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 3, N'Harvest', N'Harvest', 1, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 3, N'Clean and Maintenance', N'Clean and Maintenance', 2, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 1, N'Pack Crates', N'Pack Crates', 3, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 1, N'Fill up Planting Medium', N'Fill up planting medium', 4, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 1, N'Drench', N'Drench', 5, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 1, N'Plant', N'Plant', 6, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 98, N'Grow', N'Grow', 7, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 5, N'Switch off water', N'Switch off water', 8, 1)
INSERT [dbo].[ActivityEntry] ([ActivityType_ID], [ActivityStatus_ID], [Duration], [Description], [Title], [Sequence_Order], [Status])
VALUES (3, 1, 5, N'Pull halmes', N'Pull halmes', 9, 1)
GO

INSERT [dbo].[GreenhouseActivity] ([Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 1, CAST(N'2022-06-22 00:00:00.000' AS DateTime), NULL, 1)
INSERT [dbo].[GreenhouseActivity]
([Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 1, NULL, NULL, 0)
INSERT [dbo].[GreenhouseActivity]
([Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 4, NULL, CAST(N'2022-09-15 00:00:00.000' AS DateTime), 0)
INSERT [dbo].[GreenhouseActivity]
([Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 1, NULL, NULL, 0)
INSERT [dbo].[GreenhouseActivity]
([Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 3, NULL, CAST(N'2022-09-24 00:00:00.000' AS DateTime), 0)
INSERT [dbo].[GreenhouseActivity]
([Greenhouse_ID], [ActivityEntry_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 1, CAST(N'2022-09-28 00:00:00.000' AS DateTime), NULL, 1)
GO

INSERT [dbo].[Defect] ([Defect], [Description],[Image],[Status]) VALUES (N'Worms', N'bad',N'bad', 1)
INSERT [dbo].[Defect] ([Defect], [Description],[Image],[Status]) VALUES (N'Early Blight', N'Affects foliage, tuber infections can also occur',N'bad', 1)
INSERT [dbo].[Defect] ([Defect], [Description],[Image],[Status]) VALUES (N'Dry Rot', N'Dry and rotten',N'bad', 1)
GO

INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (1, N'<2gr', N'Smallest', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (1, N'2-5gr', N'Small', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (1, N'5-10gr', N'Medium', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (1, N'10-30gr', N'Large', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (1, N'>30gr', N'Largest', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (2, N'<150gr', N'Small', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (2, N'150-200gr', N'Average', 1)
INSERT [dbo].[CommoditySizes] ([Commodity_ID], [Size], [Description], [Status]) VALUES (2, N'>300gr', N'Large', 1)
GO

INSERT [dbo].[Batch]
([Coldroom_ID], [ClientOrder_ID], [ClientName], [CultivarName], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date],
[Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status])
VALUES (1, 1, N'Du Toit Groente', N'BP1', 7, N'DTG536279', CAST(N'2021-12-25 00:00:00.000' AS DateTime), 150, CAST(N'2022-06-20 00:00:00.000' AS DateTime), 146, 3, 1, CAST(N'2022-06-21 00:00:00.000' AS DateTime), CAST(N'2022-06-23 00:00:00.000' AS DateTime), 12, CAST(0.90 AS Decimal(10, 2)), (1))
INSERT [dbo].[Batch]
([Coldroom_ID], [ClientOrder_ID], [ClientName], [CultivarName], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date],
[Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status])
VALUES (1, 2, N'PSP', N'BP1', 7, N'PSP362782', CAST(N'2021-02-20 00:00:00.000' AS DateTime), 75, CAST(N'2022-10-27 00:00:00.000' AS DateTime), 73, 1, 1, CAST(N'2022-10-29 00:00:00.000' AS DateTime), CAST(N'2022-11-10 00:00:00.000' AS DateTime), 6, CAST(0.98 AS Decimal(10, 2)), (1))
INSERT [dbo].[Batch]
([Coldroom_ID], [ClientOrder_ID], [ClientName], [CultivarName], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date],
[Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status])
VALUES (NULL, 2, N'PSP', N'Amethyst', 1, N'PSP362783', NULL, 0, NULL, 0, 0, 0, NULL, NULL, 0, CAST(0.00 AS Decimal(10, 2)), (1))
INSERT [dbo].[Batch]
([Coldroom_ID], [ClientOrder_ID], [ClientName], [CultivarName], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date],
[Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status])
VALUES (NULL, 3, N'Du Toit Groente', N'Amigo', 2, N'DTG536280', NULL, 0, NULL , 0, 0, 0, NULL, NULL, 0, CAST(0.00 AS Decimal(10, 2)), (1))
INSERT [dbo].[Batch]
([Coldroom_ID], [ClientOrder_ID], [ClientName], [CultivarName], [Cultivar_ID], [RegistrationNr], [Plant_Date], [Total_Planted], [Harvest_Date],
[Total_Yield], [Scrap], [Sample], [Coldroom_Date_In], [Coldroom_Date_Out], [Total_Bags], [Avg_Yield], [Status])
VALUES (NULL, 4, N'Kli�nt IHF', N'COS(harder)-Rafael', 69, N'KIL536278', NULL, 0, NULL, 0, 0, 0, NULL, NULL, 0, CAST(0.00 AS Decimal(10, 2)), (1))
GO

INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (1, 1, N'Size yield for Du Toit Groente''s Eos batch', 16, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (1, 2, N'Size yield for Du Toit Groente''s Eos batch', 30, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (1, 3, N'Size yield for Du Toit Groente''s Eos batch', 60, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (1, 4, N'Size yield for Du Toit Groente''s Eos batch', 37, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (1, 5, N'Size yield for Du Toit Groente''s Eos batch', 3, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (2, 2, N'Size yield for PSP''s BP1 batch', 3, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (2, 3, N'Size yield for PSP''s BP1 batch', 10, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (2, 4, N'Size yield for PSP''s BP1 batch', 53, (1))
INSERT [dbo].[BatchSizeYields] ([Batch_ID], [CommditySize_ID], [Description], [Yield], [Status])
VALUES (2, 5, N'Size yield for PSP''s BP1 batch', 7, (1))
GO

INSERT [dbo].[EmployeeActivity] ([GreenhouseActivity_ID], [Emp_ID], [Start_Date], [End_Date], [Status])
VALUES (1, 1, CAST(N'2022-06-22 00:00:00.000' AS DateTime), NULL, 1)
GO